import React, { Component } from 'react'
import { Image, Text, View, TouchableOpacity, FlatList, ToastAndroid } from 'react-native'
// import { Ionicons, SimpleLineIcons, MaterialCommunityIcons } from '@expo/vector-icons'
import { BASEURLIMAGE } from '../util/AppConstants';

export default class DynamicComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            showIcon: false,
            marginLeft: 0
        }
    }
    renderCats(rowData) {
        return (
            <DynamicComponent nav={this.props.nav} marginLeft={this.props.marginLeft + 8} data={rowData} onItemClick={() => {
                this.props.onItemClick(rowData)
            }} />

        );
    }
    render() {
        return (
            <View style={{ backgroundColor: this.props.marginLeft > 10 ? 'white' : '#32CCFE' }}>
                <TouchableOpacity
                    style={{
                        borderColor: 'black',
                        borderWidth: 1,
                        height: 50,
                        alignItems: 'flex-start',
                        paddingLeft: 8,
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        flexDirection: 'row',
                        borderBottomWidth: 0,

                    }}
                    onPress={() => {
                        if (this.props.data.item.childIds.length > 0) {
                            this.setState({ data: this.props.data.item.childIds })
                            this.setState({ showIcon: !this.state.showIcon })

                        } else {
                            this.props.nav.navigate('ProductView', { id: this.props.data.item._id })
                            this.props.nav.closeDrawer()

                        }

                        // this.props.onItemClick(this.props.data)
                    }}
                >
                    <View style={{ flexDirection: 'row' }}>
                        <Image resizeMode={'stretch'}
                            source={{
                                uri: this.props.data.item.imagePath != null ?
                                    BASEURLIMAGE + 'image/getImage?name=' + this.props.data.item.imagePath :
                                    ''
                            }}
                            style={{
                                width: 24, height: 24, borderRadius: 10,


                            }}></Image>
                        <Text style={{
                            color: this.props.marginLeft > 10 ? 'black' : 'white', fontSize: 13,
                            marginLeft: this.props.marginLeft, textAlign: 'center', alignSelf: 'center'
                        }}>{this.props.data.item.categoryName}</Text>
                    </View>

                    {(this.props.data.item.childIds.length > 0 &&
                        <MaterialCommunityIcons name={this.state.showIcon ? 'minus-box' : 'plus-box'} size={20} style={{
                            marginRight: 8
                        }} color="#000000" />
                    )}
                </TouchableOpacity>
                {(this.state.showIcon &&
                    <FlatList
                        bounces={false}
                        removeClippedSubviews={false}
                        data={this.state.data}
                        renderItem={responsedata => this.renderCats(responsedata)}
                    />
                )}

            </View>
        )
    }
}

/* {
                   this.state.data.length > 0
                       ?
                       this.state.data.map((response, i) => (
                           <DynamicComponent data = {response}/>
                       ))
                       : null
               } */

 // <Text>ere we </Text>
                    // <FlatList
                    //     data={this.state.data}
                    //     renderItem={({ item }) => (

                    //             <Text>kuch bhi</Text>

                    //     )}
                    // />
