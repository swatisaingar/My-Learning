import React, { Component } from 'react';
import { Modal, Image, View } from 'react-native';
import images from '../util/img';
export default Loader = props => {
	return (
		<Modal visible={props.show} transparent={true}>
						{/* <View style={{ justifyContent: 'center', alignItems: 'center', flex: 1, backgroundColor: 'rgba(0,0,0,0.35)' }}> */}

			<View style={{ justifyContent: 'center', alignItems: 'center', flex: 1, }}>
				<Image source={images.loader} style={{ height: 50, width: 50 }}></Image>
			</View>
		</Modal>
	);
};
