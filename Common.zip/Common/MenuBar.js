import React, { Component } from 'react';
import { Text, View, StyleSheet, Dimensions, Image, TouchableOpacity, Alert, Linking } from 'react-native';
import { COLORS, SIZE } from '../constants/styles';

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
//  import { LinearGradient } from 'react-native-linear-gradient';
import LinearGradient from 'react-native-linear-gradient';
import { DrawerActions } from 'react-navigation-drawer';
import { connect } from 'react-redux';
import images from '../util/img';
import NavigationService from '../Services/NavigationService';

class TopBar extends Component {
	constructor(props) {
		super(props)
		this.state = {
			cartCount: 0
		}
	}
	componentDidUpdate(prevProps) {

		if (prevProps.cart != this.props.cart) {
			if (this.props.cart.cartItems != undefined) {
				if (this.props.cart.cartItems.data != undefined) {

					this.setState({ cartCount: this.props.cart.cartItems.data.length })
				}
			}
		}

	}
	async componentDidMount() {


	}
	_askForPermissions = async () => {
		await Permissions.askAsync(Permissions.AUDIO_RECORDING);
		await Permissions.askAsync(Permissions.CAMERA_ROLL);
		// this.setState({
		//   haveRecordingPermissions: response.status === 'granted',
		//   hasStoragePermission: response2.status === 'granted'
		// });
	};
	render() {
		const { children, alignMent } = this.props;
		return (
			<View style={styles.container}>
				<View style={styles.innerContainer}>
					<View style={{ position: 'absolute', left: 10 }}>
						<TouchableOpacity
							onPress={() => {
								NavigationService.openDrawerr();
								//this.props.navigation.openDrawer();
								//alert('drawer');
							}}
						>
							<Image style={{ width: 30, height: 20 }} source={images.menu} />
						</TouchableOpacity>
					</View>

					<TouchableOpacity onPress={() => {
						this.props.navigation.navigate('Home')
					}} activeOpacity={0.75}>
						<Text style={styles.textColor}>
							<Image style={styles.imageThumbnail} source={images.logo} />
						</Text>
					</TouchableOpacity>

				</View>
				<LinearGradient
					colors={[`${COLORS.MAINCOLOR.BLUE}`, '#000', `${COLORS.MAINCOLOR.BLUE}`]}
					start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
					style={{
						position: 'absolute',
						left: 0,
						right: 0,
						top: 70,
						height: 6,

					}}
				>
					{/* <Text>
    Sign in with Facebook
  </Text> */}
				</LinearGradient>
				{children}
			</View >
		);
	}
}
const mapStateToProps = state => ({
	cart: state.category,
	user: state.user
});

const mapDispatchToProps = {

};

export default connect(mapStateToProps, mapDispatchToProps)(TopBar);
const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: `${COLORS.WHITE.WHITE}`,

		marginBottom: 10,


	},
	innerContainer: {
		flexDirection: 'row',
		paddingBottom: 5,
		width: wp('100%'),
		alignItems: 'center',
		justifyContent: 'center',

		height: 70
	},
	textColor: {
		color: '#000',
		fontWeight: 'bold',
		textAlign: 'center',
		marginTop: 10,
		marginBottom: 5,
		fontSize: SIZE.LARGE,
		borderRightColor: `${COLORS.MAINCOLOR.BLUE}`,
		borderRightWidth: 5,
		borderRadius: 5,
		borderBottomColor: `${COLORS.MAINCOLOR.BLUE}`,
		borderBottomWidth: 4,
		// paddingTop: 20,
		paddingBottom: 6,
		width: wp('30%'),
		height: 58,
		padding: 0
	},
	searchIcon: {
		justifyContent: 'center',
		alignItems: 'center'
	},
	rightIcons: {
		justifyContent: 'center',
		alignItems: 'center',
		marginRight: 5
	},
	imageThumbnail: {
		height: hp('5%'),
		width: wp('50%')
	}
});
