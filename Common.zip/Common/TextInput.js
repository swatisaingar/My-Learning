import React from "react";
import { TextInput } from "react-native";

export default function TextField(props) {
  const {
    style,
    onChangeText,
    value,
    inlineImageLeft,
    inlineImagePadding,
    placeholder,
    textContentType,
    secureTextEntry,
    placeholderStyle,
    name,
    onPress,

  } = props;
  return (
    <TextInput
      style={style}
      onChangeText={onChangeText}
      value={value}
      name={name}
      maxLength={50}
      inlineImageLeft={inlineImageLeft}
      inlineImagePadding={inlineImagePadding}
      placeholder={placeholder}
      // placeholderTextColor="#000"
      textContentType={textContentType}
      secureTextEntry={secureTextEntry}
      placeholderStyle={placeholderStyle}
      onTouchStart={()=>  onPress}
      onKeyPress={keyPress => {
        onPress
      }}
    />
  );
}
