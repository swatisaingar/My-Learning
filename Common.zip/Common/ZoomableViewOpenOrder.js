import React, { Component } from 'react'
import {
    TouchableHighlight,
    Dimensions,
    Animated,
    Modal,
    Alert,
    Image,
    View,
    ScrollView,
    Text,
    TextInput,
    TouchableOpacity,
    SafeAreaView,
    FlatList,
    StyleSheet,
    ActivityIndicator
} from 'react-native'
import ImageViewer from 'react-native-image-zoom-viewer';
import { BASEURLIMAGE } from '../util/AppConstants';
export default class ZoomableViewOpenOrder extends Component {
    constructor(props) {
        super(props)
        this.state = {
            animating: true,
            imagesarray: [{url:'https://lh3.google.com/u/0/ogw/ADGmqu9nW8NU438-qYtiRvUVdbtJpESWDHDvB9nORo5I=s83-c-mo'}]
        }
    }
    componentDidMount() {
        var selectimg;
         this.closeActivityIndicator();
      //  this.props.navigation.state.params
        if (this.props.navigation.state.params != undefined) {
            selectimg=this.props.navigation.state.params.imageurl;
            if(selectimg.indexOf('file') == -1)
            {
            if(selectimg.indexOf('http') == -1)
                {
            if(selectimg.indexOf('image') == -1)
            {
                selectimg=BASEURLIMAGE + 'product-store/getProductImage?name='+selectimg;
            } 
            else
            {
                selectimg=BASEURLIMAGE + 'image/getImage?name='+selectimg;
            }
        }
        }
        else
    {

    }
            this.setState({
                
                selectedImage: selectimg,
animating:this.props.navigation.state.params.animating,


            })
        }

    }
    closeActivityIndicator = () => setTimeout(() => this.setState({
        animating: false
    }), 1000)
    render() {

        var a=[];
var array = [];
a=this.props.navigation.state.params.zoomimgs;
            a.map((item, i) => {
              
                if(item.indexOf('file') == -1)
                {
                if(item.indexOf('http') == -1)
                {
                    if(item.indexOf('image') == -1)
                {
                    item=BASEURLIMAGE + 'product-store/getProductImage?name='+item;
                } 
                else
                {
                    item=BASEURLIMAGE + 'image/getImage?name='+item;
                }
                }
            }
            else
            {

            }
                let data = {
                    url: item
                }
                array.push(data)
            });
        let array1 = [];
      
        if (array.length > 0) {
            array.map((item, i) => {
                if (item.url ===  this.state.selectedImage) {
                    array1.push(item)
                }
            })
        }
        if (array.length > 0) {
            array.map((item, i) => {
                if (item.url !==  this.state.selectedImage) {
                    array1.push(item)
                }
            })
        }

        return (
            <Modal
                animated
                animationType="slide"
                visible={true}
                animationInTiming={1000}
                animationOutTiming={1000}
                backdropTransitionInTiming={1000}
                backdropTransitionOutTiming={1000}
                backdropOpacity={1}
                transparent={true}
                onRequestClose={() => {
                    this.setState({ animating: true })
                    this.props.navigation.goBack();
                }}>
                <View activeOpacity={0.75} onPress={() => this.setState({ visible: false })} style={styles2.touchable}>
                    <View style={styles2.popback}>
                        {/* <Text style = {{color:'#ff00ff'}}>jsvcudsvcdsuv</Text> */}
                        {(this.state.animating &&
                            <ActivityIndicator style={{ alignSelf: 'center', marginTop: 10 }}></ActivityIndicator>
                        )}

                        <Text style={{
                            color: 'white', fontSize: 16, alignSelf: 'center', textAlign: 'center',
                            marginTop: 20
                        }}>{this.props.skuNumber != undefined ? this.props.skuNumber : ''}</Text>

                        <ImageViewer style={{ width: '100%', height: '100%', marginVertical: 100 }}
                            imageUrls={array1} />

                        <Text onPress={() => {
                            this.setState({ animating: true })
                            this.props.navigation.goBack();
                        }} style={{
                            color: 'white', fontSize: 16, bottom: 0, position: 'absolute',
                            paddingVertical: 10, paddingHorizontal: 25, marginBottom: 20, borderColor: '#ffffff', borderWidth: 1,
                            borderRadius: 10
                        }}>Close</Text>

                    </View>
                </View>
            </Modal >
        )
    }
}
const styles2 = StyleSheet.create({
    divider2: {
        height: 3,
        marginTop: 2,
        //   backgroundColor: Colors.tabColor,
        width: 80,
    },
    schoolicon: {
        marginLeft: 10,
        width: 20,
        height: 20,
    },
    schooltext: {
        fontWeight: 'bold',
        textAlign: 'center',
        //   color: Colors.darkText,
        marginTop: 10,
    },
    img: {
        width: 40,
        height: 40,
        marginTop: 5,
    },
    btntext: {
        fontWeight: 'bold',
        fontSize: 15,
        color: 'white',
        textAlign: 'center',
    },
    touchable: {
        backgroundColor: 'rgba(0,0,0,0.1)',
        flex: 1,
        justifyContent: 'flex-end',
    },

    popback: {
        backgroundColor: 'black',
        height: '100%',
        alignItems: 'center',
        //   borderTopRightRadius: 20,
        //   borderTopLeftRadius: 20,
    },
    textnf: {
        textAlign: 'center',
        fontWeight: 'bold',
        //   color: Colors.darkText,
        marginTop: 25,
        fontSize: 15,
    },
    textnf2: {
        textAlign: 'center',
        marginTop: 10,
        //   color: Colors.darkText,
        marginHorizontal: 35,
        fontSize: 13,
    },
    popbuttonback: {
        alignItems: 'center',
        flexDirection: 'row',
        marginTop: 25,
        justifyContent: 'space-evenly',
    },
    popbutton1: {
        marginRight: 20,
        paddingHorizontal: 10,
        paddingVertical: 8,
    },
    poptext1: {
        fontWeight: 'bold',
        fontSize: 15,
        textAlign: 'center',
        //   color: Colors.darkText,
    },
    divider1: {
        width: 65,
        //   backgroundColor: Colors.darkText,
        height: 2,
        alignSelf: 'center',
    },
})
