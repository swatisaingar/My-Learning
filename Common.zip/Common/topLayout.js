import React, { Component } from 'react';
import { StyleSheet, Text, View, ScrollView, Image, Keyboard, Dimensions } from 'react-native';
import { COLORS, SIZE } from '../constants/styles';
import { widthPercentageToDP, heightPercentageToDP } from 'react-native-responsive-screen';
const { width, height } = Dimensions.get('window');
import images from '../util/img';
export default class CommonLayout extends Component {
	constructor(props) {
		super(props);
		/* this.keyboardEventListeners =[ */
		Keyboard.addListener('keyboardDidShow', frames => {
			if (!frames.endCoordinates) return;
			this.setState({ keyboardHeight: frames.endCoordinates.height });
		});
		Keyboard.addListener('keyboardDidHide', frames => {
			this.setState({ keyboardHeight: 0 });
		});
		/* ]; */
	}
	componentWillUnmount() {
		  Keyboard.removeListener('keyboardDidShow', frames => {
			if (!frames.endCoordinates) return;
			this.setState({ keyboardHeight: frames.endCoordinates.height });
		});
		Keyboard.removeListener('keyboardDidHide', frames => {
			this.setState({ keyboardHeight: 0 });
		});

	  }
	render() {
		return (
			<View>
				<ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps={'always'}>
					<View
						style={{
							alignItems: 'center',
							marginBottom: !!this.state && !!this.state.keyboardHeight ? this.state.keyboardHeight : 0
						}}
					>
						<Text style={styles.textColor}>
							<Image style={styles.imageThumbnail} source={images.logo} />
						</Text>
						{this.props.children}
					</View>

				</ScrollView>
				<View style={{
					position: 'absolute',
					bottom: 0,
					top: height,
					height: 30,
					backgroundColor: `${COLORS.MAINCOLOR.BLUE}`,
					width: width,
				}}></View>
			</View>
		);
	}
}

const styles = StyleSheet.create({
	container: {
		backgroundColor: `${COLORS.WHITE.WHITE}`,
		borderTopColor: `${COLORS.MAINCOLOR.BLUE}`,
		borderTopWidth: 30,
		// borderBottomColor: `${COLORS.MAINCOLOR.BLUE}`,
		// borderBottomWidth: 30,
		alignItems: 'center'
	},
	textColor: {
		color: '#000',
		fontWeight: 'bold',
		textAlign: 'center',
		marginTop: 5,
		fontSize: SIZE.LARGE,
		borderRightColor: `${COLORS.MAINCOLOR.BLUE}`,
		borderRightWidth: 5,
		borderRadius: 5,
		borderBottomColor: `${COLORS.MAINCOLOR.BLUE}`,
		borderBottomWidth: 5,
		// paddingTop: 20,
		paddingBottom: 5,
		width: widthPercentageToDP('60%'),
		height: heightPercentageToDP('18%'),
		padding: 0
	}
});