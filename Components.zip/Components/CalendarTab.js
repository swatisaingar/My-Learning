import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList, Image, ScrollView, SafeAreaView, ActivityIndicator, Alert, Linking,
} from 'react-native';
import { Calendar } from 'react-native-calendars';
import Icon1 from 'react-native-vector-icons/FontAwesome';

import images from '../util/img';
import { fetchReplyList, sendOA, fetchVendors, getAllClases, getTeacherClassesData, getTeacherClassesDataFilter, rescheduleClass, fetchTeacherClassStatusForMonth , CalenderClassCancelCall} from '../actions';
import NavigationService from '../Services/NavigationService'
import { COLORS, widthPercentageToDP } from '../constants/styles'
import { connect } from 'react-redux';
import Moment from 'moment';
import { loginheaderColor, appgrayColor, rescheduleClassBgColor, appblueColor, } from '../util/AppConstants';
import Styles from '../uistyles/Styles';
import moment from 'moment'
import { isNumber, isEmpty, now } from 'lodash';
import Modal from 'react-native-modal'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../util/AppConstants';

var params;
let newDaysObject = {};
class CalendarTab extends Component {

  constructor(props) {
    super(props);

    const missed = { key: 'MISSED', dotColor: 'red', selectedDotColor: 'orange', marked: true };
    const upcoming = { key: 'UPCOMING', dotColor: 'blue', selectedDotColor: 'orange', marked: true };
    const completed = { key: 'COMPLETED', dotColor: 'green', selectedDotColor: 'orange', marked: true };
    const data = {
      '2021-02-19': { selected: true, dotColor: 'orange', dots: true, selectedColor: 'orange' }
    }
    this.state = {
      selected: new Date(),
      size: '',
      dayss: {},
      selDates: {},
      vendor: '-Select-',
      calenderClassData: [],
      todayClasses: [],
      teacherClassesList: [],
      isLoading:true,
      teacherClassStatusData:[],
      uniqueDateList:[],
      teacherListIamgeData:[],
      profileImage:{},
      showStartClassDialog:false,
      selectedDate:'',
    }
    params = this.props.navigation.state.params;
  }

  async componentDidMount() {
    this.setState({
      selected: Moment().format("YYYY-MM-DD"),
    }, () => {
      newDaysObject[this.state.selected] =
        { selected: true, disableTouchEvent: false, selectedColor: loginheaderColor, selectedTextColor: 'white' };

      this.setState({
        dayss: newDaysObject,
        selDates: newDaysObject,
      });

    });


    this.props.getAllClases(new Date())
    this.setState({ calenderClassData: this.props.calenderClassData && this.props.calenderClassData.data })
    this.getdateWiseClass(new Date(), this.props.calenderClassData && this.props.calenderClassData.data)
    const date = moment.utc().format();
    const local = moment.utc(date).local().format();

    var currentDate = moment.utc(now()).format();
    this.props.getTeacherClassesData({ dateFilter: currentDate })
    this.props.fetchTeacherClassStatusForMonth({ month: 3 })


    let AuthToken = await AsyncStorage.getItem('id_token');
    let profileid = this.props.prof?.profData?.data?.imageId;
    fetch(`${baseURL}file-blobs/getImage/${profileid}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let profileImage = this.state.profileImage || {};
      profileImage[resposne.data.id] = resposne.data;
      this.setState(profileImage);
    }).
      catch((error) => {
        console.log("#error", error);
      })


  }

  componentDidUpdate = async(prevProps) => {
    let AuthToken = await AsyncStorage.getItem('id_token');
    if (prevProps.calenderClassData != this.props.calenderClassData) {
      this.setState({ calenderClassData: this.props.calenderClassData && this.props.calenderClassData.data })
      this.getdateWiseClass(new Date(), this.props.calenderClassData && this.props.calenderClassData.data)
    }

    if (
      prevProps.teacherClassesDataProps != this.props.teacherClassesDataProps
    ) {

      this.setState({isLoading: false})
      console.log('Teacher classes list : ', this.props.teacherClassesDataProps)
      this.setState({
        teacherClassesList:
          this.props.teacherClassesDataProps &&
          this.props.teacherClassesDataProps.data,
      })


      this.props.teacherClassesDataProps?.data?.map((item) => {
        // this.props.imageLoad(item?.courseClass?.course?.imageId)
        let id = item.course.imageId;
        fetch(`https://api.idutor.tk/api/file-blobs/getImage/${id}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${AuthToken}`,
         }
        }).then(data => {
          return data.json()
        }).then(resposne => {
          let imageData = this.state.teacherListIamgeData || {};
          imageData[resposne.data.id] = resposne.data;
          this.setState(imageData);
          this.setState({teacherListIamgeData : imageData, })
        }).
          catch((error) => {
            console.log("#error", error);
          })
      })
      
    }

    if (prevProps.teacherClassStatusData != this.props.teacherClassStatusData) {
      //1=COMPLETD, 2=ONGOING, 3=UPCOMING 4=MISSED 5=CANCELLED 6=STARTED
      console.log("class Status data ===========", this.props.teacherClassStatusData)
      const uniqueTags = [];
      const nextDays = []
      this.props.teacherClassStatusData && this.props.teacherClassStatusData.data && this.props.teacherClassStatusData.data.map(item => {
        var findItem = uniqueTags.find(x => x.date === item.date);
        if (!findItem) {
          uniqueTags.push(item);
        }
        else {
          if (item.classStatus === 4) {

            let index = uniqueTags.findIndex(item => item.date === findItem.date);

            uniqueTags[index] = { ...item };
            this.setState({ uniqueTags });
            // reset existing class item status with new status
          }
        }

      });

      this.setState({ uniqueDateList: uniqueTags, })
      const markedDateList = {}
      uniqueTags.map(item => {
        markedDateList[moment(item.date).format('YYYY-MM-DD')] = {
          dotColor: item.classStatus == 1 ? 'green' : item.classStatus == 4 ? 'red' : 'orange',
          marked: true,
          selected: false,
          selectedDotColor: 'orange',
          selectedColor: 'orange',
        };

        nextDays.push(moment(item.date).format('YYYY-MM-DD'))
        console.log("nextDAys======", nextDays)
        newDaysObject[moment(item.date).format('YYYY-MM-DD')] = {
          dotColor: item.classStatus == 1 ? 'green' : item.classStatus == 4 ? 'red' : 'orange',
          marked: true
        };

      })

      this.setState({
        selected: Moment().format("YYYY-MM-DD"),
      }, () => {

        var olddd = newDaysObject
        //if (olddd.hasOwnProperty(this.state.selected)) {
          if (olddd.hasOwnProperty(Moment().format("YYYY-MM-DD"))) {
          console.log("selceted date=======", moment(new Date).format("YYYY-MM-DD"))
          console.log("newdays====",newDaysObject )
          var oldVal = newDaysObject[moment(new Date).format("YYYY-MM-DD")]
          newDaysObject[moment(new Date).format("YYYY-MM-DD")] = { ...oldVal, selected: true, disableTouchEvent: false, selectedColor: loginheaderColor, selectedTextColor: 'white' }
        }
        else {
          console.log("selceted date=======", moment(new Date).format("YYYY-MM-DD"))
          newDaysObject[moment(new Date).format("YYYY-MM-DD")] =
            { selected: true, disableTouchEvent: false, selectedColor: loginheaderColor, selectedTextColor: 'white' };
        }


        this.setState({
          dayss: newDaysObject,
          selDates: newDaysObject,
        });

      });

      // this.setState({
      //   dayss: markedDateList,
      //   selDates: markedDateList,
      // });

    }


    if(prevProps.classCancelData != this.props.classCancelData)
    {
      console.log("Cancel api response======", this.props.classCancelData )
      if(!isEmpty(this.props.classCancelData.data))
      {
        alert("Class has been cancelled successfully")
    var selectedDate = moment.utc(this.state.selected).format();
    this.getDateDiffernece(selectedDate , now())
    console.log("Selected date time in UTC-----" , selectedDate )
    this.setState({isLoading: true , selectedDate: selectedDate,})
    this.props.getTeacherClassesData({dateFilter: selectedDate})
    
      }

      else{
        alert("Class has not been cancelled.")
      }
    }
  }

  getdateWiseClass = (date, data) => {
    let dateArray = []
    this.state.calenderClassData && this.state.calenderClassData.length > 0 && this.state.calenderClassData.map(item => {
      let itemdate = moment(item.startTime).format('DD-MM-YYYY')
      let todaydate = moment(date).format('DD-MM-YYYY')
      if (itemdate === todaydate) {
        dateArray.push(item)
      }
    })

    this.setState({ todayClasses: dateArray })
  }


  onDayPress = day => {
  //  console.log("new date is selected-------------", 'true')
    // console.log("selectedDateString------" , day.dateString)
    console.log("onday press callled" , day.dateString)
    

    var selectedDate = moment.utc(day.dateString).format();
    this.setState({selected : selectedDate})
    this.getDateDiffernece(selectedDate , now())
    console.log("Selected date time in UTC-----" , selectedDate )
    this.setState({isLoading: true , selectedDate: selectedDate,})
    this.props.getTeacherClassesData({dateFilter: selectedDate})
    
    console.log("before changedd" + JSON.stringify(newDaysObject));
    // var selectedDate = moment.utc(day.dateString).format();
    // this.getDateDiffernece(selectedDate, now())
    // this.setState({ isLoading: true })
    // this.props.getTeacherClassesData(selectedDate)

    var olddd = newDaysObject;
    if (olddd.hasOwnProperty(this.state.selected)) {
      var oldVal = newDaysObject[this.state.selected]
      olddd[this.state.selected] = { ...oldVal, selected: false }
    }

    const datee = {};
    datee[day.dateString] = { selected: true, disableTouchEvent: true, selectedColor: loginheaderColor, selectedTextColor: 'white' }

    this.state.dayss = Object.assign({}, olddd, datee,)
    this.setState
      ({
        dayss: this.state.dayss
      }, () => {

      });

  };
  getClassStatusText(statusId, item) {

    const sTime = moment(item.startTime, "HH:mm");

    const currentTimeVal = moment(new Date()).format('HH:mm');

    const currentTime = moment(currentTimeVal, "HH:mm")
    console.log("current time---- start time =========", currentTime, sTime)

    var minutes = sTime.diff(currentTime, 'minutes');
    console.log("minutes to set classs ststus text =======", minutes)

    var currentDate = moment.utc(now()).format();

    var currentDate = moment(new Date(currentDate), "dd-MM-YYYY")
    var classDate = moment(new Date(item.date), 'dd-MM-YYYY')

    console.log("today ========", currentDate)
    console.log("class date ========", item.date)

    var dayDiff = classDate.diff(currentDate, 'days')
    console.log("day diff======", dayDiff)

    //1=COMPLETD, 2=ONGOING, 3=UPCOMING 4=MISSED 5=CANCELLED 6=STARTED
    switch (statusId) {

      case 1:
        return 'Completed'
      case 2:
      return 'Join now'
      case 3:
        {
          if(dayDiff>0)
          {
            return 'Reschedule'
          }

        
            else if(dayDiff==0){
             // return 'Reschedule'
              if(minutes>=30)
              {
                return 'Reschedule'
              }
  
              else if (minutes<=30)
              {
                return 'Start Class'
              }
  
              else if (minutes<0 && Math.abs(minutes)<=this.getClassDuration(item))
              {
                return 'Join Now'
              }
  
              else{
                return rescheduleClassBgColor   // need to be check again
              }
  
              }

      
          else (dayDiff<0)
          {
           return  'Missed'
          }
          
        }
      case 4:
        return 'Missed'
      case 5:
        return 'Cancelled'
      case 6:
        return 'Started'
      default:
        return 'Default'
    }
  }

  getClassStatusTextBgColor(statusId, item) {

    const sTime = moment(item.startTime, "HH:mm");

    const currentTimeVal = moment(new Date()).format('HH:mm');

    const currentTime = moment(currentTimeVal, "HH:mm")
    console.log("current time---- start time =========", currentTime, sTime)

    var minutes = sTime.diff(currentTime, 'minutes');
    console.log("minutes to set classs ststus text =======", minutes)

    var currentDate = moment.utc(now()).format();

    var currentDate = moment(new Date(currentDate), "dd-MM-YYYY")
    var classDate = moment(new Date(item.date), 'dd-MM-YYYY')

    console.log("today ========", currentDate)
    console.log("class date ========", item.date)

    var dayDiff = classDate.diff(currentDate, 'days')
    console.log("day diff======", dayDiff)

    //1=COMPLETD, 2=ONGOING, 3=UPCOMING 4=MISSED 5=CANCELLED 6=STARTED
    switch (statusId) {

      case 1:
        return  'green'  //'Completed'

      case 2:
       
          return  loginheaderColor  //'Start Class'

      case 3:
        {
          if(dayDiff>0)
          {
            return rescheduleClassBgColor //'Reschedule'
          }
          else if(dayDiff==0){
            if(minutes>=30)
            {
              return rescheduleClassBgColor //'Reschedule'
            }

            else if (minutes<=30)
            {
              return loginheaderColor //'Start Class'
            }

            else if (minutes<0 && Math.abs(minutes)<=this.getClassDuration(item))
            {
              return loginheaderColor//'Join Now'
            }

            else{
              return rescheduleClassBgColor   // need to be check again
            }

            }
          else (dayDiff<0)
          {
            return 'red' //'Missed'
          }
          
        }
      case 4:
        return 'red' //'Missed'
      case 5:
        return 'red' //'Cancelled'
      case 6:
        return loginheaderColor //'Started'
      default:
        return  'red' // need to be re-check again
    }
  }


  getDateDiffernece(date1, date2) {

    const start = new Date(date1);
    const end = new Date(date2);
    var msDiff = start.getTime() - new Date().getTime();    //Future date - current date
    var daysTill30June2035 = Math.floor(msDiff / (1000 * 60 * 60 * 24));

  }


  getClassStatusText(statusId , item){

    const sTime = moment(item.startTime, "HH:mm");
      
    const currentTimeVal  =  moment(new Date()).format('HH:mm') ;

    const currentTime = moment(currentTimeVal, "HH:mm")
    console.log("current time---- start time =========", currentTime , sTime)
   
    var minutes = sTime.diff(currentTime , 'minutes');
    console.log("minutes to set classs ststus text =======", minutes)

    var currentDate = moment.utc(now()).format();

    var currentDate = moment(new Date()  , "dd-MM-YYYY")
    var classDate = moment(new Date(this.state.selected) , 'dd-MM-YYYY')

    console.log("today ========", currentDate)
    console.log("class date ========", item.date)

    var dayDiff = currentDate.diff(classDate, 'days')
    console.log("day diff======", dayDiff)

    //1=COMPLETD, 2=ONGOING, 3=UPCOMING 4=MISSED 5=CANCELLED 6=STARTED
    switch(statusId)
    {

      case 1: 
      return 'Completed'
       case 2:
        if(dayDiff==0)
        {
          return 'Start Class'
        }
      
      case 3:
        {
          if(dayDiff==0)
          {
            if(minutes<=10)
            {
              return 'Start Class'
            }

            else if(minutes>=30)
            {
              return 'Reschedule'
            }

            else{
              return 'Reschedule'
            }
          }

          else if(dayDiff>=1)
          {
            return 'Reschedule'
          }
        
        else{
          return 'Reschedule'
        }
      }
        case 4:
          return 'Missed'
          case 5:
            return 'Cancelled'
            case 6: 
            return 'Started'
        default:
          if(dayDiff>0)
          {
            return 'Reschedule'
          }
          else{
            return 'Missed'
          }
         
    }
  }


  performClickOnClassSataus(classStatusId, item) {
    //1=COMPLETD, 2=ONGOING, 3=UPCOMING 4=MISSED 5=CANCELLED 6=STARTED
    switch (classStatusId) {
      case 1:
        {
          console.log('class status : ', 'Completed')
        }
        break;

      case 2:
        {
          this.showDialogtoStartClass(item)
        }

        break;

      case 3:
        {

          var btnText =  this.getClassStatusText(classStatusId , item)
          if(btnText=="Start Class")
          {
            this.showDialogtoStartClass(item)
          
          }
          else if(btnText== "Reschedule")
          {
            this.showDialogToRescheduleClass(item)
          }

          else{

            console.log("item clicked ", item)
          }
          
        }

        break;

      case 5:
        {
          this.cancelStartClass(item)

        }
        break;



      default:
        {

          console.log("what ststus invoked --------", classStatusId)
        }

    }

  }
  calenderClassCancelCallApiCall(item)
  {
    const data = ({...item, 
      classStatus: 5
     })
     
  this.props.CalenderClassCancelCall(data)
  }
  getTeacherClassStandard(item)
  {
    console.log("item dashboard data--------", item)
    return item.standard.class
  }
// method to class continue
continueStartClass() {
  Linking.openURL('http://idutor.com')
  this.setState({ showStartClassDialog: !this.state.showStartClassDialog })
}

cancelStartClass(item)
{


  console.log("cancel class is invoked", "status =5 ")
       if(this.state.showStartClassDialog)
     {
      this.setState({ showStartClassDialog:!this.state.showStartClassDialog})
     }   
}

  getClassStartTimeFormatted(startTime)
  {
  
console.log("startTime :" , startTime)
if(isEmpty(startTime))
{
   return '00:00'
}
else{
  const sTime = moment(startTime, "hh:mm A");
  console.log("startTime By moment :" , sTime)
  return sTime.format("hh:mm A")
}


  }

  getClassDuration(startTime , endTime)
  {

    if(isEmpty(startTime) || isEmpty(endTime))
    {
  return "0 min"
    }
    else{

      const sTime = moment(startTime, "HH:mm");
      
      const eTime = moment(endTime, "HH:mm");
      
      var minutes = eTime.diff(sTime , 'minutes');
      console.log("minutes=======", minutes)
  
      //return minutes
      if(minutes>=60)
      {
        var hr = minutes/60
        var min = minutes%60
  
        if(min==0)
        {
          return  Math.floor(hr)+  'hr'
        }
        else{
          return  Math.floor(hr) + " hr " + min +" min"
        }
        
      }
      else{
  
        return minutes +" min"
      }
    }
    
  }


  showCancelButton(item)
  {
    const sTime = moment(item.startTime, "HH:mm");

    const currentTimeVal = moment(new Date()).format('HH:mm');

    const currentTime = moment(currentTimeVal, "HH:mm")
    console.log("current time---- start time =========", currentTime, sTime)

    var minutes = sTime.diff(currentTime, 'minutes');
    console.log("minutes to set classs ststus text =======", minutes)

    var currentDate = moment.utc(now()).format();

    var currentDate = moment(new Date(currentDate), "dd-MM-YYYY")
    var classDate = moment(new Date(item.date), 'dd-MM-YYYY')

    console.log("today ========", currentDate)
    console.log("class date ========", item.date)

    var dayDiff = classDate.diff(currentDate, 'days')
    console.log("day diff======", dayDiff)

     var classStatus = item.classStatus;
    if(dayDiff>0)
    {
      switch(classStatus)
      {
        case 3:
        return true

        case 5:
          return false;

        default:
          return false
      }
    }

    else if(dayDiff==0)
    {
      switch(classStatus)
      {

        case 3:
          if(minutes>30)
          {
            return true
          }
          else{
            return false
          }

         default:
           return false
      }
     
    }

    else{
      return false
    }

  }

  showDialogtoStartClass(item) {
    console.log("item to start", "8970970900900790")
    this.setState({ showStartClassDialog: true, teacherClassSelected: item, })
  }


  showDialogToRescheduleClass(item) {
    NavigationService.navigate('RescheduleClassScreen', { fromWhere: 'CalendarTab', classData: item })
  }

  showListItem(item) {
    console.log("teacher class list item ------", item)
  }


  getClassesTitle()
  {

    var selectedDate = this.state.selectedDate
    var currentDate = moment.utc(now()).format();

    var currentDate = moment(new Date(currentDate)  , "dd-MM-YYYY")
    var selectedDate = moment(new Date(selectedDate) , 'dd-MM-YYYY')

    console.log("today ========", currentDate)
    console.log("Selected date ========", selectedDate)

    var dayDiff = selectedDate.diff(currentDate, 'days')
    console.log("Selected date day diff======", dayDiff)

    if(dayDiff>=1)
    {
      return "Upcoming Classes"
    
      
    }

    else if(dayDiff<0)
    {
      return "Previous Classes"
    }

    else{
    
      return "Upcoming Classes"

    }
   
  }


  
  render() {
    return (
      <View>


        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 50, justifyContent: 'space-between', elevation: 10, marginTop: 1 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                NavigationService.openDrawerr();
              }}
            >
              <Image style={{ width: 20, height: 20, marginLeft: 10 }} source={images.menu} />
            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 10, marginLeft: 100 }} source={images.logo} resizeMode={'contain'} />

          <TouchableOpacity
            onPress={() => {
              this.setState({ filterpopup: true })
            }}
          >
            <Icon1 style={{ marginTop: 15, alignContent: 'flex-end', marginLeft: 80 }} name="bell-o" size={25} color={'black'} />
          </TouchableOpacity>
          <TouchableOpacity onPress={()=>NavigationService.navigate('ProfileScreen')}>
         {(this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content) ? <Image
            resizeMode='contain'
            source={{uri:`data:image/jpeg;base64,${this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content}`}}
            style={{ width: 25, height: 25, marginLeft: 5, marginRight: 20, marginTop: 15,borderWidth:1 }}
          />:<View style={{
            width: 25,
            height: 25,
            marginLeft: 5,
            marginRight: 20,
            marginTop: 15,
            borderWidth: 1
          }}><ActivityIndicator size='small'/></View>}
          </TouchableOpacity>
        </View>

        <Modal
        style={{backgroundColor:'#26000000'}}
          animationType={'fade'}
          transparent={true}
          visible={this.state.showStartClassDialog}
          onRequestClose={() => { console.log("Modal has been closed.") }}>

          {/*All views of Modal*/}
          <View style={styles.modal}>
            <View style={{backgroundColor:"white"}}>

           <View style={{flexDirection:'row', justifyContent:'center',}}>
           <Text style={styles.modalTitle}>Start Class</Text>
            {/* <TouchableOpacity
            style={{alignSelf:'flex-end' ,alignContent:"center" ,marginHorizontal:20}}
            >
              <Image 
              style={{ width: 20, height: 20, }} source={images.menu}
              ></Image>
            </TouchableOpacity> */}
           </View>
           
            <Text style={styles.modalMsg}>
              You are initiating the class on small screen. For better user experience, idutor recommends hosting classes on tablet or laptops. To login to web console, please visit
              </Text>
            <Text style={styles.modalWebLink}
              onPress={() => { Linking.openURL('http://www.example.com/') }}>
              http://idutor.com
              </Text>
            <TouchableOpacity
              onPress={() =>
                this.continueStartClass()
              } >
              <Text style={styles.ContinueButtonStyle}>
                Continue</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                this.cancelStartClass(this.state.teacherClassSelected)
                //this.setState({ showStartClassDialog:!this.state.showStartClassDialog})
              }
              } >
              <Text style={styles.modalCancel}>
                Cancel</Text>
            </TouchableOpacity>
            </View>
          </View>

        </Modal>

          {console.log("markedDate------",this.state.dayss)}
          <Calendar
            style={{
              margin: 5,
              elevation: 10
            }}
            horizontal
            minDate={'2012-05-10'}
            // maxDate={'2020-12-30'}
            onDayPress={(day)=>{this.onDayPress(day)}}
            onDayLongPress={(day) => { 
              //console.log('selected day', day)
              this.onDayPress(day)
             }}
            monthFormat={'yyyy MM'}
            onMonthChange={(month) => { console.log('month changed', month) }}
            hideArrows={false}
            horizontal
            pagingEnabled
            firstDay={1}
            pastScrollRange={0}
            onPressArrowLeft={subtractMonth => subtractMonth()}
            onPressArrowRight={addMonth => addMonth()}
            current={new Date()}
            renderHeader={date => {
              const header = date.toString('MMMM yyyy');
              const [month, year] = header.split(' ');
              const textStyle = {
                fontSize: 15,
                // fontWeight: 'bold',
                paddingTop: 10,
                paddingBottom: 10,
                color: 'black',
                paddingRight: 5
              };

              return (
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'center',
                    marginTop: 10,
                    marginBottom: 10
                  }}
                >
                  <Text style={{ marginLeft: 5, ...textStyle }}>{`${month}`}</Text>
                  <Text style={{ marginRight: 5, ...textStyle }}>{year}</Text>
                </View>
              );
            }}
            theme={{
              arrowColor: 'black',
              'stylesheet.calendar.header': {
                dayHeader: {
                  fontWeight: '600',
                  color: 'red'
                }
              },
            }}
            enableSwipeMonths={true}
            markedDates={this.state.dayss}
          />



        <ScrollView>

       <View style={{height:'90%', paddingBottom:60}}>

      
{this.state.isLoading ? (
          <View >
            <ActivityIndicator />
          </View>
        ) : null}
        {this.props.selctType.typeselectedData.logintype == "Student" ?
          <View style={{ justifyContent: 'center', marginLeft: 10, marginRight: 10 }}>
            <Text style={{ fontWeight: 'bold', fontSize: 14 }}>{(this.state.todayClasses && this.state.todayClasses.length > 0) ? "Upcoming Classes" : "No Upcoming Classes"} </Text>
            <FlatList
              data={this.state.todayClasses}
              renderItem={({ item }) => {
                return (
                  <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10 }}>

                    <View style={{ flexDirection: 'row', justifyContent: 'space-evenly' }}>

                      <Image style={Styles.calimage}


                        source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}


                      />
                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginLeft: 5, marginRight: 5, marginTop: 10, padding: 10 }}>

                        <View>
                          <Text style={{ fontWeight: 'bold', fontSize: 13, }}>{item.courseClass && item.courseClass.course && item.courseClass.course.name} </Text>
                          {item.teacher && <Text style={{ fontSize: 12, fontStyle: 'italic' }}>By {item.teacher.firstName}{item.teacher.lastName}</Text>}
                        </View>

                        <View>
                          <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{item.courseClass && moment(item.courseClass.date).format('DD MMM')}</Text>
                          <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{item.courseClass && item.courseClass && item.courseClass.startTime && moment(item.courseClass.startTime).format('hh:mm A')}</Text>
                          <Text style={{ marginBottom: 5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: loginheaderColor, borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>Join Class</Text>

                        </View>



                      </View>
                    </View >

                  </View>
                 )
                }} />
                </View>
              :
              <View style={{ justifyContent: 'center', marginLeft: 10, marginRight: 10 ,paddingBottom:20}}>
              <Text style={{ fontWeight: 'bold', fontSize: 14 }}>{(this.props.teacherClassesDataProps &&  this.props.teacherClassesDataProps.data && !isEmpty(this.props.teacherClassesDataProps.data)) ?this.getClassesTitle() : "No Upcoming Classes"} </Text>
              
            <FlatList
                data={this.props.teacherClassesDataProps && this.props.teacherClassesDataProps.data}
                style={{marginBottom:140 ,}}
                nestedScrollEnabled={true}
                onEndReached={this._handleLoadMore}
                onEndReachedThreshold={0.01}
                contentContainerStyle={{paddingBottom: 100}}
                renderItem={({ item }) => {
                  return (
                    <View style={{ justifyContent: 'center', marginLeft: 10, marginRight: 10 , marginBottom:10}}>
                <View style={{ width: widthPercentageToDP('92%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10 }}>
                  <TouchableOpacity>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
    {
      isEmpty(this.state.teacherListIamgeData[item.course.imageId]?.content)
        ?
        <Image style={Styles.calimage}
        source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
       // source={{ uri:`data:image/jpeg;base64,${this.state.teacherListIamgeData[item.course.imageId]?.content}`,  }} 
     />
        :
        <Image style={Styles.calimage}
        resizeMode='contain'
        //source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
        source={{ uri:`data:image/jpeg;base64,${this.state.teacherListIamgeData[item.course.imageId]?.content}`,  }} 
     />
    }
                    
                      <View style={{ flexDirection: 'row',flex:1, justifyContent: 'space-between', marginLeft: 5, marginRight: 5, marginTop: 10, padding: 10 }}>
                        <View style={{alignContent:'flex-start' , flex:2}}>
                          <Text style={{ fontWeight: 'bold', fontSize: 13,  textAlign:'justify'}}>{item.courseName} - Class {this.getTeacherClassStandard(item)}</Text>
                          <Text style={{ fontSize: 12, fontStyle: 'italic' ,textAlign:'left'}}> {item.topicsCovered}</Text>
                          <Text style={{ fontSize: 12, alignSelf: 'flex-start' }}>{this.getClassStartTimeFormatted(item.startTime)} to { this.getClassStartTimeFormatted(item.endTime)} ({this.getClassDuration(item.startTime , item.endTime)})</Text>
                        </View>
    
                        <View style={{flex:1}}>
                          <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(item.date).utc().format("DD , MMM")}</Text>
    
                          <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{this.getClassStartTimeFormatted(item.startTime)}</Text>
                        
                        </View>
                      </View>
                      
                    </View >

                    <View style={{flexDirection:'row',alignSelf:'flex-end',marginRight:10, justifyContent:'space-evenly', alignContent:'flex-end' , marginStart: 50 ,marginBottom:10,}}>
                    {
                                 this.showCancelButton(item)? <TouchableOpacity
                                 style={{marginHorizontal:10}}
                                 onPress={() => this.calenderClassCancelCallApiCall(item)}>
                                 <Text style={{ marginBottom: 5, color: 'white', marginTop: 10, backgroundColor: 'red', borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>Cancel</Text>
                               </TouchableOpacity>
                               : null

                                }
                                
                               <TouchableOpacity
                                    onPress={() => this.performClickOnClassSataus(item.classStatus, item)}>
                                    <Text style={{ marginBottom: 5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: this.getClassStatusTextBgColor(item.classStatus, item), borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>{this.getClassStatusText(item.classStatus, item)}</Text>
                                  </TouchableOpacity> 
                                </View> 
                  </TouchableOpacity>
                </View>
              </View>
              )}}
                />
                  </View>
           } 
            </View>
            </ScrollView>
         </View >
    ) }}


const mapStateToProps = state => ({
  prof: state.prof,
  reply: state.reply,
  sendoa: state.sendoa,
  vendors: state.vendors,
  calenderClassData: state.dash.calenderClassData,
  selctType: state.selctType,
  teacherClassesDataProps: state.dash.teacherClassesData, // reducer gives state then convert to props
  // rescheduleClassDataProps : state.dash.rescheduleClassData,
  teacherClassStatusData: state.dash.fetchTeacherClassStatusForMonthData,
  classCancelData : state.dash.calendarClassCancelDataData

});
const mapDispatchToProps = {
  fetchReplyList, sendOA, fetchVendors, getAllClases,
  getTeacherClassesData,
  // rescheduleClass , 
  fetchTeacherClassStatusForMonth,// firstly define action here then we can get that into props for api call
  CalenderClassCancelCall,
};

export default connect(mapStateToProps, mapDispatchToProps)(CalendarTab);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 50,
    marginTop: 10,

  },
  statusContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: widthPercentageToDP('95%')
  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 10,
    marginTop: 5


  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `white`,
    padding: 10,
    marginTop: 10,

    backgroundColor: 'red',

  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `red`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: 'red',
    marginTop: 10,
    marginBottom: 10,

  },
  showmoreContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,

    backgroundColor: 'white',


  },
  addcartContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.DARKBLUE}`,
    padding: 5,
    marginTop: 5,

    backgroundColor: `${COLORS.MAINCOLOR.DARKBLUE}`,


  },
  backContainer:
  {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.DARKBLUE}`,
    padding: 10,
    marginTop: 10,

    backgroundColor: `${COLORS.MAINCOLOR.DARKBLUE}`,


  },
  showmoreclickedContainer:
  {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.DARKBLUE}`,
    padding: 5,


    backgroundColor: `${COLORS.MAINCOLOR.DARKBLUE}`,


  },
  Buttontext: {
    color: 'white',
    fontSize: 12,
    alignSelf: 'center'
  },
  showmoreclickedtext: {
    color: 'white',
    fontSize: 10,
    alignSelf: 'center'
  },
  BottomButtontext: {
    color: `white`,
    fontSize: 12,
    alignSelf: 'center'
  },
  showmoretext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 10,
    alignSelf: 'center'
  },
  addcarttext: {
    color: 'white',
    fontSize: 10,
    alignSelf: 'center'
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, .7)',

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  },
  text: {
    fontSize: 10,
    fontWeight: "bold",
    color: `${COLORS.MAINCOLOR.DARKBLUE}`,
  },
  selectoptionbutton: {
    margin: 10,
    height: 40,
    alignSelf: 'center',
    padding: 10,
    width: 200,
    backgroundColor: '#237D99',
    borderRadius: 10


  },


  modal: {
    justifyContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
    backgroundColor: "#26000000",
    width: '90%',
    borderRadius: 10,
    borderWidth: 1,
    marginTop: 80,
    borderWidth: 1,
    borderColor: '#26000000',
  },

  modalTitle: {
    marginTop: 20,
    color: '#353839',
    opacity: 1,
    fontSize: 12,
    fontWeight: 'bold',
    alignContent: 'center',
    textAlign: 'center',
    textAlignVertical: 'center',
    alignSelf:'center'
  },
  modalMsg: {
    marginTop: 10,
    color: '#4D4D4D',
    opacity: 1,
    fontSize: 11,
    marginHorizontal: 20,
    textAlign: 'center',
    textAlignVertical: 'center',
  },
  modalCancel: {
    marginBottom: 20,
    color: '#4D4D4D',
    opacity: 1,
    fontSize: 12,
    marginHorizontal: 20,
    textAlign: 'center',
    textAlignVertical: 'center',
  },

  modalWebLink: {
    color: '#5B82FF',
    opacity: 1,
    fontSize: 11,
    alignContent: 'center',
    marginHorizontal: 20,
    textAlign: 'center',
    textAlignVertical: 'center',
  },


  ContinueButtonStyle: {
    marginBottom: 10,
    color: 'white',
    alignSelf: 'flex-end',
    marginTop: 10,
    backgroundColor: '#165ADC',
    borderRadius: 20,
    paddingLeft: 30,
    paddingRight: 30,
    paddingBottom: 5,
    paddingTop: 5,
    width: '80%',
    alignSelf:'center',
    alignContent:'center',
    textAlign: 'center',
    textAlignVertical: 'center',
  },

})
