import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity, TouchableWithoutFeedback,
  FlatList, Alert, TextInput, ToastAndroid, Image, ActivityIndicator
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import Topbar from '../../Common/MenuBar'
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import * as EnquiryAPI from '../../Services/enquiryAPIs';
import { connect } from 'react-redux';
import moment from 'moment';
import Loader from '../../Common/Loader';
import TextField from '../../Common/TextInput';
import _ from "lodash";
import { heightPercentageToDP } from 'react-native-responsive-screen';
import { appbluebtnColor, appblueColor, appgrayColor, loginheaderColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import Modal from "react-native-modal";
import { Checkbox } from 'react-native-paper';
import NavigationService from '../../Services/NavigationService';
import { getFilteredData, addWishlistedData, removeWishlistedData } from '../../actions';
import AsyncStorage from '@react-native-async-storage/async-storage';

class AdvanceSearchActivity extends Component {

  constructor(props) {
    super(props);
    this.state = {
      filterArr: [{ id: -1, text: 'Top Rated' }, { id: 1, text: 'Top Rated', selected: 0 },
      { id: 2, text: 'Best Match', selected: 0 }, { id: 3, text: 'Price Low to High', selected: 0 }, { id: 4, text: 'Price High to Low', selected: 0 },],
      canceltext: '',
      filterpopup: false,
      isLoading: false,
      scanedCouseList: [],
      searchList: [],
      filterValue: false,
      visibility: false,
      addWishList: false
    }
  }

  componentDidMount() {

    const params = this.props.navigation.state.params
    this.setState({ isLoading: true })
    let filterPayload = {
      courseCategories: params.selectedCat,
      standard: params.selectedClass,
      subject: params.selectedSub,
      board: params.selectedBoard,
      language: params.selectedLang
    }

    _.map(filterPayload, (item, index) => {
      if (item === '') {
        delete filterPayload[index]
      }
    })

    this.props.getFilteredData(filterPayload)

  }


  componentDidUpdate(prevProps) {
    if (prevProps.dash != this.props.dash) {
      if (this.props.dash.fetchFilteredError !== null) {
        this.setState({ isLoading: false })
      }
      if (this.props.dash.fetchFilteredData !== null && prevProps.dash.fetchFilteredData != this.props.dash.fetchFilteredData) {
        this.setState({ searchList: this.props.dash.fetchFilteredData.data, isLoading: false })
      }
    }
  }

  checkCondition = (value) => {
    this.setState({ selected: value })
  }

  wishlist = async (courseid, indexValue) => {
    let profileData = await AsyncStorage.getItem('user_id');
    this.props.addWishlistedData(true, profileData, courseid)
    if (this.state.selected === indexValue) {
      this.setState({ addWishList: true })
    }
  }

  remove = (courseid, indexValue) => {
    this.props.removeWishlistedData(courseid);

    if (this.state.selected === indexValue) {
      this.setState({ addWishList: false })
    }

  }

  checkSortValue = (value, index) => {

    if (value === 1 && index == 1) {
      this.state.searchList.sort((a, b) => {
        return b.starRating - a.starRating;
      });
    }

    if (value === 2 && index == 1) {
      this.setState({ visibility: true })
    }

    if (value === 4 && index == 1) {
      this.state.searchList.sort();
      this.state.searchList.reverse();
    }

    if (value === 3 && index == 1) {
      this.state.searchList.sort();
    }
  }

  checkFilter = () => {
    if (this.state.checked1 == true || this.state.checked2 == true || this.state.checked3 == true || this.state.checked4 == true) {
      this.setState({
        filterValue: true
      });
    }
  }
  setChecked1(status) {
    this.setState({
      checked1: status
    })
  }
  setChecked2(status) {
    this.setState({
      checked2: status
    })
  }
  setChecked3(status) {
    this.setState({
      checked3: status
    })
  }
  setChecked4(status) {
    this.setState({
      checked4: status
    })
  }

  render() {
    var storedValue = 0;
    for (let i = 0; i < this.props.ratingData && this.props.ratingData.data.length; i++) {
      storedValue = storedValue + this.props.ratingData.data[i].rating;
    }
    var Avgrating = storedValue / this.props.ratingData && this.props.ratingData.totalCount

    let stars = [];
    let path = '';
    let integer_part = Math.trunc(Avgrating);
    let decimat_part = Avgrating - integer_part;
    let total_star_count = 0;
    for (let i = 1; i <= Avgrating; i++) {
      path = require('../../images/star.png');
      stars.push((<Image style={{
        width: 15,
        height: 15, marginRight: 1, marginLeft: 1
      }} source={path} />));
      total_star_count++;
    }
    if (decimat_part != 0) {
      path = require('../../images/star-half.png');
      stars.push((<Image style={{
        width: 20,
        height: 20, marginRight: 1, marginLeft: 1, position: 'relative', top: -2
      }} source={path} />));
      total_star_count++;
    }
    if (total_star_count != 5) {
      path = require('../../images/unfilled-star.png');
      for (let i = total_star_count; i < 5; i++) {
        stars.push((<Image style={{
          width: 15,
          height: 15, marginRight: 1, marginLeft: 1
        }} source={path} />));
      }
    }
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>

        <Modal

          isVisible={this.state.filterpopup}
          animationType="fade"
          transparent={true}
          backdropColor={'rgba(0,0,0,0.35)'}
          backdropOpacity={1}
          onBackdropPress={() => this.setState({ filterpopup: false })}
          onRequestClose={() => {
            this.setState({ filterpopup: false });
          }}
        >
          <View
            style={{
              flex: 1,

              justifyContent: "flex-end",
              alignItems: "center",
              height: 310,
            }}
          >
            <View
              style={{
                backgroundColor: "white",
                height: 310,
                width: widthPercentageToDP('100%'),
                alignContent: "center",
                justifyContent: "center", borderTopLeftRadius: 20, borderTopRightRadius: 20
              }}
            >
              <View>
                <Text style={{ fontSize: 20, marginTop: 20, marginLeft: 20 }}>Filter your Search</Text>
                <View style={{ flexDirection: 'row', paddingLeft: 10, paddingRight: 10, alignItems: 'center', marginTop: 10 }}>
                  <Checkbox
                    uncheckedColor={'gray'}
                    color={loginheaderColor}

                    status={this.state.checked1 ? 'checked' : 'unchecked'}
                    onPress={() => this.setChecked1(!this.state.checked1)}
                  />
                  <Text style={{ color: 'black' }}>Don't show In-progress Courses</Text>

                </View>


                <View style={{ flexDirection: 'row', paddingLeft: 10, paddingRight: 10, alignItems: 'center', marginTop: 10 }}>
                  <Checkbox
                    uncheckedColor={'gray'}
                    color={loginheaderColor}

                    status={this.state.checked2 ? 'checked' : 'unchecked'}
                    onPress={() => this.setChecked2(!this.state.checked2)}
                  />
                  <Text style={{ color: 'black' }}>My Friends / Idutor Recommended </Text>

                </View>

                <View style={{ flexDirection: 'row', paddingLeft: 10, paddingRight: 10, alignItems: 'center', marginTop: 10 }}>
                  <Checkbox
                    uncheckedColor={'gray'}
                    color={loginheaderColor}

                    status={this.state.checked4 ? 'checked' : 'unchecked'}
                    onPress={() => this.setChecked4(!this.state.checked4)}
                  />
                  <Text style={{ color: 'black' }}>Assured Registration</Text>

                </View>
                <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginRight: 20, marginTop: 10 }}>
                  <TouchableOpacity

                    onPress={() => {
                      this.setState({
                        filterpopup: false, checked1: false, checked2: false,
                        // checked3: false,
                        checked4: false
                      })
                    }}
                  >
                    <Text style={{ color: "black", textAlign: "center", marginRight: 10 }}>
                      CLEAR
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity

                    onPress={() => {
                      this.setState({ filterpopup: false });
                      this.checkFilter()
                    }}
                  >
                    <Text style={{ color: appblueColor, textAlign: "center", marginLeft: 10 }}>
                      APPLY
                    </Text>
                  </TouchableOpacity>

                </View>
              </View>
            </View>
          </View>
        </Modal>

        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                NavigationService.openDrawerr();
              }}
            >

              <Image style={{ width: 20, height: 20, marginLeft: 10 }} source={images.menu} />
            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 10 }} source={images.logo} resizeMode={'contain'} />

          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>
            <TouchableOpacity
              onPress={() => {
                this.setState({
                  filterpopup: true
                })
              }}
            >
              <Image style={{ width: 20, height: 20, }} source={images.filter} /></TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                this.setState({
                  filterpopup: true
                })
              }}
            >
              <Icon1 style={{ marginLeft: 15 }} name="bell-o" size={20} color="black" /></TouchableOpacity>
          </View>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          nestedScrollEnabled={true}
          style={styles.container}>

          {this.state.isLoading && <ActivityIndicator style={{ marginTop: 100 }} />}

          {!this.state.isLoading && <View style={{ flexDirection: 'row' }}>

            <ScrollView
              style={{ marginTop: 5, }}
              horizontal={true}
              showsHorizontalScrollIndicator={false}
            >
              <View style={{ backgroundColor: appgrayColor, paddingBottom: 20, paddingTop: 10, flexDirection: "row", flexWrap: 'wrap', width: widthPercentageToDP('100%') }}>
                {this.state.filterArr.map((item) => {
                  return (
                    <TouchableWithoutFeedback onPress={() => {

                      var index = this.state.filterArr.indexOf(item);
                      if (item.selected == 0) {
                        item.selected = 1
                        this.state.filterArr[index] = item;
                        this.setState({
                          filterArr: this.state.filterArr
                        })
                      }
                      else {
                        item.selected = 0
                        this.state.filterArr[index] = item;
                        this.setState({
                          filterArr: this.state.filterArr
                        })
                      }

                    }}>

                      <View
                        key={item.id}
                      >
                        {item.id != -1 ?
                          <Text
                            style={item.selected == 0 ? Styles.unselectedLabel : Styles.selectedLabel}
                          >
                            {item.text}
                          </Text> : <View style={{ flexDirection: 'row', marginTop: 5, marginLeft: 10 }}><Image
                            source={images.sort}
                            style={{ width: 18, height: 18, alignSelf: 'center', alignItems: 'center', padding: 5, marginRight: 5 }}
                          /><Text> Sort </Text></View>
                        }

                      </View>
                    </TouchableWithoutFeedback>
                  );
                })}
                <TouchableWithoutFeedback onPress={() => {
                  var all = this.state.filterArr;
                  all = all.map(item => {
                    this.checkSortValue(item.id, item.selected)
                    return item;
                  });
                  this.setState({
                    filterArr: all,
                  });

                }}><Text style={{ color: appbluebtnColor, alignSelf: 'flex-end', position: "absolute", right: 60, bottom: 10, fontSize: 12, fontWeight: 'bold' }}>APPLY</Text>
                </TouchableWithoutFeedback>
                <TouchableWithoutFeedback onPress={() => {
                  var all = this.state.filterArr;
                  all = all.map(item => {


                    item.selected = 0;

                    return item;
                  });
                  this.setState({
                    filterArr: all,
                  });


                }}><Text style={{ color: appbluebtnColor, alignSelf: 'flex-end', position: "absolute", right: 10, bottom: 10, fontSize: 12, fontWeight: 'bold' }}>CLEAR</Text>
                </TouchableWithoutFeedback>
              </View>
            </ScrollView>
          </View>}
              {console.log('this.state.searchList',this.state.searchList)}
          <FlatList
            data={this.state.searchList}
            nestedScrollEnabled={true}
            onEndReachedThreshold={0.01}
            renderItem={({ item }) => {
              let imageUri = (item && item.image) ? `data:${item.image && item.image.contentContentType};base64,${item.image && item.image.content}` : 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c';
              return (
                <View>

                  <TouchableOpacity
                    onPress={() => {
                      this.props.navigation.navigate('SearchDetailActivity', { courseId: item.id });
                    }}
                  >

                    <View style={{

                      paddingRight: 5,
                      paddingLeft: 5,
                      marginTop: 10,
                      justifyContent: 'center', alignItems: 'center'
                    }}>

                      {(this.state.filterValue == false) ? <View style={[styles.labelContainer]}>

                        <View style={{ flexDirection: 'row' }}>

                          <Image

                            source={{ isStatic: true, uri: imageUri }}
                            style={{
                              width: widthPercentageToDP('22%'),
                              borderRadius: 10,
                            }}
                          ></Image>

                          <View style={{ width: '80%' }}>
                            <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.subject && item.subject.subject}
                              </Text>
                              <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                {stars}
                              </View>

                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                              <View>
                                {item.teacher != null && <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item.teacher && item.teacher.firstName} {item.teacher && item.teacher.lastName}, {item.teacher && item.teacher.experienceInYear}yr</Text>}
                                <Text style={{ marginLeft: 10, fontSize: 12 }}>{item.qualification && item.teacher.qualification && item.teacher.qualification.map((item) => item.qualification)}</Text>
                              </View>

                              <View style={{ flexDirection: 'row' }}>
                                {this.state.addWishList && index === this.state.selected || item.isWishListed === true ? <TouchableOpacity onPress={() => { this.remove(item.id, index); this.checkCondition(item) }}>
                                  <Image
                                    resizeMode='contain'
                                    source={images.likeselect}
                                    style={{
                                      width: 20,
                                      height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(10)
                                    }}
                                  ></Image>
                                </TouchableOpacity> :

                                  <TouchableOpacity onPress={() => { this.wishlist(item.id, index); this.checkCondition(index) }}>
                                    <Image
                                      resizeMode='contain'
                                      source={images.shortlist_blck}
                                      style={{
                                        width: 20,
                                        height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(10)
                                      }}
                                    ></Image>
                                  </TouchableOpacity>}

                                {item.studentEnrolled > item.minBatchSize && <Image
                                  resizeMode='contain'
                                  source={images.confirmation}
                                  style={{
                                    width: 15,
                                    height: 15, position: 'absolute', top: 10, left: 10
                                  }}
                                ></Image>}
                              </View>
                            </View>
                            <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                            <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {item.startDate && moment(item.startDate).format('DD-MM-YYYY')} to {item.endDate && moment(item.endDate).format('DD-MM-YYYY')})</Text>
                            <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                              <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{item.startDate && moment(item.startDate).format('hh:mm')} to {item.startDate && moment(item.endDate).format('hh:mm')}</Text>
                              <View style={{ flexDirection: 'row', marginRight: 10 }}>
                                {(item.courseDays && item.courseDays.length > 0) ? item.courseDays.map(i => {
                                  return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                                }) : null}

                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                <Text style={{ color: loginheaderColor }}>{item.status ? 'Open' : 'Completed'}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>Number of Classes</Text>
                                <Text style={{ color: loginheaderColor, alignSelf: 'center' }}>{item?.courseClasses?.length}</Text>
                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10, marginBottom: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                                <Text style={{ color: loginheaderColor }}>{item.totalEnroledStudents}/{item.maxBatchSize}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>{item.courseSubscriptionModes.map((item) => item.subscriptionModeId.name)}</Text>
                                <Text style={{ color: loginheaderColor }}>{item.fee}</Text>
                              </View>
                            </View>
                          </View>
                        </View>
                      </View> :
                        (
                          (this.state.checked4 && (item.minBatchSize === item.totalEnrolledStudents)) &&
                          <View style={[styles.labelContainer]}>
                            <View style={{ flexDirection: 'row' }}>

                              <Image

                                source={{ isStatic: true, uri: imageUri }}
                                style={{
                                  width: widthPercentageToDP('22%'),
                                  borderRadius: 10,
                                }}
                              ></Image>

                              <View style={{ width: '80%' }}>
                                <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                                  <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.subject && item.subject.subject}
                                  </Text>
                                  <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                    {stars}
                                  </View>

                                </View>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                                  <View>
                                    <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item.teacher && item.teacher.firstName} {item.teacher && item.teacher.lastName}, {item.teacher && item.teacher.experienceInYear}yr</Text>
                                    <Text style={{ marginLeft: 10, fontSize: 12 }}>{item.qualification && item.teacher.qualification && item.teacher.qualification.map((item) => item.qualification)}</Text>
                                  </View>
                                  <View style={{ flexDirection: 'row' }}>
                                    {this.state.addWishList && index === this.state.selected || item.isWishListed === true ? <TouchableOpacity onPress={() => { this.remove(item.id, index); this.checkCondition(item) }}>
                                      <Image
                                        resizeMode='contain'
                                        source={images.likeselect}
                                        style={{
                                          width: 20,
                                          height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                        }}
                                      ></Image>
                                    </TouchableOpacity> :

                                      <TouchableOpacity onPress={() => { this.wishlist(item.id, index); this.checkCondition(index) }}>
                                        <Image
                                          resizeMode='contain'
                                          source={images.shortlist_blck}
                                          style={{
                                            width: 20,
                                            height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                          }}
                                        ></Image>
                                      </TouchableOpacity>}

                                    {item.studentEnrolled > item.minBatchSize && <Image
                                      resizeMode='contain'
                                      source={images.confirmation}
                                      style={{
                                        width: 15,
                                        height: 15, position: 'absolute', top: 10, left: 10
                                      }}
                                    ></Image>}
                                  </View>
                                </View>
                                <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                                <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {item.startDate && moment(item.startDate).format('DD-MM-YYYY')} to {item.endDate && moment(item.endDate).format('DD-MM-YYYY')})</Text>
                                <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                                  <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{item.startDate && moment(item.startDate).format('hh:mm')} to {item.startDate && moment(item.endDate).format('hh:mm')}</Text>
                                  <View style={{ flexDirection: 'row', marginRight: 10 }}>
                                    {(item.courseDays && item.courseDays.length > 0) ? item.courseDays.map(i => {
                                      return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                                    }) : null}

                                  </View>
                                </View>

                                <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                                  <View>
                                    <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                    <Text style={{ color: loginheaderColor }}>{item.status ? 'Open' : 'Completed'}</Text>
                                  </View>
                                  <View style={{ right: 20 }}>
                                    <Text style={{ fontSize: 10 }}>Number of Classes</Text>
                                    <Text style={{ color: loginheaderColor, alignSelf: 'center' }}>{item?.courseClasses?.length}</Text>
                                  </View>
                                </View>

                                <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10, marginBottom: 10 }}>
                                  <View>
                                    <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                                    <Text style={{ color: loginheaderColor }}>{item.totalEnroledStudents}/{item.maxBatchSize}</Text>
                                  </View>
                                  <View style={{ right: 20 }}>
                                    <Text style={{ fontSize: 10 }}>{item.courseSubscriptionModes.map((item) => item.subscriptionModeId.name)}</Text>
                                    <Text style={{ color: loginheaderColor }}>{item.fee}</Text>
                                  </View>
                                </View>
                              </View>
                            </View>
                          </View>)}

                      {(this.state.checked2 && item.recommendation) && <View style={[styles.labelContainer]}>
                        <View style={{ flexDirection: 'row' }}>

                          <Image

                            source={{ isStatic: true, uri: imageUri }}
                            style={{
                              width: widthPercentageToDP('22%'),
                              borderRadius: 10,
                            }}
                          ></Image>

                          <View style={{ width: '80%' }}>
                            <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.subject && item.subject.subject}
                              </Text>
                              <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                {stars}
                              </View>

                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                              <View>
                                <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item.teacher && item.teacher.firstName} {item.teacher && item.teacher.lastName}, {item.teacher && item.teacher.experienceInYear}yr</Text>
                                <Text style={{ marginLeft: 10, fontSize: 12 }}>{item.qualification && item.teacher.qualification && item.teacher.qualification.map((item) => item.qualification)}</Text>
                              </View>
                              <View style={{ flexDirection: 'row' }}>
                                {this.state.addWishList && index === this.state.selected || item.isWishListed === true ? <TouchableOpacity onPress={() => { this.remove(item.id, index); this.checkCondition(item) }}>
                                  <Image
                                    resizeMode='contain'
                                    source={images.likeselect}
                                    style={{
                                      width: 20,
                                      height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                    }}
                                  ></Image>
                                </TouchableOpacity> :

                                  <TouchableOpacity onPress={() => { this.wishlist(item.id, index); this.checkCondition(index) }}>
                                    <Image
                                      resizeMode='contain'
                                      source={images.shortlist_blck}
                                      style={{
                                        width: 20,
                                        height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                      }}
                                    ></Image>
                                  </TouchableOpacity>}
                                {item.studentEnrolled > item.minBatchSize && <Image
                                  resizeMode='contain'
                                  source={images.confirmation}
                                  style={{
                                    width: 15,
                                    height: 15, position: 'absolute', top: 10, left: 10
                                  }}
                                ></Image>}
                              </View>
                            </View>
                            <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                            <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {item.startDate && moment(item.startDate).format('DD-MM-YYYY')} to {item.endDate && moment(item.endDate).format('DD-MM-YYYY')})</Text>
                            <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                              <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{item.startDate && moment(item.startDate).format('hh:mm')} to {item.startDate && moment(item.endDate).format('hh:mm')}</Text>
                              <View style={{ flexDirection: 'row', marginRight: 10 }}>
                                {(item.courseDays && item.courseDays.length > 0) ? item.courseDays.map(i => {
                                  return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                                }) : null}

                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                <Text style={{ color: loginheaderColor }}>{item.status ? 'Open' : 'Completed'}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>Number of Classes</Text>
                                <Text style={{ color: loginheaderColor,alignSelf:'center' }}>{item?.courseClasses?.length}</Text>
                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10, marginBottom: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                                <Text style={{ color: loginheaderColor }}>{item.totalEnroledStudents}/{item.maxBatchSize}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>{item.courseSubscriptionModes.map((item) => item.subscriptionModeId.name)}</Text>
                                <Text style={{ color: loginheaderColor }}>Rs. {item.fee}</Text>
                              </View>
                            </View>
                          </View>
                        </View>
                      </View>}

                      {(this.state.checked1 && item.courseStatus != 2) && <View style={[styles.labelContainer]}>
                        <View style={{ flexDirection: 'row' }}>

                          <Image

                            source={{ isStatic: true, uri: imageUri }}
                            style={{
                              width: widthPercentageToDP('22%'),
                              borderRadius: 10,
                            }}
                          ></Image>

                          <View style={{ width: '80%' }}>
                            <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.subject && item.subject.subject}
                              </Text>
                              <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                {stars}
                              </View>

                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                              <View>
                                <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item.teacher && item.teacher.firstName} {item.teacher && item.teacher.lastName}, {item.teacher && item.teacher.experienceInYear}yr</Text>
                                <Text style={{ marginLeft: 10, fontSize: 12 }}>{item.qualification && item.teacher.qualification && item.teacher.qualification.map((item) => item.qualification)}</Text>
                              </View>
                              <View style={{ flexDirection: 'row' }}>
                                {this.state.addWishList && index === this.state.selected || item.isWishListed === true ? <TouchableOpacity onPress={() => { this.remove(item.id, index); this.checkCondition(item) }}>
                                  <Image
                                    resizeMode='contain'
                                    source={images.likeselect}
                                    style={{
                                      width: 20,
                                      height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                    }}
                                  ></Image>
                                </TouchableOpacity> :

                                  <TouchableOpacity onPress={() => { this.wishlist(item.id, index); this.checkCondition(index) }}>
                                    <Image
                                      resizeMode='contain'
                                      source={images.shortlist_blck}
                                      style={{
                                        width: 20,
                                        height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                      }}
                                    ></Image>
                                  </TouchableOpacity>}

                                {item.studentEnrolled > item.minBatchSize && <Image
                                  resizeMode='contain'
                                  source={images.confirmation}
                                  style={{
                                    width: 15,
                                    height: 15, position: 'absolute', top: 10, left: 10
                                  }}
                                ></Image>}
                              </View>
                            </View>
                            <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                            <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {item.startDate && moment(item.startDate).format('DD-MM-YYYY')} to {item.endDate && moment(item.endDate).format('DD-MM-YYYY')})</Text>
                            <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                              <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{item.startDate && moment(item.startDate).format('hh:mm')} to {item.startDate && moment(item.endDate).format('hh:mm')}</Text>
                              <View style={{ flexDirection: 'row', marginRight: 10 }}>
                                {(item.courseDays && item.courseDays.length > 0) ? item.courseDays.map(i => {
                                  return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                                }) : null}

                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                <Text style={{ color: loginheaderColor }}>{item.status ? 'Open' : 'Completed'}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>Number of Classes</Text>
                                <Text style={{ color: loginheaderColor,alignSelf:'center' }}>{item?.courseClasses?.length}</Text>
                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10, marginBottom: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                                <Text style={{ color: loginheaderColor }}>{item.totalEnroledStudents}/{item.maxBatchSize}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>{item.courseSubscriptionModes.map((item) => item.subscriptionModeId.name)}</Text>
                                <Text style={{ color: loginheaderColor }}>Rs. {item.fee}</Text>
                              </View>
                            </View>
                          </View>
                        </View>
                      </View>}

                      {(this.state.checked1 && item.courseStatus != 2) && (this.state.checked2 && item.recommendation == true) && <View style={[styles.labelContainer]}>
                        <View style={{ flexDirection: 'row' }}>

                          <Image

                            source={{ isStatic: true, uri: imageUri }}
                            style={{
                              width: widthPercentageToDP('22%'),
                              borderRadius: 10,
                            }}
                          ></Image>

                          <View style={{ width: '80%' }}>
                            <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.subject && item.subject.subject}
                              </Text>
                              <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                {stars}
                              </View>

                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                              <View>
                                <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item.teacher && item.teacher.firstName} {item.teacher && item.teacher.lastName}, {item.teacher && item.teacher.experienceInYear}yr</Text>
                                <Text style={{ marginLeft: 10, fontSize: 12 }}>{item.qualification && item.teacher.qualification && item.teacher.qualification.map((item) => item.qualification)}</Text>
                              </View>
                              <View style={{ flexDirection: 'row' }}>
                                {this.state.addWishList && index === this.state.selected || item.isWishListed === true ? <TouchableOpacity onPress={() => { this.remove(item.id, index); this.checkCondition(item) }}>
                                  <Image
                                    resizeMode='contain'
                                    source={images.likeselect}
                                    style={{
                                      width: 20,
                                      height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                    }}
                                  ></Image>
                                </TouchableOpacity> :

                                  <TouchableOpacity onPress={() => { this.wishlist(item.id, index); this.checkCondition(index) }}>
                                    <Image
                                      resizeMode='contain'
                                      source={images.shortlist_blck}
                                      style={{
                                        width: 20,
                                        height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                      }}
                                    ></Image>
                                  </TouchableOpacity>}

                                {item.studentEnrolled > item.minBatchSize && <Image
                                  resizeMode='contain'
                                  source={images.confirmation}
                                  style={{
                                    width: 15,
                                    height: 15, position: 'absolute', top: 10, left: 10
                                  }}
                                ></Image>}
                              </View>
                            </View>
                            <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                            <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {item.startDate && moment(item.startDate).format('DD-MM-YYYY')} to {item.endDate && moment(item.endDate).format('DD-MM-YYYY')})</Text>
                            <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                              <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{item.startDate && moment(item.startDate).format('hh:mm')} to {item.startDate && moment(item.endDate).format('hh:mm')}</Text>
                              <View style={{ flexDirection: 'row', marginRight: 10 }}>
                                {(item.courseDays && item.courseDays.length > 0) ? item.courseDays.map(i => {
                                  return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                                }) : null}

                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                <Text style={{ color: loginheaderColor }}>{item.status ? 'Open' : 'Completed'}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>Number of Classes</Text>
                                <Text style={{ color: loginheaderColor,alignSelf:'center' }}>{item?.courseClasses?.length}</Text>
                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10, marginBottom: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                                <Text style={{ color: loginheaderColor }}>{item.totalEnroledStudents}/{item.maxBatchSize}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>{item.courseSubscriptionModes.map((item) => item.subscriptionModeId.name)}</Text>
                                <Text style={{ color: loginheaderColor }}>Rs. {item.fee}</Text>
                              </View>
                            </View>
                          </View>
                        </View>
                      </View>}

                      {(this.state.checked1 && item.courseStatus != 2) && (this.state.checked4 && (item.minBatchSize === item.totalEnrolledStudents)) && <View style={[styles.labelContainer]}>
                        <View style={{ flexDirection: 'row' }}>

                          <Image

                            source={{ isStatic: true, uri: imageUri }}
                            style={{
                              width: widthPercentageToDP('22%'),
                              borderRadius: 10,
                            }}
                          ></Image>

                          <View style={{ width: '80%' }}>
                            <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.subject && item.subject.subject}
                              </Text>
                              <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                {stars}
                              </View>

                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                              <View>
                                <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item.teacher && item.teacher.firstName} {item.teacher && item.teacher.lastName}, {item.teacher && item.teacher.experienceInYear}yr</Text>
                                <Text style={{ marginLeft: 10, fontSize: 12 }}>{item.qualification && item.teacher.qualification && item.teacher.qualification.map((item) => item.qualification)}</Text>
                              </View>
                              <View style={{ flexDirection: 'row' }}>
                                {this.state.addWishList && index === this.state.selected || item.isWishListed === true ? <TouchableOpacity onPress={() => { this.remove(item.id, index); this.checkCondition(item) }}>
                                  <Image
                                    resizeMode='contain'
                                    source={images.likeselect}
                                    style={{
                                      width: 20,
                                      height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                    }}
                                  ></Image>
                                </TouchableOpacity> :

                                  <TouchableOpacity onPress={() => { this.wishlist(item.id, index); this.checkCondition(index) }}>
                                    <Image
                                      resizeMode='contain'
                                      source={images.shortlist_blck}
                                      style={{
                                        width: 20,
                                        height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                      }}
                                    ></Image>
                                  </TouchableOpacity>}

                                {item.studentEnrolled > item.minBatchSize && <Image
                                  resizeMode='contain'
                                  source={images.confirmation}
                                  style={{
                                    width: 15,
                                    height: 15, position: 'absolute', top: 10, left: 10
                                  }}
                                ></Image>}
                              </View>
                            </View>
                            <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                            <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {item.startDate && moment(item.startDate).format('DD-MM-YYYY')} to {item.endDate && moment(item.endDate).format('DD-MM-YYYY')})</Text>
                            <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                              <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{item.startDate && moment(item.startDate).format('hh:mm')} to {item.startDate && moment(item.endDate).format('hh:mm')}</Text>
                              <View style={{ flexDirection: 'row', marginRight: 10 }}>
                                {(item.courseDays && item.courseDays.length > 0) ? item.courseDays.map(i => {
                                  return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                                }) : null}

                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                <Text style={{ color: loginheaderColor }}>{item.status ? 'Open' : 'Completed'}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>Number of Classes</Text>
                                <Text style={{ color: loginheaderColor,alignSelf:'center' }}>{item?.courseClasses?.length}</Text>
                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10, marginBottom: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                                <Text style={{ color: loginheaderColor }}>{item.totalEnroledStudents}/{item.maxBatchSize}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>{item.courseSubscriptionModes.map((item) => item.subscriptionModeId.name)}</Text>
                                <Text style={{ color: loginheaderColor }}>Rs. {item.fee}</Text>
                              </View>
                            </View>
                          </View>
                        </View>
                      </View>}

                      {(this.state.checked2 && item.recommendation == true) && (this.state.checked4 && (item.minBatchSize === item.totalEnrolledStudents)) && <View style={[styles.labelContainer]}>
                        <View style={{ flexDirection: 'row' }}>

                          <Image

                            source={{ isStatic: true, uri: imageUri }}
                            style={{
                              width: widthPercentageToDP('22%'),
                              borderRadius: 10,
                            }}
                          ></Image>

                          <View style={{ width: '80%' }}>
                            <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.subject && item.subject.subject}
                              </Text>
                              <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                {stars}
                              </View>

                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                              <View>
                                <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item.teacher && item.teacher.firstName} {item.teacher && item.teacher.lastName}, {item.teacher && item.teacher.experienceInYear}yr</Text>
                                <Text style={{ marginLeft: 10, fontSize: 12 }}>{item.qualification && item.teacher.qualification && item.teacher.qualification.map((item) => item.qualification)}</Text>
                              </View>
                              <View style={{ flexDirection: 'row' }}>
                                {this.state.addWishList && index === this.state.selected || item.isWishListed === true ? <TouchableOpacity onPress={() => { this.remove(item.id, index); this.checkCondition(item) }}>
                                  <Image
                                    resizeMode='contain'
                                    source={images.likeselect}
                                    style={{
                                      width: 20,
                                      height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                    }}
                                  ></Image>
                                </TouchableOpacity> :

                                  <TouchableOpacity onPress={() => { this.wishlist(item.id, index); this.checkCondition(index) }}>
                                    <Image
                                      resizeMode='contain'
                                      source={images.shortlist_blck}
                                      style={{
                                        width: 20,
                                        height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                      }}
                                    ></Image>
                                  </TouchableOpacity>}

                                {item.studentEnrolled > item.minBatchSize && <Image
                                  resizeMode='contain'
                                  source={images.confirmation}
                                  style={{
                                    width: 15,
                                    height: 15, position: 'absolute', top: 10, left: 10
                                  }}
                                ></Image>}
                              </View>
                            </View>
                            <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                            <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {item.startDate && moment(item.startDate).format('DD-MM-YYYY')} to {item.endDate && moment(item.endDate).format('DD-MM-YYYY')})</Text>
                            <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                              <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{item.startDate && moment(item.startDate).format('hh:mm')} to {item.startDate && moment(item.endDate).format('hh:mm')}</Text>
                              <View style={{ flexDirection: 'row', marginRight: 10 }}>
                                {(item.courseDays && item.courseDays.length > 0) ? item.courseDays.map(i => {
                                  return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                                }) : null}

                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                <Text style={{ color: loginheaderColor }}>{item.status ? 'Open' : 'Completed'}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>Number of Classes</Text>
                                <Text style={{ color: loginheaderColor,alignSelf:'center' }}>{item?.courseClasses?.length}</Text>
                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10, marginBottom: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                                <Text style={{ color: loginheaderColor }}>{item.totalEnroledStudents}/{item.maxBatchSize}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>{item.courseSubscriptionModes.map((item) => item.subscriptionModeId.name)}</Text>
                                <Text style={{ color: loginheaderColor }}>Rs. {item.fee}</Text>
                              </View>
                            </View>
                          </View>
                        </View>
                      </View>}

                      {(this.state.checked1 && item.courseStatus != 2) && (this.state.checked2 == true && item.recommendation === true) && (this.state.checked4 && (item.minBatchSize === item.totalEnrolledStudents)) && <View style={[styles.labelContainer]}>
                        <View style={{ flexDirection: 'row' }}>

                          <Image

                            source={{ isStatic: true, uri: imageUri }}
                            style={{
                              width: widthPercentageToDP('22%'),
                              borderRadius: 10,
                            }}
                          ></Image>

                          <View style={{ width: '80%' }}>
                            <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.subject && item.subject.subject}
                              </Text>
                              <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                {stars}
                              </View>

                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                              <View>
                                <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item.teacher && item.teacher.firstName} {item.teacher && item.teacher.lastName}, {item.teacher && item.teacher.experienceInYear}yr</Text>
                                <Text style={{ marginLeft: 10, fontSize: 12 }}>{item.qualification && item.teacher.qualification && item.teacher.qualification.map((item) => item.qualification)}</Text>
                              </View>
                              <View style={{ flexDirection: 'row' }}>
                                {this.state.addWishList && index === this.state.selected || item.isWishListed === true ? <TouchableOpacity onPress={() => { this.remove(item.id, index); this.checkCondition(item) }}>
                                  <Image
                                    resizeMode='contain'
                                    source={images.likeselect}
                                    style={{
                                      width: 20,
                                      height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                    }}
                                  ></Image>
                                </TouchableOpacity> :

                                  <TouchableOpacity onPress={() => { this.wishlist(item.id, index); this.checkCondition(index) }}>
                                    <Image
                                      resizeMode='contain'
                                      source={images.shortlist_blck}
                                      style={{
                                        width: 20,
                                        height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                      }}
                                    ></Image>
                                  </TouchableOpacity>}

                                {item.studentEnrolled > item.minBatchSize && <Image
                                  resizeMode='contain'
                                  source={images.confirmation}
                                  style={{
                                    width: 15,
                                    height: 15, position: 'absolute', top: 10, left: 10
                                  }}
                                ></Image>}
                              </View>
                            </View>
                            <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                            <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {item.startDate && moment(item.startDate).format('DD-MM-YYYY')} to {item.endDate && moment(item.endDate).format('DD-MM-YYYY')})</Text>
                            <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                              <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{item.startDate && moment(item.startDate).format('hh:mm')} to {item.startDate && moment(item.endDate).format('hh:mm')}</Text>
                              <View style={{ flexDirection: 'row', marginRight: 10 }}>
                                {(item.courseDays && item.courseDays.length > 0) ? item.courseDays.map(i => {
                                  return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                                }) : null}

                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                <Text style={{ color: loginheaderColor }}>{item.status ? 'Open' : 'Completed'}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>Number of Classes</Text>
                                <Text style={{ color: loginheaderColor,alignSelf:'center' }}>{item?.courseClasses?.length}</Text>
                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10, marginBottom: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                                <Text style={{ color: loginheaderColor }}>{item.totalEnroledStudents}/{item.maxBatchSize}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>{item.courseSubscriptionModes.map((item) => item.subscriptionModeId.name)}</Text>
                                <Text style={{ color: loginheaderColor }}>Rs. {item.fee}</Text>
                              </View>
                            </View>
                          </View>
                        </View>
                      </View>}
                    </View>

                  </TouchableOpacity>


                </View>)
            }
            }
          />
         
          <FlatList
            data={this.props.getSearchData && this.props.getSearchData.data}
            nestedScrollEnabled={true}
            onEndReachedThreshold={0.01}
            renderItem={({ item }) => {

              let imageUri = (item && item.image) ? `data:${item.image && item.image.contentContentType};base64,${item.image && item.image.content}` : 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c';
              return (
                <View

                >
                  <TouchableOpacity
                    onPress={() => {
                      this.props.navigation.navigate('SearchDetailActivity', { courseId: item.id });
                    }}
                  >
                    <View style={{

                      paddingRight: 5,
                      paddingLeft: 5,
                      marginTop: 10,
                      justifyContent: 'center', alignItems: 'center'
                    }}>
                      <View style={styles.labelContainer}>

                        <View style={{ flexDirection: 'row' }}>

                          <Image

                            source={{ isStatic: true, uri: imageUri }}
                            style={{
                              width: widthPercentageToDP('22%'),
                              borderRadius: 10,
                            }}
                          ></Image>

                          <View style={{ width: '80%' }}>
                            <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.name} {','} {item.standard && "Class" + "-" + item.standard.class}
                              </Text>
                              <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                {stars}
                              </View>

                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                              <View>
                                <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item.teacherName}, 5yr</Text>
                                <Text style={{ marginLeft: 10, fontSize: 12 }}>M.A. Science</Text>
                              </View>
                              {this.state.addWishList && index === this.state.selected || item.isWishListed === true ? <TouchableOpacity onPress={() => { this.remove(item.id, index); this.checkCondition(item) }}>
                                <Image
                                  resizeMode='contain'
                                  source={images.likeselect}
                                  style={{
                                    width: 20,
                                    height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                  }}
                                ></Image>
                              </TouchableOpacity> :

                                <TouchableOpacity onPress={() => { this.wishlist(item.id, index); this.checkCondition(index) }}>
                                  <Image
                                    resizeMode='contain'
                                    source={images.shortlist_blck}
                                    style={{
                                      width: 20,
                                      height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                    }}
                                  ></Image>
                                </TouchableOpacity>}

                              {item.studentEnrolled > item.minBatchSize && <Image
                                resizeMode='contain'
                                source={images.confirmation}
                                style={{
                                  width: 20,
                                  height: 20,
                                }}
                              ></Image>}
                            </View>
                            <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                            <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {item.startDate && moment(item.startDate).format('DD-MM-YYYY')} to {item.endDate && moment(item.endDate).format('DD-MM-YYYY')})</Text>
                            <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                              <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{item.courseClasses && item.courseClasses[0] && item.courseClasses[0].startTime} to {item.courseClasses && item.courseClasses[0] && item.courseClasses[0].endTime}</Text>
                              <View style={{ flexDirection: 'row', marginRight: 10 }}>
                                {(item.courseDays && item.courseDays.length > 0) ? item.courseDays.map(i => {
                                  return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                                }) : null}

                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                <Text style={{ color: loginheaderColor }}>{item.status ? 'Open' : 'Completed'}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>Number of Classes</Text>
                                <Text style={{ color: loginheaderColor }}>{item?.courseClasses?.length}</Text>
                              </View>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10, marginBottom: 10 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                                <Text style={{ color: loginheaderColor }}>{item.studentEnrolled}/{item.maxBatchSize}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>{item.courseSubscriptionModes.map((item) => item.subscriptionModeId.name)}</Text>
                                <Text style={{ color: loginheaderColor }}>Rs. {item.fee}</Text>
                              </View>
                            </View>
                          </View>
                        </View>
                      </View>
                    </View>

                  </TouchableOpacity>



                </View>)
            }
            }
          />
          {console.log('this.props.topCourseList',this.props.topCourseList)}
          {this.state.visibility &&

            <FlatList
              data={this.props.topCourseList && this.props.topCourseList.data}
              nestedScrollEnabled={true}
              onEndReachedThreshold={0.01}
              renderItem={({ item }) => {

                let imageUri = (item && item.image) ? `data:${item.image && item.image.contentContentType};base64,${item.image && item.image.content}` : 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c';
                return (
                  <View
                  >
                    <TouchableOpacity
                      onPress={() => {
                        this.props.navigation.navigate('SearchDetailActivity', { courseId: item.id });
                      }}

                    >
                      <View style={{

                        paddingRight: 5,
                        paddingLeft: 5,
                        marginTop: 10,
                        justifyContent: 'center', alignItems: 'center'
                      }}>
                        <View style={[styles.labelContainer]}>

                          <View style={{ flexDirection: 'row' }}>

                            <Image

                              source={{ isStatic: true, uri: imageUri }}
                              style={{
                                width: widthPercentageToDP('22%'),
                                borderRadius: 10,
                              }}
                            ></Image>

                            <View style={{ width: '80%' }}>
                              <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                                <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.name} {','} {item.standard && "Class" + "-" + item.standard.class}
                                </Text>
                                <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                  {stars}
                                </View>

                              </View>
                              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                                <View>
                                  <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item.courseUsers.map((item) => item && item.userId && item.userId.firstName)}{' '}{item.courseUsers.map((item) => item && item.userId && item.userId.lastName)}</Text>
                                  {/* <Text style={{ marginLeft: 10, fontSize: 12 }}>Missing</Text> */}
                                </View>
                                {this.state.addWishList && index === this.state.selected || item.isWishListed === true ? <TouchableOpacity onPress={() => { this.remove(item.id, index); this.checkCondition(item) }}>
                                  <Image
                                    resizeMode='contain'
                                    source={images.likeselect}
                                    style={{
                                      width: 20,
                                      height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                    }}
                                  ></Image>
                                </TouchableOpacity> :

                                  <TouchableOpacity onPress={() => { this.wishlist(item.id, index); this.checkCondition(index) }}>
                                    <Image
                                      resizeMode='contain'
                                      source={images.shortlist_blck}
                                      style={{
                                        width: 20,
                                        height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(50)
                                      }}
                                    ></Image>
                                  </TouchableOpacity>}


                                {item.studentEnrolled > item.minBatchSize && <Image
                                  resizeMode='contain'
                                  source={images.confirmation}
                                  style={{
                                    width: 15,
                                    height: 15, position: 'absolute', top: 10, left: 10
                                  }}
                                ></Image>}
                              </View>
                              <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                              <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {item.startDate && moment(item.startDate).format('DD-MM-YYYY')} to {item.endDate && moment(item.endDate).format('DD-MM-YYYY')})</Text>
                              <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                                <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{moment(item.startDate).format('hh:mm')} to {moment(item.endDate).format('hh:mm')}</Text>
                                <View style={{ flexDirection: 'row', marginRight: 10 }}>
                                  {(item.courseDays && item.courseDays.length > 0) ? item.courseDays.map(i => {
                                    return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                                  }) : null}

                                </View>
                              </View>

                              <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                                <View>
                                  <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                  <Text style={{ color: loginheaderColor }}>{item.status ? 'Open' : 'Completed'}</Text>
                                </View>
                                <View style={{ right: 20 }}>
                                  <Text style={{ fontSize: 10 }}>DURATION</Text>
                                  <Text style={{ color: loginheaderColor }}>{item.courseDuration}</Text>
                                </View>
                              </View>

                              <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10, marginBottom: 10 }}>
                                <View>
                                  <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                                  <Text style={{ color: loginheaderColor }}>{item.studentEnrolled}/{item.maxBatchSize}</Text>
                                </View>
                                <View style={{ right: 20 }}>
                                  <Text style={{ fontSize: 10 }}>{item.courseSubscriptionModes && item.courseSubscriptionModes.map((item) => item.subscriptionModeId.name)}</Text>
                                  <Text style={{ color: loginheaderColor }}>Rs. {item.fee}</Text>
                                </View>
                              </View>
                            </View>
                          </View>
                        </View>
                      </View>

                    </TouchableOpacity>



                  </View>)
              }
              }
            />

          }

        </ScrollView >

        <View style={{
          flex: 1,
          flexDirection: 'row',
          flexWrap: 'wrap',
          alignContent: 'center',
          justifyContent: 'space-around',
          // paddingLeft: 15,
          // padding: 5,
          position: 'absolute',
          bottom: 0,
          alignSelf: 'center'
        }}>

        </View>
      </View >
    )
  }

}

const mapStateToProps = state => ({
  // user: state.auth,
  dash: state.dash,
  getSearchData: state.dash.getSearchData,
  addtoWishListData: state.dash.addtoWishListData,
  ratingData: state.dash.ratingData,
  topCourseList: state.dash.courseData,
  removeWishListData: state.dash.removeWishListData,
});

const mapDispatchToProps = {
  getFilteredData, addWishlistedData, removeWishlistedData
}

export default connect(mapStateToProps, mapDispatchToProps)(AdvanceSearchActivity);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
