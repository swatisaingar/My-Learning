import React, { Component, useState } from 'react'
import {
  StatusBar,
  TouchableOpacity,
  View,
  ScrollView,
  FlatList,
  Text,
  TouchableWithoutFeedback,
  BackHandler,
  ToastAndroid,
  PermissionsAndroid,
  Image,
  TextInput,
  ActivityIndicator,
  StyleSheet,

  Linking,
  SafeAreaView,
} from 'react-native'
import images from '../../util/img'
import Styles from '../../uistyles/Styles'
import NavigationService from '../../Services/NavigationService'
import Icon1 from 'react-native-vector-icons/FontAwesome'
import Modal from 'react-native-modal'
import {
  loginheaderColor,
  appgrayColor,
  appbluebtnColor,
  appcountColor,
  appheadertextColor,
  appblueColor,
  rescheduleClassBgColor,
} from '../../util/AppConstants'
import { Dropdown } from 'react-native-material-dropdown'
import { heightPercentageToDP, widthPercentageToDP } from '../../constants/styles'
import { Checkbox } from 'react-native-paper'
import { connect } from 'react-redux'
import {
  getsuggestedTeachers,
  getTopCourses,
  getAssignments,
  getClasses,
  scanApi,
  // getCourseDetail,
  fetchSearchData,
  getTeacherClassesData,
  getTeacherClassesDataFilter,
  profile,
  dashBoradClassCancelCall,
} from '../../actions'
import moment from 'moment'
import QRCodeScanner from 'react-native-qrcode-scanner'
import QRCode from 'react-native-qrcode-svg'
import Share from 'react-native-share'
import RNFS from 'react-native-fs'
import CameraRoll from '@react-native-community/cameraroll'
import { isEmpty, now } from 'lodash';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../../util/AppConstants';

var currentCount = 0;
let backHandlerClickCount = 0;
class DashboardScreen extends Component {
  static navigationOptions = {
    headerShown: false,
  }
  constructor(props) {
    super(props);
    this.state = {
      imageLoading: true,
      firstName: '',
      experienceInYear: '',
      image: '',
      topImage: '',
      qualification: '',
      id: '',
      isLoading: false,
      later: true,
      searchpopup: false,
      filterpopup: false,
      vendorArr: [],
      suggestedTeacherList: [],
      upcomingClassList: [],
      topCourseList: [],
      assignmentList: [],
      scanedCouseList: [],
      imageUri: '',
      showQr: false,
      showQr1: false,
      catListValues: [],
      language: [],
      standard: [],
      selectedCat: '',
      selectedClass: '',
      selectedSub: '',
      selectedBoard: '',
      selectedLang: '',
      subject: [],
      selectedText: '',
      qrcodevalue: '',
      IdStored: [],
      profileImage: {},
      concatedArrayforSearchTeacher:[],
      simages: [
        {
          id: 1,
          title: 'course title',
          ratting: '10/50',
          price: 'Rs. 3000',
          teacher: 'Sooraj Rai',
          image:
            'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c',
        },
        {
          id: 1,
          title: 'course title2',
          ratting: '17/50',
          price: 'Rs. 8000',
          teacher: 'Priyanka ji',
          image:
            'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c',
        },
        {
          id: 1,
          title: 'course title2',
          ratting: '17/50',
          price: 'Rs. 8000',
          teacher: 'Priyanka ji',
          image:
            'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c',
        },
        {
          id: 1,
          title: 'course title2',
          ratting: '17/50',
          price: 'Rs. 8000',
          teacher: 'Priyanka ji',
          image:
            'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c',
        },
      ],
      canceltext: false,
      teacherClassesList: [],
      showStartClassDialog: false,
      teacherSearchText: '',
      teacherClassSelected: null,
      showStartClassDialog: false,
      selectedDate: '',
      showDatePicker: true,
      date: new Date(1598051730000),
      mode: 'date',
      calledFirstTime: true,
      teacherListIamgeData: [],
      imageLoad: 1,
      imageData: {},
      validCloseWindow: false,
      backPressed: 0
    }

  }

  finalData = [];
  finalTeacherData = [];
  finalScandata = [];
  finalUpcomingdata = [];

  setDatePickerVisibility(show) {
    if(!this.state.showDatePicker){
      this.setState({ showDatePicker: show })

    }
  }

  handleConfirm = (date) => {
    hideDatePicker();
  };

  check = () => {
    if (this.state.clickcount < 2) {
      //   Toast.show({
      //     text:"Press back again to exit App ",
      //     duration:2000,
      //     onClose:()=>{this.setState({clickcount:0})}
      // })
      // ToastAndroid.show("Press Again")
    }
    else if (this.state.clickcount == 2) {
      BackHandler.exitApp()
    }
  }

  handleBackButtonClick = () => {
    if (this.state.backPressed > 0) {
      console.log('executedddd')
      BackHandler.exitApp();
      this.state.backPressed = 0;
    } else {
      this.state.backPressed++;
      ToastAndroid.show("Press Again To Exit", ToastAndroid.SHORT);
      setTimeout(() => { this.state.backPressed = 0 }, 2000);
      return true;
    }
  
  }

  //   handleBackButton = () => {
  //     if (!this.props.navigation.goBack()) {
  //         if (this.state.validCloseWindow)
  //             return false;
  //         this.state.validCloseWindow = true
  //         setTimeout(() => {
  //             this.state.validCloseWindow = false
  //         }, 3000);
  //         ToastAndroid.show("Press Again To Exit !", ToastAndroid.SHORT);
  //         BackHandler.exitApp();
  //         return true;
  //     }
  // };




  saveQRCode = () => {
    this.svg.toDataURL(this.callback)
  }

  callback(dataURL) {
    let shareImageBase64 = {
      title: 'React Native',
      url: `data:image/png;base64,${dataURL}`,
      subject: 'Share Link',
    }

    Share.open(shareImageBase64).catch(error => console.log(error))
  }

  downloadQRCode = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        {
          title: 'Cool Photo App Camera Permission',
          message:
            'Cool Photo App needs access to your camera ' +
            'so you can take awesome pictures.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      )
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.svg.toDataURL(data => {
          RNFS.writeFile(
            RNFS.CachesDirectoryPath + '/some-name.png',
            data,
            'base64',
          )
            .then(success => {
              return CameraRoll.save(
                RNFS.CachesDirectoryPath + '/some-name.png',
                'photo',
              )
            })
            .then(() => {
              ToastAndroid.show('Saved to gallery !!', ToastAndroid.SHORT)
            })
        })
      } else {
        console.log('Camera permission denied')
      }
    } catch (err) {
      console.warn(err)
    }
  }

  onChange() {
    console.log("date is selected----", "True")
  }
  componentDidMount = async () => {
    BackHandler.addEventListener('hardwareBackPress', this.handleBackButtonClick.bind(this));
    //console,log("base url ", `https://api.idutor.tk/api/`)
    let AuthToken = await AsyncStorage.getItem('id_token');
    const { profile } = this.props;
    let profileData = await AsyncStorage.getItem('user_id');
    await profile(profileData);

    StatusBar.setHidden(false)
    this.setDatePickerVisibility(true)
    var dropdownArr = []
    for (var k = 0; k < 10; k++) {
      var obj = {}
      obj.value = 'NAMEEEE' + k
      obj.id = k
      dropdownArr.push(obj)
    }
    this.setState({
      vendorArr: dropdownArr,
      suggestedTeacherList:
        this.props.teacherList && this.props.teacherList.data ,
      topCourseList: this.props.topCourseList && this.props.topCourseList.data,
      assignmentList: this.props.assignmentList && this.props.assignmentList,
      scanedCouseList:
        this.state.scanedCouseList && this.state.scanedCouseList.data,
      upcomingClassList:
        this.props.upcomingClassList && this.props.upcomingClassList.data,
      selectedDate: new Date(),
    })
    let item = this.props.teacherList && this.props.teacherList.data && this.props.teacherList.data[0]
    if (item) {
      let imageUri = `data:${item.image &&
        item.image.contentContentType};base64,${item.image &&
        item.image.content}`
      this.setState({ imageUri: imageUri })
    }

    this.props.getsuggestedTeachers();
    this.props.getTopCourses()
    this.props.getAssignments()
    this.props.getClasses()

    // this.props.IsImageEmpty();
    this?.props?.topCourseList?.data?.map((item) => {
      let id = item.imageId;
      fetch(`${baseURL}file-blobs/getImage/${id}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${AuthToken}`,
        }
      }).then(data => {
        return data.json()
      }).then(resposne => {
       
        let imageData = this.state.imageData || {};
        imageData[resposne.data.id] = resposne.data;
        this.setState(imageData);
        this.setState({ imageLoading: false });
      }).
        catch((error) => {
          console.log("#error", error);
        })
    })

    this?.props?.teacherList?.data?.map((item) => {
      let id = item.imageId;
      fetch(`${baseURL}file-blobs/getImage/${id}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${AuthToken}`,
        }
      }).then(data => {
        return data.json()
      }).then(resposne => {
        let imageData = this.state.imageData || {};
        imageData[resposne.data.id] = resposne.data;
        this.setState(imageData);
        this.setState({ imageLoading: false });
      }).
        catch((error) => {
          console.log("#error", error);
        })
    })

    // this.props.IsImageEmpty();
    this?.props?.upcomingClassList?.data?.map((item) => {

      let id = item.imageId;
      fetch(`${baseURL}file-blobs/getImage/${id}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${AuthToken}`,
        }
      }).then(data => {
        return data.json()
      }).then(resposne => {
        let imageData = this.state.imageData || {};
        imageData[resposne.data.id] = resposne.data;
        this.setState({imageData ,imageLoading: false  });
        //this.setState({ imageLoading: false });
      }).
        catch((error) => {
          console.log("#error", error);
        })
    })

    // this.props.IsImageEmpty();
    this?.props?.scanedCouseList?.data?.map((item) => {
      // this.props.imageLoad(item.imageId)
    })
    const date = moment.utc().format();
    const local = moment.utc(date).local().format();

    var currentDate = moment.utc(now()).format();
    this.props.getTeacherClassesData({ dateFilter: currentDate }) // api call with action name

    let profileid = this.props.prof.profData.data.imageId;
    fetch(`${baseURL}file-blobs/getImage/${profileid}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {

      let profileImage = this.state.profileImage || {};
      profileImage[resposne.data.id] = resposne.data;
      this.setState(profileImage);

    }).
      catch((error) => {
        console.log("#error", error);
      })

  }

  componentDidUpdate = async (prevProps) => {
    let AuthToken = await AsyncStorage.getItem('id_token');
    if (this.props.teacherList != null) {
      if (prevProps.teacherList != this.props.teacherList) {
        this.setState({
          suggestedTeacherList:
            this.props.teacherList && this.props.teacherList.data,
        })
        let item = this.props.teacherList && this.props.teacherList.data && this.props.teacherList.data[0]
        if (item) {
          let imageUri = `data:${item.image &&
            item.image.contentContentType};base64,${item.image &&
            item.image.content}`
  
          this.setState({ imageUri: imageUri })
        }
      }
    }
    if (prevProps.topCourseList != this.props.topCourseList) {
     
      this.setState({
        topCourseList:
          this.props.topCourseList && this.props.topCourseList.data,
      })
    }

    if (prevProps.assignmentList != this.props.assignmentList) {

      this.setState({
        assignmentList: this.props.assignmentList && this.props.assignmentList,
      })
    }
    if (prevProps.scanedCouseList != this.props.scanedCouseList) {
    
      this.setState({
        scanedCouseList:
          this.props.scanedCouseList && this.props.scanedCouseList.data,
      })
    }

    if (
      prevProps.teacherClassesDataProps != this.props.teacherClassesDataProps
    ) {
      this.setState({
        teacherClassesList:
          this.props.teacherClassesDataProps &&
          this.props.teacherClassesDataProps.data,
      })


      console.log("teacher classes ==========", this.props.teacherClassesDataProps)
      
      this.setState({
        teacherClassesList:
          this.props.teacherClassesDataProps &&
          this.props.teacherClassesDataProps.data,
      })
      console.log("Image data fetching==========", "true")
      this.props.teacherClassesDataProps?.data?.map((item) => {
        // this.props.imageLoad(item?.courseClass?.course?.imageId)
        let id = item.course.imageId;
        fetch(`${baseURL}file-blobs/getImage/${id}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${AuthToken}`,
          }
        }).then(data => {
          return data.json()
        }).then(resposne => {
          let imageData = this.state.teacherListIamgeData || {};
          imageData[resposne.data.id] = resposne.data;
    
          this.setState(imageData);
          this.setState({ teacherListIamgeData: imageData, })
        }).
          catch((error) => {
            console.log("#error", error);
          })
      })



     
    }

    if (
      prevProps.teacherFilteredClassesDataProps != this.props.teacherFilteredClassesDataProps
    ) {

      console.log("filtered data =========", this.props.teacherFilteredClassesDataProps)
      
      this.setState({
        teacherClassesList:
          this.props.teacherFilteredClassesDataProps &&
          this.props.teacherFilteredClassesDataProps.data,
      })
      this.props.teacherFilteredClassesDataProps?.data?.map((item) => {
        // this.props.imageLoad(item?.courseClass?.course?.imageId)
        let id = item.course.imageId;
        fetch(`${baseURL}file-blobs/getImage/${id}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${AuthToken}`,
          }
        }).then(data => {
          return data.json()
        }).then(resposne => {
          let imageData = this.state.teacherListIamgeData || {};
          imageData[resposne.data.id] = resposne.data;
          this.setState(imageData);

          console.log('image datadata', imageData)
          
          this.setState({ teacherListIamgeData: imageData, })
        }).
          catch((error) => {
            console.log("#error", error);
          })

        console.log("ImageData=============", this.state.teacherListIamgeData)

      })
     
      this.setState({
        teacherClassesList:
          this.props.teacherFilteredClassesDataProps &&
          this.props.teacherFilteredClassesDataProps.data,
      })
    }

    if(prevProps.classCancelData != this.props.classCancelData)
    {
      console.log("Cancel api response======", this.props.classCancelData )
      if(!isEmpty(this.props.classCancelData.data))
      {
        alert("Class has been cancelled successfully")
    var selectedDate = moment.utc(this.state.selected).format();
    this.getDateDiffernece(selectedDate , now())
    console.log("Selected date time in UTC-----" , selectedDate )
    this.setState({isLoading: true , selectedDate: selectedDate,})
    this.props.getTeacherClassesData({dateFilter: selectedDate})
    
      }

      else{
        alert("Class has not been cancelled.")
      }
    }
  }

  componentWillUnmount() {

    BackHandler.removeEventListener('hardwareBackPress', this.handleBackButtonClick.bind(this));
    this.finalData = [];
    this.finalTeacherData = [];
    this.finalUpcomingdata = [];
    this.finalScandata = [];
  }


  onChangeText = (value, index, data) => {
    selectedVendor = data[index].value
  }
  onChangeLangText = (value, index, data) => {
    let selectedLang = ''
    data.map(item => {
      if (item.value === value) {
        selectedLang = item.id
      }
    })
    this.setState({ selectedLang })
  }
  onChangeClassText = (value, index, data) => {
    let selectedClass = ''

    data.map(item => {
      if (item.value === value) {
        selectedClass = item.id
      }
    })
    this.setState({ selectedClass })
  }
  onChangeSubText = (value, index, data) => {
    let selectedSub = ''

    data.map(item => {
      if (item.value === value) {
        selectedSub = item.id
      }
    })
    this.setState({ selectedSub })
  }
  onChangeBoardText = (value, index, data) => {
    let selectedBoard = ''
    selectedBoard = data[index].value
  }
  onChangeCatText = (value, index, data) => {
    let selectedCat = ''
    data.map(item => {
      if (item.value === value) {
        selectedCat = item.id
      }
    })
    this.setState({ selectedCat })
  }

  // componentWillMount() {
  //   BackHandler.addEventListener('hardwareBackPress', this.handleBackButtonClick);
  // }
  // componentWillUnmount = () => {
  //   BackHandler.removeEventListener(
  //     'hardwareBackPress',
  //     this.handleBackButtonClick,
  //   )
  // }

 
  showCancelButton(item)
  {
    const sTime = moment(item.startTime, "HH:mm");

    const currentTimeVal = moment(new Date()).format('HH:mm');

    const currentTime = moment(currentTimeVal, "HH:mm")
    console.log("current time---- start time =========", currentTime, sTime)

    var minutes = sTime.diff(currentTime, 'minutes');
    console.log("minutes to set classs ststus text =======", minutes)

    var currentDate = moment.utc(now()).format();

    var currentDate = moment(new Date(currentDate), "dd-MM-YYYY")
    var classDate = moment(new Date(item.date), 'dd-MM-YYYY')

    console.log("today ========", currentDate)
    console.log("class date ========", item.date)

    var dayDiff = classDate.diff(currentDate, 'days')
    console.log("day diff======", dayDiff)

     var classStatus = item.classStatus;
    if(dayDiff>0)
    {
      switch(classStatus)
      {
        case 3:
        return true

        case 5:
          return false;

        default:
          return false
      }
    }

    else if(dayDiff==0)
    {
      switch(classStatus)
      {

        case 3:
          if(minutes>30)
          {
            return true
          }
          else{
            return false
          }

         default:
           return false
      }
     
    }

    else{
      return false
    }

  }

  setChecked = status => {
    this.setState({
      checked: status,
    })
  }

  setText = async (value) => {
    console.log('value is coming',value)
    this.setState({ selectedText: value })
    this.props.fetchSearchData(this.state.selectedText)
  }

  renderQualification = qual => {
    let temp = []
    qual &&
      qual.map(item => {
        temp.push(item.qualification)
      })
    let count = ''
    for (let i = 0; i < temp.length; i++) {
      if (i == 0) {
        count = temp[i]
      } else {
        count = count + ',' + temp[i]
      }
    }
    return count
  }
  onSuccess = async (e) => {
    let AuthToken = await AsyncStorage.getItem('id_token');
    const re = /\s*(?:,;|$)\s*/
    let one = e && e.data && e.data.split('id: ', 2, ',')
    let two = one && one[1] && one[1].split(',')
    two && this.props.scanApi(two[0], AuthToken)
    two && NavigationService.navigate('TeacherDetailActivity', { id: two[0] })
    if (!two) {
      alert('Something went wrong!')
    }
    this.setState({ showQr: false })
  }

  async getData() {
    var temp = []
    let AuthToken = await AsyncStorage.getItem('id_token');
    fetch(`${baseURL}categories`, {

      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    })
      .then(response =>
        response.json())
      .then(responseJson => {
        let cateListData = responseJson && responseJson.data.length
        if (cateListData > 0) {
          for (let i = 0; i < cateListData; i++) {
            var data = responseJson.data[i]
            var namevalue = { id: data.id, value: data.name }
            temp.push(namevalue)
          }
        }
        this.setState({
          catListValues: temp,
        })
      })
      .catch(e => {
        console.log('Exception value', e)
      })
  }

  async getlanguages() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    var lanData = []
    fetch(`${baseURL}languages`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      },
    })
      .then(response =>
        response.json())
      .then(responseJson => {
        var len = responseJson && responseJson.data.length
        if (len > 0) {
          for (let i = 0; i < len; i++) {
            var data = responseJson.data[i]
            var languagelist = { id: data.id, value: data.name }
            lanData.push(languagelist)
          }
        }
        this.setState({
          language: lanData,
        })
      })
      .catch(e => {
        console.log('Exception value', e)
      })
  }

  async getStandard() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    var standardData = []
    fetch(`${baseURL}classes`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      },
    })
      .then(response =>
        response.json())
      .then(responseJson => {
        var len = responseJson && responseJson.data.length
        if (len > 0) {
          for (let i = 0; i < len; i++) {
            var data = responseJson.data[i]

            var standardDatavalue = { id: data.id, value: data.class }
            standardData.push(standardDatavalue)
          }
        }
        this.setState({
          standard: standardData,
        })
      })
      .catch(e => {
        console.log('Exception value', e)
      })
  }

  async getSubject() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    var standardData = []
    fetch(`${baseURL}subject`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      },
    })
      .then(response => response.json())
      .then(responseJson => {

        var len = responseJson.data.length
        if (len > 0) {
          for (let i = 0; i < len; i++) {
            var data = responseJson.data[i]
            var standardDatavalue = { id: data.id, value: data.subject }
            standardData.push(standardDatavalue);
          }
        }
        this.setState({
          subject: standardData,
        })
      })
      .catch(e => {
        console.log('Exception value', e)
      })
  }

  getClassStatusText(statusId , item){

    const sTime = moment(item.startTime, "HH:mm");
      
    const currentTimeVal  =  moment(new Date()).format('HH:mm') ;

    const currentTime = moment(currentTimeVal, "HH:mm")
    console.log("current time---- start time =========", currentTime , sTime)
   
    var minutes = sTime.diff(currentTime , 'minutes');
    console.log("minutes to set classs ststus text =======", minutes)

    var currentDate = moment.utc(now()).format();

    var currentDate = moment(new Date()  , "dd-MM-YYYY")
    var classDate = moment(new Date(this.state.selected) , 'dd-MM-YYYY')

    console.log("today ========", currentDate)
    console.log("class date ========", item.date)

    var dayDiff = currentDate.diff(classDate, 'days')
    console.log("day diff======", dayDiff)

    //1=COMPLETD, 2=ONGOING, 3=UPCOMING 4=MISSED 5=CANCELLED 6=STARTED
    switch(statusId)
    {

      case 1: 
      return 'Completed'
       case 2:
        if(dayDiff==0)
        {
          return 'Start Class'
        }
      
      case 3:
        {
          if(dayDiff==0)
          {
            if(minutes<=10)
            {
              return 'Start Class'
            }

            else if(minutes>=30)
            {
              return 'Reschedule'
            }

            else{
              return 'Reschedule'
            }
          }

          else if(dayDiff>=1)
          {
            return 'Reschedule'
          }
        
        else{
          return 'Reschedule'
        }
      }
        case 4:
          return 'Missed'
          case 5:
            return 'Cancelled'
            case 6: 
            return 'Started'
        default:
          if(dayDiff>0)
          {
            return 'Reschedule'
          }
          else{
            return 'Missed'
          }
         
    }
  }


  getClassStatusTextBgColor(statusId, item) {

    const sTime = moment(item.startTime, "HH:mm");

    const currentTimeVal = moment(new Date()).format('HH:mm');

    const currentTime = moment(currentTimeVal, "HH:mm")
    console.log("current time---- start time =========", currentTime, sTime)

    var minutes = sTime.diff(currentTime, 'minutes');
    console.log("minutes to set classs ststus text =======", minutes)

    var currentDate = moment.utc(now()).format();

    var currentDate = moment(new Date(currentDate), "dd-MM-YYYY")
    var classDate = moment(new Date(item.date), 'dd-MM-YYYY')

    console.log("today ========", currentDate)
    console.log("class date ========", item.date)

    var dayDiff = classDate.diff(currentDate, 'days')
    console.log("day diff======", dayDiff)

    //1=COMPLETD, 2=ONGOING, 3=UPCOMING 4=MISSED 5=CANCELLED 6=STARTED
    switch (statusId) {

      case 1:
        return  'green'  //'Completed'

      case 2:
       
          return  loginheaderColor  //'Start Class'

      case 3:
        {
          if(dayDiff>0)
          {
            return rescheduleClassBgColor //'Reschedule'
          }
          else if(dayDiff==0){
            if(minutes>=30)
            {
              return rescheduleClassBgColor //'Reschedule'
            }

            else if (minutes<=30)
            {
              return loginheaderColor //'Start Class'
            }

            else if (minutes<0 && Math.abs(minutes)<=this.getClassDuration(item))
            {
              return loginheaderColor//'Join Now'
            }

            else{
              return rescheduleClassBgColor   // need to be check again
            }

            }
          else (dayDiff<0)
          {
            return 'red' //'Missed'
          }
          
        }
      case 4:
        return 'red' //'Missed'
      case 5:
        return 'red' //'Cancelled'
      case 6:
        return loginheaderColor //'Started'
      default:
        return  'red' // need to be re-check again
    }
  }

  getTeacherClassStandard(item) {
    console.log("item dashboard data--------", item)
    return item.standard.class
  }


  getClassStartTimeFormatted(startTime)
  {
  
console.log("startTime :" , startTime)
if(isEmpty(startTime))
{
   return '00:00'
}
else{
  const sTime = moment(startTime, "hh:mm A");
  console.log("startTime By moment :" , sTime)
  return sTime.format("hh:mm A")
}


  }

  getClassDuration(startTime , endTime)
  {

    if(isEmpty(startTime) || isEmpty(endTime))
    {
  return "0 min"
    }
    else{

      const sTime = moment(startTime, "HH:mm");
      
      const eTime = moment(endTime, "HH:mm");
      
      var minutes = eTime.diff(sTime , 'minutes');
      console.log("minutes=======", minutes)
  
      //return minutes
      if(minutes>=60)
      {
        var hr = minutes/60
        var min = minutes%60
  
        if(min==0)
        {
          return  Math.floor(hr)+  'hr'
        }
        else{
          return  Math.floor(hr) + " hr " + min +" min"
        }
        
      }
      else{
  
        return minutes +" min"
      }
    }
    
  }



  getDynamicImageData(imageId) {
    console.log("dynamic image id=========", imageId)
    let id = imageId;
    fetch(`${baseURL}file-blobs/getImage/${id}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${this.props.user &&
          this.props.user.loginMessage &&
          this.props.user.loginMessage.id_token}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      // let imageData = this.state.imageData || {};
      // imageData[resposne.data.id] = resposne.data;
      var image = resposne.data.content;

      console.log("dynamic image============", image, image)
      return image;
      //this.setState(imageData);
      // console.log('image datadata',this.state.imageData)
    }).
      catch((error) => {
        console.log("#error", error);
        return ""
      })
  }
  // method to class continue
  continueStartClass() {
    Linking.openURL('http://idutor.com')
    this.setState({ showStartClassDialog: !this.state.showStartClassDialog })
  }

  cancelStartClass(item) {


    console.log("cancel class is invoked", "status =5 ")
    if (this.state.showStartClassDialog) {
      this.setState({ showStartClassDialog: !this.state.showStartClassDialog })
    }
  }


  performClickOnClassSataus(classStatusId, item) {
    //1=COMPLETD, 2=ONGOING, 3=UPCOMING 4=MISSED 5=CANCELLED 6=STARTED
    switch (classStatusId) {
      case 1:
        {
          console.log('class status : ', 'Completed')
        }
        break;

      case 2:
        {
          this.showDialogtoStartClass(item)
        }

        break;

      case 3:
        {

          var btnText = this.getClassStatusText(classStatusId, item)
          if (btnText == "Start Class") {
            this.showDialogtoStartClass(item)
          }
          else if (btnText == "Reschedule") {
            this.showDialogToRescheduleClass(item)
          }

          else {
            console.log("item clicked ", item)
          }

        }

        break;

      case 5:
        {
          this.cancelStartClass(item)

        }
        break;



      default:
        {

          console.log("what ststus invoked --------", classStatusId)
        }

    }

  }
  calenderClassCancelCallApiCall(item)
  {
    //alert('Do you want to cancel the class?')
    const data = ({...item, 
      classStatus: 5
     })
     
  this.props.dashBoradClassCancelCall(data)
  }

  showDialogtoStartClass(item) {
    if(!this.state.showStartClassDialog){
      this.setState({ showStartClassDialog: true, teacherClassSelected: item, })
    }
    
  }


  showDialogToRescheduleClass(item) {
    NavigationService.navigate('RescheduleClassScreen', { fromWhere: 'DashboardScreen', classData: item })
  }

  handleTeacherSearchText = (text) => {
    this.setState({ teacherSearchText: text })
    this.props.getTeacherClassesDataFilter(text)
  }


  hideDatePicker() {
    if(this.state.showDatePicker)
    {
      this.setState({ showDatePicker: false })
    }
    
  }

  render() {
   
    
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>

        <Modal
          isVisible={this.state.filterpopup}
          animationType='fade'
          transparent={true}
          backdropColor={'rgba(0,0,0,0.35)'}
          backdropOpacity={1}
          onBackdropPress={() => this.setState({ filterpopup: false })}
          onRequestClose={() => {
            this.setState({ filterpopup: false })
          }}>
          <View
            style={{
              flex: 1,

              justifyContent: 'flex-end',
              alignItems: 'center',
              height: heightPercentageToDP('85%'),
              marginBottom: -20,
            }}>
            <View
              style={{
                backgroundColor: 'white',
                height: heightPercentageToDP('90%'),
                width: widthPercentageToDP('100%'),
                alignContent: 'center',
                borderTopLeftRadius: 20,
                borderTopRightRadius: 20,
              }}>
              <View>
                <ScrollView nestedScrollEnabled={true}>
                  <Text
                    style={{
                      color: appblueColor,
                      alignSelf: 'flex-end',
                      marginRight: 10,
                      marginTop: 10,
                      fontStyle: 'italic',
                    }}>
                    Mark all as Read
                  </Text>
                  <FlatList
                    data={this.state.simages}
                    nestedScrollEnabled={true}
                    onEndReached={this._handleLoadMore}
                    onEndReachedThreshold={0.01}
                    renderItem={({ item }) => (
                      <View>
                        <View
                          style={{
                            padding: 10,
                            justifyContent: 'center',
                            alignItems: 'center',
                          }}>
                          <View style={{ flexDirection: 'row' }}>
                            <Image
                              source={{
                                isStatic: true,
                                uri:
                                  'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c',
                              }}
                              style={{
                                width: 30,
                                height: 30,
                                borderRadius: 15,
                              }}>

                            </Image>
                            <View>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>
                                Assignment submitted class 12 Maths
                              </Text>
                              <View>
                                <Text
                                  style={{
                                    fontStyle: 'italic',
                                    marginLeft: 10,
                                    fontSize: 12,
                                  }}>
                                  By Sooraj Rai, 5 yr
                                </Text>
                              </View>
                            </View>
                          </View>
                          <View
                            style={{
                              height: 0.5,
                              width: '100%',
                              backgroundColor: appheadertextColor,
                              marginTop: 10,
                            }}>

                          </View>
                        </View>
                      </View>
                    )}
                  />
                  <FlatList
                    data={this.state.simages}
                    nestedScrollEnabled={true}
                    onEndReached={this._handleLoadMore}
                    onEndReachedThreshold={0.01}
                    renderItem={({ item }) => (
                      <View>
                        <View
                          style={{
                            padding: 20,
                            justifyContent: 'center',
                            alignItems: 'center',
                            backgroundColor: appgrayColor,
                            borderRadius: 20,
                          }}>
                          <View style={{ flexDirection: 'row' }}>
                            <Image
                              source={{
                                isStatic: true,
                                uri:
                                  'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c',
                              }}
                              style={{
                                width: 30,
                                height: 30,
                                borderRadius: 15,
                              }}>

                            </Image>
                            <View>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>
                                Assignment submitted class 12 Maths
                              </Text>
                              <View>
                                <Text
                                  style={{
                                    fontStyle: 'italic',
                                    marginLeft: 10,
                                    fontSize: 12,
                                  }}>
                                  By Sooraj Rai, 5 yr
                                </Text>
                              </View>
                            </View>
                          </View>
                          <View
                            style={{
                              height: 0.5,
                              width: '100%',
                              backgroundColor: appheadertextColor,
                              marginTop: 10,
                            }}>

                          </View>
                        </View>
                      </View>
                    )}
                  />
                </ScrollView>
              </View>
            </View>
          </View>
        </Modal>
        <Modal
          isVisible={this.state.showQr1}
          animationType='fade'
          transparent={true}
          backdropColor={'rgba(0,0,0,0.35)'}
          backdropOpacity={1}
          onBackdropPress={() => this.setState({ showQr1: false })}
          onRequestClose={() => {
            this.setState({ showQr1: false })
          }}>
          <View
            style={{
              marginBottom: 10,
              height: heightPercentageToDP('60%'),
              width: widthPercentageToDP('90%'),
              backgroundColor: 'white',
              marginTop: 80,
            }}>
            <View
              style={{
                backgroundColor: 'white',
                width: 130,
                height: 130,
                borderRadius: 70,
                alignSelf: 'center',
                position: 'absolute',
                top: -70,
                justifyContent: 'center',
                borderWidth: 1,
              }}>

              {this.props.prof.profData ? (
                <Image
                  style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: 70,
                    alignSelf: 'center',
                  }}
                  source={{
                    uri: `data:image/jpeg;base64,${this.props.prof.profData &&
                      this.props.prof.profData.data && this.props.prof.profData.data.image &&
                      this.props.prof.profData.data.image.content}`,
                  }}
                />
              ) : (
                  <Image
                    style={{ width: 125, height: 125, alignSelf: 'center' }}
                    source={images.male}
                  />
                )}
            </View>
            <TouchableOpacity
              style={{ position: 'relative', left: 310, marginTop: 10 }}
              onPress={() => this.setState({ showQr1: false })}>
              <Image resizeMode='contain' source={images.drawerclose} />
            </TouchableOpacity>
            <View style={{ marginTop: 40 }}>
              <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>

                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.firstName}
                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.lastName}
              </Text>
              <Text
                style={{
                  textAlign: 'center',
                  color: '#888888',
                  fontStyle: 'italic',
                }}>

                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.experienceInYear}
                yr,
                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.qualifications &&
                  this.props.prof.profData.data.qualifications.map(
                    item => item.qualification,
                  )}
              </Text>
              <View style={{ alignSelf: 'center', margin: 10 }}>
                <QRCode
                  value={`{id: ${this.props.prof.profData && this.props.prof.profData.data &&
                    this.props.prof.profData.data.id},name: ${this.props.prof
                      .profData && this.props.prof.profData.data && this.props.prof.profData.data.firstName}}`}
                  size={200}
                  getRef={c => (this.svg = c)}
                />
              </View>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  marginBottom: 5,
                  alignSelf: 'center',
                  marginTop: 10,
                  backgroundColor: '#1976D2',
                  borderRadius: 35,
                  width: widthPercentageToDP('32%'),
                  textAlign: 'center',
                  height: 50,
                }}
                onPress={() => this.saveQRCode()}>
                <Image
                  resizeMode='contain'
                  source={images.share_list}
                  style={{ alignSelf: 'center', marginLeft: 20 }}
                />
                <Text
                  style={{
                    fontSize: 20,
                    marginLeft: 10,
                    color: 'white',
                    alignSelf: 'center',
                  }}>
                  Share
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  marginTop: 10,
                }}
                onPress={() => this.downloadQRCode()}>
                <Image
                  resizeMode='contain'
                  source={images.download}
                  style={{ alignSelf: 'center' }}
                />
                <Text style={{ marginLeft: 10 }}> Save to Photos </Text>
              </TouchableOpacity>
            </View>
          </View>
          {this.state.canceltext == false ? (
            <View
              style={{
                elevation: 10,
                backgroundColor: 'white',
                marginBottom: 10,
                borderRadius: 10,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  paddingTop: 10,
                  paddingBottom: 10,
                }}>
                <Image
                  style={{
                    width: 20,
                    height: 20,
                    marginLeft: 20,
                    alignSelf: 'center',
                  }}
                  source={images.info}
                />
                <View style={{ width: '70%' }}>
                  <Text
                    style={{
                      fontWeight: 'bold',
                      color: appheadertextColor,
                      fontSize: 12,
                    }}>
                    Did you know ?
                  </Text>
                  <Text
                    numberOfLines={3}
                    style={{ fontSize: 10, color: appheadertextColor }}>
                    You can invite your students directly to your profile on
                    idutor by sharing your QR code with them.idutor does not
                    charge any convenience fee for students enrolled to your
                    courses using your QR code.
                  </Text>
                </View>
              </View>
            </View>
          ) : null}
        </Modal>

        <Modal
          animationType={"fade"}
          transparent={true}
          visible={this.state.showStartClassDialog}
          onRequestClose={() => { console.log("Modal has been closed.") }}>

          {/*All views of Modal*/}
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>Start Class</Text>
            <Text style={styles.modalMsg}>
              You are initiating the class on small screen. For better user experience, idutor recommends hosting classes on tablet or laptops. To login to web console, please visit
              </Text>
            <Text style={styles.modalWebLink}
              onPress={() => { Linking.openURL('http://www.example.com/') }}>
              http://idutor.com
              </Text>
            <TouchableOpacity
              onPress={() =>
                this.continueStartClass()
              } >
              <Text style={styles.ContinueButtonStyle}>
                Continue</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                this.cancelStartClass(this.state.teacherClassSelected)
                //this.setState({ showStartClassDialog:!this.state.showStartClassDialog})
              }
              } >
              <Text style={styles.modalCancel}>
                Cancel</Text>
            </TouchableOpacity>
          </View>

        </Modal>
        <View
          style={{
            flexDirection: 'row',
            backgroundColor: 'white',
            height: 100,
            justifyContent: 'space-between',
            elevation: 10,
            marginTop: 1,
          }}>
          <View style={{ marginTop: 15 }}>
            <TouchableOpacity
              onPress={() => {
                NavigationService.openDrawerr()
              }}>
              <Image
                style={{ width: 20, height: 20, marginLeft: 10 }}
                source={images.menu}
              />
            </TouchableOpacity>
          </View>
          <Image
            style={{ width: 90, height: 25, marginTop: 10, marginLeft: 100 }}
            source={images.logo}
            resizeMode={'contain'}
          />
          <TouchableOpacity
            onPress={() => {
              this.setState({ filterpopup: true })
            }}>
            <Icon1
              style={{ marginTop: 15, alignContent: 'flex-end', marginLeft: 80 }}
              name='bell-o'
              size={25}
              color={'black'}
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => NavigationService.navigate('ProfileScreen')}>
          {/* {console.log('this.state.profileImagethis.state.profileImage',this.state.profileImage)} */}
            {(this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content) ? <Image
              resizeMode='contain'
              source={{ uri: `data:image/jpeg;base64,${this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content}` }}
              style={{
                width: 25,
                height: 25,
                marginLeft: 5,
                marginRight: 20,
                marginTop: 15,
                borderWidth: 1
              }}
            />:<View style={{
              width: 25,
              height: 25,
              marginLeft: 5,
              marginRight: 20,
              marginTop: 15,
              borderWidth: 1
            }}><ActivityIndicator size='small'/></View>}
          </TouchableOpacity>

        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
          <View style={[Styles.searchinput]}>
            <View style={Styles.searchbackground} />
            <View style={{ flexDirection: 'row' }}>
              <Icon1
                style={{ marginLeft: 10, alignSelf: 'center' }}
                name='search'
                size={15}
                color='gray'
              />
              {this.props.selctType && this.props.selctType.typeselectedData && this.props.selctType.typeselectedData.logintype == 'Student' ? (
                <TextInput
                  style={{
                    color: 'gray',
                    flex: 1,
                    height: 50,
                    textAlignVertical: 'center',
                    alignSelf: 'center',
                    zIndex: 1,
                    paddingLeft: 10,
                  }}
                  placeholder='Search Teacher/Courses'
                  onChangeText={this.setText}
                  defaultValue={this.state.selectedText}
                />
              ) : (
                  <TextInput
                    style={{
                      color: 'gray',
                      flex: 1,
                      height: 50,
                      textAlignVertical: 'center',
                      alignSelf: 'center',
                      zIndex: 1,
                      paddingLeft: 10,
                    }}
                    placeholder='Search'
                    onChangeText={this.handleTeacherSearchText}

                  />
                )}
              <TouchableOpacity
                style={{ justifyContent: 'center' }}
                onPress={() =>
                  this.props.selctType && 
                  this.props.selctType.typeselectedData && this.props.selctType.typeselectedData.logintype == 'Student'
                    ? this.setState({ showQr: !this.state.showQr })
                    : this.setState({ showQr1: !this.state.showQr1 })
                }>
                <Image
                  source={images.scan}
                  style={{ width: 18, height: 18, marginRight: 35 }}
                />
              </TouchableOpacity>
            </View>
          </View>
          {this.props.selctType && this.props.selctType.typeselectedData && this.props.selctType.typeselectedData.logintype == 'Student' ? (
            <TouchableWithoutFeedback
              onPress={() => {
                this.getData()
                this.getlanguages()
                this.getStandard()
                this.getSubject()
                this.setState({
                  searchpopup: !this.state.searchpopup,
                })
              }}>
              <View
                style={{
                  height: 45,
                  width: 45,
                  backgroundColor: 'white',
                  borderRadius: 45 / 2,
                  justifyContent: 'center',
                  marginLeft: -30,
                  elevation: 100,
                  zIndex: 1,
                  marginTop: -35,
                }}>

                {this.state.searchpopup == false ? (
                  <Icon1
                    style={{ alignSelf: 'center', alignItems: 'center' }}
                    name='sliders'
                    size={20}
                    color={loginheaderColor}
                  />
                ) : (
                    <Image
                      onPress={() =>
                        this.setState({
                          selectedClass: '',
                          selectedLang: '',
                          selectedSub: '',
                          selectedBoard: '',
                          selectedCat: '',
                        })
                      }
                      resizeMode='contain'
                      source={images.close}
                      style={{ alignSelf: 'center', alignItems: 'center' }}
                    />
                  )}
              </View>
            </TouchableWithoutFeedback>
          ) : null}
        </View>
        {this.state.searchpopup == true ? (
          <View
            style={{
              backgroundColor: appgrayColor,
              height: 350,
              width: '100%',
            }}>
            <View style={{ justifyContent: 'center' }}>
              <Dropdown
                placeholder='Select Category'
                placeholderTextColor='gray'
                renderAccessory={() => (
                  <Image
                    resizeMode='contain'
                    source={images.dropdown}
                    style={{ marginTop: 5, justifyContent: 'center' }}
                  />
                )}
                rippleCentered={true}
                inputContainerStyle={{
                  borderBottomColor: 'transparent',
                  justifyContent: 'center',
                }}
                dropdownPosition={0}
                dropdownOffset={{ top: 5, left: 0 }}
                onChangeText={this.onChangeCatText}
                containerStyle={{
                  width: widthPercentageToDP('95%'),
                  paddingLeft: 20,
                  justifyContent: 'center',
                  alignContent: 'center',
                  alignSelf: 'center',
                  backgroundColor: 'white',
                  borderRadius: 30,
                  paddingRight: 20,
                  height: 40,
                  marginTop: 10,
                  paddingTop: 10,
                }}
                fontSize={15}
                ref={this.dropdown}
                value={this.state.selectedcat}
                data={this.state.catListValues}
              />
            </View>
            <View style={{ justifyContent: 'center' }}>
              <Dropdown
                placeholder='Select Class'
                placeholderTextColor='gray'
                renderAccessory={() => (
                  <Image
                    resizeMode='contain'
                    source={images.dropdown}
                    style={{ marginTop: 5, justifyContent: 'center' }}
                  />
                )}
                rippleInsets={{ top: 5, bottom: 0, right: 0, left: 0 }}
                inputContainerStyle={{
                  borderBottomColor: 'transparent',
                  justifyContent: 'center',
                }}
                dropdownPosition={0}
                dropdownOffset={{ top: 5, left: 0 }}
                onChangeText={this.onChangeClassText}
                containerStyle={{
                  width: widthPercentageToDP('95%'),
                  paddingLeft: 20,
                  justifyContent: 'center',
                  alignContent: 'center',
                  alignSelf: 'center',
                  backgroundColor: 'white',
                  borderRadius: 30,
                  paddingRight: 20,
                  height: 40,
                  marginTop: 10,
                  paddingTop: 10,
                }}
                fontSize={15}
                ref={this.dropdown}
                value={this.state.selectedClass}
                data={this.state.standard}
              />
            </View>
            <View style={{ justifyContent: 'center' }}>
              <Dropdown
                placeholder='Select Subject'
                placeholderTextColor='gray'
                renderAccessory={() => (
                  <Image
                    resizeMode='contain'
                    source={images.dropdown}
                    style={{ marginTop: 5, justifyContent: 'center' }}
                  />
                )}
                rippleInsets={{ top: 5, bottom: 0, right: 0, left: 0 }}
                inputContainerStyle={{
                  borderBottomColor: 'transparent',
                  justifyContent: 'center',
                }}
                dropdownPosition={0}
                dropdownOffset={{ top: 5, left: 0 }}
                onChangeText={this.onChangeSubText}
                containerStyle={{
                  width: widthPercentageToDP('95%'),
                  paddingLeft: 20,
                  justifyContent: 'center',
                  alignContent: 'center',
                  alignSelf: 'center',
                  backgroundColor: 'white',
                  borderRadius: 30,
                  paddingRight: 20,
                  height: 40,
                  marginTop: 10,
                  paddingTop: 10,
                }}
                fontSize={15}
                ref={this.dropdown}
                value={this.state.selectedSub}
                data={this.state.subject}
              />
            </View>
            <View style={{ justifyContent: 'center' }}>
              <Dropdown
                placeholder='Select Board'
                placeholderTextColor='gray'
                renderAccessory={() => (
                  <Image
                    resizeMode='contain'
                    source={images.dropdown}
                    style={{ marginTop: 5, justifyContent: 'center' }}
                  />
                )}
                rippleInsets={{ top: 5, bottom: 0, right: 0, left: 0 }}
                inputContainerStyle={{
                  borderBottomColor: 'transparent',
                  justifyContent: 'center',
                }}
                dropdownPosition={0}
                dropdownOffset={{ top: 5, left: 0 }}
                onChangeText={this.onChangeBoardText}
                containerStyle={{
                  width: widthPercentageToDP('95%'),
                  paddingLeft: 20,
                  justifyContent: 'center',
                  alignContent: 'center',
                  alignSelf: 'center',
                  backgroundColor: 'white',
                  borderRadius: 30,
                  paddingRight: 20,
                  height: 40,
                  marginTop: 10,
                  paddingTop: 10,
                }}
                fontSize={15}
                ref={this.dropdown}
                value={this.state.vendor}
                data={this.state.vendorArr}
              />
            </View>
            <View style={{ justifyContent: 'center' }}>
              <Dropdown
                placeholder='Select Language'
                placeholderTextColor='gray'
                renderAccessory={() => (
                  <Image
                    resizeMode='contain'
                    source={images.dropdown}
                    style={{ marginTop: 5, justifyContent: 'center' }}
                  />
                )}
                rippleInsets={{ top: 5, bottom: 0, right: 0, left: 0 }}
                inputContainerStyle={{
                  borderBottomColor: 'transparent',
                  justifyContent: 'center',
                }}
                dropdownPosition={0}
                dropdownOffset={{ top: 5, left: 0 }}
                onChangeText={this.onChangeLangText}
                containerStyle={{
                  width: widthPercentageToDP('95%'),
                  paddingLeft: 20,
                  justifyContent: 'center',
                  alignContent: 'center',
                  alignSelf: 'center',
                  backgroundColor: 'white',
                  borderRadius: 30,
                  paddingRight: 20,
                  height: 40,
                  marginTop: 10,
                  paddingTop: 10,
                }}
                fontSize={15}
                ref={this.dropdown}
                value={this.state.selectedLang}
                data={this.state.language}
              />
            </View>
            <View
              style={{
                flexDirection: 'row',
                paddingLeft: 10,
                paddingRight: 10,
                alignItems: 'center',
                marginTop: 10,
              }}>
              <Checkbox
                uncheckedColor={loginheaderColor}
                color={loginheaderColor}
                status={this.state.checked ? 'unchecked' : 'checked'}
                onPress={() => this.setChecked(!this.state.checked)}
              />
              <Text style={{ color: appheadertextColor, fontSize: 12 }}>
                Show in -progress classes also
              </Text>
            </View>
            <View
              style={{
                flexDirection: 'row',
                position: 'absolute',
                bottom: 0,
                alignSelf: 'center',
                width: '100%',
                justifyContent: 'center',
              }}>
              <TouchableOpacity
                style={[
                  this.state.changeClicked == 1
                    ? Styles.selectoptionbutton
                    : Styles.withoutselectoptionbutton,
                ]}
                onPress={() => {
                  NavigationService.navigate('AdvanceSearchActivity', {
                    selectedCat: this.state.selectedCat,
                    selectedClass: this.state.selectedClass,
                    selectedSub: this.state.selectedSub,
                    selectedBoard: this.state.selectedBoard,
                    selectedLang: this.state.selectedLang,
                    getSearchData: this.props.getSearchData,
                  })
                }}>
                <Text style={{ color: 'white', alignSelf: 'center' }}>
                  Search
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : null}
        {this.props.selctType && this.props.selctType.typeselectedData && this.props.selctType.typeselectedData.logintype == 'Student' ? (
          (this.state.upcomingClassList &&
            this.state.upcomingClassList.length > 0) ||
            (this.state.suggestedTeacherList &&
              this.state.suggestedTeacherList.length > 0) ||
            (this.state.assignmentList && this.state.assignmentList.length > 0) ||
            (this.state.topCourseList &&
              this.state.topCourseList.length > 0) ? null : (
              <View
                style={{ flex: 2, justifyContent: 'center', alignItems: 'center' }}>
                <Text style={{ width: '80%', textAlign: 'center' }}>
                  Please select the preferences from the profile area to view the
                  content or if you already have, try adding more preference
                  because the preference you selected donot match any record.
              </Text>
                <TouchableOpacity
                  onPress={() => NavigationService.navigate('ProfileScreen')}>
                  <Text style={{ textDecorationLine: 'underline', marginTop: 20 }}>
                    Go to profile
                </Text>
                </TouchableOpacity>
              </View>
            )
        ) : <></>}
        {/* <ScrollView> */}
        {/* {console.log('this.props.selctType.typeselectedData.logintype',this.props.selctType.typeselectedData.logintype)} */}
        {this.props.selctType && this.props.selctType.typeselectedData && this.props.selctType.typeselectedData.logintype == 'Student' ? (
          <ScrollView>
            <View style={{ marginLeft: 10, marginTop: 10 }}>
              {this.state.upcomingClassList &&
                this.state.upcomingClassList.length > 0 && (
                  <Text
                    style={{ fontWeight: 'bold', fontSize: 14, marginTop: 20, marginLeft: 10 }}>

                    Upcoming Classes
                  </Text>
                )}
              {this.state.upcomingClassList &&
                this.state.upcomingClassList.length > 0 ? (
                  <ScrollView
                    style={{ marginLeft: 10, marginTop: 10 }}
                    horizontal={true}
                    showsHorizontalScrollIndicator={false}>
                    <View style={{ flexDirection: 'row' }}>

                      {this.state.upcomingClassList.map(item => {
                        return (
                          <TouchableWithoutFeedback>
                            <View
                              key={item.id}
                              style={{
                                flexDirection: 'column',
                                width: widthPercentageToDP('50%'),
                                marginRight: 20,
                                borderRadius: 10,
                                backgroundColor: appgrayColor,
                              }}>
                              {!this.state.imageLoading ? <Image
                                resizeMode='contain'
                                source={{ isStatic: true, uri: `data:image/jpeg;base64,${this.state.imageData[item.imageId] && this.state.imageData[item.imageId].content}` }}
                                style={{
                                  width: widthPercentageToDP('50%'),
                                  borderRadius: 10,
                                  height: 120
                                }}
                              ></Image> :
                                <View style={{
                                  width: widthPercentageToDP('50%'),
                                  borderRadius: 10,
                                  height: 120
                                }}>
                                  <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                                </View>}

                              <View style={{ flexDirection: 'row' }}>
                                <Text style={{ fontSize: 13 }}>

                                  {moment(
                                    item.courseClass.course.startTime,
                                  ).format('DD MMM')}
                                </Text>
                                <Text style={{ fontSize: 12, marginLeft: 50 }}>

                                  {moment(
                                    item.courseClass.course.startTime,
                                  ).format('hh:mm A')}
                                </Text>
                              </View>
                              <View
                                style={{
                                  flexDirection: 'row',
                                  justifyContent: 'space-between',
                                  marginRight: 10,
                                }}>
                                <Text style={{ fontSize: 13 }}>

                                  {item.courseClass.course.name}
                                </Text>
                                <Text
                                  style={{
                                    color: appheadertextColor,
                                    fontSize: 12,
                                    marginLeft: 10,
                                  }}>
                                  By {item.teacher && item.teacher.firstName}
                                  {item.teacher && item.teacher.lastName}
                                  {item.teacher &&
                                    item.teacher.experienceInYear &&
                                    ',' + item.teacher &&
                                    item.teacher.experienceInYear + 'Yrs'}
                                </Text>
                              </View>
                            </View>
                          </TouchableWithoutFeedback>
                        )
                      })}
                    </View>
                  </ScrollView>
                ) : null}
              {this.state.assignmentList &&
                (this.state.assignmentList.newAssignments !== 0 ||
                  this.state.assignmentList.pendingAssignments !== 0) && (
                  <>
                    <Text
                      style={{
                        fontWeight: 'bold',
                        fontSize: 14,
                        marginTop: 10, marginLeft: 10
                      }}>

                      Assignments
                      </Text>
                    <View
                      style={{
                        width: widthPercentageToDP('95%'),
                        backgroundColor: appgrayColor,
                        marginRight: 10,
                        elevation: 10,
                        marginTop: 10,
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          marginRight: 10,
                          marginLeft: 10,
                          marginTop: 10,
                          marginBottom: 10,
                        }}>
                        <View
                          style={{
                            width: widthPercentageToDP('40%'),
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                          }}>
                          <Text> New </Text>
                          <View
                            style={{
                              width: 25,
                              height: 25,
                              borderRadius: 25 / 2,
                              backgroundColor: appbluebtnColor,
                              justifyContent: 'center',
                            }}>
                            <Text
                              style={{ alignSelf: 'center', color: 'white' }}>

                              {this.state.assignmentList &&
                                this.state.assignmentList.newAssignments}
                            </Text>
                          </View>
                        </View>
                        <View
                          style={{
                            backgroundColor: 'gray',
                            height: 20,
                            width: 1,
                          }}>

                        </View>
                        <View
                          style={{
                            width: widthPercentageToDP('40%'),
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                          }}>
                          <Text> Pending </Text>
                          <View
                            style={{
                              width: 25,
                              height: 25,
                              borderRadius: 25 / 2,
                              backgroundColor: appcountColor,
                              justifyContent: 'center',
                            }}>
                            <Text
                              style={{ alignSelf: 'center', color: 'white' }}>

                              {this.state.assignmentList &&
                                this.state.assignmentList
                                  .pendingAssignments}
                            </Text>
                          </View>
                        </View>
                      </View>
                    </View>
                  </>
                )}
            </View>
            {this.state.suggestedTeacherList &&
              this.state.suggestedTeacherList.length > 0 && (
                <Text
                  style={{ fontWeight: 'bold', fontSize: 14, marginTop: 20, marginLeft: 10 }}>

                  Suggested Teachers
                </Text>
              )}
            {this.state.suggestedTeacherList &&
              this.state.suggestedTeacherList.length > 0 ? (
                <ScrollView
                  style={{ marginLeft: 10, marginTop: 10 }}
                  horizontal={true}
                  showsHorizontalScrollIndicator={false}>
                  <View style={{ flexDirection: 'row' }}>

                    {this.state.suggestedTeacherList.map(item => {
                      return (
                        <TouchableOpacity
                          onPress={async () => {
                            this.props.navigation.navigate(
                              'TeacherDetailActivity',
                              { id: item.id },
                            )
                          }}>
                          {<View
                            key={item.id}
                            style={{
                              flexDirection: 'column',
                              width: widthPercentageToDP('40%'),
                              marginRight: 20,
                              borderRadius: 10,
                              backgroundColor: appgrayColor,
                            }}>

                            {!this.state.imageLoading ? <Image
                              resizeMode='contain'
                              source={{ isStatic: true, uri: `data:image/jpeg;base64,${this.state.imageData[item.imageId] && this.state.imageData[item.imageId].content}` }}
                              style={{
                                width: widthPercentageToDP('38%'),
                                borderRadius: 10,
                                height: 120
                              }}

                            ></Image> :
                              <View style={{
                                width: widthPercentageToDP('38%'),
                                borderRadius: 10,
                                height: 120
                              }}>
                                <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                              </View>}

                            <View
                              style={{
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                                marginLeft: 10,
                                marginRight: 10,
                              }}>
                              <Text
                                style={{
                                  color: appheadertextColor,
                                  fontSize: 12,
                                }}>

                                {item.firstName} {item.lastName}
                                {item.experienceInYear &&
                                  ',' + item.experienceInYear + 'Yrs'}
                              </Text>
                            </View>
                            <View
                              style={{
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                                marginLeft: 10,
                                marginRight: 10,
                                marginBottom: 10,
                              }}>
                              <Text
                                style={{
                                  color: appheadertextColor,
                                  fontSize: 12,
                                }}>

                                {this.renderQualification(
                                  item.qualification,
                                )}
                              </Text>
                            </View>
                          </View>}
                        </TouchableOpacity>
                      )
                    })}
                  </View>
                </ScrollView>
              ) : null}
            {this.state.topCourseList &&
              this.state.topCourseList.length > 0 && (
                <Text
                  style={{ fontWeight: 'bold', fontSize: 14, marginTop: 20, marginLeft: 10 }}>

                  Top Courses
                </Text>
              )}

            {this.state.topCourseList &&
              this.state.topCourseList.length > 0 ? (
                <ScrollView
                  style={{ marginLeft: 10, marginTop: 10 }}
                  horizontal={true}
                  showsHorizontalScrollIndicator={false}>
                  <View style={{ flexDirection: 'row' }}>
                    {this.state.topCourseList.map(item => {
                      return (
                        <TouchableOpacity
                          onPress={async () => {
                            this.props.navigation.navigate(
                              'SearchDetailActivity',
                              { courseId: item.id },
                            )
                          }}>
                          {
                            <View
                              key={item.id}
                              style={{
                                flexDirection: 'column',
                                marginRight: 20,
                                borderRadius: 10,
                                backgroundColor: 'lightgray',
                              }}>
                                {/* {console.log('this.state.imageData[item.imageId].content',this.state.imageData)} */}
                              {!this.state.imageLoading ? <Image
                                resizeMode='contain'
                                source={{ isStatic: true, uri: `data:image/jpeg;base64,${this.state.imageData[item.imageId] && this.state.imageData[item.imageId].content}` }}
                                style={{
                                  width: widthPercentageToDP('70%'),
                                  borderRadius: 10,
                                  height: 150
                                }}
                              ></Image> :
                                <View style={{
                                  width: widthPercentageToDP('70%'),
                                  borderRadius: 10,
                                  height: 150
                                }}>
                                  <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                                </View>}
                              <View
                                style={{
                                  flexDirection: 'row',
                                  justifyContent: 'space-between',
                                  marginLeft: 10,
                                  marginRight: 10,
                                }}>
                                <Text style={{ color: appheadertextColor }}>

                                  {item && item.name}
                                </Text>
                                <Text style={{ color: appheadertextColor }}>

                                  {item && item.totalEnroledStudents}/ {item && item.maxBatchSize}
                                </Text>
                              </View>
                              <View
                                style={{
                                  flexDirection: 'row',
                                  justifyContent: 'space-between',
                                  marginLeft: 10,
                                  marginRight: 10,
                                  marginBottom: 10,
                                }}>
                                <Text
                                  style={{
                                    fontStyle: 'italic',
                                    color: appheadertextColor,
                                  }}>
                                  By
                                     {' '}
                                  {item?.courseUsers[0]?.userId?.firstName}{' '}
                                  {item?.courseUsers[0]?.userId?.lastName}
                                </Text>
                                <Text style={{ color: 'orange' }}>
                                  ₹{' '}{item && item.fee}
                                </Text>
                              </View>
                            </View>
                          }
                        </TouchableOpacity>
                      )
                    })}
                  </View>
                </ScrollView>
              ) : null}
          </ScrollView>
        ) : (
            <>

              <View>
                <Text style={{ fontWeight: 'bold', fontSize: 14, marginTop: 20, marginHorizontal: 15, }}>{(this.props.teacherClassesDataProps && this.props.teacherClassesDataProps.data && !isEmpty(this.props.teacherClassesDataProps.data)) ? "Upcoming Classes" : "No Upcoming Classes"} </Text>
              </View>

              {!isEmpty(this.props.teacherClassesDataProps) && (
                <View style={{ marginBottom: 10 , paddingBottom:130}}>
                  <ScrollView style={{ marginTop: 20, paddingBottom: 15, backgroundColor: 'white' }}>
                    <FlatList
                      data={this.state.teacherClassesList}
                      style={{ marginBottom: 20 }}
                      nestedScrollEnabled={true}
                      onEndReached={this._handleLoadMore}
                      onEndReachedThreshold={0.01}
                      contentContainerStyle={{paddingBottom: 100}}
                      renderItem={({ item }) => (
                        <View style={{ justifyContent: 'center', marginLeft: 10, marginRight: 10 }}>
                          <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10 }}>
                            {/* <TouchableOpacity> */}
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                              <View style={{ widthPercentageToDP: '10' }}>

                                {console.log("image content data ", this.state.teacherListIamgeData)}

                                {
                                  isEmpty(this.state.teacherListIamgeData[item.course.imageId]?.content)
                                    ?
                                    <Image style={Styles.calimage}
                                      source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                                    // source={{ uri:`data:image/jpeg;base64,${this.state.teacherListIamgeData[item.course.imageId]?.content}`,  }} 
                                    />
                                    :
                                    <Image style={Styles.calimage}
                                      resizeMode='contain'
                                      source={{ uri: `data:image/jpeg;base64,${this.state.teacherListIamgeData[item.course.imageId]?.content}`, }}
                                    />
                                }
                              </View>

                              <View style={{ flexDirection: 'row', flex: 1, widthPercentageToDP: '80', justifyContent: 'space-between', marginLeft: 5, marginRight: 5, marginTop: 10, padding: 10 }}>
                                <View style={{ alignContent: 'flex-start', flex: 2, widthPercentageToDP: '50' }}>
                                  <Text style={{ fontWeight: 'bold', fontSize: 13, textAlign: 'justify' }}>{item.courseName}-Class {this.getTeacherClassStandard(item)}</Text>
                                  <Text style={{ fontSize: 12, fontStyle: 'italic', textAlign: 'left' }}> {item.topicsCovered}</Text>
                                  <Text style={{ fontSize: 12, alignSelf: 'flex-start' }}>{this.getClassStartTimeFormatted(item.startTime)} to {this.getClassStartTimeFormatted(item.endTime)} ({this.getClassDuration(item.startTime, item.endTime)})</Text>
                                </View>

                                <View style={{ widthPercentageToDP: '20', flex: 1 }}>
                                  <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(item.date).utc().format("DD , MMM")}</Text>

                                  <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{this.getClassStartTimeFormatted(item.startTime)}</Text>
                                  {/* <TouchableOpacity

                                    onPress={() => this.performClickOnClassSataus(item.classStatus, item)}>
                                    <Text style={{ marginBottom: 5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: this.getClassStatusTextBgColor(item.classStatus, item), borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>{this.getClassStatusText(item.classStatus, item)}</Text>
                                  </TouchableOpacity> */}

                                </View>
                             
                              </View>

  
                            </View >
                            {/* </TouchableOpacity> */}

                            <View style={{flexDirection:'row',alignSelf:'flex-end', justifyContent:'space-evenly', alignContent:'flex-end' , marginStart: 50 ,marginBottom:10,}}>
                                {
                                 this.showCancelButton(item)? <TouchableOpacity
                                 style={{marginHorizontal:10}}
                                 onPress={() => this.calenderClassCancelCallApiCall(item)}>
                                 <Text style={{ marginBottom: 5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: 'red', borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>Cancel</Text>
                               </TouchableOpacity>
                               : null

                                }
                                
                               <TouchableOpacity
                                    onPress={() => this.calenderClassCancelCallApiCall(item)}>
                                    <Text style={{ marginBottom: 5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: this.getClassStatusTextBgColor(item.classStatus, item), borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>{this.getClassStatusText(item.classStatus, item)}</Text>
                                  </TouchableOpacity> 

                                {/* {
                                 this.showRescheduleButton(item)? 
                                  <TouchableOpacity
                                    onPress={() => this.performClickOnClassSataus(item.classStatus, item)}>
                                    <Text style={{ marginBottom: 5,marginHorizontal:5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: rescheduleClassBgColor, borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>Reschedule</Text>
                                  </TouchableOpacity>
                                  :null}
                                 { 
                                 this.showStartJoinButton(item)? 
                                 <TouchableOpacity
                                 onPress={() => this.performClickOnClassSataus(item.classStatus, item)}>
                                 <Text style={{ marginBottom: 5, marginHorizontal:5,color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: loginheaderColor, borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>Start Class</Text>
                               </TouchableOpacity>:
                               null
                                 }  */}

                                 {/* {
                                   this.showMissedButton(item) ? 
                                   <TouchableOpacity
                                   onPress={() => this.performClickOnClassSataus(item.classStatus, item)}>
                                   <Text style={{ marginBottom: 5, marginHorizontal:5,color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: 'red', borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>Missed</Text>
                                 </TouchableOpacity>:
                                 null
                                 } */}
                                </View> 
                          </View>

                        </View>
                      )}
                    />
                  </ScrollView>
                </View>
              )}
            </>
          )}


        {this.state.isLoading ? (
          <View style={Styles.loading}>
            <ActivityIndicator sizewhite='large' color='white'>

            </ActivityIndicator>
          </View>
        ) : null}
        {this.state.showQr && (
          <View style={{ position: 'absolute' }}>
            <QRCodeScanner
              onRead={this.onSuccess}
              fadeIn={false}
              onRequestClose={() => this.setState({ showQr: false })}
              showMarker={true}
              topContent={
                <Text>
                  Go to <Text> wikipedia.org / wiki / QR_code </Text> on your
                  computer and scan the QR code.
                </Text>
              }
              bottomContent={
                <TouchableOpacity>
                  <Text> OK.Got it! </Text>
                </TouchableOpacity>
              }
            />
          </View>
        )}


      </View>
    )
  }
}
const mapStateToProps = state => ({
  // user: state.auth,
  teacherList: state.dash.teacherData,
  topCourseList: state.dash.courseData,
  assignmentList: state.dash.assignmentData,
  upcomingClassList: state.dash.classesData,
  getSearchData: state.dash.getSearchData,
  selctType: state.selctType,
  prof: state.prof,
  teacherClassesDataProps: state.dash.teacherClassesData, // reducer gives state then convert to props
  teacherFilteredClassesDataProps: state.dash.teacherFilteredClassesData,
  classCancelData : state.dash.dashboardClassCancelDataData,
  //rescheduleClassDataProps : state.dash.rescheduleClassData,
  //teacherStudentListData : state.dash.fetchTeacherStudentData,
  // imageData: state.dash.imageData
})
const mapDispatchToProps = {
  getsuggestedTeachers,
  getTopCourses,
  getAssignments,
  getClasses,
  scanApi,
  // getCourseDetail,
  fetchSearchData,
  getTeacherClassesData, // firstly define action here then we can get that into props for api call
  getTeacherClassesDataFilter,
  profile,
  dashBoradClassCancelCall,

}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: StatusBar.currentHeight || 0,
  },
  item: {
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  title: {
    fontSize: 32,
  },

  modal: {
    justifyContent: 'center',
    alignSelf: 'center',
    alignItems: 'center',
    backgroundColor: "#F9F9F9",
    width: '90%',
    borderRadius: 10,
    borderWidth: 1,
    marginTop: 80,
    borderWidth: 1,
    borderColor: '#F9F9F9',
  },

  modalTitle: {
    marginTop: 20,
    color: '#353839',
    opacity: 1,
    fontSize: 12,
    fontWeight: 'bold',
    alignContent: 'center',
  },
  modalMsg: {
    marginTop: 10,
    color: '#4D4D4D',
    opacity: 1,
    fontSize: 11,
    marginHorizontal: 20,
    textAlign: 'center',
    textAlignVertical: 'center',
  },
  modalCancel: {
    marginBottom: 20,
    color: '#4D4D4D',
    opacity: 1,
    fontSize: 12,
    marginHorizontal: 20,
    textAlign: 'center',
    textAlignVertical: 'center',
  },

  modalWebLink: {
    color: '#5B82FF',
    opacity: 1,
    fontSize: 11,
    alignContent: 'center',
    marginHorizontal: 20,
  },


  ContinueButtonStyle: {
    marginBottom: 10,
    color: 'white',
    alignSelf: 'flex-end',
    marginTop: 10,
    backgroundColor: '#165ADC',
    borderRadius: 20,
    paddingLeft: 30,
    paddingRight: 30,
    paddingBottom: 5,
    paddingTop: 5,
    width: '80%',

  },

})

export default connect(mapStateToProps, mapDispatchToProps)(DashboardScreen)
