import React, { useState, useEffect,useCallback } from 'react'
import { Platform, Text, View, Button, ActivityIndicator,TouchableOpacity, ScrollView,FlatList } from 'react-native'
import { useDispatch, useSelector } from 'react-redux'

import Style from './HomeScreenStyle'

import Topbar from '../../Common/MenuBar';
import Loader from '../../Common/Loader';
import Moment from 'moment';
import { authLogin,fetchList } from '../../actions/index';
import home from '../../service/home';
import NavigationService from '../../Services/NavigationService'
import { COLORS, SIZE, heightPercentageToDP } from '../../constants/styles';

const HomeScreen = () => {
  const [start, setStart] = useState(0);
  const [showLoader, setLoader] = useState(false);
  const [homeList, setHomeList] = useState([]);
  const dispatch = useDispatch()

  /* const user = useSelector((state) => state.home.pendings.message);
  const userIsLoading = useSelector((state) => state.example.userIsLoading)
  const userErrorMessage = useSelector((state) => state.example.userErrorMessage)
 */
const loginLoading = useSelector((state) => state.auth.loginLoading)
const homeData = useSelector((state) => state.home.homeData);

const user = useSelector((state) => state.auth.loginMessage!=null?state.auth.loginMessage.data:null);


const _handleLoadMore =() => {
  console.log(
    "load more" + start + "TOTAL" + homeData.count
  );

  if (start <= homeData.count) {
  
  console.log("CALL METHOD"); 
  dispatch(fetchList(start,10));
  setHomeList([...homeList,homeData.enquiries]);
  setStart(start+3);
    /* EnquiryAPI.enquiryHistory(this.props.user.user.data.token,this.state.start,10).then(res => {
      this.setState({ showLoader: false })
      if(res.data!=undefined)
      {
      if (res.data.status == 1 && res.data.enquiries) {
        this.setState({ enquiries: [...this.state.enquiries,...res.data.enquiries],   start: this.state.start + 10,total:res.data.count });
        console.log('history', JSON.stringify(res.data))
        

      } else if (res.data.status != 1) {
        console.log(JSON.stringify(res.data))
        this.showAlert(res.data.message);
      }
    }
    else
    {
      alert('Please connect to internet');
    }
    }); */
  
  }
  };
useEffect(() => {
 
    dispatch(fetchList(start,100));

    //setHomeList(homeData.enquiries);
    //(start+3);
    
  },[])
  // useEffect(() => {
  //   dispatch(fetchList("pending"));
  //  if(homeData!=null)
  //   setPendingOrders(homeData.result); 
  // },homeData)
  return (
   /*  <View
      style={[
        Helpers.fillCenter,
        Helpers.rowMain,
        Metrics.mediumHorizontalMargin,
        Metrics.mediumVerticalMargin,
      ]}
    >
      {userIsLoading ? (
        <ActivityIndicator size="large" color="#0000ff" />
      ) : (
        <View>
          <View style={Style.logoContainer}>
            <Image style={Helpers.fullSize} source={Images.logo} resizeMode={'contain'} />
          </View>
          <Text style={Style.text}>To get started, edit App.js</Text>
          <Text style={Style.instructions}>{instructions}</Text>
          {userErrorMessage ? (
            <Text style={Style.error}>{userErrorMessage}</Text>
          ) : (
            <View>
              <Text style={Style.result}>
                {"I'm a fake user, my name is "}
                {user.name}
              </Text>
              <Text style={Style.result}>
                {liveInEurope ? 'I live in Europe !' : "I don't live in Europe."}
              </Text>
            </View>
          )}
          <Button
            style={ApplicationStyles.button}
            onPress={() => dispatch(ExampleActions.fetchUser())}
            title="Refresh"
          />
        </View>
      )}
    </View> */
    <Topbar >
        <Loader show={loginLoading} />
      <ScrollView 
      showsVerticalScrollIndicator={false}
      nestedScrollEnabled={true}
      style={Style.container}>
          <Loader show={showLoader} />
         
          <View
            style={{
              paddingLeft: 10,
              paddingRight: 10,
              paddingTop: 10,


            }}
          >
            <Text
              style={{
                fontWeight: 'bold'
              }}
            >
              Latest Enquiries 
            </Text>
           {/*  <Text
             
             >
 Latest Enquiries : (this section will show only those enquiries which are new or replied by retailer or OA)            </Text>
          */}
          </View>
           <FlatList
               nestedScrollEnabled={true}
      
//onEndReached={_handleLoadMore}
           // onEndReachedThreshold={0.01}
            data={homeData?homeData.enquiries:[]}
           //data={homeList}
            renderItem={({ item }) => <View
              
            >
              {
              item.status!='closed'?
              <View style={{
                paddingTop: 10,
                alignItems: 'center'
              }}>
              <View style={Style.statusContainer}>
                <View style={Style.topHead}>
                  <View>
                    <Text style={{fontSize:12,fontWeight:'bold'}}>{item.enquiryId + ''}</Text>
                    <Text style={{fontSize:12}}>Enquiry Date: {Moment(item.updatedAt).format('MMM DD, YYYY')}</Text>
                  </View>

                  <View
                      style={{
                        justifyContent: 'flex-end',
                        alignItems: 'flex-end',
                        marginRight:10
                      }}
                    >
                      <Text style={{fontWeight:'bold',fontSize:12,}}>Status : {item.status}</Text>
                      </View>
                
                </View>
                <View style={{flexDirection:'row'}}>
                <View >
                  <View style={Style.topHead2}>
                    <View style={Style.grossText}>
                      <Text style={{flex:.75,fontSize:11,justifyContent: "center",}}>Item Name</Text>
                      <Text style={{flex:.15, }}>:</Text>
                      <Text style={{flex:1,fontSize:10,textAlign:'auto' }}>{item.itemName?item.itemName:"--"}</Text>
                    </View>
                  </View>

                  <View style={Style.topHead2}>
                    <View style={Style.grossText}>
                      <Text style={{ flex:.75,fontSize:11,justifyContent: "center",}}>Purity (Kt).</Text>
                      <Text style={{ flex:.15 }}>:</Text>
                      <Text style={{ flex:1,fontSize:10,textAlign:'auto' }}>{item.purity? item.purity.purityName:"--"}</Text>
                    </View >
                  </View>
                  <View style={Style.topHead2}>
                    <View style={Style.grossText}>
                      <Text style={{flex:.75,fontSize:11,justifyContent: "center",}}>Net Wt.</Text>
                      <Text style={{ flex:.15 }}>:</Text>
                      <Text style={{flex:1,fontSize:10,textAlign:'auto' }}>{item.netWt} gm</Text>
                    </View>
                  </View>
                  </View>
                  <View
                      style={{
                    
                        position:'absolute',
                        right:10,
                        bottom:10,
                        alignSelf:'flex-end'
                      }}
                    >
                      <TouchableOpacity
                        style={Style.ViewDetailContainer}
                        onPress={() =>
                        {
//this.props.navigation.navigate('ViewEnquiryDetails')
var enqItem={};
enqItem.info=item;
NavigationService.navigate('ViewEnquiryDetails',enqItem);
                        }
                        }
                      >
                        <Text style={Style.Buttontext}>View Details</Text>
                      </TouchableOpacity>
                    </View>

                  {/* {(item.status === 'confirmed' && */}

                  
                  </View>
              
              </View>
</View>
:null
}
           
           
           
           
           
           
            </View>
            
          
          
          
          
          }          />


       
        </ScrollView >
      
         </Topbar>
  )
}

export default HomeScreen
