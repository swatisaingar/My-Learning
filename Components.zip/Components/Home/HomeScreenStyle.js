import { StyleSheet } from 'react-native'

import { COLORS, widthPercentageToDP } from '../../constants/styles';
export default StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 10,
    marginTop:10
  },
  statusContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: widthPercentageToDP('95%')
  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft:10,
    marginBottom:5,
    marginTop:5
  },
  topHead2: {
    
    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,
 
  },
  grossText: {
  
    flexDirection: 'row',
   
    width: widthPercentageToDP('50%'),

  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',
   
    marginBottom:10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize:12
  },
})
