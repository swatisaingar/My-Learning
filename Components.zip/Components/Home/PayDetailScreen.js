import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput, Image
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import { connect } from 'react-redux';
import Loader from '../../Common/Loader';
import _ from "lodash";
import { appblueColor, appgrayColor, loginheaderColor, appheadertextColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import { cartData, getPromoCode, initialPayment, processPayment } from '../../actions'
import RazorpayCheckout from 'react-native-razorpay';
import NavigationService from '../../Services/NavigationService';

class PayDetailScreen extends Component {

  constructor(props) {
    super(props);
    this.state = {
      coursename: '',
      techerfirstname: '',
      techerlastname: '',
      platformFee: '', addonData: '', addonprice: '', totalAmount: '', paymentname: '', Amount: '',
      promo: '',
      showLoader: false,
      showPopup: false,
      canceltext: false,
      _id: '',

      _selectedids: [],
      adons: [
        { "title": "10 classes recorded video", "price": "Rs. 3000", "checked": false },
        { "title": "12 classes recorded video", "price": "Rs. 31000", "checked": false },
        { "title": "8 classes recorded video", "price": "Rs. 9000", "checked": false }
      ],

    }
  }


  componentDidMount() {
    this.props.cartData()
  }

  componentDidUpdate(prevProps) {
    if (prevProps.getCartData != this.props.getCartData && this.props.getCartData != null) {
      this.setState({
        Amount:  (this.props?.getCartData?.data?.totalAmount).toFixed(2),
      })
     this?.props?.getCartData?.data?.cartCourses?.map((item => {

        this.setState({
          coursename: item?.courseId?.name,
          platformFee: (item?.platformFee).toFixed(2),
          addonData: item?.CartCourseAddons?.map((item) => item?.addOnId?.name),
          addonprice: item?.CartCourseAddons?.map((item) => item?.totalAmount),
          totalAmount: item?.totalAmount
        })
        if (item?.courseId?.teacher?.firstName != null) {

          this.setState({
            techerfirstname: item?.courseId?.teacher?.firstName
          })
        }
        if (item?.courseId?.teacher?.lastName != null) {
          this.setState({
            techerlastname: item?.courseId?.teacher?.lastName
          })
        }
        if (item?.paymentModeId != null) {
          this.setState({
            paymentname: item?.paymentModeId?.name
          })
        }

      }))
    }

     if (this?.props?.getPromoData?.data === "PromoCode Applied") {
      this.props.cartData();
     }
  }


  handlepromo = (text) => {
    this.setState({ promo: text })
  }

  checkPromo = () =>{
    this.props.getPromoCode(this?.props?.getCartData?.data?.id, this.state.promo);
    if(this?.props?.getPromoError?.message){
      alert(this.props.getPromoError.message)
    }
  }

  displayRazorPay = async () => {

    const { initialPayment } = this.props;
    await initialPayment(this.state.Amount, 'INR');

    if (this.props.getPaymentData != null) {
      if (this.props.getPaymentData.data != null) {
        var options = {
          description: 'Payment',
          image: 'https://i.imgur.com/3g7nmJC.png',
          currency: this.props.getPaymentData.data.currency,
          key: this.props.getPaymentData.data.key,
          amount: this.props.getPaymentData.data.amount,

          name: this.props.getPaymentData.data.userDetails.name,
          prefill: {
            email: this.props.getPaymentData.data.userDetails.email,
            contact: this.props.getPaymentData.data.userDetails.contactNumber,
            name: this.props.getPaymentData.data.userDetails.name
          },
          theme: { color: '#F37254' },
        }
        RazorpayCheckout.open(options).
          then((data) => {
            console.log('qebfqeilgbg',this?.props?.getPaymentData?.data?.orderId, 'sucess', data, this?.props?.getCartData?.data?.id)
            this.props.processPayment(this?.props?.getPaymentData?.data?.orderId, 'sucess', data, this?.props?.getCartData?.data?.id)

          }).catch((error) => {
            NavigationService.navigate('PaymentFailed')
            // handle failure
            // alert(`Error: ${error.code} | ${error.description}`);
          });

      }
    }

    // })



  }

  render() {
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>

        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();
                //	NavigationService.openDrawerr();
                //this.props.navigation.openDrawer();
                //alert('drawer');
              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

              {/* <Image style={{ width: 20, height: 20,marginLeft:10 }} source={images.menu} /> */}
            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />

          {/* <Text style={{color:'white',marginTop:15}}>Search Detail</Text> */}
          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

            <Icon1 style={{ marginLeft: 15 }} name="bell-o" size={20} color="black" />
          </View>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          nestedScrollEnabled={true}
          style={styles.container}>
          <Loader show={this.state.showLoader} />

          <View style={{
            marginTop: 10,
            marginLeft: 10,
            marginRight: 10
          }}>

            <Text style={{ fontWeight: 'bold' }}>Payment Details</Text>
            <View style={Styles.unselectedPay}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginLeft: 10, marginRight: 10, marginTop: 10 }}>
                <View>
                  <Text style={{ fontWeight: 'bold' }}>{this.state.coursename}</Text>
                  <Text style={{ fontStyle: 'italic', color: 'gray', fontSize: 12 }}>By {this.state.techerfirstname} {this.state.techerlastname}</Text>
                </View>

              </View>
              {this.state.totalAmount ? <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginLeft: 10, marginRight:2, }}>
                <Text style={{ color: appheadertextColor, fontSize: 12 }}>Pay Monthly</Text>
                <Text style={{ color: 'black', fontSize: 12 }}>₹{' '}{(this.state.totalAmount).toFixed(2)}</Text>
              </View> : null}

              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginLeft: 10,marginRight:2}}>
                <Text style={{ color: appheadertextColor, fontSize: 12 }}>Platform Fee</Text>
                <Text style={{ color: 'black', fontSize: 12 }}>₹{' '}{(this.state.platformFee)}</Text>
              </View>

              {(this?.props?.getCartData?.data?.IGST === true )&& <View style={{flexDirection:'row',justifyContent: 'space-between', marginLeft: 10, marginRight:2}}>
                <Text style={{ color: appheadertextColor, fontSize: 12 }}>GST</Text>
                <Text style={{ color: 'black', fontSize: 12 }}>₹{' '}{(this?.props?.getCartData?.data?.gstAmount).toFixed(2)}</Text>
              </View>}

             {this?.props?.getCartData?.data?.IGST === false &&  <View style={{flexDirection:'row',justifyContent: 'space-between', marginLeft: 10, marginRight:2}}>
                <Text style={{ color: appheadertextColor, fontSize: 12 }}>GST</Text>
                {<Text style={{ color: 'black', fontSize: 12 }}>{'CGST:'}{((this?.props?.getCartData?.data?.gstAmount)/2).toFixed(2)}{' '}{'SGST:'}{(this?.props?.getCartData?.data?.gstAmount).toFixed(2)}</Text>}
              </View>}

              <View style={Styles.promoinput}
              >
                <View style={Styles.background} />
                {/* <View style={{flexDirection:'row', borderBottomColor: 'gray', // Add this to specify bottom border color
    borderBottomWidth: 1 }}> */}

                <View style={{ flexDirection: 'row', }}>
                  <TextInput

                    keyboardType="default"
                    style={[Styles.textInput, { fontSize: 12 }]}
                    //  onChangeText = {this.handlePassword}
                    value={this.state.promo}
                    disableFullscreenUI={true}
                    onChangeText={this.handlepromo}
                    placeholder="PromoCode (if you have)"
                    placeholderTextColor={'gray'}
                    underlineColorAndroid="transparent"
                    returnKeyType="done"
                  />

                  <TouchableOpacity
                    style={{ alignSelf: 'center' }}
                    onPress={() => {
                      this.checkPromo()
                    }}
                  >
                    <Text style={{ color: appblueColor, marginRight: 5, alignSelf: 'center', fontSize: 12, alignContent: 'center' }}>APPLY</Text>
                  </TouchableOpacity>


                  <TouchableOpacity
                    style={{ alignSelf: 'center' }}
                    onPress={() => {
                      this.setState({
                        promo: ''
                      })
                    }}
                  >
                    <Text style={{ color: appblueColor, marginRight: 10, alignSelf: 'center', fontSize: 12, alignContent: 'center' }}>CLEAR</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            {this.state.addonData != '' && this.state.addonprice != '' ? <Text style={{ fontWeight: 'bold', marginTop: 20 }}>Add On</Text> : null}
            <ScrollView >

              {this.state.addonData != '' && this.state.addonprice != '' ? <View style={{ flexDirection: "column", }}>
                <View style={{ flexDirection: 'row', backgroundColor: appgrayColor, borderRadius: 10, elevation: 10, marginBottom: 10, marginTop: 10, marginLeft: 5, marginRight: 5, justifyContent: 'space-between' }}>

                  <View style={{ alignSelf: 'center', marginLeft: 10, marginRight: 10 }}>
                    <Text style={{ color: 'black', marginTop: 10 }}>{this.state.addonData}</Text>
                    <Text style={{ color: loginheaderColor, marginBottom: 10 }}>Rs. {this.state.addonprice}</Text>

                  </View>

                </View>
              </View> : null}



            </ScrollView>


            <Text style={{ fontWeight: 'bold', marginTop: 20 }}>Payment Mode</Text>
            <View>
              <View style={{ flexDirection: 'row' }}>
                <Image style={{ width: 20, height: 20, marginLeft: 10, marginTop: 8 }} source={images.browser} />

                <Text style={{ marginTop: 5, marginLeft: 10 }}>{this.state.paymentname} </Text>
              </View>


            </View>

          </View>

        </ScrollView >



        <View style={{
          flex: 1,
          width: '100%',

          // paddingLeft: 15,
          // padding: 5,
          position: 'absolute',
          bottom: 10,
          alignSelf: 'center',
        }}>
          <View style={{ flexDirection: 'row' }}>
            <Text style={{ marginLeft: widthPercentageToDP(12) }}>Total</Text>
            <Text style={{ marginLeft: widthPercentageToDP(60), color: '#FAA21C' }}>₹{' '}{this.state.Amount}</Text>
          </View>
          <TouchableOpacity onPress={() =>
            this.displayRazorPay()
          }>
            <Text style={Styles.registercoursebutton}>Pay</Text>
          </TouchableOpacity>
        </View>
      </View >
    )
  }

}

const mapStateToProps = state => ({
  getCartData: state.dash.getCartData,
  getPromoData: state.dash.getPromoData,
  getPaymentData: state.dash.getPaymentData,
  getProcessPaymentData: state.dash.getProcessPaymentData,
  getPromoError:state.dash.getPromoError
});

const mapDispatchToProps = {
  cartData, getPromoCode, initialPayment, processPayment
}
export default connect(mapStateToProps, mapDispatchToProps)(PayDetailScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',

    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',

    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
