import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import { connect } from 'react-redux';
import Loader from '../../Common/Loader';
import _ from "lodash";
import { appgrayColor, loginheaderColor, appheadertextColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import { Checkbox } from 'react-native-paper';
import { RadioButton } from 'react-native-paper';
import { getCart, moveToCart } from '../../actions';
import { stat } from 'react-native-fs';

class PayPlanScreen extends Component {

  constructor(props) {
    super(props);
    this.state = {
      coursename: '',
      feeDetail: '',
      standardclass: '',
      teacherFirstName: '',
      teacherLastName: '',
      addonAmount: '',
      paymentmode: '',
      subscriptionmode: '',
      addonName: '', selectedID:0 , payment: '', amount: '',newindex:'',
      checked: 'first',
      selected: false,
      check: false,
      enquiries: [],
      showLoader: false,
      showPopup: false,
      canceltext: false,
      _id: '',
      pay1: false,
      pay2: false,
      _selectedids: [],
      fetchCartData: [],
      adons: '',
      selectedIDValue:0
    }
  }

  componentDidMount() {

    this.props.fetchCartData && this.props.fetchCartData.data && this.props.fetchCartData.data.courseSubscriptionModes && this.props.fetchCartData.data.courseSubscriptionModes.map((item,index)=>{
      if(index === 0){
        this.setState({
          selectedID:item.id
        })
      }
    
    })
    this.props.getCart(this.props.navigation.state.params && this.props.navigation.state.params.courseId)
  }

  setRadioChecked(value) {
    this.setState({
      checked: value
    })
  }


  checkCondition = (value) => {
    this.setState({
      selectedID: value,
      // newindex:indexValue
    })
  }

  storedValue = () => {
    let paymentModeId;
    let amount;
    let addons;
    let subscriptionModeId
    this.props.fetchCartData.data.courseSubscriptionModes.map((item) => {
      if (item.id == this.state.selectedID) {
        amount = item.price;
        if (this.state.check) {
          addons = item.addons;
        }

        subscriptionModeId = item.subscriptionModeId;
      }
      this.props.fetchCartData.data.paymentMode.map((item) => {
        paymentModeId = item.paymentModeId;
      })
      this.props.moveToCart(this.props.navigation.state.params.courseId, amount, addons, subscriptionModeId, paymentModeId);
    })

  }

  componentDidUpdate(prevProps) {
    if (prevProps.fetchCartData != this.props.fetchCartData) {
      if (this.props.fetchCartData != null) {
        if (this.props.fetchCartData && this.props.fetchCartData.data != null) {
          if (this.props.fetchCartData.data.teacher != null) {
            this.setState({
              coursename: this.props.fetchCartData && this.props.fetchCartData.data && this.props.fetchCartData.data.name,
              teacherFirstName: this.props.fetchCartData && this.props.fetchCartData.data && this.props.fetchCartData.data.teacher.firstName,
              teacherLastName: this.props.fetchCartData && this.props.fetchCartData.data && this.props.fetchCartData.data.teacher.lastName,
              feeDetail: this.props.fetchCartData && this.props.fetchCartData.data && this.props.fetchCartData.data.fee,
            })
          }
          if ((this.props.fetchCartData && this.props.fetchCartData.data && this.props.fetchCartData.data.standard != null)) {
            this.setState({
              standardclass: this.props.fetchCartData.data.standard.class,
            })
          }
          for (let i = 0; i < (this.props.fetchCartData && this.props.fetchCartData.data && this.props.fetchCartData.data.paymentMode && this.props.fetchCartData.data.paymentMode.length); i++) {
            this.setState({
              paymentmode: this.props.fetchCartData.data.paymentMode[i].paymentModeId.name,
              payment: this.props.fetchCartData.data.paymentMode[i].paymentModeId
            })
          }

          for (let j = 0; j < (this.props.fetchCartData && this.props.fetchCartData.data && this.props.fetchCartData.data.courseSubscriptionModes && this.props.fetchCartData.data.courseSubscriptionModes.length); j++) {
            let storedvalue = []
            storedvalue = this.props.fetchCartData.data.courseSubscriptionModes[j];
            this.setState({
              subscriptionmode: storedvalue.subscriptionModeId,
              addonAmount: storedvalue.addons.price,
              addonName: storedvalue.addons.name,
              adons: storedvalue.addons,
              amount: storedvalue.price
            })
          }
        }
      }
    }

    if (prevProps.moveToCartResponse != this.props.moveToCartResponse) {
      if (this.props.moveToCartResponse && this.props.moveToCartResponse.data === "Moved to Cart") {
        this.props.navigation.navigate('PayDetailScreen');
      }
    }

    if (prevProps.addToCartError != this.props.addToCartError) {
      if (this.props.addToCartError && this.props.addToCartError.message === "Update your Address") {
        alert(this.props.addToCartError.message)
      }
    }
  }


  render() {
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>

        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();
              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />
            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />

          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

            <Icon1 style={{ marginLeft: 15 }} name="bell-o" size={20} color="black" />
          </View>
        </View>

        <ScrollView

          showsVerticalScrollIndicator={false}
          nestedScrollEnabled={true}
          style={styles.container}>
          <Loader show={this.state.showLoader} />

          <View style={{
            marginTop: 10,
            marginLeft: 10,
            marginRight: 10
          }}>

            <Text style={{ fontWeight: 'bold' }}>Select Payment Plan</Text>
          
            {this.props.fetchCartData && this.props.fetchCartData.data && this.props.fetchCartData.data.courseSubscriptionModes && this.props.fetchCartData.data.courseSubscriptionModes.length > 0 ? (

              <View>
                {this.props.fetchCartData && this.props.fetchCartData.data.courseSubscriptionModes.map((item,index) => {
                  return (
                    <TouchableOpacity
                      onPress={() => {
                        this.checkCondition(item.id);
                      }}
                    >
                      {/* {console.log('selectedIDValueselectedIDValue',index , this.state.selectedIDValue , this.state.selectedID , item.id)} */}
                      <View style={item.id === this.state.selectedID ? Styles.selectedPay : Styles.unselectedPay}>
                        {<View style={{ flexDirection: 'row', justifyContent: 'space-between', padding: 10, paddingTop: 15, paddingBottom: 15, }}>
                          <View>
                            <Text style={{ fontWeight: 'bold' }}>{this.state.coursename} - Class{this.state.standardclass}</Text>
                            <Text style={{ fontStyle: 'italic', color: 'gray', fontSize: 12 }}>By {this.state.teacherFirstName} {this.state.teacherLastName}</Text>
                          </View>
                          <View>  
                            <Text style={{ color: loginheaderColor, alignSelf: 'flex-end' }}>₹{' '}{item.price}</Text>
                            <Text style={{ color: 'gray', fontSize: 12,alignSelf: 'flex-end' }}>{item.subscriptionModeId.name}</Text>
                          </View>
                        </View>}
                      </View></TouchableOpacity>)
                })}
              </View>
            )

              : null}


            <Text style={{ fontWeight: 'bold', marginTop: 20 }}>Add On</Text>
            <View style={{ flexDirection: 'row', backgroundColor: appgrayColor, borderRadius: 10, elevation: 10, marginBottom: 10, marginTop: 10, marginLeft: 5, marginRight: 10, }}>
              <View style={{ backgroundColor: 'white', justifyContent: 'center', borderTopLeftRadius: 10, borderBottomLeftRadius: 10 }}>
                <Checkbox
                  style={{ alignSelf: 'center' }}
                  uncheckedColor={'gray'}
                  color={loginheaderColor}
                  status={this.state.check ? 'checked' : 'unchecked'}
                  onPress={() => {
                    this.setState({ check: !this.state.check });
                  }}
                />

              </View>
              <View style={{ alignSelf: 'center', marginLeft: 10, marginRight: 10 }}>
                <Text style={{ color: 'black', marginTop: 10 }}>{this.state.addonName}</Text>
                {this.props.fetchCartData && this.props.fetchCartData.data.courseSubscriptionModes.map((item,index) => {
                  return (
                    <View>
                      {(item.id === this.state.selectedID) && <Text style={{ color: loginheaderColor, marginBottom: 10 }}>{item.addons.price}</Text>}
                    </View>)
                })}
              </View>
            </View>


            <Text style={{ fontWeight: 'bold', marginTop: 20 }}>Payment Mode</Text>
            {this.props.fetchCartData && this.props.fetchCartData.data.paymentMode.length > 0 ? (
              <View>
                {this.props.fetchCartData && this.props.fetchCartData.data.paymentMode.map((item) => {
                  return (
                    <View style={{ flexDirection: 'row' }}>
                      <RadioButton
                        value="Online"
                        color={loginheaderColor}
                        status={this.state.checked === 'first' ? 'checked' : 'unchecked'}
                        onPress={() => {
                          this.setRadioChecked('first')
                        }
                        }
                      />
                      <Image style={{ width: 20, height: 20, marginLeft: 10, marginTop: 8 }} source={images.browser} />

                      <Text style={{ marginTop: 5, marginLeft: 10 }}>{item.paymentModeId.name} </Text>
                    </View>
                  )
                })}

              </View>
            ) : null}

          </View>
        </ScrollView >

        <View style={{
          flex: 1,
          position: 'absolute',
          bottom: 10,
          alignSelf: 'center'
        }}>
          {this.state.canceltext == false ?
            <View style={{ elevation: 10, backgroundColor: 'white', marginBottom: 10, borderRadius: 10 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop: 10, paddingBottom: 10 }}>
                <Image style={{ width: 20, height: 20, marginLeft: 20, alignSelf: 'center' }} source={images.info} />
                <View style={{ width: '70%' }}>
                  <Text style={{ fontWeight: 'bold', color: appheadertextColor, fontSize: 12 }}>Did you know?</Text>
                  <Text numberOfLines={3} style={{ fontSize: 10, color: appheadertextColor }}>You will get 1 class of evaluation and you can cancel the registration within same day after joining the class.</Text>
                </View>
                <TouchableOpacity
                  style={{ width: 10, height: 10, marginRight: 10, alignSelf: 'center' }}
                  onPress={() => {
                    this.setState({
                      canceltext: true,
                    })
                  }}
                >
                </TouchableOpacity>
              </View>
            </View> : null
          }
          <TouchableOpacity
            onPress={() => {
              this.storedValue()
            }}
          >
            <Text style={Styles.registercoursebutton}>Continue</Text>
          </TouchableOpacity>
        </View>
      </View >
    )
  }

}

const mapStateToProps = state => ({
  fetchCartData: state.dash.fetchCartData,
  moveToCartResponse: state.dash.addToCartData,
  addToCartError:state.dash.addToCartError,
  wish: state.wish
});

const mapDispatchToProps = {
  getCart, moveToCart
}

export default connect(mapStateToProps, mapDispatchToProps)(PayPlanScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',

    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',

    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
