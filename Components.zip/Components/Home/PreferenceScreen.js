import React, { Component } from 'react'
import { StatusBar, TouchableOpacity, View, ScrollView, Text, BackHandler, Image, ActivityIndicator } from 'react-native'
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import { StackActions, NavigationActions } from 'react-navigation';
import NavigationService from '../../Services/NavigationService';
import SectionedMultiSelect from 'react-native-sectioned-multi-select';
import Icon1 from 'react-native-vector-icons/FontAwesome';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { widthPercentageToDP } from '../../constants/styles'
import { appheadertextColor, loginheaderColor } from '../../util/AppConstants';
import { standardList,categoryList,updateprofile,profile } from '../../actions';
import { connect } from 'react-redux';
import { Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../../util/AppConstants';

class PreferenceScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      tutors: [],
      categoryName:[],
      selectedClass: '',
      profData: null,
      selectedItems: [],
      language: [],
      selectedItemsCat: [],
      langKnown: [],
      languageId: '',
      languageClass: '',
     
    }
  }

  
  static navigationOptions = {
    headerShown: false,
  };

  handleBackButtonClick = () => {
    if (this.state.backPressed > 0) {
      console.log('executedddd')
      BackHandler.exitApp();
      this.state.backPressed = 0;
    } else {
      this.state.backPressed++;
      ToastAndroid.show("Press Again To Exit", ToastAndroid.SHORT);
      setTimeout(() => { this.state.backPressed = 0 }, 2000);
      return true;
    }
  
  }

  onSelectedItemsChangee = selectedItems => {
    this.setState({ selectedItemsCat: selectedItems });
  };

  onSelectedItemsChange = selectedItems => {
    this.state.tutors.map(item => {
      if(item.id === selectedItems[0]){
        this.setState({selectedClass : item.class})
      }
    })
    this.setState({ selectedItems });
  };
  

  async componentDidMount() {
    StatusBar.setHidden(false);

    
    this.getlanguages();
    this.getStandard();
    this.getData();

    this.setState({
      // categoryName: categoryitems,
      profData: this.props.prof.profData && this.props.prof.profData.data
    });
    let profileData= await AsyncStorage.getItem('user_id');
    this.props.profile(profileData);

    BackHandler.addEventListener('hardwareBackPress', this.handleBackButtonClick.bind(this));
    
  }

  async getData() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    var temp = [];
    fetch(`${baseURL}categories`, {
      method: "GET",
      headers: {
         Authorization: `Bearer ${AuthToken}`,
      }
    }).then(response => response.json())
      .then(responseJson => {
        console.log('responsejson',responseJson)
        let cateListData = responseJson.data.length;
        if (cateListData > 0) {
          for (let i = 0; i < cateListData; i++) {
            var data = responseJson.data[i];
            // var namevalue = { id: data.id, value: data.name };
            temp.push(data);
          }
        }
        this.setState({
          categoryName: temp
        });
      })
      .catch(e => {
        console.log('Exception value', e);
      })
  }

  async getStandard() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    var standardData = [];
    fetch(`${baseURL}classes`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(response => response.json())
      .then(responseJson => {
  
        var len = responseJson.data.length;
        if (len > 0) {
          for (let i = 0; i < len; i++) {
            var data = responseJson.data[i];

            var standardDatavalue = { id: data.id, value: data.class };
            standardData.push(data);
          }
        }
        this.setState({
          tutors : standardData
        })
      })
      .catch(e => {
        console.log('Exception value', e);
      })
  }
  async getlanguages() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    var lanData = [];
    fetch(`${baseURL}languages`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(response => response.json())
      .then(responseJson => {
        let len = responseJson.data.length;
        if (len > 0) {
          for (let i = 0; i < len; i++) {
            let data = responseJson.data[i];
            var languagelist = { id: data.id, value: data.name };
            lanData.push(languagelist);
          }
        }
        this.setState({
          language: lanData
        })
      })
      .catch(e => {
        console.log('Exception value', e);
      })
  }

  componentWillUnmount() {
    BackHandler.addEventListener('hardwareBackPress', this.handleBackButtonClick.bind(this));
    }

  componentDidUpdate(prevProps){
    if (this.props.prof != null) {
      if (this.props.prof != prevProps.prof) {
        this.setState({ profData : this.props.prof.profData && this.props.prof.profData.data})
      }
      this.props.prof.profData = null
  }
}

onChangeLanguage = (langValue) => {
  this.setState({ langKnown: langValue })

  var filteredCategoryObject = this.state.language && this.state.language.filter(data => (langValue.includes(data.id)));
  let filteredLanguage = filteredCategoryObject && filteredCategoryObject[0].id;
  let filteredLanguageName =filteredCategoryObject && filteredCategoryObject[0].value;
  this.setState({ languageId: filteredLanguage, languageClass: filteredLanguageName })
}

  update(){
    
    let tempcat =[]
    this.state.categoryName.map(item => {
      if(this.state.selectedItemsCat.includes(item.id)){
        tempcat.push({
          id: item.id,
          // value: item.name
        })
      }
    })

    let apiData = this.state.profData;
    
   
    apiData.preferredCategory = tempcat,
   
    apiData.standard = {
      id : this.state.selectedItems && this.state.selectedItems[0],
      class: this.state.selectedClass
    }

    apiData.language = [{
      id: this.state.languageId,
      name : this.state.languageClass
    }]
   
    // apiData.image = {
    //   id: this.state.profData.imageId
    // }
    apiData.authorities = ["ROLE_STUDENT"]
    if(tempcat.length > 0 && this.state.selectedItems.length > 0 &&  this.state.langKnown.length> 0){
      
     console.log('apiData being calledd',apiData)
      this.props.updateprofile(apiData)
    }else{
      Alert.alert('Add atleast one of each preference')
    }

    
  }

  render() {

    return (

      <View style={{ backgroundColor: 'white', flex: 1 }}>
        <ScrollView>
          <View>
            <View style={{ backgroundColor: loginheaderColor, paddingBottom: 40 }}>
              <View style={{ flexDirection: 'row', marginTop: 40, justifyContent: 'space-between' }}>
                <Text style={{ marginLeft: 20, fontSize: 18, fontWeight: 'bold', color: 'white' }}>Set Preference </Text>
              </View>
              <Text style={{ marginLeft: 20, fontSize: 12, fontStyle: 'italic', width: '80%', color: 'white', marginTop: 10 }}>Set Preferences for your best personalized result. You can change anytime from profile</Text>

              <View style={[Styles.multilabel, { marginLeft: 20, marginTop: 80,}]}>
                <SectionedMultiSelect
                  IconRenderer={Icon}
                  items={this.state.tutors}
                  uniqueKey="id"
                  subKey="children"
                  selectText="Select Standard"
                  displayKey="class"
                  selectToggleIconComponent={<Icon1 style={{ marginRight: 20 }} name="angle-down" size={20} color="black" />
                  }
                  itemFontFamily={"Avenir / normal - 200"}
                  searchPlaceholderText="Search Standard"
                  showDropDowns={false}
                  hideSearch={true}
                  readOnlyHeadings={false}
                  onSelectedItemsChange={this.onSelectedItemsChange}
                  single={true}
                  hideConfirm={true}

                  styles={{ selectToggleText: { color: 'black', fontSize: 13, textAlignVertical: 'center' }, button: { backgroundColor: 'red', fontSize: 15 }, container: { marginTop: 200, marginBottom: 200 }, selectToggle: { backgroundColor: 'white', alignContent: 'center', paddingLeft: 10, borderRadius: 30, height: 50 } }}

                  modalWithTouchable={true}
                  selectedItems={this.state.selectedItems}
                  alwaysShowSelectText={false}
                />
              </View>
              <View style={[Styles.multilabel, { marginLeft: 20, marginTop: 20, }]}>
                <SectionedMultiSelect
                  IconRenderer={Icon}
                  items={this.state.categoryName}
                  uniqueKey="id"
                  subKey="children"
                  selectText="Preferred Category"
                  displayKey="name"
                  selectToggleIconComponent={<Icon1 style={{ marginRight: 20 }} name="angle-down" size={20} color="black" />
                  }
                  itemFontFamily={"Avenir / normal - 200"}
                  searchPlaceholderText="Search Category"
                  showDropDowns={false}
                  hideSearch={false}
                  readOnlyHeadings={false}
                  onSelectedItemsChange={this.onSelectedItemsChangee}
                  single={false}
                  hideConfirm={false}
                  confirmText='OK'
                  styles={{ selectToggleText: { color: 'black', fontSize: 13, textAlignVertical: 'center' }, button: {backgroundColor:loginheaderColor, color:'black',fontSize: 15 }, container: { marginTop: 200, marginBottom: 200 }, selectToggle: { backgroundColor: 'white', alignContent: 'center', paddingLeft: 10, borderRadius: 30, height: 50 }, chipText: { color: appheadertextColor }, chipsWrapper: { marginTop: 10 }, chipContainer: { backgroundColor: 'white' },}}
                  modalWithTouchable={true}
                  selectedItems={this.state.selectedItemsCat}
                  alwaysShowSelectText={false}
                />
              </View>

              <View style={[Styles.multilabel, { marginLeft: 20, marginTop: 20, }]}>
              <SectionedMultiSelect
              IconRenderer={Icon}
              items={this.state.language}
              uniqueKey="id"
              selectToggleIconComponent={<Icon1 style={{ marginRight: 20 }} name="angle-down" size={20} color="black" />
              }
              selectText="Select Language"
              itemFontFamily={"Avenir / normal - 200"}
              searchPlaceholderText="Search Language"
              showDropDowns={true}
              hideSearch={false}
              readOnlyHeadings={false}
              onSelectedItemsChange={this.onChangeLanguage}
              single={true}
              hideConfirm={false}
              confirmText='OK'
              displayKey='value'
              styles={{ selectToggleText: { color: appheadertextColor, fontSize: 13, textAlignVertical: 'center' }, button: {backgroundColor:loginheaderColor,color:'black', fontSize: 15 }, container: { marginTop: 200, marginBottom: 200 }, selectToggle: { backgroundColor: 'white', alignContent: 'center', paddingLeft: 10, borderRadius: 30, height: 50 } }}
              modalWithTouchable={true}
              selectedItems={this.state.langKnown}
              alwaysShowSelectText={true}

            />
            </View>

            </View>

            {
              this.state.isLoading ? <View style={Styles.loading}>
                <ActivityIndicator sizewhite='large' color='white'>
                </ActivityIndicator>
              </View>
                : null
            }
            {/* <View style={{position:'absolute',bottom:20,alignSelf:'center'}}> */}

            <View style={{ marginTop: 100, backgroundColor: 'white' }}>

              <TouchableOpacity onPress={async() => {
              await  this.update()
                // NavigationService.navigateAndReset('Home');

              }

              } >
                <View
                  style={[Styles.loginscreenbtn, { width: widthPercentageToDP('80%') }]}


                >


                  <Text style={{ color: 'white', justifyContent: 'center', alignContent: 'center', alignSelf: 'center' }}>Save
</Text>
                </View>
              </TouchableOpacity>


            </View>
          </View></ScrollView>
      </View>

    )
  }
}

const mapStateToProps = state => ({
  tuts: state.standard,
  catList:state.category,
  // user: state.auth,
  prof: state.prof,
});
const mapDispatchToProps = {
  standardList,categoryList,updateprofile,
  profile
};
export default connect(mapStateToProps, mapDispatchToProps)(PreferenceScreen);
