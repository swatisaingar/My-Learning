import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList, Alert, TextInput, TouchableWithoutFeedback, Image, ImageBackground, Dimensions
} from 'react-native';
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';
import Icon1 from 'react-native-vector-icons/FontAwesome';



import { fetchReplyList, sendOA, fetchVendors } from '../../actions';
import NavigationService from '../../Services/NavigationService'
import ActiveScreen from '../Recordings/ActiveScreen';
import DormantScreen from '../Recordings/DormantScreen';
import CompletedScreen from '../Recordings/CompletedScreen';

import { COLORS, widthPercentageToDP } from '../../constants/styles'
import { connect } from 'react-redux';
import { BASEURLIMAGE, loginheaderColor, appgrayColor, appbluebtnColor, appheadertextColor } from '../../util/AppConstants';
import images from '../../util/img';

import { client } from "../../util/serviceConfig";
import { useDispatch, useSelector } from 'react-redux'
import { createStackNavigator } from 'react-navigation-stack';

import { createAppContainer } from 'react-navigation'

import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../../util/AppConstants';

class RecordingTab extends Component {

  constructor(props) {
    super(props);
    this.state = {
      profileImage:{}
    }
    params = this.props.navigation.state.params;
  }

  async componentDidMount() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    let profileid = this.props.prof?.profData?.data?.imageId;
    fetch(`${baseURL}file-blobs/getImage/${profileid}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let profileImage = this.state.profileImage || {};
      profileImage[resposne.data.id] = resposne.data;
      this.setState(profileImage);
    }).
      catch((error) => {
        console.log("#error", error);
      })

  }







  render() {


    const Stylelist = createAppContainer(createStackNavigator({
      TabDrawerScreen1: {
        screen:
          createMaterialTopTabNavigator({
            ActiveScreen: { screen: ActiveScreen },
            DormantScreen: { screen: DormantScreen },
            CompletedScreen: { screen: CompletedScreen },











          },


            {

              tabBarPosition: 'top',
              swipeEnabled: true,
              tabBarOptions: {
                scrollEnabled: true,
                activeTintColor: loginheaderColor,
                inactiveTintColor: appheadertextColor,
                indicatorStyle: {
                  opacity: 1,
                  backgroundColor: loginheaderColor

                },

                style:
                {
                  backgroundColor: 'white',
                },

                showIcon: false,
                lazy: true,
                upperCaseLabel: false,
                labelStyle: {
                  fontSize: 14,
                  fontFamily: "Helvetica",


                },

                tabStyle: { height: 50, width: Dimensions.get('window').width / 3 }
              }
            }
          ),
      },
    },

      { headerMode: 'none' }
    ));



    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>
        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 50, justifyContent: 'space-between', elevation: 10 ,marginTop:5}}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                NavigationService.openDrawerr();
              }}
            >
              <Image style={{ width: 20, height: 20, marginLeft: 10 }} source={images.menu} />
            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 10,marginLeft:120 }} source={images.logo} resizeMode={'contain'} />

            <Icon1 style={{ marginTop: 15, alignContent: 'flex-end',marginLeft:80 }} name="bell-o" size={25} color={'black'} />
            <TouchableOpacity onPress={()=>NavigationService.navigate('ProfileScreen')}>
          {(this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content) ?<Image
              resizeMode='contain'
                source={{uri:`data:image/jpeg;base64,${this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content}`}}
                style={{ width: 25, height: 25, marginLeft:5,marginRight:20,marginTop:15,borderWidth:1}}
              />:<View style={{
                width: 25,
                height: 25,
                marginLeft: 5,
                marginRight: 20,
                marginTop: 15,
                borderWidth: 1
              }}><ActivityIndicator size='small'/></View>}
              </TouchableOpacity>
        </View>
                <Stylelist /></View >

    )
  }



}

const mapStateToProps = state => ({
  prof: state.prof,
  user: state.auth,
  reply: state.reply,
  sendoa: state.sendoa,
  vendors: state.vendors
});
const mapDispatchToProps = {
  fetchReplyList, sendOA, fetchVendors
};

export default connect(mapStateToProps, mapDispatchToProps)(RecordingTab);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 50,
    marginTop: 10,

  },
  statusContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: widthPercentageToDP('95%')
  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 10,
    marginTop: 5


  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `white`,
    padding: 10,
    marginTop: 10,

    backgroundColor: 'red',

  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `red`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: 'red',
    marginTop: 10,
    marginBottom: 10,

  },
  showmoreContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,

    backgroundColor: 'white',


  },
  addcartContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.DARKBLUE}`,
    padding: 5,
    marginTop: 5,

    backgroundColor: `${COLORS.MAINCOLOR.DARKBLUE}`,


  },
  backContainer:
  {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.DARKBLUE}`,
    padding: 10,
    marginTop: 10,

    backgroundColor: `${COLORS.MAINCOLOR.DARKBLUE}`,


  },
  showmoreclickedContainer:
  {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.DARKBLUE}`,
    padding: 5,


    backgroundColor: `${COLORS.MAINCOLOR.DARKBLUE}`,


  },
  Buttontext: {
    color: 'white',
    fontSize: 12,
    alignSelf: 'center'
  },
  showmoreclickedtext: {
    color: 'white',
    fontSize: 10,
    alignSelf: 'center'
  },
  BottomButtontext: {
    color: `white`,
    fontSize: 12,
    alignSelf: 'center'
  },
  showmoretext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 10,
    alignSelf: 'center'
  },
  addcarttext: {
    color: 'white',
    fontSize: 10,
    alignSelf: 'center'
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, .7)',

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  },
  text: {
    fontSize: 10,
    fontWeight: "bold",
    color: `${COLORS.MAINCOLOR.DARKBLUE}`,
  },
  selectoptionbutton: {
    margin: 10,
    height: 40,
    alignSelf: 'center',
    padding: 10,
    width: 200,
    backgroundColor: '#237D99',
    borderRadius: 10


  },
})
