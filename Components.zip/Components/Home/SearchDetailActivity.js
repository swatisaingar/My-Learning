import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity, TouchableWithoutFeedback,
  Image,
  Dimensions,
  ActivityIndicator
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import moment from 'moment';
import Loader from '../../Common/Loader';
import _, { isInteger } from "lodash";
import { loginheaderColor, appheadertextColor, appblueColor } from '../../util/AppConstants';
import images from '../../util/img';
import { moveToCart, getCourseDetail, scanApi, fetchRating, addWishlistedData, removeWishlistedData, imageWithoutLoopLoad, imageForTeacher } from '../../actions'
import HTML from 'react-native-render-html';
import { connect } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import NavigationService from '../../Services/NavigationService';
import { baseURL } from '../../util/AppConstants';

class SearchDetailActivity extends Component {

  constructor(props) {
    super(props);
    this.state = {
      teacherFirstName: '', teacherLastName: '', paymentMode: '', language: '', teacherExp: '',
      img: '',
      name: '',
      class: '',
      teachername: '',
      teacherqualification: '',
      coursedays: '',
      courseduration: '',
      feedetails: '',
      startdate: '',
      startTime: '',
      endTime: '',
      rating: '',
      enquiries: [],
      showLoader: false,
      isLoading: false,
      showPopup: false,
      canceltext: false,
      _id: '',
      _selectedids: [],
      start: 0, total: 0,
      start2: 0, total2: 0,
      courseDetailData: [],
      addWishList: false,
      removeWishList: false,
      teacherSubs: '',
      imageData: {},
      teacherimageData: {},
      imageLoading: true,
      profileImage: {}
    }
  }


  async componentDidMount() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    this.setState({ isLoading: true })
    this.props.getCourseDetail(this.props.navigation.state.params && this.props.navigation.state.params.courseId);
    if (this.props.courseDetailData && this.props.courseDetailData.creator.id != null) {
      this.props.scanApi(this.props.courseDetailData && this.props.courseDetailData.creator.id)
    }
    let profileData = await AsyncStorage.getItem('user_id');
    this.props.fetchRating(profileData)

    let id = this.props?.courseDetailData?.imageId;
    fetch(`${baseURL}file-blobs/getImage/${id}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let imageData = this.state.imageData || {};
      imageData[resposne.data.id] = resposne.data;
      this.setState(imageData);
      this.setState({ imageLoading: false });
    }).
      catch((error) => {
        console.log("#error", error);
      })

    let teacherid = this.props.courseDetailData && this.props.courseDetailData.courseUsers && this.props.courseDetailData.courseUsers[0] && this.props.courseDetailData.courseUsers[0].teacher_id?.imageId;
    fetch(`${baseURL}file-blobs/getImage/${teacherid}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let teacherimageData = this.state.teacherimageData || {};
      teacherimageData[resposne.data.id] = resposne.data;
      this.setState(teacherimageData);
      this.setState({ imageLoading: false });
    }).
      catch((error) => {
        console.log("#error", error);
      })

    let profileid = this.props.prof?.profData?.data?.imageId;
    fetch(`${baseURL}file-blobs/getImage/${profileid}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let profileImage = this.state.profileImage || {};
      profileImage[resposne.data.id] = resposne.data;
      this.setState(profileImage);
    }).
      catch((error) => {
        console.log("#error", error);
      })
  }

  checkCondition = (value) => {
    this.setState({ selected: value })
  }

  wishlist = async () => {
    let profileData = await AsyncStorage.getItem('user_id');
    this.props.addWishlistedData(true, profileData, this.props.courseDetailData && this.props.courseDetailData.id)

  }

  remove = () => {
    this.props.removeWishlistedData(this.props.courseDetailData && this.props.courseDetailData.id);

  }

  componentDidUpdate(prevProps) {
    if (this.props.courseDetailData != null) {
      if (prevProps.courseDetailData != this.props.courseDetailData) {
        this.setState({ isLoading: false })
        this.setState({
          courseDetailData: this.props.courseDetailData,
        })

        for (let i = 0; i < (this?.props?.courseDetailData?.courseSubscriptionModes?.length); i++) {
          this.setState({
            teacherSubs: this.props.courseDetailData.courseSubscriptionModes[i].subscriptionModeId.name,
          });
        }

        if (this.props.courseDetailData.paymentMode != null) {
          this.setState({
            paymentMode: this.props.courseDetailData.paymentMode.map((item) => item.paymentModeId.name)
          })
        }

        if (this.props.courseDetailData.language != null) {
          this.setState({
            language: this.props.courseDetailData.language.name
          })
        }
      }
    }
    if (this.props.ratingData != null) {
      if (prevProps.ratingData != this.props.ratingData) {
        var storedValue = 0;
        for (let i = 0; i < this?.props?.ratingData?.data?.length; i++) {
          storedValue = storedValue + this.props.ratingData.data[i].rating;
        }
        var Avgrating = storedValue / this?.props?.ratingData?.totalCount

        this.setState({
          rating: Avgrating
        })
      }
    }
    if (prevProps.addtoWishListData != this.props.addtoWishListData) {
      if (this.props.addtoWishListData.data === "wishList Created") {
        this.setState({ addWishList: true })
      }
    }

    if (prevProps.removeWishListData != this.props.removeWishListData) {
      if (this.props.removeWishListData.data === "Course removed from WishList") {
        this.setState({ addWishList: false })
      }
    }
  }


  render() {

    let stars = [];
    let path = '';
    let integer_part = Math.trunc(this.state.rating);
    let decimat_part = this.state.rating - integer_part;
    let total_star_count = 0;
    for (let i = 1; i <= this.state.rating; i++) {
      path = require('../../images/star.png');
      stars.push((<Image style={{
        width: 15,
        height: 15, marginRight: 1, marginLeft: 1
      }} source={path} />));
      total_star_count++;
    }
    if (decimat_part != 0) {
      path = require('../../images/star-half.png');
      stars.push((<Image style={{
        width: 20,
        height: 20, marginRight: 1, marginLeft: 1, position: 'relative', top: -2
      }} source={path} />));
      total_star_count++;
    }
    if (total_star_count != 5) {
      path = require('../../images/unfilled-star.png');
      for (let i = total_star_count; i < 5; i++) {
        stars.push((<Image style={{
          width: 15,
          height: 15, marginRight: 1, marginLeft: 1
        }} source={path} />));
      }
    }

    const { courseDetailData } = this.state;
    let imageUri = `data:${courseDetailData?.image?.contentContentType};base64,${courseDetailData?.image?.content}`;

    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>

        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 50, justifyContent: 'space-between', elevation: 10, marginTop: 5 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();

              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 10, marginLeft: 120 }} source={images.logo} resizeMode={'contain'} />

          <Icon1 style={{ marginTop: 15, alignContent: 'flex-end', marginLeft: 80 }} name="bell-o" size={25} color={'black'} />
          <TouchableOpacity onPress={() => NavigationService.navigate('ProfileScreen')}>
            {(this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content) ?<Image
              resizeMode='contain'
              source={{ uri: `data:image/jpeg;base64,${this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content}` }}
              style={{ width: 25, height: 25, marginLeft: 5, marginRight: 20, marginTop: 15, borderWidth: 1 }}
            />:<View style={{
              width: 25,
              height: 25,
              marginLeft: 5,
              marginRight: 20,
              marginTop: 15,
              borderWidth: 1
            }}><ActivityIndicator size='small'/></View>}
          </TouchableOpacity>
        </View>
        {this.state.isLoading ? <ActivityIndicator style={{ marginTop: 100 }} /> : <>
          {console.log('coursedeailssss data', courseDetailData)}
          {(courseDetailData) ? (
            <ScrollView
              showsVerticalScrollIndicator={false}
              nestedScrollEnabled={true}
              style={styles.container}>
              <Loader show={this.state.showLoader} />

              <View style={{

                paddingRight: 5,
                paddingLeft: 5,
                marginTop: 10,
                justifyContent: 'center', alignItems: 'center'
              }}>
                <View style={styles.labelContainer}>
                  {/* {console.log('this.state.imageData[this.props?.courseDetailData?.imageId]',this.state.imageData[this.props?.courseDetailData?.imageId])} */}
                  <View style={{ flexDirection: 'row' }}>
                    {!this.state.imageLoading ? <Image
                      resizeMode='contain'
                      source={{ isStatic: true, uri: `data:image/jpeg;base64,${this.state.imageData[this.props?.courseDetailData?.imageId] && this.state.imageData[this.props?.courseDetailData?.imageId].content}` }}
                      style={{
                        width: widthPercentageToDP('22%'),
                        borderRadius: 10,

                      }}
                    ></Image>
                      :
                      <View style={{
                        width: widthPercentageToDP('22%'),
                        borderRadius: 10,

                      }}>
                        <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                      </View>}

                    <View style={{ width: '80%' }}>
                      <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                        <Text style={{ fontSize: 12, marginLeft: 10 }}>{courseDetailData?.name}{','} {"Class" + "-" + courseDetailData?.standard?.class}</Text>

                        <View style={{ flexDirection: 'row', marginRight: 20 }}>
                          {stars}
                        </View>
                      </View>

                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                        <View>
                          <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By{' '}
                            {courseDetailData && courseDetailData.courseUsers && courseDetailData.courseUsers[0] && courseDetailData.courseUsers[0].teacher_id?.firstName}{' '}{courseDetailData && courseDetailData.courseUsers && courseDetailData.courseUsers[0] && courseDetailData.courseUsers[0].teacher_id.lastName}{', '}{courseDetailData && courseDetailData.courseUsers && courseDetailData.courseUsers[0] && courseDetailData.courseUsers[0].teacher_id?.experienceInYear}yr</Text>
                        </View>

                        {this.state.addWishList || courseDetailData.isWishListed === true ?
                          <TouchableOpacity onPress={() => this.remove()} style={{ position: 'absolute', right: 20 }}>
                            <Image
                              resizeMode='contain'
                              source={images.likeselect}
                              style={{
                                width: 20,
                                height: 20, alignSelf: 'center',
                              }}
                            ></Image>
                          </TouchableOpacity>
                          :
                          <TouchableOpacity onPress={() => this.wishlist()} style={{ position: 'absolute', right: 20 }}>
                            <Image
                              resizeMode='contain'
                              source={images.shortlist_blck}
                              style={{
                                width: 20,
                                height: 20, alignSelf: 'center',
                              }}
                            ></Image>
                          </TouchableOpacity>
                        }

                        {courseDetailData.totalEnrolledStudents > courseDetailData.minBatchSize ?
                          <Image
                            resizeMode='contain'
                            source={images.confirmation}
                            style={{
                              width: 20,
                              height: 20, alignSelf: 'center', position: 'absolute', right: 1
                            }}
                          ></Image>
                          : null}
                      </View>
                      <View>
                        <Text style={{ fontSize: 12, marginLeft: 10 }}>{courseDetailData && courseDetailData.courseUsers && courseDetailData.courseUsers[0] && courseDetailData.courseUsers[0].teacher_id.qualification.map((item) => item.qualification)}</Text>
                      </View>
                      <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                      <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {moment(courseDetailData?.startDate).format('DD-MM-YYYY')})</Text>
                      <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                        <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{moment(courseDetailData?.createdDate).format('hh:mm')} to {moment(courseDetailData?.endDate).format('hh:mm')}</Text>
                        <View style={{ flexDirection: 'row', marginRight: 10 }}>
                          {courseDetailData?.courseDays?.length > 0 && courseDetailData?.courseDays?.map(i => {
                            return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                          })}
                        </View>
                      </View>

                      <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                        <View>
                          <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                          <Text style={{ color: loginheaderColor }}>{courseDetailData.status ? 'Open' : 'Completed'}</Text>
                        </View>
                        <View style={{ right: 20 }}>
                          <Text style={{ fontSize: 10 }}>Number of Classes</Text>
                          <Text style={{ color: loginheaderColor, alignSelf: 'center' }}>{courseDetailData?.courseClasses?.length}</Text>
                        </View>
                      </View>

                      <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                        <View>
                          <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                          <Text style={{ color: loginheaderColor }}>{courseDetailData.totalEnrolledStudents}/{courseDetailData.maxBatchSize}</Text>
                        </View>
                        <View style={{ right: 20 }}>

                          <Text style={{ fontSize: 10, marginLeft: 50 }}>{this.state.teacherSubs}</Text>

                          <Text style={{ color: loginheaderColor, marginLeft: 50 }}>₹{' '}{courseDetailData.fee}</Text>

                        </View>
                      </View>

                      <Text style={{ fontSize: 8, marginLeft: 10 }}>Batch will start with minimum student {courseDetailData.minBatchSize}</Text>

                    </View>
                  </View>
                </View>
              </View>
              <TouchableOpacity disabled={courseDetailData && courseDetailData.userRegistered === true}
                onPress={() => {
                  this.props.navigation.navigate('PayPlanScreen', { courseId: courseDetailData.id });
                }}>
                <Text style={[styles.registerButton, { opacity: (courseDetailData.userRegistered === true) ? 0.5 : 1 }]}>Register</Text>
              </TouchableOpacity>
              {this.state.canceltext == false ?
                <View style={{ elevation: 10, backgroundColor: 'white', marginLeft: 10, marginRight: 10, marginBottom: 10, borderRadius: 10 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop: 10, paddingBottom: 10 }}>
                    <Image style={{ width: 20, height: 20, marginLeft: 20, alignSelf: 'center' }} source={images.info} />
                    <View style={{ width: '70%' }}>
                      <Text style={{ fontWeight: 'bold', color: appheadertextColor, fontSize: 12 }}>Did you know?</Text>
                      <Text numberOfLines={3} style={{ fontSize: 10, color: appheadertextColor }}>You will get 1 class of evaluation and you can cancel the registration within same day after joining the class.</Text>
                    </View>
                  </View>
                </View> : null
              }

              <View style={{ marginTop: 10, marginLeft: 10, marginRight: 10 }}>
                <Text style={{ fontSize: 12, color: loginheaderColor, fontWeight: 'bold' }}>Course Detail</Text>
                <HTML html={courseDetailData.description} imagesMaxWidth={Dimensions.get('window').width} />
              </View>

              <TouchableWithoutFeedback
                onPress={() => {

                  this.props.navigation.navigate('TeacherDetailActivity', { id: courseDetailData.creator.id });

                }}
              >

                <View style={{ elevation: 2, backgroundColor: 'white', marginLeft: 10, marginRight: 10, marginBottom: 10, borderRadius: 10 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-around', paddingTop: 10, paddingBottom: 10 }}>

                    {!this.state.imageLoading ? <Image resizeMode='contain' style={{ width: 50, height: 50, marginLeft: 10, alignSelf: 'center' }} source={{
                      uri: `data:image/jpeg;base64,${this.state.teacherimageData[this.props.courseDetailData && this.props.courseDetailData.courseUsers[0] && this.props.courseDetailData.courseUsers[0].teacher_id && this.props.courseDetailData.courseUsers[0].teacher_id?.imageId] && this.state.teacherimageData[this.props.courseDetailData && this.props.courseDetailData.courseUsers[0] && this.props.courseDetailData.courseUsers[0].teacher_id && this.props.courseDetailData.courseUsers[0].teacher_id?.imageId].content}`,
                    }} />
                      :
                      <View style={{ width: 50, height: 50, marginLeft: 10, alignSelf: 'center' }}>
                        <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                      </View>}


                    <View style={{ width: '70%' }}>
                      {courseDetailData && courseDetailData.courseUsers && courseDetailData.courseUsers[0] && courseDetailData.courseUsers[0].teacher_id ? <Text style={{ fontWeight: 'bold', color: appheadertextColor, fontSize: 12 }}>By {courseDetailData && courseDetailData.courseUsers && courseDetailData.courseUsers[0] && courseDetailData.courseUsers[0].teacher_id.firstName}{' '}{courseDetailData && courseDetailData.courseUsers && courseDetailData.courseUsers[0] && courseDetailData.courseUsers[0].teacher_id.lastName}{', '}{courseDetailData && courseDetailData.courseUsers && courseDetailData.courseUsers[0] && courseDetailData.courseUsers[0].teacher_id.experienceInYear}yr</Text>
                      :<Text style={{alignSelf:'center'}}>Teacher is not assigned for this Course</Text>} 
                       <Text style={{ color: appheadertextColor, fontStyle: 'italic', fontSize: 12 }}>{courseDetailData && courseDetailData.courseUsers && courseDetailData.courseUsers[0] && courseDetailData.courseUsers[0].teacher_id.qualification.map((item) => item && item.qualification)}</Text>
                      <Text numberOfLines={1} style={{ color: appheadertextColor, fontSize: 12 }}>{courseDetailData && courseDetailData.courseUsers && courseDetailData.courseUsers[0] && courseDetailData.courseUsers[0].teacher_id.preferredCategory.map((item) => item && item.name)} </Text>

                    </View>

                  </View>
                </View>
              </TouchableWithoutFeedback>

              {this.props.courseDetailData && <View style={{ marginTop: 10, marginLeft: 10, marginRight: 10 }}>
                <Text style={{ fontSize: 12, color: loginheaderColor, fontWeight: 'bold' }}>Payment Mode</Text>
                <View style={{ flexDirection: 'row' }}>
                  <Image style={{ width: 20, height: 20, alignSelf: 'center' }} source={images.browser} />
                  <Text style={{ fontSize: 12, color: appheadertextColor, marginLeft: 10, textAlign: 'center' }}>{this.state.paymentMode}</Text>
                </View>
              </View>}

              {this.props.courseDetailData && <View style={{ marginTop: 10, marginLeft: 10, marginRight: 10 }}>
                <Text style={{ fontSize: 12, color: loginheaderColor, fontWeight: 'bold' }}>Languages Spoken</Text>
                <Text style={{ fontSize: 12, color: appheadertextColor, textAlign: 'justify' }}>{this.state.language}</Text>
              </View>}


            </ScrollView >) : <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
              <Text>No detail found for this course</Text>
            </View>}</>}

        <View style={{
          flex: 1,
          flexDirection: 'row',
          flexWrap: 'wrap',
          alignContent: 'center',
          justifyContent: 'space-around',
          // paddingLeft: 15,
          // padding: 5,
          position: 'absolute',
          bottom: 0,
          alignSelf: 'center'
        }}>

        </View>
      </View >
    )
  }
}

const mapStateToProps = state => ({
  prof: state.prof,
  courseDetailData: state.dash.courseDetailData,
  moveToCartResponse: state.dash.addToCartData,
  scanedCouseList: state.dash.scanedCourseData,
  ratingData: state.dash.ratingData,
  addtoWishListData: state.dash.addtoWishListData,
  removeWishListData: state.dash.removeWishListData,
  imagewithoutloopData: state.dash.imagewithoutloopData,
  teacherImageData: state.dash.teacherImageData
});
const mapDispatchToProps = {
  moveToCart, getCourseDetail, scanApi, fetchRating, addWishlistedData, removeWishlistedData, imageWithoutLoopLoad, imageForTeacher
};

export default connect(mapStateToProps, mapDispatchToProps)(SearchDetailActivity);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',

    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',

    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  },
  registerButton: {
    margin: 10,
    height: 40,
    alignSelf: 'center',
    padding: 10,
    width: "90%",
    borderRadius: 20,
    color: 'white',
    textAlign: "center",
    backgroundColor: appblueColor
  }
})
