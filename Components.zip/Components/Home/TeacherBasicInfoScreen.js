import React, { Component } from 'react'
import { TouchableOpacity, View, Text, TextInput, Image , Alert } from 'react-native'
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import { connect } from 'react-redux';
import { loginheaderColor } from '../../util/AppConstants';
import NavigationService from '../../Services/NavigationService';
import { heightPercentageToDP } from 'react-native-responsive-screen';
import { updateTeacherDetail, getTeacherDetail } from '../../actions';
import {isNumber, isEmpty} from 'lodash';

var params;
class TeacherBasicInfoScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      phone: '',
      userCheck: '',
      isModalVisible: false,
      isEmailEdit: true,
      isPhnEdit: true,
      teacherProfileDataState:null,
      loginMeansState: "CONTACT_NUMBER",
      fname:'',
      lname:'',
    }
    params = this.props.navigation.state.params;

  }
  static navigationOptions = {
    headerShown: false,
  };


  handlefname = (text) => {
    this.setState({ fname: text })
  }

  handlelname = (text) => {
    this.setState({ lname: text })
  }

  handleemail = (text) => {
    this.setState({ email: text })
  }

  handlePhone = (text) => {
    this.setState({ phone: text })
  }

  componentDidUpdate(prevProps) {
    if(prevProps.teacherProfileData!= this.props.teacherProfileData)
    {
     this.setState({teacherProfileDataState : this.props.teacherProfileData})
    
    }
    if(prevProps.updateTeacherProfileData != this.props.updateTeacherProfileData)
    {
    console.log("Api resp=====", this.props.updateTeacherProfileData )
      NavigationService.navigate('Teacher' , this.props.teacherProfileData) 
    }
  }

  componentDidMount(){
    this.props.getTeacherDetail();
    this.setLoginMedium();
  
    
  }
showSingleButtonAlert(title , txt)
{
  Alert.alert(
    title,
    txt,
    [
      { text: "OK"}
    ],
    { cancelable: false }
  );
}

showTwoButtonAlert(txt)
{
  Alert.alert(
    title,
    txt,
    [
      {
        text: "Cancel",
        style: "cancel"
      },
      { text: "OK"}
    ],
    { cancelable: false }
  );
}
  setLoginMedium(){
    !this.mobilevalidate(params.email)?
      this.setState({email: params.email, isEmailEdit: false, isPhnEdit: true})
    : this.setState({phone: params.email, isPhnEdit : false, isEmailEdit: true})
  }

  mobilevalidate(text) {
    const reg = /^[0]?[789]\d{9}$/;
    if (reg.test(text) === false) {
      this.setState({
        mobilevalidate: false,
        telephone: text,
      });
      return false;
    } else {
      this.setState({
        mobilevalidate: true,
        telephone: text,
        message: '',
      });
      return true;
    }
  }

  hanndleUpdate=()=>{
  if(( this.props.teacherProfileData) !=null && ( this.props.teacherProfileData.data)!=null)
  {
    var contact_number = !isEmpty(this.state.phone) ? this.state.phone : this.state.teacherProfileDataState.data.contactNumber
    var email_update = !isEmpty(this.state.email) ? this.state.email : this.state.teacherProfileDataState.data.email

    if(isEmpty(this.state.fname))
    {
      this.showSingleButtonAlert("", "Please enter your first name")
    }

    else if(isEmpty(this.state.lname))
    {
      this.showSingleButtonAlert("", "Please enter your last name")
    }
   else if(isEmpty(contact_number))
    {
      
      this.showSingleButtonAlert("", "Please enter your mobile number")
    }
    else if(!this.mobilevalidate(contact_number))
    {
      this.showSingleButtonAlert("", "Please enter valid mobile number")
    }
    else if(isEmpty(email_update))
    {
      
      this.showSingleButtonAlert("", "Please enter your email") 
    }
   

    if(!isEmpty(this.state.teacherProfileDataState)){

      const updateData = ({...this.state.teacherProfileDataState.data, 
        email: email_update,
        contactNumber: contact_number,
        firstName: this.state.fname,
        lastName:this.state.lname

       })
       this.props.updateTeacherDetail(updateData)
  }
    

     }

    else{
      //Alert.Alert
    }
    
  }

  render() {
    return (
      <View style={{ flex: 1 }}>
        <View style={{ height: heightPercentageToDP('50%'), backgroundColor: loginheaderColor, }}>

          <TouchableOpacity
            style={{ position: 'absolute', left: 10, top: 20 }}
            onPress={() => { this.props.navigation.goBack() }}>

            <Image source={images.loginback} style={{
              height: 40, width: 40,
              resizeMode: 'contain',
            }}></Image>
          </TouchableOpacity>

          <View style={{ justifyContent: 'center', }}>
            <View style={{ marginTop: 100, marginLeft: 20 }}>
              <Text style={{ fontSize: 18, color: 'white' }}>Enter Details</Text>
              <Text style={{ fontSize: 12, color: 'white', fontStyle: 'italic', marginTop: 5 }}>Enter your basic details</Text>
            </View>
          </View>

          <View style={{ flexDirection: 'row', justifyContent: 'center' }}>

            <View style={[Styles.profilescreeninput1, { marginTop: 20 }]}>
              <View style={Styles.loginbackground} />

              <TextInput
                ref='fname'
                style={Styles.textInput}
                value={this.state.fname}
                disableFullscreenUI={true}
                onChangeText={this.handlefname}
                placeholder="First Name"
                placeholderTextColor={'gray'}
                underlineColorAndroid="transparent"
                returnKeyType="next"
              />
            </View>

            <View style={[Styles.profilescreeninput1, { marginTop: 20 }]}>
              <View style={Styles.loginbackground} />

              <TextInput
                ref='lname'
                style={Styles.textInput}
                value={this.state.lname}
                disableFullscreenUI={true}
                onChangeText={this.handlelname}
                placeholder="Last Name"
                placeholderTextColor={'gray'}
                underlineColorAndroid="transparent"
                returnKeyType="next"
              />
            </View>
          </View>


          <View style={{
            marginLeft: 10,
            marginRight: 10,
            width: '90%',
            alignSelf: 'center',
            justifyContent: 'center',
            height: 50,
            borderRadius: 20,
            marginTop: 20,
          }}>


            <View style={[Styles.loginbackground]} />
            <TextInput
              ref='emailAddress'
              style={Styles.textInput}
              //  onChangeText = {this.handlePassword}
              keyboardType="email-address"
              value={this.state.email}
              disableFullscreenUI={true}
              onChangeText={this.handleemail}
              placeholder="Email Address"
              placeholderTextColor={'gray'}
              underlineColorAndroid="transparent"
              returnKeyType="next"
              blurOnSubmit={false}
              onSubmitEditing={(event) => { this.refs.lname.focus(); }}
              editable = {this.state.isEmailEdit}
            />
          </View>

          <View style={Styles.loginscreeninput2}>
            <View style={Styles.loginbackground} />
            <View style={{ flexDirection: 'row', }}>

              <TextInput
                ref='phone'
                style={Styles.textInput}
                value={this.state.phone}
                disableFullscreenUI={true}
                onChangeText={this.handlePhone}
                placeholder="Mobile Number"
                placeholderTextColor={'gray'}
                underlineColorAndroid="transparent"
                returnKeyType="done"
                keyboardType="phone-pad"
                editable = {this.state.isPhnEdit}
              />
            </View>
          </View>
        </View>

        <View style={{ marginTop: 20 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 10 }}>
            <TouchableOpacity onPress={() => this.hanndleUpdate()}>
              <View style={Styles.loginscreenbtn}>
                <Text style={{ color: 'white', justifyContent: 'center', alignContent: 'center', alignSelf: 'center' }}>Save
              </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>

      </View>
    )
  }

}
const mapStateToProps = state => ({
  selctType: state.selctType,
  registerTeacherMessage: state.auth.registerTeacherMessage,
  signUpSuccess: state.auth.signUpSuccess,
  teacherProfileData: state.auth.teacherProfileData,
  updateTeacherProfileData : state.auth.updateTeacherData,
});
const mapDispatchToProps = {
  updateTeacherDetail,
  getTeacherDetail
};
export default connect(mapStateToProps, mapDispatchToProps)(TeacherBasicInfoScreen);