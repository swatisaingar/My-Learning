import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList, Image
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import { connect } from 'react-redux';
import _, { indexOf, map } from "lodash";
import { loginheaderColor } from '../../util/AppConstants';
import images from '../../util/img';
import moment from 'moment'
import { getCourseDetail, scanApi, addWishlistedData, removeWishlistedData, imageLoad, IsImageEmpty } from '../../actions'
import { ActivityIndicator } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../../util/AppConstants';

class TeacherDetailActivity extends Component {

  constructor(props) {
    super(props);
    this.state = {
      showLoader: false,
      scanedCouseList: null,
      courseSubs: '',
      addWishList: false,
      selectedId: '',
      SacnnedtempData: [],
      imageData: {},
      teacherimageData: {},
      selected: '',
      imageLoading: true
    }
  }

  finalScandata = [];

  async componentDidMount() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    this.props.scanApi(this.props.navigation.state.params && this.props.navigation.state.params.id)


    let teacherid = this.props.courseDetailData && this.props.courseDetailData.courseUsers && this.props.courseDetailData.courseUsers[0] && this.props.courseDetailData.courseUsers[0].teacher_id?.imageId;
    fetch(`${baseURL}file-blobs/getImage/${teacherid}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let teacherimageData = this.state.teacherimageData || {};
      teacherimageData[resposne.data.id] = resposne.data;
      this.setState(teacherimageData);
      this.setState({ imageLoading: false});
    }).
      catch((error) => {
        console.log("#error", error);
      })


    // this.props.IsImageEmpty();
    this?.props?.scanedCouseList?.data?.map((item) => {
      let id = item.imageId;

      fetch(`${baseURL}file-blobs/getImage/${id}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${AuthToken}`,
        }
      }).then(data => {
        return data.json()
      }).then(resposne => {
        let imageData = this.state.imageData || {};
        imageData[resposne.data.id] = resposne.data;
        this.setState(imageData);
        this.setState({ imageLoading: false });
      }).
        catch((error) => {
          console.log("#error", error);
        })
    })
  }

  componentDidUpdate(prevProps) {
    if (this.props.scanedCouseList != null) {
      if (prevProps.scanedCouseList != this.props.scanedCouseList) {
        if (this.props.scanedCouseList.data && this.props.scanedCouseList.data != null) {
          this.setState({ scanedCouseList: this.props.scanedCouseList && this.props.scanedCouseList.data })
        }
      }
    }
    if (prevProps.removeWishListData != this.props.removeWishListData) {
      if (this.props.removeWishListData.data === "Course removed from WishList") {
        this.props.scanApi(this.props.navigation.state.params && this.props.navigation.state.params.id)
      }
    }
  }

  renderQualification = (qual) => {
    let temp = [];
    temp.push(qual);
    let count = ''
    count = temp + ","

    return count;
  }

  checkCondition = (value) => {
    this.setState({ selected: value })
  }

  wishlist = async (courseid, indexValue) => {
    let profileData = await AsyncStorage.getItem('user_id');
    this.props.addWishlistedData(true, profileData, courseid)
    if (this.state.selected === indexValue) {
      this.setState({ addWishList: true })
    }
  }

  remove = (courseid, indexValue) => {
    this.props.removeWishlistedData(courseid);

    if (this.state.selected === indexValue) {
      this.setState({ addWishList: false })
    }

  }

  render() {
    var storedValue = 0;
    for (let i = 0; i < this.props.ratingData && this.props.ratingData.data.length; i++) {
      storedValue = storedValue + this.props.ratingData.data[i].rating;
    }
    var Avgrating = storedValue / this.props.ratingData && this.props.ratingData.totalCount

    let stars = [];
    let path = '';
    let integer_part = Math.trunc(Avgrating);
    let decimat_part = Avgrating - integer_part;
    let total_star_count = 0;
    for (let i = 1; i <= Avgrating; i++) {
      path = require('../../images/star.png');
      stars.push((<Image style={{
        width: 15,
        height: 15, marginRight: 1, marginLeft: 1
      }} source={path} />));
      total_star_count++;
    }
    if (decimat_part != 0) {
      path = require('../../images/star-half.png');
      stars.push((<Image style={{
        width: 20,
        height: 20, marginRight: 1, marginLeft: 1, position: 'relative', top: -2
      }} source={path} />));
      total_star_count++;
    }
    if (total_star_count != 5) {
      path = require('../../images/unfilled-star.png');
      for (let i = total_star_count; i < 5; i++) {
        stars.push((<Image style={{
          width: 15,
          height: 15, marginRight: 1, marginLeft: 1
        }} source={path} />));
      }
    }
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>
        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();
              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />


          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

            <Icon1 style={{ marginLeft: 15 }} name="bell-o" size={20} color="black" />
          </View>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          nestedScrollEnabled={true}
          style={styles.container}>
          {!this.props.scanedCouseList ? <View style={{ alignItems: 'center', justifyContent: 'center', flex: 1 }}>
            <ActivityIndicator />
          </View> :
            <>

              <View style={{

                paddingRight: 5,
                paddingLeft: 5,
                marginTop: 10,
                justifyContent: 'center', alignItems: 'center'
              }}>
                <View style={styles.labelContainer}>

                  <View style={{ flexDirection: 'row' }}>

                  {!this.state.imageLoading ?  <Image resizeMode='contain'  style={{
                        width: widthPercentageToDP('20%'),
                        height: widthPercentageToDP('20%'),
                        borderRadius: widthPercentageToDP('25%') / 2,
                        alignSelf: 'center'
                      }} source={{
                      uri: `data:image/jpeg;base64,${this.state.teacherimageData[this.props.courseDetailData && this.props.courseDetailData.courseUsers[0] && this.props.courseDetailData.courseUsers[0].teacher_id && this.props.courseDetailData.courseUsers[0].teacher_id?.imageId] && this.state.teacherimageData[this.props.courseDetailData && this.props.courseDetailData.courseUsers[0] && this.props.courseDetailData.courseUsers[0].teacher_id && this.props.courseDetailData.courseUsers[0].teacher_id?.imageId].content}`,
                    }} />
                      :
                      <View style={{ width: 50, height: 50, marginLeft: 10, alignSelf: 'center' }}>
                        <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                      </View>}
                    {/* {(this?.props?.teacherImageData?.data) ? <Image

                      source={{ isStatic: true, uri: `data:image/jpeg;base64,${this?.props?.teacherImageData?.data?.content}`, }}
                      style={{
                        width: widthPercentageToDP('20%'),
                        height: widthPercentageToDP('20%'),
                        borderRadius: widthPercentageToDP('25%') / 2,
                        alignSelf: 'center'
                      }}
                    ></Image>:
                    <View>
                      <ActivityIndicator size='large' style={{marginTop:10}}/>
                      </View>} */}

                    <View style={{ width: '62%' }}>
                      <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                        <Text style={{ fontSize: 15, marginLeft: 10 }}>{this.props.scanedCouseList && this.props.scanedCouseList.teacher && this.props.scanedCouseList.teacher.firstName}{this.props.scanedCouseList && this.props.scanedCouseList.teacher && this.props.scanedCouseList.teacher.lastName}{", "}{this.props.scanedCouseList && this.props.scanedCouseList.teacher && this.props.scanedCouseList.teacher.experienceInYear}{' '}yr</Text>
                        <View style={{ flexDirection: 'row', marginRight: -40 }}>
                          {stars}
                        </View>

                      </View>
                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                        <View>
                          <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 15 }}>{this.props.scanedCouseList && this.props.scanedCouseList.teacher && this.props.scanedCouseList.teacher.qualification && this.props.scanedCouseList.teacher.qualification.map((item) => this.renderQualification(item.qualification))}</Text>
                        </View>
                      </View>

                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                        <View>
                          <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 15 }}>{this.props.scanedCouseList && this.props.scanedCouseList.teacher && this.props.scanedCouseList.teacher.preferredCategory && this.props.scanedCouseList.teacher.preferredCategory.map((item) => item.name)}</Text>
                        </View>
                      </View>

                      <View style={{ width: '120%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5, marginLeft: 50 }}></View>

                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                        <Text style={{ marginLeft: 10, fontSize: 15 }}>Total Students
                          </Text>
                        <Text style={{ marginLeft: 50, fontSize: 15 }}>Total Course
                          </Text>
                      </View>

                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                        <Text style={{ marginLeft: 10, fontSize: 15, color: '#FAA21C' }}>{this.props.scanedCouseList && this.props.scanedCouseList.enrolledStudent}
                        </Text>
                        <Text style={{ marginLeft: 10, fontSize: 15, color: '#FAA21C' }}>{this.props.scanedCouseList && this.props.scanedCouseList.totalCount}
                        </Text>
                      </View>
                    </View>
                  </View>
                  {/* <View style={{ marginTop: 10, marginLeft: 10, marginRight: 10 }}>
                    <Text style={{ fontSize: 15, color: loginheaderColor, fontWeight: 'bold' }}>About</Text>
                    <Text>{this.props.courseDetailData && this.props.courseDetailData.description}</Text>
                  </View> */}
                  <View style={{ marginTop: 10, marginLeft: 10, marginRight: 10 }}>
                    <Text style={{ fontSize: 15, color: loginheaderColor, fontWeight: 'bold' }}>Education</Text>

                    <ScrollView>
                      <View>
                        {this.props.scanedCouseList && this.props.scanedCouseList.teacher && this.props.scanedCouseList.teacher.qualification && this.props.scanedCouseList.teacher.qualification.map((item) => {

                          return (

                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>

                              <View style={{ marginTop: 5 }}>
                                <Text style={{ fontSize: 15 }}>{item.university}</Text>
                                <Text style={{ fontSize: 13 }}>{item.qualification}</Text>

                              </View>
                              <Text style={{ fontSize: 15 }}>{item.yearOfPassing}</Text>
                            </View>


                          );
                        })}
                      </View>
                    </ScrollView>

                  </View>
                  {/* <View style={{ marginTop: 10, marginLeft: 10, marginRight: 10 }}>
                    <Text style={{ fontSize: 15, color: loginheaderColor, fontWeight: 'bold' }}>Languages Spoken</Text>
                    <Text>Missing Data</Text>
                  </View> */}

                </View>
              </View>
              <View style={{ marginTop: 15, marginLeft: 17, marginRight: 10 }}>
                <Text style={{ fontSize: 15, color: loginheaderColor, fontWeight: 'bold' }}>My Courses</Text>
              </View>
              {this.props.scanedCouseList && this.props.scanedCouseList.totalCount > 0 ? <FlatList
                data={this.props.scanedCouseList && this.props.scanedCouseList.data}
                nestedScrollEnabled={true}

                onEndReached={this._handleLoadMore}
                onEndReachedThreshold={0.01}
                renderItem={({ item, index }) => {
                  // let imageUri = `data:${item.image && item.image.contentContentType};base64,${item.image && item.image.content}`;
                  return (
                    <View>
                    
                      <TouchableOpacity
                        onPress={async () => {
                          this.props.navigation.navigate('SearchDetailActivity', { courseId: item.id });
                        }}
                      >
                        <View style={{

                          paddingRight: 5,
                          paddingLeft: 5,
                          marginTop: 10,
                          backgroundColor: '#F9F9F9',
                          justifyContent: 'center', alignItems: 'center'
                        }}>
                          <View style={styles.labelContainer}>

                            <View style={{ flexDirection: 'row' }}>
                              {!this.state.imageLoading ? <Image

                                source={{ isStatic: true, uri: `data:image/jpeg;base64,${this.state.imageData[item.imageId] && this.state.imageData[item.imageId].content}` }}
                                style={{
                                  width: widthPercentageToDP('22%'),
                                  borderRadius: 10,

                                }}
                              ></Image>
                                :
                                <View style={{
                                  width: widthPercentageToDP('22%'),
                                  borderRadius: 10,

                                }}>
                                  <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                                </View>}


                              <View style={{ width: '80%' }}>
                                <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                                  <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.name}{' '}
                                    {item.standard && 'Class-'} {item.standard.class}
                                  </Text>
                                  <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                    {stars}
                                  </View>

                                </View>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                                  {this.state.addWishList && index === this.state.selected || item.isWishListed === true ? <TouchableOpacity onPress={() => { this.remove(item.id, index); this.checkCondition(item) }}>
                                    <Image
                                      resizeMode='contain'
                                      source={images.likeselect}
                                      style={{
                                        width: 20,
                                        height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(60)
                                      }}
                                    ></Image>
                                  </TouchableOpacity> :

                                    <TouchableOpacity onPress={() => { this.wishlist(item.id, index); this.checkCondition(index) }}>
                                      <Image
                                        resizeMode='contain'
                                        source={images.shortlist_blck}
                                        style={{
                                          width: 20,
                                          height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(60)
                                        }}
                                      ></Image>
                                    </TouchableOpacity>}

                                  {this.props.scanedCouseList && this.props.scanedCouseList.enrolledStudent > item.minBatchSize && <Image
                                    resizeMode='contain'
                                    source={images.confirmation}
                                    style={{
                                      width: 20,
                                      height: 20, alignSelf: 'center'
                                    }}
                                  ></Image>}
                                </View>
                                <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                                <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {moment(item.startDate).format('DD-MM-YYYY')})</Text>
                                <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                                  <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{item && item.createdDate && moment(item.createdDate).format('hh:mm A')}-{item && item.endDate && moment(item.endDate).format('hh:mm A')}</Text>
                                  <View style={{ flexDirection: 'row', marginRight: 10 }}>
                                    {item.courseDays && item.courseDays.length > 0 && item.courseDays.map(i => {
                                      return <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                                    })}
                                  </View>
                                </View>

                                <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10 }}>
                                  <View>
                                    <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                    <Text style={{ color: loginheaderColor }}>{item.status ? 'Open' : 'Completed'}</Text>
                                  </View>
                                  <View style={{ right: 20 }}>
                                    <Text style={{ fontSize: 10 }}>Number of Classes</Text>
                                    <Text style={{ color: loginheaderColor }}>{item?.courseClasses?.length}</Text>
                                  </View>
                                </View>

                                <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 10, marginBottom: 10 }}>
                                  <View>
                                    <Text style={{ fontSize: 10 }}>STUDENTS ENROLLED</Text>
                                    <Text style={{ color: loginheaderColor }}>{this.props.scanedCouseList && this.props.scanedCouseList.enrolledStudent}/{item.maxBatchSize}</Text>
                                  </View>
                                  <View style={{ right: 20 }}>
                                    <Text style={{ fontSize: 10, marginLeft: 50 }}>MONTHLY</Text>

                                    <Text style={{ color: loginheaderColor }}>₹{' '}{item.fee}</Text>

                                  </View>
                                </View>
                              </View>
                            </View>
                          </View>
                        </View>

                      </TouchableOpacity>


                    </View>)
                }}

              /> : <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', margin: 20 }}>
                  <Text>This teacher does not have any course at the moment</Text>
                </View>}


            </>}







        </ScrollView >


        <View style={{
          flex: 1,
          flexDirection: 'row',
          flexWrap: 'wrap',
          alignContent: 'center',
          justifyContent: 'space-around',
          // paddingLeft: 15,
          // padding: 5,
          position: 'absolute',
          bottom: 0,
          alignSelf: 'center'
        }}>

        </View>
      </View >
    )
  }

}

const mapStateToProps = state => ({
  // user: state.auth,
  scanedCouseList: state.dash.scanedCourseData,
  courseDetailData: state.dash.courseDetailData,
  addtoWishListData: state.dash.addtoWishListData,
  ratingData: state.dash.ratingData,
  removeWishListData: state.dash.removeWishListData,
  teacherImageData: state.dash.teacherImageData,
  wish: state.wish,
  // imageData: state.dash.imageData
});

const mapDispatchToProps = {
  getCourseDetail, scanApi, addWishlistedData, removeWishlistedData, imageLoad, IsImageEmpty
};

export default connect(mapStateToProps, mapDispatchToProps)(TeacherDetailActivity);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',

    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',

    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
