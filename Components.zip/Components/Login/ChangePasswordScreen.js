import React, { Component } from 'react'
import { StatusBar, TouchableOpacity, View, ToastAndroid, Text, TextInput, Image, ActivityIndicator } from 'react-native'
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { changePassword } from '../../actions'
import { connect } from 'react-redux';
import NavigationService from '../../Services/NavigationService';
import Icon from 'react-native-vector-icons/FontAwesome5';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../../util/AppConstants';
var params;
class ChangePasswordScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      email: '',
      pwd: '',
      userCheck: '',
      checked: 'first',
      checkedcond: true,
      isStudent: false,
      matchPassword: false,
      profileImage:{},
      hidePass2: true,
      hidePass1:true,
      hidePass3:true,
    }
    params = this.props.navigation.state.params;
  }
  static navigationOptions = {
    headerShown: false,




  };



  async componentDidMount() {

    StatusBar.setHidden(false);
    
    let AuthToken = await AsyncStorage.getItem('id_token');
    let id = this.props.prof?.profData?.data?.imageId;
    fetch(`${baseURL}file-blobs/getImage/${id}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let profileImage = this.state.profileImage || {};
      profileImage[resposne.data.id] = resposne.data;
      this.setState(profileImage);
    }).
      catch((error) => {
        console.log("#error", error);
      })
  }

  componentDidUpdate(prevProps) {
    if (prevProps.user != this.props.user) {
      if (prevProps.user.changePasswordData && !prevProps.user.changePasswordError) {
        console.log('changePasswordchangePassword',this.props.changePasswordData)
        if (prevProps.user.changePasswordData.data === "Password Updated.") {
          ToastAndroid.show(
            "Password updated Successfully",
            ToastAndroid.SHORT,
            ToastAndroid.BOTTOM//can be SHORT, LONG
          );
        }
      }
      if(prevProps.user.changePasswordError != this.props.user.changePasswordError && this.props.user.changePasswordError != null){
        alert(this.props.user.changePasswordError.message)
      }
    }
  }

  handleoldpwd = (text) => {
    this.setState({ oldpwd: text })
  }

  handlenewpwd = (text) => {
    var check = /^(?=.{8,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[@#$%^&+=*]).*$/;
    if(!check.test(text)){
      this.setState({ newpwd: text });
    }
    if (!isNaN(parseInt(text[0]))) {
      this.setState({ newpwd: text });
     alert("Password should not start with Number");      
    }

    if (!isNaN(parseInt(text.slice(-1)[0]))) {
      this.setState({ newpwd: text });
     alert("Password should not end with Number");      
    }

    if(text[0] === '@'|| text[0] === '#' || text[0] === '$' || text[0] === '&' || text[0] === '%' || text[0] === '!' || text[0] === '~'){
      this.setState({ newpwd: text });
      alert('Password should not start with Special character')
    }

    if(text.slice(-1)[0] === '@'|| text.slice(-1)[0] === '#' || text.slice(-1)[0] === '$' || text.slice(-1)[0] === '&' || text.slice(-1)[0] === '%' || text.slice(-1)[0] === '!' || text.slice(-1)[0] === '~'){
      this.setState({ newpwd: text });
      alert('Password should not end with Special character')
    }

    this.setState({ newpwd: text })
  }


  handlecpwd = (text) => {
    var check = /^(?=.{8,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[@#$%^&+=*]).*$/;
    if(!check.test(text)){
      this.setState({ cpwd: text });
    }
    if (!isNaN(parseInt(text[0]))) {
      this.setState({ cpwd: text });
     alert("Password should not start with Number");      
    }

    if (!isNaN(parseInt(text.slice(-1)[0]))) {
      this.setState({ cpwd: text });
     alert("Password should not end with Number");      
    }

    if(text[0] === '@'|| text[0] === '#' || text[0] === '$' || text[0] === '&' || text[0] === '%' || text[0] === '!' || text[0] === '~'){
      this.setState({ cpwd: text });
      alert('Password should not start with Special character')
    }

    if(text.slice(-1)[0] === '@'|| text.slice(-1)[0] === '#' || text.slice(-1)[0] === '$' || text.slice(-1)[0] === '&' || text.slice(-1)[0] === '%' || text.slice(-1)[0] === '!' || text.slice(-1)[0] === '~'){
      this.setState({ cpwd: text });
      alert('Password should not end with Special character')
    }
    this.setState({ cpwd: text })
    this.matchPassword(text)
  }

  matchPassword = (text) => {
    if (text === this.state.newpwd) {

      this.setState({ matchPassword: true })
    } else {
      if (this.state.matchPassword) {
        this.setState({ matchPassword: false })
      }
    }
  }


  setChecked(status) {
    this.setState({
      checked: status
    })
  }
  render() {

    return (
      <View style={{ flex: 1 }}>

        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();

              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />

          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

            <TouchableOpacity
              onPress={() => {
                this.setState({
                  filterpopup: true
                })
              }}
            >
              <Icon1 style={{ marginLeft: 15, marginTop: 15 }} name="bell-o" size={20} color="black" /></TouchableOpacity>
              <TouchableOpacity onPress={()=>NavigationService.navigate('ProfileScreen')}>
            {(this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content) ?<Image
              resizeMode='contain'
              source={{uri:`data:image/jpeg;base64,${this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content}`}}
              style={{ width: 25, height: 25, marginLeft: 5, marginRight: 20, marginTop: 15,borderWidth:1 }}
            />:<View style={{
              width: 25,
              height: 25,
              marginLeft: 5,
              marginRight: 20,
              marginTop: 15,
              borderWidth: 1
            }}><ActivityIndicator size='small'/></View>}
            </TouchableOpacity>
          </View>
        </View>

        <Text style={{ marginLeft: 10, marginTop: 10, fontWeight: 'bold' }}>Change password</Text>



        <View style={[Styles.loginscreeninput1, { marginTop: 20 }]}
        >
          {/* <View style={{ flexDirection: 'row',borderWidth:1 }}> */}
          <View style={[Styles.loginbackground]} />
          <View style={{ flexDirection: 'row', borderWidth:1,borderRadius:20}}>
          <TextInput
            ref='fname'
            style={[Styles.textInput]}
            secureTextEntry={this.state.hidePass1 ? true : false}
            value={this.state.oldpwd}
            disableFullscreenUI={true}
            onChangeText={this.handleoldpwd}
            placeholder="Enter old password"
            placeholderTextColor={'gray'}
            underlineColorAndroid="transparent"
            returnKeyType="next"
          />
           <Icon
              name={this.state.hidePass1 ? 'eye-slash' : 'eye'}
              size={15}
              color="grey"
              onPress={() => this.setState({ hidePass1: !this.state.hidePass1 })}
              style={{ alignSelf: 'center',marginRight:10}}
            />
            </View>
        </View>
        <View style={[Styles.loginscreeninput1, { marginTop: 20 }]}
        >
          <View style={Styles.loginbackground} />
          <View style={{ flexDirection: 'row', borderWidth:1,borderRadius:20}}>
          <TextInput
            ref='fname'
            style={[Styles.textInput]}
            secureTextEntry={this.state.hidePass2 ? true : false}
            value={this.state.newpwd}
            disableFullscreenUI={true}
            onChangeText={this.handlenewpwd}
            placeholder="Enter new password"
            placeholderTextColor={'gray'}
            underlineColorAndroid="transparent"
            returnKeyType="next"
          />
           <Icon
              name={this.state.hidePass2 ? 'eye-slash' : 'eye'}
              size={15}
              color="grey"
              onPress={() => this.setState({ hidePass2: !this.state.hidePass2 })}
              style={{ alignSelf: 'center',marginRight:10}}
            />
            </View>
        </View>
        <View style={[Styles.loginscreeninput1, { marginTop: 20 }]}
        >
          <View style={Styles.loginbackground} />
          <View style={{ flexDirection: 'row', borderWidth:1,borderRadius:20}}>
          <TextInput
            ref='fname'
            style={[Styles.textInput]}
            secureTextEntry={this.state.hidePass3 ? true : false}
            keyboardType="email-address"
            value={this.state.cpwd}
            disableFullscreenUI={true}
            onChangeText={this.handlecpwd}
            placeholder="Enter confirm password"
            placeholderTextColor={'gray'}
            underlineColorAndroid="transparent"
            returnKeyType="done"
          />
           <Icon
              name={this.state.hidePass3 ? 'eye-slash' : 'eye'}
              size={15}
              color="grey"
              onPress={() => this.setState({ hidePass3: !this.state.hidePass3 })}
              style={{ alignSelf: 'center',marginRight:10}}
            />
            </View>
        </View>
        {this.state.cpwd && !this.state.matchPassword && <Text style={{ marginLeft: 20 }}>Password doesnot match</Text>}
        <View style={{ marginTop: 40 }}>

          <TouchableOpacity disabled={!this.state.oldpwd || !this.state.matchPassword} onPress={() => {
            this.props.changePassword(this.state.oldpwd, this.state.newpwd)

          }

          } >
            <View
              style={[Styles.loginscreenbtn, { opacity: (!this.state.oldpwd || !this.state.matchPassword) ? 0.5 : 1 }]}
            >
              <Text style={{ color: 'white', justifyContent: 'center', alignContent: 'center', alignSelf: 'center' }}>Update
  </Text>
            </View>
          </TouchableOpacity>
        </View>



        {
          this.state.isLoading ? <View style={Styles.loading}>
            <ActivityIndicator sizewhite='large' color='white'>
            </ActivityIndicator>
          </View>
            : null
        }
      </View>
    )
  }




}

const mapStateToProps = state => ({
  user: state.auth,
  prof: state.prof,
  changePasswordData:state.dash.changePasswordData
})
const mapDispatchToProps = {
  changePassword
}
export default connect(mapStateToProps, mapDispatchToProps)(ChangePasswordScreen);