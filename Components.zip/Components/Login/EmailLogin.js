import React, { Component } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Image, Alert } from 'react-native';
import { connect } from 'react-redux';
import { COLORS, SIZE, widthPercentageToDP } from '../../constants/styles';
import NavigationService from '../../Services/NavigationService'
import CommonLayout from '../../Common/topLayout';
import TextField from '../../Common/TextInput';
import Loader from '../../Common/Loader';
import Ionicons from 'react-native-vector-icons/Ionicons';
import images from '../../util/img';
import { authLogin, UserLogout } from '../../actions';

class LoginWithEmail extends Component {
	state = {
		showLoader: false,
		keyboardHeight: 0,
		username: '',
		password: '',
		checkedASM: false
	};

	showAlert(text) {
		Alert.alert('Error', text, [
			{
				text: 'OK'
			}
		]);
	}

	onchangeText = (value, name) => {
		this.setState({
			[name]: value
		});
	};

	showLoader = show => {
		this.setState({ showLoader: show });
	};
	validateUserName = username => {
		var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
		return re.test(String(username).toLowerCase()) || username.match(phoneno);
	};
	static getDerivedStateFromProps(props, state)
	{
	  
		if(props.user!=null)
		{
			if(props.user.loginMessage!=null)
			{
		console.log('LOGIN CHECK', props.user.loginMessage.status);
		if(props.user.loginMessage.status==1)
		{
			if(props.user.loginMessage.data.user.accountType=='orderRunner')
			{
			NavigationService.navigateAndReset('AccountScreen');
			}
			else
			{
				alert("Your account is not OR type so you can not login in this app");
				props.UserLogout();
			}
		}
		else
		{
			alert(props.user.loginMessage.message);
			props.UserLogout();
		}
	}
	else
	{
		if(props.user.loginError!=null)
		{
			alert(props.user.loginError.message);
			props.UserLogout();
		}
	}
	}

	}
	onLogin = async () => {
		const { username, password } = this.state;
		const { authLogin } = this.props;
		if (!!!username || !!!password) {
			this.showAlert("Username or password can't be empty");
		} else if (!this.validateUserName(username)) {
			this.showAlert('Please enter a valid Phone number or email address');
		} else {
			//this.showLoader(true);
			let params = { username, password };
			console.log('paras', params)
			 await authLogin(username, password);
			//this.showLoader(false);
			console.log('LOGIN', this.props.user)
			
		}
	};
	async componentDidMount(){
	
	}

	render() {
		return (
			<CommonLayout>
				<Loader show={this.props.user.loginLoading} />
				<View style={[styles.container, { marginBottom: 70 }]}>
					<View>
						<Text style={styles.textColor}>
							LOG INTO <Text style={styles.innerText}>YOUR ACCOUNT</Text>
						</Text>
						<View
							style={{
								alignItems: 'center'
							}}
						>
							<Text
								style={{
									borderBottomColor: '#000',
									borderBottomWidth: 2,
									width: widthPercentageToDP('28%')
								}}
							/>
						</View>
					</View>
					<View style={styles.formContainer}>
						<View style={styles.boxContainer}>
							<View style={{alignSelf:'center'}}>
								<Image
									style={{
										width: 20,
										height: 28
									}}
									source={images.phone}
								/>
							</View>
							<View >
								<TextField
									style={styles.textInput}
									placeholder="Enter Your Mobile Number or Email Id"
									onChangeText={value => this.onchangeText(value, 'username')}
								/>
							</View>
						</View>
						<View style={styles.boxContainer}>
							<View style={{alignSelf:'center'}}>
								<Image
									style={{
										width: 20,
										height: 28
									}}
									source={images.lock}
								/>
							</View>
							<View>
								<TextField
									style={styles.textInput}
									placeholder="Enter Your Password          "
									textContentType="password"
									secureTextEntry={true}
									onChangeText={value => this.onchangeText(value, 'password')}
								/>
							</View>
						</View>

						{/* <TouchableOpacity onPress={() => {
							this.setState({ checkedASM: !this.state.checkedASM })
						}} style={{ flexDirection: 'row', marginBottom: 10, alignItems: 'center' }}>
							<Ionicons name={!this.state.checkedASM ? 'ios-checkbox-outline' : 'ios-checkbox'} size={22} iconStyle={styles.iconStyle} color={COLORS.MAINCOLOR.UIBLUE} />

							<Text style={{ fontSize: 13, marginLeft: 10 }}>Login As ASM</Text>

						</TouchableOpacity> */}

						<View style={styles.buttonContainer}>

							<TouchableOpacity onPress={this.onLogin}>
								<Ionicons name="md-arrow-forward" size={40} iconStyle={styles.iconStyle} color="#fff" />
							</TouchableOpacity>
						</View>
					{/* 	<Text style={styles.signUpText} onPress={() => this.props.navigation.navigate('OTPLogin')}>
							Or, Sign In Using OTP
						</Text> */}
					</View>
				{/* 	<View style={styles.bottomContainer}>
						<View>
							<TouchableOpacity onPress={() => this.props.navigation.navigate('Signup')}>
								<Text style={styles.signUpText2}>SignUp</Text>
							</TouchableOpacity>
						</View>
						<View>
							<TouchableOpacity onPress={() => {

								this.props.navigation.navigate('ForgotPassword')
							}}>
								<Text style={styles.forgotText}>Forgot Password ?</Text>
							</TouchableOpacity>
						</View>
					</View>
				
				 */}
				</View>
			</CommonLayout>
		);
	}
}

const mapStateToProps = state => ({
	user: state.auth
});

const mapDispatchToProps = {
	authLogin,UserLogout
};

export default connect(mapStateToProps, mapDispatchToProps)(LoginWithEmail);

const styles = StyleSheet.create({
	container: {
		flex: 1,
		flexDirection: 'column'
	},
	textColor: {
		flexWrap: 'wrap',
		color: '#000',
		paddingTop: 25,
		textAlign: 'center',
		marginTop: 30,
		fontSize: SIZE.MINLARGE,
		padding: 2
	},
	innerText: {
		fontWeight: 'bold'
	},
	formContainer: {
		// marginTop: 40,
		alignItems: 'center',
		paddingTop: 50
	},
	boxContainer: {
		flexDirection: 'row',
		justifyContent: 'flex-start',
		alignItems: 'flex-start',
		alignContent: 'flex-start',
		borderColor: `${COLORS.MAINCOLOR.BLUE}`,
		borderRadius: 50,
		borderLeftWidth: 4,
		borderRightWidth: 4,
		borderTopWidth: 4,
		borderBottomWidth: 4,
		marginBottom: 20,
		borderWidth: 1,
		paddingLeft:10,
		paddingRight:10,
		width: 300,
		color: '#000',
	},

	textInput: {
		// backgroundColor:'#ff00ff',
		textAlign: 'left',
		fontSize: 13,
		paddingLeft: 10,
		paddingRight:10,
		width:260
	},
	iconStyle: {
		borderColor: '#000',
		borderWidth: 30
	},
	buttonContainer: {
		backgroundColor: `${COLORS.MAINCOLOR.BLUE}`,
		width: 50,
		height: 50,
		marginTop: 20,
		justifyContent: 'center',
		alignItems: 'center',
		borderRadius: 100 / 2
	},
	signUpText: {
		color: `${COLORS.MAINCOLOR.BLUE}`,
		// marginTop: 10,
		fontSize: SIZE.MEDIUM
	},
	signUpText2: {
		color: `${COLORS.MAINCOLOR.BLUE}`,
		// marginTop: 10,
		fontSize: SIZE.MEDIUM,
		borderBottomWidth: 1,
		borderBottomColor: `${COLORS.MAINCOLOR.BLUE}`
	},
	bottomContainer: {
		flex: 1 / 2,
		flexDirection: 'row',
		flexWrap: 'wrap',
		marginTop: 20,
		justifyContent: 'space-around',
		alignContent: 'space-around',
		alignItems: 'center'
	},
	forgotText: {
		color: `${COLORS.MAINCOLOR.BLUE}`,
		fontSize: SIZE.MEDIUM,
		borderBottomWidth: 1,
		borderBottomColor: `${COLORS.MAINCOLOR.BLUE}`
	}
});
