import React, { Component } from 'react'
import {  TouchableOpacity, View, Text,TextInput,Image, ActivityIndicator } from 'react-native'
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import { StackActions, NavigationActions } from 'react-navigation';
import NavigationService from '../../Services/NavigationService';
import { heightPercentageToDP } from 'react-native-responsive-screen';
import {  loginheaderColor} from '../../util/AppConstants';
import { generateForgotPasswordOtp} from '../../actions'
import { connect } from 'react-redux';
// import { ActivityIndicator} from 'react-native'

var params;
class ForgetPassWordScreen extends Component {

  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      email: '',
      valid: false
    }
    params= this.props.navigation.state.params;
  }
  static navigationOptions = {
    headerShown: false,
  };

  

  handleemail = (text) => {
    this.setState({ email: text })
    this.validateEmail(text)
  }

  finishPreviousScreens(screen) {
    console.log('FINISH CALLED');
    const resetAction = StackActions.reset({
      index: 0,
      key: null,
      actions: [
        NavigationActions.navigate({ routeName: screen })
      ]
    });
    this.props.navigation.dispatch(resetAction);
  }

  

  validateEmail = (text) => {
    var mailformat = /^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[A-Za-z]+$/;
  
    if (this.state.email.length == 9 || mailformat.test(text)){
      this.setState({valid : false})
    }else{
      this.setState({valid : true})
      
    }
  }

  componentDidMount(){
    const email = this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.email
    this.setState({ email : email
    
    })
    var mailformat = /^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[A-Za-z]+$/;

    if(mailformat.test(email)){

    this.setState({emailValid : false})
    }else{
      this.setState({emailValid : true})
      
    }
  }

  
  render() {

    return (
      <View>
        <View style={{ height: heightPercentageToDP('40%'), backgroundColor: loginheaderColor, }}>
          <TouchableOpacity
            style={{ position: 'absolute', left: 10, top: 20 }}
            onPress={() => {
              this.props.navigation.goBack();
            }}>

              <Image source={images.loginback} style={{
                height: 40, width: 40,
                resizeMode: 'contain',
              }}></Image>
         </TouchableOpacity>
          <View style={{ justifyContent: 'center', }}>
            <View style={{ marginTop: 100, marginLeft: 20 }}>
              <Text style={{ fontSize: 18, color: 'white' }}>Forgot Password</Text>
              <Text style={{ fontSize: 12, color: 'white', fontStyle: 'italic', marginTop: 5 }}>Enter your email or mobile number to get the reset link</Text>
            </View>
          </View>
          <View style={Styles.loginscreeninput1}>
            <View style={Styles.loginbackground} />

            <TextInput
              ref='fname'
              style={Styles.textInput}
              keyboardType="email-address"
              value={this.state.email}
              disableFullscreenUI={true}
              onChangeText={this.handleemail}
              placeholder="Mobile Number / Email"
              placeholderTextColor={'lightgray'}
              underlineColorAndroid="transparent"
              returnKeyType="done"
              maxLength={parseInt(this.state.email)?10:100}
            />
          </View>
         {(this.state.email !== '' && this.state.valid) && <Text style={{marginLeft: 25}}>Please enter valid email / mobile number.</Text>}
        </View>

        <View style={{ marginTop: 15 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 10 }}>
            <TouchableOpacity disabled={this.state.email === ''} onPress={() => {
              this.props.generateForgotPasswordOtp()
              NavigationService.navigate('OTPScreen', { email : this.state.email , resetPass : true});
                // NavigationService.navigate('Home')
              }}>

              <View style={[Styles.loginscreenbtn, {opacity : (this.state.email === '') ? 0.5 : 1}]}>
                {<Text style={{ color: 'white', justifyContent: 'center', alignContent: 'center', alignSelf: 'center' }}>Send OTP
                </Text> }
              </View>
            </TouchableOpacity>

          </View>
        
        </View>

        {
          this.state.isLoading ? <View style={Styles.loading}>
            <ActivityIndicator sizewhite='large' color='white'>
            </ActivityIndicator>
          </View>
            : null
        }
      </View>
    )
  }
}

const mapStateToProps = state => ({
  generateOtpResponse : state.auth.generateResetOtpData,
  selctType: state.selctType
  // isApiLoading: state.auth.generateResetOtpLoading
});

const mapDispatchToProps ={
  generateForgotPasswordOtp
}
export default connect(mapStateToProps, mapDispatchToProps)(ForgetPassWordScreen);
