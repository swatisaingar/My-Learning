import React, { Component } from 'react'
import { StatusBar, TouchableOpacity, View, Text, TextInput, Image, ActivityIndicator } from 'react-native'
import { StackActions, NavigationActions } from 'react-navigation';
import { GoogleSignin, statusCodes } from 'react-native-google-signin';
import { CheckBox } from 'react-native-elements'
import { AccessToken, LoginManager, GraphRequest, GraphRequestManager } from 'react-native-fbsdk';
import { heightPercentageToDP } from 'react-native-responsive-screen';
import { connect } from 'react-redux';
import InstagramLogin from 'react-native-instagram-login';
import images from '../../util/img';
import { loginheaderColor, appblueColor } from '../../util/AppConstants';
import { widthPercentageToDP } from '../../constants/styles'
import { otpLogin } from '../../actions';
import Styles from '../../uistyles/Styles';
import NavigationService from '../../Services/NavigationService'

class LoginScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      email: '',
      pwd: '',
      userCheck: '',
      checked: 'first',
      checkedcond: true,
      isStudent: false,
      valid: false
    }
  }

  static navigationOptions = {
    headerShown: false,
  };

  componentDidMount() {
    GoogleSignin.configure({ webClientId: '626155858203-thnmln5egd27j16pos4hhhmuj6qv9r72.apps.googleusercontent.com' }// client ID of type WEB for your server (needed to verify user ID and offline access)
    );
    //  GoogleSignin.configure();
    StatusBar.setHidden(false);
  }

  signIn = async () => {
    try {
      await GoogleSignin.hasPlayServices();
    const userInfo = await GoogleSignin.signIn();
    this.setState({ userInfo });
  
  // let json = await authLogin(email, password);
  // console.log("googleAuthApi response ", json)
    // if(userInfo.idToken){
    //   NavigationService.navigate('Home')
    // }
    } catch (error) {
      console.log('inside catch' + JSON.stringify(error));
      if (error.code === statusCodes.SIGN_IN_CANCELLED) {
        // user cancelled the login flow
        console.log('cancelled');
      } else if (error.code === statusCodes.IN_PROGRESS) {
        console.log('in progress');
        // operation (f.e. sign in) is in progress already
      } else if (error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
        // play services not available or outdated
        console.log('no play service');
      } else {
        // some other error happened
      }
    }
  };

  setIgToken = (data) => {
    console.log('data', data)
    this.setState({ token: data.access_token })
  }

  handleemail = (text) => {
    var number = /^\d{10}$/;
    if(number.test(text)){
      // this.setState({ valid: true })
      this.setState({email:text})    
    }
    this.setState({ email: text })
  }

  otpgenerator = async (numbervalue) => {
    var mailformat = /^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[A-Za-z]+$/;
    var number = /^\d{10}$/;
    var number2 = /^\d{13}$/;
    if (mailformat.test(numbervalue) || number.test(numbervalue) || number2.test(numbervalue)) {
      const { otpLogin } = this.props;
      await otpLogin(numbervalue);
      var obj = {};
      obj.email = this.state.email;
      this.props.navigation.navigate('OTPScreen', obj);
      this.setState({ valid: false })
    } else {
      this.setState({ valid: true })
    }
  };

  facebookLogin = async () => {
    try {
      const result = await LoginManager.logInWithPermissions(['public_profile', 'email']);
      if (result.isCancelled) {
        throw new Error('User cancelled request'); // Handle this however fits the flow of your app
      }
      console.log(`Login success with permissions: ${result.grantedPermissions.toString()}`);
      // get the access token
      const data = await AccessToken.getCurrentAccessToken();

      if (!data) {
        throw new Error('Something went wrong obtaining the users access token'); // Handle this however fits the flow of your app
      }
      console.log('after login access token' + data.accessToken.toString());
      // create a new firebase credential with the token
      var accessToken = data.accessToken.toString();
      // this.initUser(accessToken)
      const infoRequest = new GraphRequest(
        '/me?fields=name,email,picture',
        null,
        this._responseInfoCallback
      );
      // Start the graph request.
      new GraphRequestManager().addRequest(infoRequest).start();
    } catch (e) {
      console.log(e);
    }
  }
  _responseInfoCallback = (error, result) => {
    if (error) {
      alert('Error fetching data: ' + error.toString());
    } else {
      alert('Result : ' + JSON.stringify(result));
    }
  }

  finishPreviousScreens(screen) {
    console.log('FINISH CALLED');
    const resetAction = StackActions.reset({
      index: 0,
      key: null,
      actions: [
        NavigationActions.navigate({ routeName: screen })
      ]
    });
    this.props.navigation.dispatch(resetAction);
  }
  setChecked(status) {
    this.setState({
      checked: status
    })
  }
  render() {
    return (
      <View>
        <InstagramLogin
          ref={ref => (this.instagramLogin = ref)}
          appId='659821971382149'
          appSecret='dd5bb8a58c5dfc2c4198d4d6e96b5997'
          redirectUrl='https://www.google.com/'
          scopes={['user_profile', 'user_media']}
          onLoginSuccess={this.setIgToken}
          onLoginFailure={(data) => console.log(data)}
        />


        <View style={{ height: heightPercentageToDP('40%'), backgroundColor: loginheaderColor, }}>
          <TouchableOpacity
            style={{ position: 'absolute', left: 10, top: 20 }}
            onPress={() => this.props.navigation.goBack()} >
            <Image source={images.loginback} style={{
              height: 40, width: 40,
              resizeMode: 'contain',
            }}></Image>
          </TouchableOpacity>
          <View style={{ justifyContent: 'center', }}>
            <View style={{ marginTop: 100, marginLeft: 20 }}>
              <Text style={{ fontSize: 18, color: 'white' }}>Welcome</Text>
              {this.props.selctType.typeselectedData.logintype === "Student" ? <Text style={{ fontSize: 14, color: 'white', fontStyle: 'italic' }}>Student</Text> :
                <Text style={{ fontSize: 14, color: 'white', fontStyle: 'italic' }}>Teacher</Text>
              }
            </View>
          </View>
          <View style={Styles.loginscreeninput1}
          >
            <View style={Styles.loginbackground} />

            <TextInput
              ref='fname'
              style={Styles.textInput}
              keyboardType="email-address"
              value={this.state.email}
              disableFullscreenUI={true}
              onChangeText={this.handleemail}
              placeholder="Mobile Number / Email"
              placeholderTextColor={'lightgray'}
              underlineColorAndroid="transparent"
              returnKeyType="done"
              maxLength={parseInt(this.state.email)? 10:100}
            />
          </View>
          {(this.state.email !== '' && this.state.valid) && <Text style={{ marginLeft: 20, color: 'red' }}>Please enter valid email / mobile number.</Text>}
          
        </View>

        <View style={{ marginTop: 5 }}>
          <View
            style={Styles.loginchck}>
            <CheckBox
              checkedColor={loginheaderColor}
              activeOpacity={1}
              containerStyle={{ backgroundColor: 'transparent', borderWidth: 0 }}
              textStyle={{ color: appblueColor, fontWeight: 'normal', fontSize: 13 }}
              style={{ flex: 1 }}
              title='I agree to Terms & Conditions'
              size={18}
              checked={this.state.checkedcond}
              onPress={() => this.setState({ checkedcond: !this.state.checkedcond })}
            />
          </View>

          <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 5 }}>
            {<TouchableOpacity
              disabled={!this.state.checkedcond}
              onPress={() => this.otpgenerator(this.state.email)} >
              <View
                style={[Styles.loginscreenbtn, { opacity: this.state.checkedcond ? 1 : 0.5 }]}
              >
                <Text style={{ color: 'white', justifyContent: 'center', alignContent: 'center', alignSelf: 'center' }}>Proceed
              </Text>
              </View>
            </TouchableOpacity>}
          </View>

          {this.props.selctType.typeselectedData.logintype === "Student" && <Text style={{ fontSize: 12, alignSelf: 'center', marginTop: 10 }}>or connect with</Text>}

          {this.props.selctType.typeselectedData.logintype === "Student" ?
            <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 20 }}>
              <TouchableOpacity onPress={() => this.signIn()} >
                <Image style={{ height: 40, width: 40 }}
                  resizeMode={'contain'}
                  source={images.google}
                >
                </Image>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.instagramLogin.show()}>
                <Image style={{ height: 40, width: 40, marginLeft: 20, marginRight: 20 }}
                  resizeMode={'contain'}
                  source={images.insta}>
                </Image>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.facebookLogin()}>
                <Image style={{ height: 40, width: 40 }}
                  resizeMode={'contain'}
                  source={images.fb}
                >
                </Image>
              </TouchableOpacity>
            </View>
            :
            <View style={{ flexDirection: 'row', alignSelf: 'center', width: widthPercentageToDP('100%'), justifyContent: 'center', marginTop: 20 }}>
              <Text onPress={() => {
                this.props.navigation.navigate('PasswordLoginScreen')
              }}>Already I have an account<Text style={{ marginTop: 0, color: '#1976D2', textDecorationLine: 'underline' }}> Login</Text></Text>
            </View>}
        </View>
        {/* </ImageBackground> */}
        {
          this.state.isLoading ? <View style={Styles.loading}>
            <ActivityIndicator sizewhite='large' color='white'>
            </ActivityIndicator>
          </View>
            : null
        }
      </View>
    )
  }
}
const mapStateToProps = state => ({
  selctType: state.selctType
});

const mapDispatchToProps = {
  otpLogin
};

export default connect(mapStateToProps, mapDispatchToProps)(LoginScreen);
