import React, { Component } from 'react'
import { TouchableOpacity, View, ToastAndroid, Text, Image, ActivityIndicator } from 'react-native'
import OTPInput from 'react-native-otp';
import { heightPercentageToDP } from 'react-native-responsive-screen';
import { connect } from 'react-redux';
import { Alert } from 'react-native';

import { loginheaderColor, appgrayColor, appblueColor } from '../../util/AppConstants';
import NavigationService from '../../Services/NavigationService';
import Styles from '../../uistyles/Styles';
import images from '../../util/img';
import { otpvalidate, otpLogin, generateForgotPasswordOtp, validateForgotPasswordOtp } from '../../actions';

var params;
class OTPScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      email: '',
      pwd: '',
      userCheck: '',
      checked: 'first',
      checkedcond: true,
      otp: ''
    }
    params = this.props.navigation.state.params;
  }
  static navigationOptions = {
    headerShown: false,
  };

  componentDidUpdate(prevProps) {
    if (this.props.valOtp != null && prevProps.valOtp != this.props.valOtp) {
      if (this.props.valOtp.otpvalidateerror != undefined && this.props.valOtp.otpvalidateerror != null) {
        if (this.props.valOtp.otpvalidateerror != prevProps.valOtp.otpvalidateerror) {
          alert(this.props.valOtp.otpvalidateerror.message);
        }
      }
      else {
        if (this.props.valOtp.otpvalidatemessage != null) {
          if (this.props.valOtp.otpvalidatemessage != prevProps.valOtp.otpvalidatemessage && !this.props.navigation.state.params.resetPass) {
            ToastAndroid.show(
              "Otp Verified",
              ToastAndroid.SHORT,
              ToastAndroid.BOTTOM//can be SHORT, LONG
            );
            NavigationService.navigate('SetPasswordScreen', { newUser: true, email: params.email });
          }
        }
      }
    }

    if (prevProps.otpgeneratemessage != this.props.otpgeneratemessage) {
      if (this.props.otpgeneratemessage && this.props.otpgeneratemessage.data === "otp Sent") {
        this.setState({ otp: this.props.otpgeneratemessage.otp })
      }
    }
    if (prevProps.resetPassOtp != this.props.resetPassOtp) {
      if (this.props.resetPassOtp && this.props.resetPassOtp.data === "otp Sent") {
        this.setState({ otp: this.props.resetPassOtp.otp })
      }
    }
    if (prevProps.validatePassResponse != this.props.validatePassResponse) {
      if (this.props.validatePassResponse && this.props.validatePassResponse.data === "otp Verified") {
        NavigationService.navigate('SetPasswordScreen', { email: this.state.email })
      } else {
        Alert.alert(this.props.validatePassResponse && this.props.validatePassResponse.data)
      }
    }
  }

  componentDidMount() {
    if (this.props.navigation && this.props.navigation.state && this.props.navigation.state.params) {
      if (this.props.navigation.state.params.resetPass) {
        this.setState({ email: this.props.navigation.state.params.email })
        this.setState({ otp: this.props.resetPassOtp && this.props.resetPassOtp.otp })
      } else {
        this.setState({ email: this.props.navigation && this.props.navigation.state && this.props.navigation.state.params && this.props.navigation.state.params.email })
        this.setState({ otp: this.props.otpgeneratemessage && this.props.otpgeneratemessage.otp })
      }
    }
  }


  validateotp = async (checknumber, checkotp) => {
    if (this.props.navigation.state.params && this.props.navigation.state.params.resetPass) {
      this.props.validateForgotPasswordOtp(checknumber, checkotp)
    } else {
      const { otpvalidate } = this.props;
      await otpvalidate(checknumber, checkotp);
    }
  }

  otpgenerator = async (numbervalue) => {
    if (this.props.navigation.state.params && this.props.navigation.state.params.resetPass) {
      this.props.generateForgotPasswordOtp(numbervalue)
    } else {
      const { otpLogin } = this.props;
      await otpLogin(numbervalue);
    }
  };

  handleOTPChange = (otp) => {
    this.setState({ otp })
  }


  render() {
    return (
      <View>
        <View style={{ height: heightPercentageToDP('40%'), backgroundColor: loginheaderColor, }}>
          <TouchableOpacity
            style={{ position: 'absolute', left: 10, top: 20 }}
            onPress={() => this.props.navigation.goBack()} >
            <Image source={images.loginback} style={{
              height: 40, width: 40,
              resizeMode: 'contain',
            }}></Image>
          </TouchableOpacity>
          <View style={{ justifyContent: 'center', }}>
            <View style={{ marginTop: 100, marginLeft: 20 }}>
              <Text style={{ fontSize: 18, color: 'white' }}>Verify</Text>
              <Text style={{ fontSize: 12, color: 'white', fontStyle: 'italic', marginTop: 5 }}>We have sent a verification code to {this.state.email}</Text>
              <Text style={{ fontSize: 12, color: 'white', fontStyle: 'italic', }}>Enter the code below</Text>
            </View>
          </View>
          <View style={Styles.loginscreeninput1}>
            <OTPInput
              value={this.state.otp}
              onChange={this.handleOTPChange}
              tintColor="black"
              offTintColor={appgrayColor}
              backColor="white"
              otpLength={4}
            />
          </View>
        </View>

        <View style={{ marginTop: 15 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 10 }}>
            <TouchableOpacity onPress={() =>
              this.validateotp(this.state.email, this.state.otp)} >
              <View style={Styles.loginscreenbtn}>
                <Text style={{ color: 'white', justifyContent: 'center', alignContent: 'center', alignSelf: 'center' }}>Verify & Proceed
               </Text>
              </View>
            </TouchableOpacity>
          </View>
          <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 10 }}>
            <Text style={{ fontSize: 12 }}>Didn't receive code?</Text>
            <Text>{' '}</Text>
            <TouchableOpacity onPress={() => this.otpgenerator(this.state.email)}>
              <Text style={{ color: appblueColor, fontSize: 12, fontWeight: 'bold' }}>Resend code</Text>
            </TouchableOpacity>
          </View>
        </View>

        {
          this.state.isLoading ? <View style={Styles.loading}>
            <ActivityIndicator sizewhite='large' color='white'>
            </ActivityIndicator>
          </View>
            : null
        }
      </View >
    )
  }
}
const mapStateToProps = state => ({
  valOtp: state.valOtp,
  otpgeneratemessage: state.genOtp.otpgeneratemessage,
  resetPassOtp: state.auth.generateResetOtpData,
  validatePassResponse: state.auth.validateResetOtpData,
});

const mapDispatchToProps = {
  otpvalidate,
  otpLogin,
  generateForgotPasswordOtp,
  validateForgotPasswordOtp
};

export default connect(mapStateToProps, mapDispatchToProps)(OTPScreen);