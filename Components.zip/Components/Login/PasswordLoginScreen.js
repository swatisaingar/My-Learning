import React, { Component } from 'react'
import { StatusBar, TouchableOpacity, View, ToastAndroid, Text, TextInput, Image, ActivityIndicator  } from 'react-native'
import { StackActions, NavigationActions } from 'react-navigation';
import { heightPercentageToDP } from 'react-native-responsive-screen';
import { connect } from 'react-redux';

import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import { loginheaderColor } from '../../util/AppConstants';
import NavigationService from '../../Services/NavigationService';
import { authLogin } from '../../actions';
import AsyncStorage from '@react-native-async-storage/async-storage';

var params;
class PasswordLoginScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      pwd: '',
      userCheck: '',
      isModalVisible: false
    }
    params = this.props.navigation.state.params;
  }
  static navigationOptions = {
    headerShown: false,
  };

  async componentDidMount() {
    if (params != undefined) {
      this.setState({
        email: params.email
      })
    }
    
    StatusBar.setHidden(false);
  }

  async componentDidUpdate(prevProps) {
    if (this.props.user != null) {
      if (this.props.user != prevProps.user) {
        if (this.props.user.loginError != undefined && this.props.user.loginError != null) {
          if (this.props.user.loginError != prevProps.user.loginError) {
            alert(this.props.user.loginError.message);
          }
        }
        else {
          if (this.props.user.loginMessage != null) {
            if (this.props.user.loginMessage != prevProps.user.loginMessage) {
              AsyncStorage.setItem('user_id',(this.props.user.loginMessage.userId))
              AsyncStorage.setItem('id_token',(this.props.user.loginMessage.id_token))
              AsyncStorage.setItem('loginMessage',JSON.stringify(this.props.user.loginMessage))
              ToastAndroid.show(
                "Login Successfull",
                ToastAndroid.SHORT,
                ToastAndroid.BOTTOM//can be SHORT, LONG
              );
              {
                this.props.selctType.typeselectedData.logintype == "Student" ?
                  NavigationService.navigate('Home') : NavigationService.navigate('Teacher')
              };
            }
          }
        }
      }
    }
    
  }

  handleemail = (text) => {
    this.setState({ email: text })
  }
  handlepwd = (text) => {
    this.setState({ pwd: text })
  }

  validateLogin = async (email, password) => {
    let AuthToken = await AsyncStorage.getItem('loginMessage');
    const { authLogin } = this.props;
    await authLogin(email, password , AuthToken);
  }

  finishPreviousScreens(screen) {
    const resetAction = StackActions.reset({
      index: 0,
      key: null,
      actions: [
        NavigationActions.navigate({ routeName: screen })
      ]
    });
    this.props.navigation.dispatch(resetAction);
  }

  render() {
    return (
      <View style={{ flex: 1 }}>
      
        <View style={{ height: heightPercentageToDP('50%'), backgroundColor: loginheaderColor, }}>
          <TouchableOpacity
            style={{ position: 'absolute', left: 10, top: 20 }}
            onPress={() => { this.props.navigation.goBack() }}>

            <Image source={images.loginback} style={{
              height: 40, width: 40,
              resizeMode: 'contain',
            }}></Image>
          </TouchableOpacity>

          <View style={{ justifyContent: 'center', }}>
            <View style={{ marginTop: 100, marginLeft: 20 }}>
              <Text style={{ fontSize: 18, color: 'white' }}>Welcome</Text>
              <Text style={{ fontSize: 12, color: 'white', fontStyle: 'italic', marginTop: 5 }}>Enter E-mail ID & Password</Text>
            </View>
          </View>

          <View style={Styles.loginscreeninput1}>
            <View style={Styles.loginbackground} />

            <TextInput
              ref='mobnumber'
              style={Styles.textInput}
              //  onChangeText = {this.handlePassword}
              keyboardType="email-address"
              value={this.state.email}
              disableFullscreenUI={true}
              onChangeText={this.handleemail}
              placeholder="Mobile Number / Email"
              placeholderTextColor={'gray'}
              underlineColorAndroid="transparent"
              returnKeyType="next"
              blurOnSubmit={false}
              maxLength={parseInt(this.state.email)? 10:100}
              onSubmitEditing={(event) => { this.refs.lname.focus(); }}
            />
          </View>

          <View style={Styles.loginscreeninput2}>
            <View style={Styles.loginbackground} />
            <View style={{ flexDirection: 'row', }}>

              <TextInput
                ref='pwd'
                style={Styles.textInput}
                //  onChangeText = {this.handlePassword}
                secureTextEntry={true}
                value={this.state.pwd}
                disableFullscreenUI={true}
                onChangeText={this.handlepwd}
                placeholder="Password"
                placeholderTextColor={'gray'}
                underlineColorAndroid="transparent"
                returnKeyType="done"
              />
              <TouchableOpacity onPress={() => NavigationService.navigate('ForgetPassWordScreen', { email: this.state.email })}
                style={{ color: loginheaderColor, marginRight: 10, textDecorationColor: 'white', textDecorationLine: 'underline', fontSize: 12, alignSelf: 'center' }}>
                <Text style={{ color: loginheaderColor, marginRight: 10, textDecorationColor: 'white', textDecorationLine: 'underline', fontSize: 12, alignSelf: 'center' }} >Forgot Password</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <View style={{ marginTop: 20 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 10 }}>
            <TouchableOpacity onPress={() => { this.autoLogin
              this.validateLogin(this.state.email, this.state.pwd)
               }}>
              <View style={Styles.loginscreenbtn}>
                <Text style={{ color: 'white', justifyContent: 'center', alignContent: 'center', alignSelf: 'center' }}>Login
              </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {
          this.props.user.loginLoading ? <View style={Styles.loading}>
            <ActivityIndicator sizewhite='large' color={loginheaderColor}>
            </ActivityIndicator>
          </View>
            : null
        }
      </View>
    )
  }

}

const mapStateToProps = state => ({
  user: state.auth,
  selctType: state.selctType
});

const mapDispatchToProps = {
  authLogin
};

export default connect(mapStateToProps, mapDispatchToProps)(PasswordLoginScreen);