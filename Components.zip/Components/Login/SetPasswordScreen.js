import React, { Component } from 'react'
import { StatusBar, TouchableOpacity, View, ToastAndroid, Text, TextInput, Image, ActivityIndicator } from 'react-native'
import { StackActions, NavigationActions } from 'react-navigation';
import { connect } from 'react-redux';
import { heightPercentageToDP, widthPercentageToDP } from 'react-native-responsive-screen';
import { Alert } from 'react-native';
import { isEmpty, isInteger, isNull } from 'lodash';

import { loginheaderColor } from '../../util/AppConstants';
import NavigationService from '../../Services/NavigationService';
import { authLogin, resetPassword, SignUp } from '../../actions';
import Styles from '../../uistyles/Styles';
import images from '../../util/img';
import Icon from 'react-native-vector-icons/FontAwesome5';
import AsyncStorage from '@react-native-async-storage/async-storage';

var params;
class SetPasswordScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      pwd: [],
      cpwd: '',
      userCheck: '',
      passmatch: false,
      isModalVisible: false,
      userType: '',
      hidePass: true,
      hidePass1:true,
      validation:false
    }
    params = this.props.navigation.state.params;
  }
  static navigationOptions = {
    headerShown: false,
  };

  componentDidMount() {
    if (params != undefined) {
      console.log("DETAIL" + JSON.stringify(params.email));
      this.setState({
        email: params.email,
        userType: this.props.selctType.typeselectedData.logintype === 'Student' ? 'ROLE_STUDENT' : "ROLE_TEACHER",

      })
    }
    StatusBar.setHidden(false);
    // this.setState({ hidePass: true })
  }


  componentDidUpdate(prevProps) {
    if (this.props.user !== null) {
      if (this.props.user !== prevProps.user) {
        if (this.props.user.signUpError !== undefined && this.props.user.signUpError !== null) {
          if (this.props.user.signUpError !== prevProps.user.signUpError) {
            if (this.props.user?.signUpError?.message?.indexOf('Duplicate') !== -1) {
              alert("User already exists for these credentials!")
            } else {
              alert(this.props.user.signUpError.message);
            }
          }
        }
      }
    }

    if (prevProps.resetPasswordData !== this.props.resetPasswordData) {
      if (this.props.resetPasswordData && this.props.resetPasswordData.message === "passwordResetDone") {
        this.props.authLogin(this.state.email, this.state.pwd)
      } else[
        Alert.alert(this.props.resetPasswordData && this.props.resetPasswordData.message)
      ]
    }

    if (prevProps.resetPasswordError !== this.props.resetPasswordError) {
      if (this.props.resetPasswordError && this.props.resetPasswordError.message) {
        Alert.alert(this.props.resetPasswordError && this.props.resetPasswordError.message)
      }
    }

    if (prevProps.signUpSuccess !== this.props.signUpSuccess && !isEmpty(this.props.signUpSuccess)) {
      if (!isEmpty(this.props.signUpSuccess.id_token)) {
        AsyncStorage.setItem('user_id',(this.props.signUpSuccess.userId))
        AsyncStorage.setItem('id_token',(this.props.signUpSuccess.id_token))
        AsyncStorage.setItem('loginMessage',JSON.stringify(this.props.signUpSuccess))
        ToastAndroid.show(
          "User Created",
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM//can be SHORT, LONG
        );
        var obj = {};
        obj.email = this.state.email;
        this.state.userType === "ROLE_STUDENT" && params.newUser ?
          NavigationService.navigateAndReset('PreferenceScreen') :
          NavigationService.navigate('TeacherBasicInfoScreen', obj);
      }
    }
  }

  handleemail = (text) => {
    this.setState({ email: text })
  }
  handlepwd = (text) => {
    var check = /^(?=.{8,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[@#$%^&+=*]).*$/;
    if(!check.test(text)){
     this.setState({ pwd: text });
    }
    if (!isNaN(parseInt(text[0]))) {
     this.setState({ pwd: text });
     alert("Password should not start with Number");      
    }

    if (!isNaN(parseInt(text.slice(-1)[0]))) {
     this.setState({ pwd: text });
     alert("Password should not end with Number");      
    }

    if(text[0] === '@'|| text[0] === '#' || text[0] === '$' || text[0] === '&' || text[0] === '%' || text[0] === '!' || text[0] === '~'){
      this.setState({ pwd: text });
      alert('Password should not start with Special character')
    }

    if(text.slice(-1)[0] === '@'|| text.slice(-1)[0] === '#' || text.slice(-1)[0] === '$' || text.slice(-1)[0] === '&' || text.slice(-1)[0] === '%' || text.slice(-1)[0] === '!' || text.slice(-1)[0] === '~'){
      this.setState({ pwd: text });
      alert('Password should not end with Special character')
    }

    this.setState({ pwd: text });
  }
  handlecpwd = (text) => {
    var check = /^(?=.{8,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[@#$%^&+=*]).*$/;
    if(!check.test(text)){
      this.setState({ cpwd: text });
    }
    if (!isNaN(parseInt(text[0]))) {
      this.setState({ cpwd: text });
     alert("Password should not start with Number");      
    }

    if (!isNaN(parseInt(text.slice(-1)[0]))) {
      this.setState({ cpwd: text });
     alert("Password should not end with Number");      
    }

    if(text[0] === '@'|| text[0] === '#' || text[0] === '$' || text[0] === '&' || text[0] === '%' || text[0] === '!' || text[0] === '~'){
      this.setState({ cpwd: text });
      alert('Password should not start with Special character')
    }

    if(text.slice(-1)[0] === '@'|| text.slice(-1)[0] === '#' || text.slice(-1)[0] === '$' || text.slice(-1)[0] === '&' || text.slice(-1)[0] === '%' || text.slice(-1)[0] === '!' || text.slice(-1)[0] === '~'){
      this.setState({ cpwd: text });
      alert('Password should not end with Special character')
    }

     this.setState({ cpwd: text });
    this.handlePass(text)
  }

  handlePass = (text) => {
    if (text !== this.state.pwd) {
      this.setState({ passmatch: false })
    } else {
      this.setState({ passmatch: true })
    }
  }


  render() {
    return (
      <View style={{ flex: 1 }}>
        <View style={{ height: heightPercentageToDP('50%'), backgroundColor: loginheaderColor, }}>

          <TouchableOpacity
            style={{ position: 'absolute', left: 10, top: 20 }}
            onPress={() => {

              this.props.navigation.goBack();
            }

            } >
            <Image source={images.loginback} style={{
              height: 40, width: 40,
              resizeMode: 'contain',
            }}></Image>
          </TouchableOpacity>
          <View style={{ justifyContent: 'center', }}>
            <View style={{ marginTop: 100, marginLeft: 20 }}>
              <Text style={{ fontSize: 18, color: 'white' }}>Set Password</Text>
              <Text style={{ fontSize: 12, color: 'white', fontStyle: 'italic', marginTop: 5 }}>Set Password</Text>

            </View>
          </View>
          <View style={Styles.loginscreeninput1}
          >
            <View style={Styles.loginbackground} />

            <View style={{ flexDirection: 'row', }}>

            <TextInput
              ref='mobnumber'
              style={Styles.textInput}
              //  onChangeText = {this.handlePassword}
              secureTextEntry={this.state.hidePass1 ? true : false}
              value={this.state.pwd}
              disableFullscreenUI={true}
              onChangeText={this.handlepwd}
              placeholder="Password"
              placeholderTextColor={'gray'}
              underlineColorAndroid="transparent"
              returnKeyType="next"
              blurOnSubmit={false}
             
            />

            <Icon
              name={this.state.hidePass1 ? 'eye-slash' : 'eye'}
              size={15}
              color="grey"
              onPress={() => this.setState({ hidePass1: !this.state.hidePass1 })}
              style={{ alignSelf: 'center',marginRight:10}}
            />
            </View>
          </View>
          {this.state.validation && <View>
            <Text style={{marginLeft:25}}>Password must be greater than 8</Text>
            </View>}

          <View style={Styles.loginscreeninput2}>
            <View style={Styles.loginbackground} />

            <View style={{ flexDirection: 'row', }}>
              <TextInput
                ref='pwd'
                style={Styles.textInput}
                //  onChangeText = {this.handlePassword}
                secureTextEntry={this.state.hidePass ? true : false}
                value={this.state.cpwd}
                disableFullscreenUI={true}
                onChangeText={this.handlecpwd}
                placeholder="Confirm Password"
                placeholderTextColor={'gray'}
                underlineColorAndroid="transparent"
                returnKeyType="done"
                
              />

              <Icon
                name={this.state.hidePass ? 'eye-slash' : 'eye'}
                size={15}
                color="grey"
                onPress={() => this.setState({ hidePass: !this.state.hidePass })}
                style={{ alignSelf: 'center', marginRight: 10 }}
              />
            </View>
          </View>
          {(this.state.cpwd !== '' && !this.state.passmatch) && <Text style={{ marginLeft: 25 }}>Password does not match</Text>}
        </View>

        <View style={{ marginTop: 20 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'center', marginTop: 10 }}>
            <TouchableOpacity disabled={!this.state.passmatch} onPress={() => {
              let mailformat = /^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[A-Za-z]+$/;
              let temp = ''
              if (mailformat.test(this.state.email)) {
                temp = 'email'
              } else {
                temp = 'num'
              }
              (params.newUser ? this.props.SignUp(this.state.email, this.state.pwd, this.state.userType) : this.props.resetPassword(this.state.email, this.state.pwd))
            }}>
              <View style={[Styles.loginscreenbtn, this.props.selctType.typeselectedData.logintype == "Student" ? { opacity: (!this.state.passmatch) ? 0.5 : 1 } : null]}>
                <Text style={{ color: 'white', justifyContent: 'center', alignContent: 'center', alignSelf: 'center' }}>Login
              </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
        {
          this.props.user.loginLoading ? <View style={Styles.loading}>
            <ActivityIndicator sizewhite='large' color={loginheaderColor}>
            </ActivityIndicator>
          </View>
            : null
        }
      </View>
    )
  }
}

const mapStateToProps = state => ({
  user: state.auth,
  resetPasswordData: state.auth.resetPasswordData,
  resetPasswordError: state.auth.resetPasswordError,
  selctType: state.selctType,
  signUpSuccess: state.auth.signUpSuccess
});

const mapDispatchToProps = {
  authLogin,
  resetPassword,
  SignUp,
  // authLogin,
};

export default connect(mapStateToProps, mapDispatchToProps)(SetPasswordScreen);