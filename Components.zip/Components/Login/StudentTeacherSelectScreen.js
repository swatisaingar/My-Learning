import React, { Component } from 'react'
import {
  View,
  Text,
  TouchableOpacity,
  Image
} from 'react-native'
import { widthPercentageToDP } from '../../constants/styles'
import { connect } from 'react-redux';
import { loginheaderColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import Modal from "react-native-modal";
import NavigationService from '../../Services/NavigationService';
import { checkSelectedType } from '../../actions/index';
import AsyncStorage from '@react-native-async-storage/async-storage';

class StudentTeacherSelectScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showLoader: false,
      isModalVisible: false,
      selectStudent: false,
    }
  }

  async checkType(value) {
    AsyncStorage.setItem('UserType',value);
    let typeValue = await AsyncStorage.getItem('UserType');
  
    const { checkSelectedType } = this.props;
    await checkSelectedType(typeValue);

    // console.log('value for select type',this.props.selctType)
    // AsyncStorage.setItem('UserType',JSON.stringify(this.props.selctType));
  }

  render() {
    return (
      <View style={{ backgroundColor: 'white', flex: 1, backgroundColor: loginheaderColor, paddingLeft: 30, paddingRight: 30, justifyContent: 'center' }}>

        <Modal
          isVisible={this.state.isModalVisible}
          animationType="fade"
          transparent={true}
          backdropColor={"transparent"}
          backdropOpacity={1}
          onBackdropPress={() => this.setState({ isModalVisible: false })}
          onRequestClose={() => {
            this.setState({ isModalVisible: false });
          }}
        >
          <View
            style={{
              flex: 1,
              justifyContent: "flex-end",
              alignItems: "center",
              height: 150,
              marginBottom: -18
            }}
          >
            <View
              style={{
                backgroundColor: "white",
                height: 150,
                width: widthPercentageToDP('100%'),
                borderTopLeftRadius: 15,
                borderTopRightRadius: 15
              }}
            >
              <View style={{ alignItems: 'center', marginTop: 10 }}>
                <View style={{ flexDirection: 'row', marginLeft: 10, marginRight: 10 }}>
                  <Text style={{ marginTop: 0, textAlign: 'center' }}>You are registering to idutor as </Text>
                  {this.state.selectStudent == true ? <Text style={{ marginTop: 0, color: 'red' }}>Student</Text> :
                    <Text style={{ marginTop: 0, color: 'red' }}>Teacher/Trainer</Text>
                  }
                </View>
                <Text style={{ marginTop: 0, textAlign: 'center' }}>Please confirm,as this can not be changed later</Text>
              </View>
              <View style={{ flexDirection: 'row', position: 'absolute', bottom: 25, alignSelf: 'center', width: widthPercentageToDP('100%'), justifyContent: 'center' }}>
                <TouchableOpacity
                  style={[
                    Styles.selectcontinuebutton,
                  ]}
                  onPress={() => {
                    this.setState({ isModalVisible: false });
                    var obj = {};
                    obj.isStudent = this.state.selectStudent;
                    NavigationService.navigate('LoginScreen', obj);
                  }}
                >
                  <Text style={{ color: 'white', justifyContent: 'center', alignContent: 'center', alignSelf: 'center'}}>
                    Continue
                  </Text>
                </TouchableOpacity>
              </View>
              <View style={{ flexDirection: 'row', position: 'absolute', bottom: 15, alignSelf: 'center', width: widthPercentageToDP('150%'), justifyContent: 'center' }}>
                <Text onPress={() => {
                  this.setState({ isModalVisible: false });
                  var obj = {};
                  obj.isStudent = this.state.selectStudent;
                  this.props.navigation.navigate('PasswordLoginScreen')
                }}>Already a user?<Text style={{ marginTop: 0, color: 'red', textDecorationLine: 'underline' }}> Login</Text></Text>
              </View>
            </View>
          </View>
        </Modal>
        <Text style={{ fontSize: 25, color: 'white' }}>Welcome</Text>
        <Text style={{ fontSize: 12, color: 'white', fontStyle: 'italic' }}>Select your profile</Text>
        <TouchableOpacity
          style={{ marginTop: 30 }}
          onPress={() => {
            this.setState({
              selectStudent: true,
              selectTeacher: false,
              isModalVisible: true
            });
            this.checkType('Student')
          }}
        >
          <View style={this.state.selectStudent == true ? Styles.selectedLabell : Styles.unselectedLabell}>
            <View style={{ flexDirection: 'row', justifyContent: 'center',alignItems:'center',paddingTop:widthPercentageToDP(3),paddingBottom:widthPercentageToDP(3)}}>
              <Image source={images.graduated} style={{
                height: 50, width: 50,
                resizeMode: 'contain'
              }}></Image>
              <Text style={this.state.selectStudent == true ? Styles.selectedText : Styles.unselectedText}>Student</Text>
            </View></View>
        </TouchableOpacity>
        <TouchableOpacity
          style={{ marginTop: 10 }}
          onPress={() => {
            this.setState({
              selectStudent: false,
              selectTeacher: true,
              isModalVisible: true
            })
            this.checkType('Teacher')
          }}
        >
          <View style={this.state.selectTeacher == true ? Styles.selectedLabell : Styles.unselectedLabell}>
            <View style={{ flexDirection: 'row', justifyContent: 'center', paddingTop:widthPercentageToDP(3),paddingBottom:widthPercentageToDP(3),alignItems:'center' }}>
              <Image source={images.teacher_name} style={{
                height: 50, width: 50,
                resizeMode: 'contain'
              }}></Image>
              <Text style={this.state.selectTeacher == true ? Styles.selectedText : Styles.unselectedText}>Teacher/Trainer</Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    )
  }
}

const mapStateToProps = state => ({
  selctType: state.selctType
});

const mapDispatchToProps = {
  checkSelectedType
};

export default connect(mapStateToProps, mapDispatchToProps)(StudentTeacherSelectScreen);