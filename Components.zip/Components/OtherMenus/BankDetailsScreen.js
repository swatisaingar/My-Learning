import React, { Component } from 'react'
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity, TouchableWithoutFeedback,
    FlatList, Alert, TextInput, ToastAndroid, Image
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { connect } from 'react-redux';
import _ from "lodash";
import { appbluebtnColor, appblueColor, appgrayColor, loginheaderColor, appheadertextColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import NavigationService from '../../Services/NavigationService';
import { profile, updateprofile , uploadBankImageData, imageWithoutLoopLoad,fetchBankImageData} from '../../actions';
import {isNumber, isEmpty, now} from 'lodash';
import BottomSheet from 'reanimated-bottom-sheet';
import Animated from 'react-native-reanimated';
import ImagePicker from 'react-native-image-crop-picker';

var params;
class BankDetailsScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            saving: true,
            current: false,
            canceltext: false,
            // panNumber: '',
            // accountnumber: '', 
            // accountholder: '', 
            // ifsccode: '',
            accountnumber1:'',
            accountype: '',
            passmatch: false,

           accountnumber:'' ,//"12872191057195",
           accountType:1,
           bankName:'',//"oriental",
           accountholder:'',//"raman Singh",
           id:null,//"d00c5269-19ad-4db3-93c7-2f8a2cbcdcad",
           ifscCode:'',//"ORBC00125",
            panNumber:'',//"BPSPN4907F",
            status:null,//null,
            userProfileData:{},
            docImage:{},
            docImageId:'',
            aadharNumber:'',
            img:'',
    
            width: '',
            height:'',
            path: '',
            size: '',
            mime: '',
            modificationDate: '',
        

        }

        params = this.props.navigation.state.params && this.props.navigation.state.params.profileData

        console.log("params=========", params)
        console.log("payment doc image id =========", params.payment.imageId)
        this.setState({docImageId:params.payment.imageId,
                       docImage : this.props.imagewithoutloopData?.data})

    }

    bs = React.createRef();
    fall = new Animated.Value(1)

    takePhotoFromCamera = () => {
        ImagePicker.openCamera({
          width: 300,
          height: 400,
          cropping: true,
          includeBase64: true,
          compressImageMaxWidth: 500,
          compressImageMaxHeight: 500,
          compressImageQuality: 1,
        }).then(image => {
            console.log("image path========", image.path)
            console.log("image data ========", image.data)
          this.setState({
            img: `${image.data}`,
            width: `${image.width}`,
            height: `${image.height}`,
            path: `${image.path}`,
            size: `${image.size}`,
            mime: `${image.mime}`,
            modificationDate: `${image.modificationDate}`,

          })
          let imageStored = this.props.imagewithoutloopData;
         
          imageStored.data.content = image.data;
          imageStored.data.width = image.width;
          imageStored.data.height = image.height;
          imageStored.data.contentContentType = image.mime;
          imageStored.data.contentSize = image.size;
          imageStored.data.createTime = image.modificationDate;
          imageStored.data.name = image.path;
          console.log("image data to upload=========", imageStored)
          var imgsize=image.size/1024; 
          //alert(imgsize);
          console.log("image data to upload Size =========", imgsize)
          this.setState({docImage: imageStored.data})
          if(image.size/1024<=500*1024)
          {
            this.setState({docImage: imageStored.data})
            this.props.uploadBankImageData(imageStored)
          }

          else{
              Alert.alert('Select image less than 500kb')
          }
          

          this.bs.current.snapTo(1)
        }).catch(e => {
          console.log('exception value', e);
        });

        console.log("image path state ========", this.state.path)
      }

      choosePhotoFromLibrary = () => {
        ImagePicker.openPicker({
          width: 300,
          height: 400,
          cropping: true,
          includeBase64: true,
          compressImageMaxWidth: 500,
          compressImageMaxHeight: 500,
          compressImageQuality: 1,
        }).then(image => {
          this.setState({
            img: `${image.data}`,
            width: `${image.width}`,
            height: `${image.height}`,
            path: `${image.path}`,
            size: `${image.size}`,
            mime: `${image.mime}`,
            modificationDate: `${image.modificationDate}`,
          })

          let imageStored = this.props.imagewithoutloopData;
         
          imageStored.data.content = image.data;
          imageStored.data.width = image.width;
          imageStored.data.height = image.height;
          imageStored.data.contentContentType = image.mime;
          imageStored.data.contentSize = image.size;
          imageStored.data.createTime = image.modificationDate;
          imageStored.data.name = image.path;
          console.log("image data to upload=========", imageStored)
          var imgsize=image.size/1024; 
          alert(imgsize);
          console.log("image data to upload Size =========", imgsize)
          if(image.size/1024<=500*1024)
          {
            this.setState({docImage: imageStored.data})
            this.props.uploadBankImageData(imageStored)
          }

          else{
              Alert.alert('Select image less than 500kb')
          }
          

          this.bs.current.snapTo(1)
        }).catch(e => {
          console.log('exception value', e);
        });
      }
    handleaccountnumber = (text) => {
        this.setState({ accountnumber: text })
    }

    handleaccountnumber1 = (text) => {
        this.setState({ accountnumber1: text })
        this.handlePass(text)
    }
    handlePass = (text) => {
        if (text !== this.state.accountnumber) {
          this.setState({ passmatch: false })
        } else {
          this.setState({ passmatch: true })
        }
      }
    handleifsc = (text) => {
        this.setState({ ifscCode: text })
    }

    handlepan = (text) => {
        this.setState({ panNumber: text })
    }

    handleAadhar = (text) => {
        this.setState({ aadharNumber: text })
    }

    handleBankName = (text) => {
        this.setState({ bankName: text })
    }

    async componentDidMount() {
        const { profile } = this.props;
        let profileData = this.props.user && this.props.user.loginMessage && this.props.user.loginMessage.userId;
        await profile(profileData);
        var imageId = this.props.prof.profData.data && this.props.prof.profData.data != null && this.props.prof.profData.data.payment!=null && this.props.prof.profData.data.payment.imageId
        console.log("bank image id ========", imageId)
        this.props.fetchBankImageData(imageId)

        if(this.props.imagewithoutloopData && this.props.imagewithoutloopData.data)
        {
            console.log("doc image from reducer=======", this.props.imagewithoutloopData.data)
            this.setState({docImage: this.props.imagewithoutloopData.data})
        }

       
       
    }


    async componentDidUpdate(prevProps) {
        if (this.props.prof != null) {
            if (this.props.prof != prevProps.prof) {
                if (this.props.prof.profData.data && this.props.prof.profData.data != null && this.props.prof.profData.data.payment!=null) {
                    console.log("Payment data before changed============",this.props.prof.profData.data.payment )
                    this.setState({panNumber: this.props.prof.profData.data.payment.panNumber,
                        ifscCode: this.props.prof.profData.data.payment.ifscCode,
                        accountholder: this.props.prof.profData.data.firstName + " " +this.props.prof.profData.data.lastName,
                        accountnumber: this.props.prof.profData.data.payment.accountNumber,
                        current:(this.props.prof.profData.data.payment.account_type == 2)? true : false,
                        saving: (this.props.prof.profData.data.payment.account_type == 1 )? true : false,
                        account_type : this.props.prof.profData.data.payment.account_type,
                        id:this.props.prof.profData.data.payment.id,
                        userProfileData:this.props.prof.profData.data,
                        docImageId : this.props.prof.profData.data.payment.imageId,
                        adhaarNumber :  this.props.prof.profData.data.payment.adhaarNumber,
                    })

                    //  if (this.props.prof.profData.data.payment.account_type == 1) {
                    //     this.setState({
                    //         current: true, saving: false,
                    //    })
                    // }
                    // else {
                    //     this.setState({
                    //         saving: true, current: false,
                    //     })
                    // }
                }
            }
        }


        // if(prevProps.updateProfileData != this.props.updateProfileData)
        // {
        //     console.log("Updated bank details data ==========",this.props.updateProfileData )
        // }

        if(prevProps.uploadBankImageDataResp != this.props.uploadBankImageDataResp)
        {
            console.log("Updated bank image data ==========",this.props.uploadBankImageDataResp, this.state.docImage )

            if(this.props.uploadBankImageDataResp.data=='updated')
            {
                 console.log("Image is updated successfully " , 'true')
            }
            else{
                console.log("Image is updated successfully " , 'true')
            }
        }


        if(prevProps.imagewithoutloopData != this.props.imagewithoutloopData)
        {
            console.log("Get bank image data ==========",this.props.imagewithoutloopData) 
            this.setState({docImage:this.props.imagewithoutloopData.data })
        }
    }

    updatedprofileValue = async (values) => {
        
        //let docIamge={}
        
        var tempPayment={
            accountNumber: this.state.accountnumber , //"12872191057195",
            account_type: this.state.saving==true ? 1 : 2, //this.state.accountType,//1,
            bankName: this.state.bankName,//"oriental",
            holderName: this.state.accountholder,//"raman Singh",
            id: this.state.id,//"d00c5269-19ad-4db3-93c7-2f8a2cbcdcad",
            ifscCode: this.state.ifscCode,//"ORBC00125",
            panNumber: this.state.panNumber,//"BPSPN4907F",
            status: true,//null,
            adhaarNumber:this.state.adhaarNumber,

        }

        // if(this.props.updateProfileData.data.payment.imageId==null)
        // {
        //    tempPayment.image={}
        // }

        // else{

        //     tempPayment.image ={
        //         id : this.props.updateProfileData.data.payment.imageId,

        //     }
        // }
    console.log('apidata tempPayment being called',tempPayment)

        let apiData = this.props.updateProfileData.data
        apiData.payment = tempPayment
        apiData.image=[]
       
        // apiData.image={
        //     id: apiData.imageId

        // }

        if(this.state.docImage)
        {
            apiData.payment.image  = this.state.docImage
        }
        else {
            apiData.payment.image=  { id: apiData.imageId} 
        }

        console.log("doc image data in Bank details to send Update bank detail============",  apiData.image)
        
        delete apiData.standard;
        delete apiData.imageId;
        delete apiData.authorities;

        console.log('apidata being called in Bank details : ============   ',apiData)
        this.setState({userProfileData: apiData})
        NavigationService.navigate('UpdatedBankDetails',{profileData:apiData , docImageData: this.state.docImage? this.state.docImage :apiData.image})
        // const { updateprofile } = this.props;
        // await updateprofile(apiData);


    }

    selectDocImage()
    {
        console.log("Select image=======", "Clicked")
        this.bs.current.snapTo(0)
    }


  renderInner = () => (
    <View style={{ backgroundColor: appgrayColor, borderTopStartRadius: 15, borderTopEndRadius: 15, height: '100%' }}>
      <View style={{ alignItems: 'center', marginTop: 20 }}>
        <Text style={{ fontSize: 25, fontWeight: '900' }}>Upload Document</Text>
        <Text style={{ fontSize: 16, marginTop: 10 }}>Choose Your Aadhar/ PAN Image</Text>
      </View>

      <TouchableOpacity style={{ backgroundColor: 'white', marginTop: 30, width: '80%', alignSelf: 'center', borderWidth: 1, borderRadius: 10, height: '12%' }}
        onPress={this.takePhotoFromCamera}>
        <Text style={{ fontSize: 18, alignSelf: 'center', padding: 5 }}>Take Photo</Text>
      </TouchableOpacity>

      <TouchableOpacity style={{ backgroundColor: 'white', marginTop: 30, width: '80%', alignSelf: 'center', borderWidth: 1, borderRadius: 10, height: '12%' }}
        onPress={this.choosePhotoFromLibrary}>
        <Text style={{ fontSize: 18, alignSelf: 'center', padding: 5 }}>Choose From Your Library</Text>

      </TouchableOpacity>
      <TouchableOpacity style={{ backgroundColor: 'white', marginTop: 30, width: '80%', alignSelf: 'center', borderWidth: 1, borderRadius: 10, height: '12%' }} onPress={() => this.bs.current.snapTo(1)}>
        <Text style={{ fontSize: 18, alignSelf: 'center', padding: 5 }}>Cancel</Text>
      </TouchableOpacity>
    </View>
  );


    render() {
        return (
            <View style={{ backgroundColor: 'white', flex: 1 }}>
<BottomSheet
          ref={this.bs}
          snapPoints={[330, 0]}
          renderContent={this.renderInner}
          initialSnap={1}
          callbackNode={this.fall}
          enabledGestureInteraction={true}
        />
                <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
                    <View style={{ marginTop: 15 }} >
                        <TouchableOpacity
                            onPress={() => {
                                this.props.navigation.goBack();

                            }}
                        >
                            <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={30} color="black" />

                        </TouchableOpacity>
                    </View>
                    <Image style={{ width: 90, height: 25, marginTop: 10 }} source={images.logo} resizeMode={'contain'} />

                    <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

                        <TouchableOpacity>
                            <Icon1 style={{ marginLeft: 15 }} name="bell-o" size={20} color="black" /></TouchableOpacity>
                    </View>
                </View>
                <ScrollView>
                    <View style={{height:'80%',marginBottom:10,}}>

                   
                    <Text style={{ margin: 10, fontSize: 15  , color:'#4d4d4d', fontWeight:'bold', fontFamily:'Helvetica'}}>Change Bank Details</Text>
                    <Text style={{ marginLeft: 10, fontSize: 12 }}>Account Type</Text>
                    <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                        <TouchableOpacity
                            style={[this.state.saving ? Styles.selectedprofilescreeninput1 : Styles.profilescreeninput1, { marginTop: 20 }]}
                            onPress={() => {
                                console.log("LIST ITEM CLICKED");
                                this.setState({
                                    saving: true,
                                    current: false
                                })
                            }}
                        >
                            <View>
                                <Text style={{ alignSelf: 'center' }}>Saving</Text>
                            </View>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[this.state.current ? Styles.selectedprofilescreeninput1 : Styles.profilescreeninput1, { marginTop: 20 }]}

                            onPress={() => {
                                console.log("LIST ITEM CLICKED");
                                this.setState({
                                    saving: false,
                                    current: true
                                })
                            }}
                        >
                            <View
                            >

                                <Text style={{ alignSelf: 'center' }}>Current</Text>

                            </View>
                        </TouchableOpacity>
                    </View>

                    <View style={{ flexDirection: 'row', margin: 10 }}>
                        <Text style={{ color: '#888888' }}>Account Holder Name</Text>
                        <Text style={{ marginLeft: 75, color:'#353839' }}>{this.state.accountholder}</Text>
                    </View>

                    <View style={[Styles.addprofilescreeninput1, { marginTop: 20, marginBottom: 10 }]}
                    >
                        <View style={Styles.loginbackground} />

                        <TextInput
                            ref='add'
                            style={Styles.textInput}
                            value={this.state.accountnumber}
                            disableFullscreenUI={true}
                            onChangeText={this.handleaccountnumber}
                            placeholder="Account Number"
                            placeholderTextColor={'gray'}
                            underlineColorAndroid="transparent"
                            returnKeyType="done"
                        />
                    </View>

                    <View style={[Styles.addprofilescreeninput1, { marginTop: 20, marginBottom: 10 }]}
                    >
                        <View style={Styles.loginbackground} />

                        <TextInput
                            ref='add'
                            style={Styles.textInput}
                            value={this.state.accountnumber1}
                            disableFullscreenUI={true}
                            onChangeText={this.handleaccountnumber1}
                            placeholder="Re-enter Account Number"
                            placeholderTextColor={'gray'}
                            underlineColorAndroid="transparent"
                            returnKeyType="done"
                        />
                    </View>

                    {(this.state.accountnumber1 !== '' && !this.state.passmatch) && <Text style={{ marginLeft: 25 }}>Account Number doesnot match</Text>}

                    <View style={[Styles.addprofilescreeninput1, { marginTop: 20, marginBottom: 10 }]}
                    >
                        <View style={Styles.loginbackground} />

                        <TextInput
                            ref='add'
                            style={Styles.textInput}
                            value={this.state.ifscCode}
                            disableFullscreenUI={true}
                            onChangeText={this.handleifsc}
                            placeholder="IFSC Code"
                            placeholderTextColor={'gray'}
                            underlineColorAndroid="transparent"
                            returnKeyType="done"
                        />
                    </View>

                    <View style={[Styles.addprofilescreeninput1, { marginTop: 20, marginBottom: 10 }]}
                    >
                        <View style={Styles.loginbackground} />

                        <TextInput
                            ref='add'
                            style={Styles.textInput}
                            value={this.state.panNumber}
                            disableFullscreenUI={true}
                            onChangeText={this.handlepan}
                            placeholder="PAN Number"
                            placeholderTextColor={'gray'}
                            underlineColorAndroid="transparent"
                            returnKeyType="done"
                        />
                    </View>

                    <View style={[Styles.addprofilescreeninput1, { marginTop: 20, marginBottom: 10 }]}>
                        <View style={Styles.loginbackground} />

                        <TextInput
                            ref='add'
                            style={Styles.textInput}
                            value={this.state.adhaarNumber}
                            disableFullscreenUI={true}
                            onChangeText={this.handleAadhar}
                            placeholder="Aadhar"
                            placeholderTextColor={'gray'}
                            underlineColorAndroid="transparent"
                            returnKeyType="done"
                        />
                    </View>
                   
                    {console.log("image get data 1========",this.props.imagewithoutloopData ,this.state.docImage)}
                  
                  {console.log("docImageId ==========",params.payment.imageId )}
                    {
                        isEmpty(this.state.docImageId) ?  <Text style={{ color:'red', fontSize:14,alignSelf:'flex-end',marginTop:20, marginHorizontal:40 , }}>Delete</Text>
                        : (
                            <TouchableOpacity onPress={() => {
                                this.selectDocImage()
                                
                            }} 
                            style={{  bottom: 10, alignSelf: 'center',alignContent:'center', justifyContent:'center',width:'80%' }}>
                                <Text style={{ marginBottom: 5, width:'80%',color: 'white', marginTop: 10, backgroundColor: appblueColor, borderRadius: 20, paddingBottom: 10, paddingTop: 10, textAlign: 'center', width: '100%' }}>Upload Aadhar/PAN card</Text>
                            </TouchableOpacity>
                        
                         )  
                         
                    }
                  {/* </View> */}

                  
                  <View style={{ flexDirection: 'row', height:'40%' , marginTop:10,marginBottom:80}}>
                  <View style={{marginRight:40,marginStart:40, marginVertical:20, height:'40%', width:'80%' , backgroundColor:'#00393939', alignContent:'center', justifyContent:'center'}}>
                  {console.log("image in UI ", this.state.path,  `${this.state.path}`,  this.state.img)}
            
                 
                  
                  {
                  
                 
                    !isEmpty(this.props.imagewithoutloopData) ? 
<View>
{console.log("image get data 2 in Bank Details ========",this.state.docImage)}
<Image style={{ width: '100%', height: '100%' }} source={{
                    uri:`data:image/jpeg;base64,${this.props.imagewithoutloopData?.data?.content}`,
                  }} />
</View> 
                  : 

                  <View>
                      
                     { this.state.path != null? 
                  
                  
                      <Image   source={ 
                            {uri : this.state.path}  }
                        
                        style={{height:'40%',width:'80%', margin:40, alignSelf:'center'}}
                        onLoadEnd={(event)=>{
                            console.log("event", event)
                        }}
                        
        
                      />
                       


:
<Image 
resizeMode="contain"
source={images.id_doc_palceholder} 
style={{ marginTop: 5, justifyContent: 'center',alignSelf:'center' }}/>
                  }
                    


                  {/* <Image 
                  resizeMode="contain"
                  source={images.id_doc_palceholder} 
                  style={{ marginTop: 5, justifyContent: 'center',alignSelf:'center' }}/> */}
                  </View>
                } 



                    </View>
                    </View>

</View>
                </ScrollView>
                <View  style={{height:'20%' , color:'transparent'}}>
                {this.state.canceltext == false ?
                        <View style={{ elevation: 10, backgroundColor: 'white',margin:10, padding:15,borderRadius: 10 }}>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', }}>
                                <Image style={{ width: 20, height: 20, marginLeft: 20, alignSelf: 'center' }} source={images.info} />
                                <View style={{ width: '70%' }}>
                                    <Text style={{ fontWeight: 'bold', color: appheadertextColor, fontSize: 12 }}>Attention</Text>
                                    <Text numberOfLines={3} style={{ fontSize: 10, color: appheadertextColor }}>Your Payment will be done on this account, please verify the details once and confirm.</Text>
                                </View>
                                <TouchableOpacity
                                    style={{ width: 10, height: 10, marginRight: 10, alignSelf: 'center' }}
                                    onPress={() => {
                                        this.setState({
                                            canceltext: true,
                                        })
                                    }}
                                >
                                    <Image style={{ width: 10, height: 10, marginRight: 10, alignSelf: 'center' }} source={images.close} />
                                </TouchableOpacity>
                            </View>
                        </View> : null
                    }
                <TouchableOpacity
                 onPress={() => {
                        this.updatedprofileValue(this.state);
                    }
                    } style={{ position: 'absolute', bottom: 10, alignSelf: 'center', left: 20, right: 20 }}>
                        <Text style={{ marginBottom: 5, color: 'white', marginTop: 10, backgroundColor: appblueColor, borderRadius: 20, paddingBottom: 10, paddingTop: 10, textAlign: 'center', width: '100%' }}>Update</Text>
                    </TouchableOpacity>
                </View>

              
            </View >
        )
    }

}

const mapStateToProps = state => ({
    user: state.auth,
    prof: state.prof,
    updateProfileData : state.prof.profData,
    uploadBankImageDataResp : state.prof.bankImageDataData,
    imagewithoutloopData : state.prof.fetchBankImageDataData,   
});

const mapDispatchToProps = {
    profile,
    updateprofile,
    uploadBankImageData,
    fetchBankImageData,
};


export default connect(mapStateToProps, mapDispatchToProps)(BankDetailsScreen);

