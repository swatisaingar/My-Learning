import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity, TouchableWithoutFeedback,
  FlatList, Alert, ToastAndroid, Image, Linking, Dimensions, SafeAreaView, TextInput, ActivityIndicator,
} from 'react-native';
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP, heightPercentageToDP } from '../../constants/styles'
import * as EnquiryAPI from '../../Services/enquiryAPIs';
import { connect } from 'react-redux';
import Loader from '../../Common/Loader';
import _ from "lodash";
import { appbluebtnColor, appblueColor, appgrayColor, apppinkColor, loginheaderColor, rescheduleClassBgColor, appheadertextColor, } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import Modal from "react-native-modal";
import { Checkbox } from 'react-native-paper';
import NavigationService from '../../Services/NavigationService';
import moment from 'moment';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import {
  fetchClassesForCourse, getTeacherClassesDataFilter,
  imageWithoutLoopLoad, getClassesData, MyClassesClassCancelCall,
}
  from '../../actions'
import { isNumber, isEmpty, now } from 'lodash';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../../util/AppConstants';
import QRCode from 'react-native-qrcode-svg';
import Share from 'react-native-share';
import RNFS from 'react-native-fs';

var params;
var params1;
class ClassDetailScreen extends Component {

  constructor(props) {
    super(props);
    this.state = {
      enquiries: [],
      filterArr: [{ id: -1, text: 'Top Rated' }, { id: 1, text: 'Top Rated', selected: 0 },
      { id: 2, text: 'Best Match', selected: 0 }, { id: 3, text: 'Price Low to High', selected: 0 }, { id: 4, text: 'Price High to Low', selected: 0 },],
      showLoader: false,
      showPopup: false,
      canceltext: '',
      _id: '',
      _selectedids: [],
      start: 0, total: 0,
      start2: 0, total2: 0,
      filterpopup: false,
      searchList: [{
        'class': "CHemistry Class 12th",
        'teacher': 'By Sooraj Rai',
      }],
      checkClass: false,
      modalVisible: false,
      url: 'https://meet.idutor.tk/BroadFilmMakersElevateAmazingly',
      classListForTeacher: [],
      teacherSearchText: '',
      showLoader: false,
      teacherListIamgeData: [],
      showQr1: false,
    }
    params1 = this.props.navigation.state.params;
    console.log('paramsssghdfvssdv', params1)
    params = this.props.navigation.state.params.courseData;
    this.opneModal = this.opneModal.bind(this);
    this.handleCall = this.handleCall.bind(this);
  }

  handleCall() {
    console.log('calling..')
    this.setState({ modalVisible: !this.state.modalVisible })
  }

  opneModal() {
    this.setState({ modalVisible: !this.state.modalVisible });
  }

  async componentDidMount() {
    let profileData = await AsyncStorage.getItem('user_id');
    this.props.getClassesData(profileData);
    let AuthToken = await AsyncStorage.getItem('id_token');
    // setTimeout(() => {
    // const url = 'https://meet.idutor.tk/BroadFilmMakersElevateAmazingly';

    //this.props.fetchClassesForCourse({id: this.props.navigation.state.params.courseData.id})
    if (
      this.props.navigation.state.params.courseData && this.props.navigation.state.params.courseData.courseClasses
    ) {

      console.log("Image data fetching==========", "true")
      this.props.navigation.state.params?.courseData?.courseClasses?.map((item) => {
        // this.props.imageLoad(item?.courseClass?.course?.imageId)
        console.log("item to fetch image============", item, this.props.navigation.state.params.courseData)
        let id = this.props.navigation.state.params.courseData?.image?.id;
        console.log("imageId ========", id)
        fetch(`${baseURL}file-blobs/getImage/${id}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${AuthToken}`,
          }
        }).then(data => {
          return data.json()
        }).then(resposne => {
          console.log("image======", resposne.data)
          let imageData = this.state.teacherListIamgeData || {};
          imageData[resposne.data.id] = resposne.data;
          this.setState(imageData);
          this.setState({ teacherListIamgeData: imageData, })
        }).
          catch((error) => {
            console.log("#error", error);
          })

        console.log("ImageData=============", this.state.teacherListIamgeData)

      })



      this.setState({
        teacherClassesList:
          this.props.teacherClassesDataProps &&
          this.props.teacherClassesDataProps.data,
      })
    }
    this.props.imageWithoutLoopLoad(params1?.id?.courseClass?.course?.imageId)

    // console.log('params1?.id?.course?.imageId',params1?.id?.course?.imageId)
  }

  componentDidUpdate = prevProps => {

    if (prevProps.classesForCourseData != this.props.classesForCourseData) {
      if (this.props.classesForCourseData != null && this.props.classesForCourseData.data) {
        this.setState({ classListForTeacher: this.props.classesForCourseData.data })
      }
    }

    if (
      prevProps.teacherFilteredClassesDataProps != this.props.teacherFilteredClassesDataProps
    ) {

      this.setState({ showLoader: false, })
      this.props.teacherFilteredClassesDataProps?.data?.map((item) => {
        // this.props.imageLoad(item?.courseClass?.course?.imageId)
        let id = item.course.imageId;
        fetch(`https://api.idutor.tk/api/file-blobs/getImage/${id}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${this.props.user &&
              this.props.user.loginMessage &&
              this.props.user.loginMessage.id_token}`,
          }
        }).then(data => {
          return data.json()
        }).then(resposne => {
          let imageData = this.state.teacherListIamgeData || {};
          imageData[resposne.data.id] = resposne.data;
          this.setState(imageData);
          console.log('image datadata', imageData)
          this.setState({ teacherListIamgeData: imageData, })
        }).
          catch((error) => {
            console.log("#error", error);
          })

        console.log("ImageData=============", this.state.teacherListIamgeData)

      })

      console.log("class list ========", this.props.teacherFilteredClassesDataProps)
      this.setState({
        classListForTeacher:
          this.props.teacherFilteredClassesDataProps &&
          this.props.teacherFilteredClassesDataProps.data,
        showLoader: false,

      })
    }


  if(prevProps.cancelClassApiData != this.props.cancelClassApiData)
  {

    console.log('cancel api data response=====', this.props.cancelClassApiData)
    if(!isEmpty(this.props.cancelClassApiData.data))
    {
      alert("Class has been cancelled successfully")
  
    }
    else{
      alert("Class has not been cancelled.")
    }
  }

<<<<<<< HEAD

  }


  showCancelButton(item)
  {
=======
  showCancelButton(item) {
>>>>>>> eb140c3... Bug Fixes
    const sTime = moment(item.startTime, "HH:mm");

    const currentTimeVal = moment(new Date()).format('HH:mm');

    const currentTime = moment(currentTimeVal, "HH:mm")
    console.log("current time---- start time =========", currentTime, sTime)

    var minutes = sTime.diff(currentTime, 'minutes');
    console.log("minutes to set classs ststus text =======", minutes)

    var currentDate = moment.utc(now()).format();

    var currentDate = moment(new Date(currentDate), "dd-MM-YYYY")
    var classDate = moment(new Date(item.date), 'dd-MM-YYYY')

    console.log("today ========", currentDate)
    console.log("class date ========", item.date)

    var dayDiff = classDate.diff(currentDate, 'days')
    console.log("day diff======", dayDiff)
<<<<<<< HEAD

     var classStatus = item.classStatus;
    if(dayDiff>0)
    {
      switch(classStatus)
      {
        case 3:
        return true

        case 5:
          return false;

        default:
          return false
      }
    }

    else if(dayDiff==0)
    {
      switch(classStatus)
      {

        case 3:
          if(minutes>30)
          {
            return true
          }
          else{
            return false
          }

         default:
           return false
=======
    if (dayDiff > 0) {
      return true
    }

    else if (dayDiff == 0) {
      if (minutes > 30) {
        return true
      }
      else {
        return false
>>>>>>> eb140c3... Bug Fixes
      }
     
    }

    else {
      return false
    }

  }
<<<<<<< HEAD
  
=======


>>>>>>> eb140c3... Bug Fixes
  checkJoinClass = () => {
    const url = 'https://meet.idutor.tk/BroadFilmMakersElevateAmazingly';
    const userInfo = { displayName: 'User', email: 'user@example.com', avatar: 'https:/gravatar.com/avatar/abc123' };
  }

  setChecked1(status) {
    this.setState({
      checked1: status
    })
  }
  setChecked2(status) {
    this.setState({
      checked2: status
    })
  }
  setChecked3(status) {
    this.setState({
      checked3: status
    })
  }
  setChecked4(status) {
    this.setState({
      checked4: status
    })
  }


  getClassStatusText(statusId, item) {

    const sTime = moment(item.startTime, "HH:mm");

    const currentTimeVal = moment(new Date()).format('HH:mm');

    const currentTime = moment(currentTimeVal, "HH:mm")
    console.log("current time---- start time =========", currentTime, sTime)

    var minutes = sTime.diff(currentTime, 'minutes');
    console.log("minutes to set classs ststus text =======", minutes)

    var currentDate = moment.utc(now()).format();

    var currentDate = moment(new Date(currentDate), "dd-MM-YYYY")
    var classDate = moment(new Date(item.date), 'dd-MM-YYYY')

    console.log("today ========", currentDate)
    console.log("class date ========", item.date)

    var dayDiff = classDate.diff(currentDate, 'days')
    console.log("day diff======", dayDiff)

    //1=COMPLETD, 2=ONGOING, 3=UPCOMING 4=MISSED 5=CANCELLED 6=STARTED
    switch (statusId) {

      case 1:
        return 'Completed'
      case 2:
        return 'Join now'
      case 3:
        {
          if (dayDiff > 0) {
            return 'Reschedule'
          }
<<<<<<< HEAD

        
            else if(dayDiff==0){
             // return 'Reschedule'
              if(minutes>=30)
              {
                return 'Reschedule'
              }
  
              else if (minutes<=30)
              {
                return 'Start Class'
              }
  
              else if (minutes<0 && Math.abs(minutes)<=this.getClassDuration(item))
              {
                return 'Join Now'
              }
  
              else{
                return rescheduleClassBgColor   // need to be check again
              }
  
              }

      
          else (dayDiff<0)
=======
          else if (dayDiff == 0) {
            if (minutes >= 30) {
              return 'Reschedule' //rescheduleClassBgColor //'Reschedule'
            }

            else if (minutes <= 30) {
              return 'Start Class' //loginheaderColor //'Start Class'
            }

            else if (minutes < 0 && Math.abs(minutes) <= this.getClassDuration(item)) {
              return 'Join Now' //loginheaderColor//'Join Now'
            }

            else {
              return 'Reschedule' //rescheduleClassBgColor   // need to be check again
            }

          }
          else (dayDiff < 0)
>>>>>>> eb140c3... Bug Fixes
          {
            return 'Missed'
          }

        }
      case 4:
        return 'Missed'
      case 5:
        return 'Cancelled'
      case 6:
        return 'Started'
      default:
        return 'Default'
    }
  }


  getClassStatusTextBgColor(statusId, item) {

    const sTime = moment(item.startTime, "HH:mm");

    const currentTimeVal = moment(new Date()).format('HH:mm');

    const currentTime = moment(currentTimeVal, "HH:mm")
    console.log("current time---- start time =========", currentTime, sTime)

    var minutes = sTime.diff(currentTime, 'minutes');
    console.log("minutes to set classs ststus text =======", minutes)

    var currentDate = moment.utc(now()).format();

    var currentDate = moment(new Date(currentDate), "dd-MM-YYYY")
    var classDate = moment(new Date(item.date), 'dd-MM-YYYY')

    console.log("today ========", currentDate)
    console.log("class date ========", item.date)

    var dayDiff = classDate.diff(currentDate, 'days')
    console.log("day diff======", dayDiff)

    //1=COMPLETD, 2=ONGOING, 3=UPCOMING 4=MISSED 5=CANCELLED 6=STARTED
    switch (statusId) {

      case 1:
        return 'green'  //'Completed'

      case 2:

        return loginheaderColor  //'Start Class'

      case 3:
        {
          if (dayDiff > 0) {
            return rescheduleClassBgColor //'Reschedule'
          }
          else if (dayDiff == 0) {
            if (minutes >= 30) {
              return rescheduleClassBgColor //'Reschedule'
            }

            else if (minutes <= 30) {
              return loginheaderColor //'Start Class'
            }

            else if (minutes < 0 && Math.abs(minutes) <= this.getClassDuration(item)) {
              return loginheaderColor//'Join Now'
            }

            else {
              return rescheduleClassBgColor   // need to be check again
            }

          }
          else (dayDiff < 0)
          {
            return 'red' //'Missed'
          }

        }
      case 4:
        return 'red' //'Missed'
      case 5:
        return 'red' //'Cancelled'
      case 6:
        return loginheaderColor //'Started'
      default:
        return 'red' // need to be re-check again
    }
  }

  getTeacherClassStandard(item) {
    console.log("item dashboard data--------", item)
    return item.standard.class
  }


  getClassStartTimeFormatted(startTime) {

    console.log("startTime :", startTime)
    const sTime = moment(startTime, "hh:mm a");
    console.log("startTime By moment :", sTime)
    return sTime.format("hh:mm a")

  }

  getClassDuration(startTime, endTime) {

    const sTime = moment(startTime, "HH:mm");

    const eTime = moment(endTime, "HH:mm");

    var minutes = eTime.diff(sTime, 'minutes');
    console.log("minutes=======", minutes)

    //return minutes
    if (minutes >= 60) {
      var hr = minutes / 60
      var min = minutes % 60

      if (min == 0) {
        return Math.floor(hr) + 'hr'
      }
      else {
        return Math.floor(hr) + " hr " + min + " min"
      }

    }
    else {

      return minutes + " min"
    }
  }

  // method to class continue
  continueStartClass() {
    Linking.openURL('http://idutor.com')
    this.setState({ showStartClassDialog: !this.state.showStartClassDialog })
  }

  cancelStartClass(item) {
    //NavigationService.navigate('RescheduleClassScreen',{ fromWhere: 'DashboardScreen', classData:item })
    console.log('class status : ', 'Cancelled clicked')
    if (item) {
      const data = ({
        ...item,
        classStatus: 5
      })

      if (this.state.showStartClassDialog) {
        this.setState({ showStartClassDialog: !this.state.showStartClassDialog })
      }

      this.props.rescheduleClass(data)

    }
    else {
      console.log('class status  item : ', item)
    }

  }


  performClickOnClassSataus(classStatusId, item) {
    //1=COMPLETD, 2=ONGOING, 3=UPCOMING 4=MISSED 5=CANCELLED 6=STARTED
    switch (classStatusId) {
      case 1:
        {
          cconsole.log('class status : ', 'Completed')
        }


      case 2:
        {
          this.showDialogtoStartClass(item)
        }



      case 3:
        {
          this.showDialogToRescheduleClass(item)
        }



      case 5:
        {
          console.log("what ststus invoked --------", classStatusId)
          //this.cancelStartClass(item)
        }



      default:
        {

          console.log("what ststus invoked --------", classStatusId)
        }

    }

  }

  showDialogtoStartClass(item) {
    this.setState({ showStartClassDialog: true, teacherClassSelected: item, })
  }


  showDialogToRescheduleClass(item) {
    // reschedule class
    console.log('class status : ', 'Reschedule clicked')
    NavigationService.navigate('RescheduleClassScreen', { fromWhere: 'ClassDetailScreen', classData: item, courseData: this.props.navigation.state.params.courseData })
  }


  handleTeacherSearchText = (text) => {
    this.setState({ teacherSearchText: text })
    this.props.getTeacherClassesDataFilter(text)
  }

  showQRCodeScanner() {
    if (!this.state.showQr1) {
      this.setState({ showQr1: true })
    }
  }

  saveQRCode() {
    this.svg.toDataURL(this.callback)
  }

  callback(dataURL) {
    let shareImageBase64 = {
      title: 'React Native',
      url: `data:image/png;base64,${dataURL}`,
      subject: 'Share Link',
    }

    Share.open(shareImageBase64).catch(error => console.log(error))
  }

  downloadQRCode = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        {
          title: 'Cool Photo App Camera Permission',
          message:
            'Cool Photo App needs access to your camera ' +
            'so you can take awesome pictures.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      )
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.svg.toDataURL(data => {
          RNFS.writeFile(
            RNFS.CachesDirectoryPath + '/some-name.png',
            data,
            'base64',
          )
            .then(success => {
              return CameraRoll.save(
                RNFS.CachesDirectoryPath + '/some-name.png',
                'photo',
              )
            })
            .then(() => {
              ToastAndroid.show('Saved to gallery !!', ToastAndroid.SHORT)
            })
        })
      } else {
        console.log('Camera permission denied')
      }
    } catch (err) {
      console.warn(err)
    }
  }

  async getUserProfileImage() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    let id = this.props.prof.profData &&
      this.props.prof.profData.data &&
      this.props.prof.profData.data.imageId
    //let id = item.course.imageId;
    console.log("imageId ========", id)
    fetch(`https://api.idutor.tk/api/file-blobs/getImage/${id}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let imageData = this.state.imageData || {};
      imageData[id] = resposne.data;
      this.setState(imageData);
      console.log('image datadata', imageData)
      this.setState({ imageData: imageData, })
    }).
      catch((error) => {
        console.log("#error", error);
      })

    console.log("ImageData=============", this.state.imageData)


  }

  cancelClassCall(item)
  {
    const data = ({...item, 
      classStatus: 5
     })
     
  this.props.MyClassesClassCancelCall(data)

  }
  render() {
    return (

      <View style={{ backgroundColor: 'white', flex: 1 }}>

        <Modal
          isVisible={this.state.showQr1}
          animationType='fade'
          transparent={true}
          backdropColor={'rgba(0,0,0,0.35)'}
          backdropOpacity={1}
          onBackdropPress={() => this.setState({ showQr1: false })}
          onRequestClose={() => {
            this.setState({ showQr1: false })
          }}>
          <View
            style={{
              marginBottom: 10,
              height: heightPercentageToDP('60%'),
              width: widthPercentageToDP('90%'),
              backgroundColor: 'white',
              marginTop: 80,
            }}>
            <View
              style={{
                backgroundColor: 'white',
                width: 130,
                height: 130,
                borderRadius: 70,
                alignSelf: 'center',
                position: 'absolute',
                top: -70,
                justifyContent: 'center',
                borderWidth: 1,
              }}>

              {this.props.prof.profData && this.state.teacherListIamgeData[0]?.content ? (
                <Image
                  style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: 70,
                    alignSelf: 'center',
                  }}
                  source={{
                    uri: `data:image/jpeg;base64,${this.props.prof.profData &&
                      this.props.prof.profData.data && this.props.prof.profData.data.image &&
                      this.state.teacherListIamgeData[0]?.content}`,
                  }}
                />
              ) : (
                <Image
                  style={{ width: 125, height: 125, alignSelf: 'center' }}
                  source={images.male}
                />
              )}
            </View>
            <TouchableOpacity
              style={{ position: 'relative', left: 310, marginTop: 10 }}
              onPress={() => this.setState({ showQr1: false })}>
              <Image resizeMode='contain' source={images.drawerclose} />
            </TouchableOpacity>
            <View style={{ marginTop: 40 }}>
              <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>

                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.firstName}
                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.lastName}
              </Text>
              <Text
                style={{
                  textAlign: 'center',
                  color: '#888888',
                  fontStyle: 'italic',
                }}>

                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.experienceInYear}
                yr,
                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.qualifications &&
                  this.props.prof.profData.data.qualifications.map(
                    item => item.qualification,
                  )}
              </Text>
              <View style={{ alignSelf: 'center', margin: 10 }}>
                <QRCode
                  value={`{id: ${this.props.prof.profData && this.props.prof.profData.data &&
                    this.props.prof.profData.data.id},name: ${this.props.prof
                      .profData && this.props.prof.profData.data && this.props.prof.profData.data.firstName}}`}
                  size={200}
                  getRef={c => (this.svg = c)}
                />
              </View>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  marginBottom: 5,
                  alignSelf: 'center',
                  marginTop: 10,
                  backgroundColor: '#1976D2',
                  borderRadius: 35,
                  width: widthPercentageToDP('32%'),
                  textAlign: 'center',
                  height: 50,
                }}
                onPress={() => this.saveQRCode()}>
                <Image
                  resizeMode='contain'
                  source={images.share_list}
                  style={{ alignSelf: 'center', marginLeft: 20 }}
                />
                <Text
                  style={{
                    fontSize: 20,
                    marginLeft: 10,
                    color: 'white',
                    alignSelf: 'center',
                  }}>
                  Share
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  marginTop: 10,
                }}
                onPress={() => this.downloadQRCode()}>
                <Image
                  resizeMode='contain'
                  source={images.download}
                  style={{ alignSelf: 'center' }}
                />
                <Text style={{ marginLeft: 10 }}> Save to Photos </Text>
              </TouchableOpacity>
            </View>
          </View>
          {this.state.canceltext == false ? (
            <View
              style={{
                elevation: 10,
                backgroundColor: 'white',
                marginBottom: 10,
                borderRadius: 10,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  paddingTop: 10,
                  paddingBottom: 10,
                }}>
                <Image
                  style={{
                    width: 20,
                    height: 20,
                    marginLeft: 20,
                    alignSelf: 'center',
                  }}
                  source={images.info}
                />
                <View style={{ width: '80%', alignContent: "flex-start" }}>
                  <Text
                    style={{
                      fontWeight: 'bold',
                      color: appheadertextColor,
                      fontSize: 12,
                    }}>
                    Did you know ?
                  </Text>
                  <Text
                    numberOfLines={4}
                    style={{ fontSize: 10, color: appheadertextColor }}>
                    You can invite your students directly to your profile on
                    idutor by sharing your QR code with them.idutor does not
                    charge any convenience fee for students enrolled to your
                    courses using your QR code.
                  </Text>
                </View>
              </View>
            </View>
          ) : null}
        </Modal>

        {this.props.selctType.typeselectedData.logintype == "Student" ? <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();

              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />

          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

            <TouchableOpacity
              onPress={() => {
                this.setState({
                  filterpopup: true
                })
              }}
            >
              <Icon1 style={{ marginLeft: 15 }} name="bell-o" size={20} color="black" /></TouchableOpacity>
          </View>
        </View> :

          <View><View style={{ flexDirection: 'row', backgroundColor: 'white', height: 100, justifyContent: 'space-between', elevation: 10 }}>
            <View style={{ marginTop: 15 }} >
              <TouchableOpacity
                onPress={() => {
                  this.props.navigation.goBack();

                }}
              >
                <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

              </TouchableOpacity>
            </View>
            <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />

            <TouchableOpacity
              onPress={() => {
                this.setState({ filterpopup: true })
              }}
            >
              <Icon1 style={{ marginTop: 15, alignContent: 'flex-end', marginRight: 10 }} name="bell-o" size={20} color={'black'} />
            </TouchableOpacity>
          </View>

            <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
              <View style={[Styles.searchinput,]}>

                <View style={Styles.searchbackground} />
                <View style={{ flexDirection: 'row', }}>
                  <Icon1 style={{ marginLeft: 10, alignSelf: 'center' }} name="search" size={15} color="gray" />

                  {/* <Text style={{
                    color: 'gray', flex: 1, height: 50, textAlignVertical: 'center',
                    alignSelf: 'center',
                    zIndex: 1,
                    paddingLeft: 10,
                  }}>Search</Text> */}
                  {this.props.selctType.typeselectedData.logintype == 'Student' ? (
                    <TextInput
                      style={{
                        color: 'gray',
                        flex: 1,
                        height: 50,
                        textAlignVertical: 'center',
                        alignSelf: 'center',
                        zIndex: 1,
                        paddingLeft: 10,
                      }}
                      placeholder='Search Teacher/Courses'
                      onChangeText={this.setText}
                      defaultValue={this.state.selectedText}
                    />
                  ) : (
                    // <Text
                    //   style={{
                    //     color: 'gray',
                    //     flex: 1,
                    //     height: 50,
                    //     textAlignVertical: 'center',
                    //     alignSelf: 'center',
                    //     zIndex: 1,
                    //     paddingLeft: 10,
                    //   }}>
                    //   Search
                    // </Text>
                    <TextInput
                      style={{
                        color: 'gray',
                        flex: 1,
                        height: 50,
                        textAlignVertical: 'center',
                        alignSelf: 'center',
                        zIndex: 1,
                        paddingLeft: 10,
                      }}
                      placeholder='Search'
                      onChangeText={this.handleTeacherSearchText}

                    />
                  )}
                  <TouchableOpacity
                    style={{ alignContent: 'center', justifyContent: 'center', }}
                    onPress={() => {
                      //this.setState({ showQr1: true })
                      this.showQRCodeScanner()
                      console.log("QR code scanner clicked", "true")
                    }

                    }>
                    <Image
                      source={images.qrcode}
                      style={{ width: 18, height: 18, marginRight: 35, alignSelf: 'center' }}
                    />
                  </TouchableOpacity>

                </View>
              </View>
            </View>
          </View>}

        {this.props.selctType.typeselectedData.logintype == "Student" ? <ScrollView
          showsVerticalScrollIndicator={false}
          nestedScrollEnabled={true}
          style={styles.container}>

          {/* {(this.props.courseListData && this.props.courseListData.totalCount !== 0) ?
            <FlatList
              data={(this.props.courseListData && this.props.courseListData.data)}
              nestedScrollEnabled={true}
              renderItem={({ item }) =>
              (
                <View>

                  <TouchableOpacity
                    onPress={() => {
                      NavigationService.navigate('ClassDetailScreen', { id: item })
                    }}
                  >
                    <View style={{

                      paddingRight: 5,
                      paddingLeft: 5,
                      marginTop: 10,
                      justifyContent: 'center', alignItems: 'center',
                    }}>
                      {console.log('params.id and item.id',item)}
                      {params1.id === item.courseClass.course.id && <View style={styles.labelContainer}>

                        <View style={{ flexDirection: 'row' }}>

                          {(this?.props?.imagewithoutloopData?.data) ? <Image style={Styles.calimage}
                            source={{ uri: `data:image/jpeg;base64,${this?.props?.imagewithoutloopData?.data?.content}` }}
                          /> : <View style={Styles.calimage}>
                              <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                            </View>}


                          <View style={{ width: '80%' }}>
                            <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>{item && item.courseClass && item.courseClass?.course?.name} Class-{item && item.course_id && item.courseClass?.course?.standard.class}</Text>

                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                              <View>
                                <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item && item.teacher?.firstName} {' '}{item && item.teacher?.lastName}{' '}{item && item.teacherDetails && item.teacherDetails.experienceInYear}yr</Text>
                              </View>

                            </View>
                            <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                            <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 5 }}>TIMING (START FROM {item && item.courseClass?.course?.createdDate && moment(item && item.courseClass?.course?.createdDate).format('DD-MM-YYYY')})</Text>
                            <View style={{ flexDirection: 'row', marginRight: 20, justifyContent: 'space-between' }}>
                              <Text style={{ fontSize: 10, marginLeft: 10, color: loginheaderColor }}>{moment(item.courseClass?.endTime).format('hh:mm A')}</Text>
                            </View>

                          </View>
                        </View>
                      </View>}
                    </View>
                  </TouchableOpacity>
                </View>)

              }

            /> :
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', margin: 20 }}>
              <Text>No Classes found for this course</Text>
            </View>} */}
          <Text style={{ margin: 10 }}>Upcoming Class</Text>
          {this.props.courseListData.data.map((item) => {
            return (
              params1.id === item.courseClass.course.id && <View style={{ justifyContent: 'center', marginRight: 10, marginLeft: 10 }}>
                <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10, paddingBottom: 10 }}>

                  <View style={{ flexDirection: 'row', marginLeft: 10, marginRight: 10 }}>
                    {(this?.props?.imagewithoutloopData?.data) ? <Image style={Styles.calimage}
                      source={{ uri: `data:image/jpeg;base64,${this?.props?.imagewithoutloopData?.data?.content}` }}
                    /> : <View style={Styles.calimage}>
                      <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                    </View>}

                    <View style={{ marginLeft: 10, marginTop: 5 }}>
                      <Text style={{ fontWeight: 'bold', fontSize: 13, }}>{item.courseClass?.course?.name}{' '}
                  Class-{item.courseClass?.course?.standard.class}
                      </Text>
                      {item.teacher && <Text style={{ fontSize: 12, fontStyle: 'italic' }}>{'By'} {item.teacher?.firstName} {item.teacher?.lastName}</Text>}
                    </View>

                    <View style={{ position: 'absolute', right: 0, alignSelf: 'center' }}>
                      <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(item.courseClass?.course?.createdDate).format('DD-MM-YYYY')}</Text>
                      <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{item.courseClass?.endTime}</Text>
                      {<TouchableOpacity onPress={() => { this.checkJoinClass(), this.setState({ checkClass: true }) }}>
                        <Text style={{ marginBottom: 5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: loginheaderColor, borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>Join Class</Text>
                      </TouchableOpacity>}
                    </View>

                  </View >

                </View>
              </View >)
          })}
          <Text style={{ margin: 10 }}>Previous Class</Text>
          {this.props.courseListData.data.map((item) => {
            return (
              params1.id === item.courseClass.course.id && item.classStatus === 4 && <View style={{ justifyContent: 'center', marginRight: 10, marginLeft: 10 }}>

                <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10, paddingBottom: 10 }}>

                  <View style={{ flexDirection: 'row', marginLeft: 10, marginRight: 10 }}>
                    {(this?.props?.imagewithoutloopData?.data) ? <Image style={Styles.calimage}
                      source={{ uri: `data:image/jpeg;base64,${this?.props?.imagewithoutloopData?.data?.content}` }}
                    /> : <View style={Styles.calimage}>
                      <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                    </View>}

                    <View style={{ marginLeft: 10, alignSelf: 'center' }}>
                      <Text style={{ fontWeight: 'bold', fontSize: 13, }}>{item?.courseClass?.course?.name} class-{item?.courseClass?.course?.standard?.class}</Text>
                      {item.teacher && <Text style={{ fontSize: 12, fontStyle: 'italic' }}>By {item?.teacher?.firstName} {item?.teacher?.lastName}</Text>
                      }
                      <TouchableOpacity
                        onPress={() => {
                          this.props.navigation.navigate('ReqRecordingScreen', { id: params1.id });

                        }}
                      >
                        <Text style={{ fontSize: 12, color: 'green', fontWeight: 'bold' }}>Request Recording</Text>
                      </TouchableOpacity>
                    </View>

                    <View style={{ position: 'absolute', right: 0, alignSelf: 'center' }}>
                      <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(item?.courseClass?.course?.createdDate).format('DD-MM-YYYY')}</Text>
                      <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{item?.courseClass?.endTime}</Text>
                      <Text style={{ fontSize: 12, color: apppinkColor, fontWeight: 'bold' }}>Missed</Text>
                    </View>
                  </View >

                </View>
              </View >)
          })}


          {this.props.courseListData.data.map((item) => {
            return (
              params1.id === item.courseClass.course.id && item.classStatus === 1 && <View style={{ justifyContent: 'center', marginRight: 10, marginLeft: 10 }}>

                <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10, paddingBottom: 10 }}>

                  <View style={{ flexDirection: 'row', marginLeft: 10, marginRight: 10 }}>
                    {(this?.props?.imagewithoutloopData?.data) ? <Image style={Styles.calimage}
                      source={{ uri: `data:image/jpeg;base64,${this?.props?.imagewithoutloopData?.data?.content}` }}
                    /> : <View style={Styles.calimage}>
                      <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                    </View>}
                    <View style={{ marginLeft: 10, alignSelf: 'center' }}>
                      <Text style={{ fontWeight: 'bold', fontSize: 13, }}>{item.courseClass?.course?.name} class-{item.courseClass?.course?.standard?.class}</Text>
                      <Text style={{ fontSize: 12, fontStyle: 'italic' }}>By {item.teacher?.firstName} {item.teacher?.lastName}</Text>
                      <TouchableOpacity
                        onPress={() => {
                          this.props.navigation.navigate('ReqRecordingScreen', { id: params1?.id });

                        }}
                      >
                        <Text style={{ fontSize: 12, color: '#FAA21C', fontWeight: 'bold' }}>Watch Recording</Text>
                      </TouchableOpacity>
                    </View>

                    <View style={{ position: 'absolute', right: 0, alignSelf: 'center' }}>
                      <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(item.courseClass?.course?.createdDate).format('DD-MM-YYYY')}</Text>
                      <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{item.courseClass?.endTime}</Text>
                      <Text style={{ fontSize: 12, color: '#36CE00', fontWeight: 'bold' }}>Attended</Text>
                    </View>
                  </View >

                </View>
              </View >)
          })}


          {/* {(params1?.id?.classStatus === 4 || params1?.id?.classStatus === 1) && <Text style={{ fontWeight: 'bold', fontSize: 14, marginLeft: 10, marginTop: 10 }}> Previous Classes </Text>}
          {params1?.id?.classStatus === 4 ? <View style={{ justifyContent: 'center', marginRight: 10, marginLeft: 10 }}>

            <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10, paddingBottom: 10 }}>

              <View style={{ flexDirection: 'row', marginLeft: 10, marginRight: 10 }}>
              { (this?.props?.imagewithoutloopData?.data)?<Image style={Styles.calimage}
                 source={{ uri: `data:image/jpeg;base64,${this?.props?.imagewithoutloopData?.data?.content}` }}
                />:<View style={Styles.calimage}>
                  <ActivityIndicator size='large' style={{marginTop:10}}/>
                  </View>} 
               
                <View style={{ marginLeft: 10, alignSelf: 'center' }}>
                  <Text style={{ fontWeight: 'bold', fontSize: 13, }}>{params1?.id?.courseClass?.course?.name} class-{params1?.id?.courseClass?.course?.standard?.class}</Text>
                  <Text style={{ fontSize: 12, fontStyle: 'italic' }}>By {params1?.id?.teacher?.firstName} {params1?.id?.teacher?.lastName}</Text>
                  <TouchableOpacity
                    onPress={() => {
                      this.props.navigation.navigate('ReqRecordingScreen', { id: params1.id });

                    }}
                  >
                    <Text style={{ fontSize: 12, color: 'green', fontWeight: 'bold' }}>Request Recording</Text>
                  </TouchableOpacity>
                </View>

                <View style={{ position: 'absolute', right: 0, alignSelf: 'center' }}>
                  <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(params1?.id?.courseClass?.course?.createdDate).format('DD-MM-YYYY')}</Text>
                  <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{params1?.id?.courseClass?.endTime}</Text>
                  <Text style={{ fontSize: 12, color: apppinkColor, fontWeight: 'bold' }}>Missed</Text>
                </View>
              </View >

            </View>
          </View > : <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', margin: 20 }}>
              <Text>No Previous Classes found for Missed Classes</Text>
            </View>}

          {params1.id && params1.id.classStatus == 1 ? <View style={{ justifyContent: 'center', marginRight: 10, marginLeft: 10 }}>

            <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10, paddingBottom: 10 }}>

              <View style={{ flexDirection: 'row', marginLeft: 10, marginRight: 10 }}>
               { (this?.props?.imagewithoutloopData?.data)?<Image style={Styles.calimage}
                 source={{ uri: `data:image/jpeg;base64,${this?.props?.imagewithoutloopData?.data?.content}` }}
                />:<View style={Styles.calimage}>
                  <ActivityIndicator size='large' style={{marginTop:10}}/>
                  </View>} 
                <View style={{ marginLeft: 10, alignSelf: 'center' }}>
                  <Text style={{ fontWeight: 'bold', fontSize: 13, }}>{params1?.id?.courseClass?.course?.name} class-{params1?.id?.courseClass?.course?.standard?.class}</Text>
                  <Text style={{ fontSize: 12, fontStyle: 'italic' }}>By {params1?.id?.teacher?.firstName} {params1?.id?.teacher?.lastName}</Text>
                  <TouchableOpacity
                    onPress={() => {
                      this.props.navigation.navigate('ReqRecordingScreen', { id: params1?.id });

                    }}
                  >
                    <Text style={{ fontSize: 12, color: '#FAA21C', fontWeight: 'bold' }}>Watch Recording</Text>
                  </TouchableOpacity>
                </View>

                <View style={{ position: 'absolute', right: 0, alignSelf: 'center' }}>
                  <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(params1?.id?.courseClass?.course?.createdDate).format('DD-MM-YYYY')}</Text>
                  <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{params1?.id?.courseClass?.endTime}</Text>
                  <Text style={{ fontSize: 12, color: '#36CE00', fontWeight: 'bold' }}>Attended</Text>
                </View>
              </View >

            </View>
          </View >
            : <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', margin: 20 }}>
              <Text>No Previous Classes found for Attended Classes</Text>
            </View>} */}
          {/* }
          /> */}
        </ScrollView >
          :

          (
            <>
              <ScrollView>
                <View style={{ marginBottom: 10 }}>



                  <View>
                    <Text style={{ fontWeight: 'bold', fontSize: 14, marginTop: 20, }}>{(this.props.navigation.state.params && this.props.navigation.state.params.courseData && !isEmpty(this.props.navigation.state.params.courseData.courseClasses)) ? "Upcoming Classes" : "No Upcoming Classes"} </Text>
                  </View>
                  {this.state.showLoader ? (<View style={{ margin: 10, }}>
                    <ActivityIndicator />
                  </View>
                  ) : null}
                  {/* <View>
        {this.setState({showLoader:false,})}
        </View> */}
                  {this.props.navigation.state.params.courseData && !isEmpty(this.props.navigation.state.params.courseData.courseClasses) && (
                    <View>

                      <SafeAreaView style={{ marginTop: 20 }}>
                        <FlatList
                          data={this.props.navigation.state.params.courseData && this.props.navigation.state.params.courseData.courseClasses}
                          nestedScrollEnabled={true}
                          onEndReached={this._handleLoadMore}
                          onEndReachedThreshold={0.01}
                          renderItem={({ item }) => (

                            <View style={{ justifyContent: 'center', marginLeft: 10, marginRight: 10 }}>

                              <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10 }}>
                                <TouchableOpacity>
                                  <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>

                                    {
                                      isEmpty(this.state.teacherListIamgeData[this.props.navigation.state.params.courseData?.image?.id]?.content)
                                        ?
                                        <Image style={Styles.calimage}
                                          source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                                        // source={{ uri:`data:image/jpeg;base64,${this.state.teacherListIamgeData[item.course.imageId]?.content}`,  }} 
                                        />
                                        :
                                        <Image
                                          resizeMode={'contain'}
                                          style={{
                                            width: widthPercentageToDP('18%'),
                                            borderRadius: 10,
                                            marginHorizontal: 2,
                                            marginVertical: 10,
                                          }}
                                          //source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}

                                          source={{ uri: `data:image/jpeg;base64,${this.state.teacherListIamgeData[this.props.navigation.state.params.courseData?.image?.id]?.content}`, }}
                                        />
                                    }

                                    {/* <Image style={Styles.calimage}
                   source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                 /> */}
                                    <View style={{ flexDirection: 'row', flex: 1, justifyContent: 'space-between', marginLeft: 5, marginRight: 5, marginTop: 10, padding: 10 }}>
                                      <View style={{ alignContent: 'flex-start', flex: 2, }}>
                                        <Text style={{ fontWeight: 'bold', fontSize: 13, textAlign: 'justify' }}>{this.props.navigation.state.params.courseData && this.props.navigation.state.params.courseData.name} class {'10th'}</Text>
                                        <Text style={{ fontSize: 12, fontStyle: 'italic', textAlign: 'left' }}> {item.topicsCovered}</Text>
                                        <Text style={{ fontSize: 12, alignSelf: 'flex-start' }}>{this.getClassStartTimeFormatted(item.startTime)} to {this.getClassStartTimeFormatted(item.endTime)} ({this.getClassDuration(item.startTime, item.endTime)})</Text>
                                      </View>

                                      <View style={{ flex: 1, }}>
                                        <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(item.date).utc().format("DD , MMM")}</Text>

                                        <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{this.getClassStartTimeFormatted(item.startTime)}</Text>
                                        {/* <TouchableOpacity

                                          onPress={() => this.performClickOnClassSataus(item.classStatus, item)}>
                                          <Text style={{ marginBottom: 5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: this.getClassStatusTextBgColor(item.classStatus, item), borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>{this.getClassStatusText(item.classStatus, item)}</Text>
                                        </TouchableOpacity> */}
                                      </View>

                                    </View>
                                  </View >
<<<<<<< HEAD
                                  <View style={{flexDirection:'row',alignSelf:'flex-end',marginRight:10, justifyContent:'space-evenly', alignContent:'flex-end' , marginStart: 50 ,marginBottom:10,}}>
                    {
                                 this.showCancelButton(item)? <TouchableOpacity
                                 style={{marginHorizontal:10}}
                                 onPress={() => this.cancelClassCall(item)}>
                                 <Text style={{ marginBottom: 5, color: 'white', marginTop: 10, backgroundColor: 'red', borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>Cancel</Text>
                               </TouchableOpacity>
                               : null

                                }
                                
                               <TouchableOpacity
                                    onPress={() => this.performClickOnClassSataus(item.classStatus, item)}>
                                    <Text style={{ marginBottom: 5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: this.getClassStatusTextBgColor(item.classStatus, item), borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>{this.getClassStatusText(item.classStatus, item)}</Text>
                                  </TouchableOpacity> 
                                </View> 
=======
                                  <View style={{ flexDirection: 'row', alignSelf: 'flex-end', marginRight: 10, justifyContent: 'space-evenly', alignContent: 'flex-end', marginStart: 50, marginBottom: 10, }}>
                                    {
                                      this.showCancelButton(item) ? <TouchableOpacity
                                        style={{ marginHorizontal: 10 }}
                                        onPress={() => this.performClickOnClassSataus(item.classStatus, item)}>
                                        <Text style={{ marginBottom: 5, color: 'white', marginTop: 10, backgroundColor: 'red', borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>Cancel</Text>
                                      </TouchableOpacity>
                                        : null

                                    }

                                    <TouchableOpacity
                                      onPress={() => this.performClickOnClassSataus(item.classStatus, item)}>
                                      <Text style={{ marginBottom: 5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: this.getClassStatusTextBgColor(item.classStatus, item), borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>{this.getClassStatusText(item.classStatus, item)}</Text>
                                    </TouchableOpacity>
                                  </View>
>>>>>>> eb140c3... Bug Fixes
                                </TouchableOpacity>
                              </View>
                            </View>
                          )}
                        />
                      </SafeAreaView>
                    </View>
                  )}

                </View>

              </ScrollView>
            </>
          )

          // <ScrollView>
          //   <View style={{ justifyContent: 'center', marginLeft: 10, marginRight: 10 }}>
          //     <Text>Upcoming Classes</Text>

          //     <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10, marginBottom: 10 }}>

          //       {console.log('claaaaaaaaaaaaaaaa', params.id.classStatus)}
          //       {params && params.id && params.id.classStatus === 2 ? <View style={{ flexDirection: 'row', justifyContent: 'space-evenly' }}>

          //         {params && params.id && params.id.course && params.id.course.image ? <Image

          //           source={{ isStatic: true, uri: `data:image/jpeg;base64,${params.id.course && params.id.course.image && params.id.course.image.content}` }}
          //           style={{
          //             width: widthPercentageToDP('22%'),
          //             borderRadius: 10,
          //           }}
          //         ></Image> : <Image style={Styles.calimage, { width: 80 }}
          //           source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
          //           />}

          //         <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginLeft: 5, marginRight: 5, marginTop: 10, padding: 10 }}>
          //           <View>
          //             <Text style={{ fontWeight: 'bold', fontSize: 13, }}>{params.id.course.name} class-{params.id.course.standard.class}</Text>
          //             <Text style={{ fontSize: 12, fontStyle: 'italic' }}>Class {params.id.title}</Text>
          //           </View>

          //           <View>
          //             <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(params.id.course.createdDate).format('DD_MM_YYYY')}</Text>
          //             <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{params.id.endTime}</Text>
          //             <Text style={{ marginBottom: 5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: loginheaderColor, borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>Start Class</Text>
          //           </View>
          //         </View>
          //       </View >:

          //     <View><Text style={{alignSelf:'center'}}>Classes is not Active</Text></View>}

          //       {params && params.id && params.id.classStatus === 3 ? 

          //       <TouchableOpacity onPress={() => { 
          //         NavigationService.navigate('RescheduleClassScreen' , {
          //           fromWhere: 'ClassDetailScreen',
          //           classData: params.id,
          //         }) }}>
          //         <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10 }}>
          //           <View style={{ flexDirection: 'row', justifyContent: 'space-evenly' }}>

          //             {params && params.id && params.id.course && params.id.course.image ? <Image

          //               source={{ isStatic: true, uri: `data:image/jpeg;base64,${params.id.course && params.id.course.image && params.id.course.image.content}` }}
          //               style={{
          //                 width: widthPercentageToDP('22%'),
          //                 borderRadius: 10,
          //               }}
          //             ></Image> : <Image style={Styles.calimage, { width: 80 }}
          //               source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
          //               />}
          //             <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginLeft: 5, marginRight: 5, marginTop: 10, padding: 10 }}>

          //               <View>
          //                 <Text style={{ fontWeight: 'bold', fontSize: 13, }}>{params.id.course.name} class-{params.id.course.standard.class}</Text>
          //                 <Text style={{ fontSize: 12, color: '#1976D2' }}>{params.id.title}</Text>
          //               </View>

          //               <View>
          //                 <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(params.id.course.createdDate).format('DD_MM_YYYY')}</Text>
          //                 <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{params.id.endTime}</Text>
          //                 <Text style={{ marginBottom: 5, color: 'white', alignSelf: 'flex-end', marginTop: 10, backgroundColor: "#1976D2", borderRadius: 20, paddingLeft: 10, paddingRight: 10, paddingBottom: 5, paddingTop: 5 }}>Reschedule</Text>

          //               </View>
          //             </View>
          //           </View >

          //         </View>
          //       </TouchableOpacity>:


          //       <View><Text style={{alignSelf:'center'}}>Classes is not Reschedule</Text></View>}

          //     </View>
          //   </View>
          // </ScrollView>

        }
        {/* <JitsiCallModal
          modalVisible={this.state.modalVisible}
          opneModal={this.opneModal}

        /> */}
      </View >
    )
  }

}

const mapStateToProps = state => ({
  prof: state.prof,
  selctType: state.selctType,
  courseData: state.dash.courseData,
  classesForCourseData: state.dash.fetchClassesForCourseData,
  teacherFilteredClassesDataProps: state.dash.teacherFilteredClassesData,
  imagewithoutloopData: state.dash.imagewithoutloopData,
  courseListData: state.dash.courseListData,
  // rescheduleClassDataProps : state.dash.rescheduleClassData,
  cancelClassApiData: state.dash.myClassesClassCancelDataData
});

const mapDispatchToProps = {
  fetchClassesForCourse, getTeacherClassesDataFilter, imageWithoutLoopLoad, getClassesData,
  MyClassesClassCancelCall,
  //rescheduleClass,
};

export default connect(mapStateToProps, mapDispatchToProps)(ClassDetailScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
