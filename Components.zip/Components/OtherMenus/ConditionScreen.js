import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity, TouchableWithoutFeedback, Dimensions,
  FlatList, Alert, TextInput, ToastAndroid, Image
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import Topbar from '../../Common/MenuBar'
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import * as EnquiryAPI from '../../Services/enquiryAPIs';
import { connect } from 'react-redux';
import Moment from 'moment';
import Loader from '../../Common/Loader';
import TextField from '../../Common/TextInput';
import _ from "lodash";
import { heightPercentageToDP } from 'react-native-responsive-screen';
import { appbluebtnColor, appblueColor, appgrayColor, loginheaderColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import Modal from "react-native-modal";
import { Checkbox } from 'react-native-paper';
import NavigationService from '../../Services/NavigationService';
import HTML from 'react-native-render-html';
import { baseURL } from '../../util/AppConstants';

import { getTerms } from '../../actions';

class ConditionScreen extends Component {

  constructor(props) {
    super(props);
    
    this.state = {
      title: '', desc: '',
      showLoader: false,
      showPopup: false,
      canceltext: '',
      _id: '',
      profileImage:{},

      searchList: [{
        'q': "Question 1. sample question will be here",
        'ans': 'Sample explained answer will be here please check in detailed manner.....',
      },
      {
        'q': "Question 2. sample question will be here",
        'ans': 'Sample explained answer will be here .....',
      },
      {
        'q': "Question 3. sample question will be here",
        'ans': 'Sample explained answer will be here .....',
      },
      {
        'q': "Question 4. sample question will be here",
        'ans': 'Sample explained answer will be here .....',
      }]
    }
  }
  params = this.props.navigation.state.params
  componentDidUpdate(prevProps) {
    console.log("terms COMPONENT DID UPDATE CALLED", this.props);
    if (this.props.terms != null) {
      if (this.props.terms != prevProps.terms) {

        console.log("terms COMPONENT DID UPDATE CALLED" + JSON.stringify(this.props.faqq),this.props.faqq && this.props.faqq.faqData && this.props.faqq.faqData);
        this.setState({
          title: this.props.terms && this.props.terms.termsData && this.props.terms.termsData.data && this.props.terms.termsData.data.name,
          desc: this.props.terms && this.props.terms.termsData && this.props.terms.termsData.data && this.props.terms.termsData.data.content
        })
      }
    }

  }
  async componentDidMount() {
    const { getTerms } = this.props;
    this.props.navigation.state.params.screen === 'privacy' ? await getTerms('privacy') : await getTerms('terms');

    let AuthToken = await AsyncStorage.getItem('id_token');
    let id = this.props.prof?.profData?.data?.imageId;
    fetch(`${baseURL}file-blobs/getImage/${id}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let profileImage = this.state.profileImage || {};
      profileImage[resposne.data.id] = resposne.data;
      this.setState(profileImage);
    }).
      catch((error) => {
        console.log("#error", error);
      })
  }

  showAlert(text) {
    Alert.alert('Error', text, [
      {
        text: 'OK'
      }
    ]);
  }
  _handleLoadMore = () => {

  }


  render() {
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>

        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();

              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />

          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

            <TouchableOpacity
              onPress={() => {

              }}
            >
              <Icon1 style={{ marginLeft: 15,marginTop:15 }} name="bell-o" size={20} color="black" /></TouchableOpacity>
              <TouchableOpacity onPress={()=>NavigationService.navigate('ProfileScreen')}>
              {(this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content) ?<Image
              resizeMode='contain'
                source={{uri:`data:image/jpeg;base64,${this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content}`}}
                style={{ width: 25, height: 25, marginLeft:5,marginRight:20,marginTop:15,borderWidth:1}}
              /> :<View style={{
                width: 25,
                height: 25,
                marginLeft: 5,
                marginRight: 20,
                marginTop: 15,
                borderWidth: 1
              }}><ActivityIndicator size='small'/></View>}
              </TouchableOpacity>
          </View>
        </View>

        <Text style={{ fontWeight: 'bold', marginLeft: 10, marginTop: 10, }}>{this.state.title}</Text>
        <ScrollView style={{ flex: 1, marginLeft: 10, marginTop: 10, marginRight: 10 }}>
          <View style={{ justifyContent: 'center', }}>
            <HTML html={this.state.desc} imagesMaxWidth={Dimensions.get('window').width} />
          </View>
        </ScrollView>
      </View >
    )
  }

}

const mapStateToProps = state => ({
  terms: state.terms,
  prof: state.prof,
});
const mapDispatchToProps = {
  getTerms,
};
export default connect(mapStateToProps, mapDispatchToProps)(ConditionScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',

    width: '98%',

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
