import { Modal, Text, View } from 'react-native';
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
// import JitsiMeet, { JitsiMeetView } from 'react-native-jitsi-meet';
// import { isEmpty } from 'lodash';


function JitsiCallModal(props) {
    const { modalVisible, opneModal, url } = props;
    const [showJitsi, setShowJitsi] = useState(true);

    useEffect(() => {
        if (modalVisible) {
            setTimeout(() => {
                const url = 'https://meet.idutor.tk/BroadFilmMakersElevateAmazingly';
                const userInfo = { displayName: 'User', email: 'user@example.com', avatar: 'https:/gravatar.com/avatar/abc123' };
                JitsiMeet.call(url, userInfo);
                /* You can also use JitsiMeet.audioCall(url) for audio only call */
                /* You can programmatically end the call with JitsiMeet.endCall() */
            }, 1000);
        }
    }, [modalVisible])

    const onConferenceTerminated = (nativeEvent) => {
        /* Conference terminated event */
        // opneModal();
    }

    const onConferenceJoined = (nativeEvent) => {
        /* Conference joined event */
        setShowJitsi(false);
        setTimeout(() => {
            setShowJitsi(true)
        }, 100)
    }

    const onConferenceWillJoin = (nativeEvent) => {
        /* Conference will join event */
    }

    const handleClose=()=>{
        // JitsiMeet.endCall();
        // opneModal();
    }

    return (
        <Modal
            visible={modalVisible}
            animationType={'slide'}
            onRequestClose={()=>{}}
            transparent={true}>
            <View style={{ backgroundColor: 'black', flex: 1 }}>

                {showJitsi &&
                    <JitsiMeetView onConferenceTerminated={onConferenceTerminated}
                        onConferenceJoined={onConferenceJoined}
                        onConferenceWillJoin={onConferenceWillJoin}
                        style={{ flex: 1, height: '100%', width: '100%' }} />
                }
            </View>
        </Modal>
    );
}

JitsiCallModal.propTypes = {
    modalVisible: PropTypes.bool,
    opneModal: PropTypes.func,
    url: PropTypes.string,

};
JitsiCallModal.defaultProps = {
    modalVisible: false,
    opneModal: null,
    url: '',
};
export default JitsiCallModal;
