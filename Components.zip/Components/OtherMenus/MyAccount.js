import React, { Component } from 'react'
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity, TouchableWithoutFeedback,
    FlatList, Alert, ToastAndroid, Image, TextInput, SafeAreaView,
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP ,heightPercentageToDP } from '../../constants/styles'
import * as EnquiryAPI from '../../Services/enquiryAPIs';
import { connect } from 'react-redux';
import Loader from '../../Common/Loader';
import _ from "lodash";
import { appbluebtnColor, appblueColor, appgrayColor, apppinkColor, loginheaderColor , pdf  , excel , monthly, yearly , current , previous,} from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import NavigationService from '../../Services/NavigationService';
import {fetchAccountData,fetchTeacherMonthlyAccountData, fetchTeacherPreviousMonthlyAccountData} from '../../actions';
import {isNumber, isEmpty, now} from 'lodash';
import QRCodeScanner from 'react-native-qrcode-scanner'
import QRCode from 'react-native-qrcode-svg'
import Share from 'react-native-share'
import RNFS from 'react-native-fs'
import Modal from 'react-native-modal'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../../util/AppConstants';

class MyAccount extends Component {

    constructor(props) {
        super(props);
        this.state = {
            showDetails: false,
            filterpopup: false,
            accountData:'',
            courseList:[],
            accountMonthly:'',
            showPreviousMonthDetails:false,
            showQr1:false,
            teacherListIamgeData:[],

        }

        
    }

    showdetails = () => {
        this.setState({ showDetails: true })
    }

    hidedetails = () => {
        this.setState({ showDetails: false })
    }

    showPreviousdetails = () => {
        this.setState({ showPreviousMonthDetails: true })
    }

    hidePreviousdetails = () => {
        this.setState({ showPreviousMonthDetails: false })
    }


    componentDidMount()
    {
       
        const  months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var d = new Date();
var monthName=months[d.getMonth()];
console.log("current Month ========" , monthName)

        this.props.fetchTeacherMonthlyAccountData({
            month:''
        })
        this.props.fetchTeacherPreviousMonthlyAccountData({
            month:'prev',
        })


        this.getUserProfileImage()
    }


    getCurrentMonthData()
    {
        const  months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        var d = new Date();
        var monthName=months[d.getMonth()];

        console.log("current Month ========" , monthName)
        return monthName.slice(0,3)
    }


    getCurrentYear()
    {
        var d = new Date();
        var monthInt =  d.getMonth();
        var curentYear = d.getFullYear();
        return curentYear;

    }


    getPreviousMonthData()
    {
        const  months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        var d = new Date();
        var monthName=months[d.getMonth()-1];

        console.log("current Month ========" , monthName)
        return monthName.slice(0,3)
    }

    downloadMonthlyStatement()
    {

        const  months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        var d = new Date();
        var monthInt =  d.getMonth();
        var curentYear = d.getFullYear();

        console.log("current monthInt ========" , monthInt+1 , curentYear)

        const data ={
            type:monthly ,
            year:curentYear,
            month:monthInt+1,
            // page:0,
            // size:10,
            // sort:'ASC',
            export:'pdf'
            
    }
    this.props.fetchAccountData(data)
    }

    getShowDetailsText()
    {

        if(this.state.showPreviousMonthDetails)
        {
            return 'Hide Details for' + this.getPreviousMonthData() + this.getCurrentYear()
        }

        else{
            return 'Show Details for ' + this.getPreviousMonthData() + this.getCurrentYear()
        }
    }

    downloadYearlyStatement()
    {
        const  months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        var d = new Date();
        var monthInt =  d.getMonth();
        var curentYear = d.getFullYear();

        // for download monthly/yearly bill
        // const dataRequest ={
        //     export: pdf,
        //     type:  monthly ,
        //     year:'2021',
        //     month: 2,//current,
        //     page:0,
        //     size:10,
        //     sort:'ASC',
        // }

        const data ={
            type:yearly ,
            year:curentYear,
            // month:2,
            // page:0,
            // size:10,
            // sort:'ASC',
            export:'pdf'
            
    }
    this.props.fetchAccountData(data)
   
    }

    componentDidUpdate(prevProps)
    {

        if(prevProps.fetchAccountDetailsData != this.props.fetchAccountDetailsData)
        {
          if(this.props.fetchAccountDetailsData !=null &&  this.props.fetchAccountDetailsData.data)
          {
            console.log("account data : --------", this.props.fetchAccountDetailsData.data)
            // this.setState({accountData:this.props.fetchAccountDetailsData.data , 
            //     classList : this.props.fetchAccountDetailsData.data , })
        }
      }

      if(prevProps.fetchCurrentMonthAccountDetails != this.props.fetchCurrentMonthAccountDetails)
      {
        console.log("account  for current month : --------", this.props.fetchCurrentMonthAccountDetails)
        // this.setState({ accountMonthly: this.props.fetchCurrentMonthAccountDetails.data,
        //     classList : this.props.fetchCurrentMonthAccountDetails.data , })
      }

      if(prevProps.fetchPreviousMonthAccountDetails != this.props.fetchPreviousMonthAccountDetails)
      {
        console.log("account for previous month : --------", this.props.fetchPreviousMonthAccountDetails)
        // this.setState({ accountMonthly: this.props.fetchCurrentMonthAccountDetails.data,
        //     classList : this.props.fetchCurrentMonthAccountDetails.data , })
      }
        
    }

    showQRCodeScanner()
    {
        if(!this.state.showQr1)
        {
            this.setState({showQr1 : true})
        }
    }

    saveQRCode()
    {
        this.svg.toDataURL(this.callback)
    }

    callback(dataURL) {
        let shareImageBase64 = {
          title: 'React Native',
          url: `data:image/png;base64,${dataURL}`,
          subject: 'Share Link',
        }
    
        Share.open(shareImageBase64).catch(error => console.log(error))
      }

      downloadQRCode = async () => {
        try {
          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
            {
              title: 'Cool Photo App Camera Permission',
              message:
                'Cool Photo App needs access to your camera ' +
                'so you can take awesome pictures.',
              buttonNeutral: 'Ask Me Later',
              buttonNegative: 'Cancel',
              buttonPositive: 'OK',
            },
          )
          if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            this.svg.toDataURL(data => {
              RNFS.writeFile(
                RNFS.CachesDirectoryPath + '/some-name.png',
                data,
                'base64',
              )
                .then(success => {
                  return CameraRoll.save(
                    RNFS.CachesDirectoryPath + '/some-name.png',
                    'photo',
                  )
                })
                .then(() => {
                  ToastAndroid.show('Saved to gallery !!', ToastAndroid.SHORT)
                })
            })
          } else {
            console.log('Camera permission denied')
          }
        } catch (err) {
          console.warn(err)
        }
      }

     async getUserProfileImage()
      {
        let AuthToken = await AsyncStorage.getItem('id_token');
        let id = this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.imageId
        //let id = item.course.imageId;
        console.log("imageId ========", id)
        fetch(`${baseURL}file-blobs/getImage/${id}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${AuthToken}`,
         }
        }).then(data => {
          return data.json()
        }).then(resposne => {
          let imageData = this.state.teacherListIamgeData || {};
          imageData[id] = resposne.data;
          this.setState(imageData);
          console.log('image datadata',imageData)
          this.setState({teacherListIamgeData : imageData, })
        }).
          catch((error) => {
            console.log("#error", error);
          })

        console.log("ImageData=============", this.state.teacherListIamgeData)
    
  
      }
    
    render() {
        return (
            <View style={{ backgroundColor: 'white', flex: 1 }}>
               
               <Modal
          isVisible={this.state.showQr1}
          animationType='fade'
          transparent={true}
          backdropColor={'rgba(0,0,0,0.35)'}
          backdropOpacity={1}
          onBackdropPress={() => this.setState({ showQr1: false })}
          onRequestClose={() => {
            this.setState({ showQr1: false })
          }}>
          <View
            style={{
              marginBottom: 10,
              height: heightPercentageToDP('60%'),
              width: widthPercentageToDP('90%'),
              backgroundColor: 'white',
              marginTop: 80,
            }}>
            <View
              style={{
                backgroundColor: 'white',
                width: 130,
                height: 130,
                borderRadius: 70,
                alignSelf: 'center',
                position: 'absolute',
                top: -70,
                justifyContent: 'center',
                borderWidth: 1,
              }}>

              {this.props.prof.profData  && this.state.teacherListIamgeData[0]?.content? (
                <Image
                  style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: 70,
                    alignSelf: 'center',
                  }}
                  source={{
                    uri: `data:image/jpeg;base64,${this.props.prof.profData &&
                      this.props.prof.profData.data && this.props.prof.profData.data.image &&
                      this.state.teacherListIamgeData[0]?.content}`,
                  }}
                />
              ) : (
                  <Image
                    style={{ width: 125, height: 125, alignSelf: 'center' }}
                    source={images.male}
                  />
                )}
            </View>
            <TouchableOpacity
              style={{ position: 'relative', left: 310, marginTop: 10 }}
              onPress={() => this.setState({ showQr1: false })}>
              <Image resizeMode='contain' source={images.drawerclose} />
            </TouchableOpacity>
            <View style={{ marginTop: 40 }}>
              <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>

                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.firstName}
                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.lastName}
              </Text>
              <Text
                style={{
                  textAlign: 'center',
                  color: '#888888',
                  fontStyle: 'italic',
                }}>

                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.experienceInYear}
                yr,
                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.qualifications &&
                  this.props.prof.profData.data.qualifications.map(
                    item => item.qualification,
                  )}
              </Text>
              <View style={{ alignSelf: 'center', margin: 10 }}>
                <QRCode
                  value={`{id: ${this.props.prof.profData && this.props.prof.profData.data &&
                    this.props.prof.profData.data.id},name: ${this.props.prof
                      .profData && this.props.prof.profData.data && this.props.prof.profData.data.firstName}}`}
                  size={200}
                  getRef={c => (this.svg = c)}
                />
              </View>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  marginBottom: 5,
                  alignSelf: 'center',
                  marginTop: 10,
                  backgroundColor: '#1976D2',
                  borderRadius: 35,
                  width: widthPercentageToDP('32%'),
                  textAlign: 'center',
                  height: 50,
                }}
                onPress={() => this.saveQRCode()}>
                <Image
                  resizeMode='contain'
                  source={images.share_list}
                  style={{ alignSelf: 'center', marginLeft: 20 }}
                />
                <Text
                  style={{
                    fontSize: 20,
                    marginLeft: 10,
                    color: 'white',
                    alignSelf: 'center',
                  }}>
                  Share
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  marginTop: 10,
                }}
                onPress={() => this.downloadQRCode()}>
                <Image
                  resizeMode='contain'
                  source={images.download}
                  style={{ alignSelf: 'center' }}
                />
                <Text style={{ marginLeft: 10 }}> Save to Photos </Text>
              </TouchableOpacity>
            </View>
          </View>
          {this.state.canceltext == false ? (
            <View
              style={{
                elevation: 10,
                backgroundColor: 'white',
                marginBottom: 10,
                borderRadius: 10,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  paddingTop: 10,
                  paddingBottom: 10,
                }}>
                <Image
                  style={{
                    width: 20,
                    height: 20,
                    marginLeft: 20,
                    alignSelf: 'center',
                  }}
                  source={images.info}
                />
                <View style={{ width: '70%' }}>
                  <Text
                    style={{
                      fontWeight: 'bold',
                      color: appheadertextColor,
                      fontSize: 12,
                    }}>
                    Did you know ?
                  </Text>
                  <Text
                    numberOfLines={3}
                    style={{ fontSize: 10, color: appheadertextColor }}>
                    You can invite your students directly to your profile on
                    idutor by sharing your QR code with them.idutor does not
                    charge any convenience fee for students enrolled to your
                    courses using your QR code.
                  </Text>
                </View>
              </View>
            </View>
          ) : null}
        </Modal>


                    <View><View style={{ flexDirection: 'row', backgroundColor: 'white', height: 100, justifyContent: 'space-between', elevation: 10 }}>
                        <View style={{ marginTop: 15 }} >
                            <TouchableOpacity
                                onPress={() => {
                                    NavigationService.openDrawerr();
                                }}
                            >
                                <Image style={{ width: 20, height: 20, marginLeft: 10 }} source={images.menu} />
                            </TouchableOpacity>
                        </View>
                        <Image style={{ width: 90, height: 25, marginTop: 10 }} source={images.logo} resizeMode={'contain'} />

                        <TouchableOpacity
                            onPress={() => {
                                this.setState({ filterpopup: true })
                            }}
                        >
                            <Icon1 style={{ marginTop: 15, alignContent: 'flex-end', marginRight: 10 }} name="bell-o" size={20} color={'black'} />
                        </TouchableOpacity>
                    </View>

                        <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                            <View style={[Styles.searchinput,]}>

                                <View style={Styles.searchbackground} />
                                <View style={{ flexDirection: 'row', }}>
                                    <Icon1 style={{ marginLeft: 10, alignSelf: 'center' }} name="search" size={15} color="gray" />

                                    <Text style={{
                                        color: 'gray', flex: 1, height: 50, textAlignVertical: 'center',
                                        alignSelf: 'center',
                                        zIndex: 1,
                                        paddingLeft: 10,
                                    }}>Search</Text>
                                    <TouchableOpacity
                                    style={{alignContent:'center', justifyContent:'center'}}
                                    onPress={ ()=>{
 //this.setState({ showQr1: true })
 this.showQRCodeScanner()
 console.log("QR code scanner clicked", "true")
                                    }
                                       
                                    }>
                                     <Image
                                        source={images.qrcode}
                                        style={{ width: 18, height: 18, marginRight: 35, alignSelf: 'center' }}
                                    />
                                    </TouchableOpacity>
                                   

                                </View>
                            </View>
                        
                        </View>
                    </View>
<ScrollView style={{marginBottom:40 , paddingBottom:30}}>


                    <View style={{ flex: 1 }}>
                        <View style={{ marginLeft: 10, marginRight: 10, backgroundColor: '#FAA21C', borderRadius: 20, marginTop: 10, height: 220 }}>
                            <Text style={{ margin: 10, color: 'white', fontSize: 15 }}>Expected You get</Text>
                            <View style={{ flexDirection: 'row', marginBottom: 10, borderBottomColor: 'white' }}>
                                <View>
                                    <Text style={{ marginLeft: 10, color: 'white', fontSize: 20 }}>Rs {this.props.fetchPreviousMonthAccountDetails && this.props.fetchPreviousMonthAccountDetails.totalExpectedEarning}</Text>
                                    <Text style={{ color: 'white', fontSize: 12, marginLeft: 10 }}>{this.getPreviousMonthData()}</Text>
                                </View>
                                <View>
                                    <Text style={{ marginLeft: 150, color: 'white', fontSize: 20 }}>Rs {this.props.fetchCurrentMonthAccountDetails && this.props.fetchCurrentMonthAccountDetails.totalExpectedEarning}</Text>
                                    <Text style={{ color: 'white', fontSize: 12, marginLeft: 150 }}>{this.getCurrentMonthData()}</Text>
                                </View>

                            </View>
                            <View style={{ marginTop: 10, flexDirection: 'row' }}>
                                <View style={{ flexDirection: 'row', marginLeft: 10 }}>
                                    <Image

                                        source={images.browser}
                                        resizeMode='contain'
                                        style={{
                                            width: 30, height: 30,
                                            borderRadius: 10,
                                        }}

                                    ></Image>
                                    <Text style={{ color: 'white', marginLeft: 10, alignSelf: 'center', fontSize: 15 }}>Online</Text>
                                </View>
                                <View style={{ flexDirection: 'row', marginLeft: 130 }}>
                                    <Image

                                        resizeMode='contain'
                                        source={images.payment} style={{
                                            width: 30, height: 30,
                                            borderRadius: 10,
                                        }}
                                    ></Image>
                                    <Text style={{ marginLeft: 10, color: 'white', alignSelf: 'center', fontSize: 15 }}>Offline</Text>
                                </View>
                            </View>
                            <View style={{ flexDirection: 'row', marginTop: 10, borderBottomWidth: 1, borderBottomColor: 'white' }}>
                                <Text style={{ marginLeft: 10, color: 'white', fontSize: 15, marginBottom: 10 }}>{this.props.fetchPreviousMonthAccountDetails && this.props.fetchPreviousMonthAccountDetails.onlineStudentCount}</Text>
                                <Text style={{ marginLeft: 210, color: 'white', fontSize: 15 }} >{this.props.fetchCurrentMonthAccountDetails && this.props.fetchCurrentMonthAccountDetails.onlineStudentCount}</Text>
                            </View>
                            {this.state.showDetails == false ?
                                <TouchableOpacity onPress={this.showdetails}>
                                    {/* <View style={{ flexDirection: 'row', }}> */}
                                        <Text style={{ alignSelf: 'center', color: 'white', fontSize: 15, marginTop: 5 }}>Show Details for {this.getCurrentMonthData()} {this.getCurrentYear()}</Text>
                                        {/* <Image
                                            resizeMode='contain'
                                            source={images.downarrow} style={{
                                                width: 30, height: 30, color: 'red',
                                                justifyContent: 'flex-end'
                                            }}
                                        ></Image> */}
                                    {/* </View> */}
                                </TouchableOpacity> :
                                <TouchableOpacity onPress={this.hidedetails}>
                                    <Text style={{ alignSelf: 'center', color: 'white', fontSize: 15, marginTop: 5  }}>Hide Details for {this.getCurrentMonthData()} {this.getCurrentYear()}</Text>
                                </TouchableOpacity>
                            }
                        </View>

                        {this.state.showDetails && this.props.fetchCurrentMonthAccountDetails?.data && this.props.fetchCurrentMonthAccountDetails?.data  && !isEmpty(this.props.fetchCurrentMonthAccountDetails?.data)? 
                        
                        <View style={{ marginLeft: 10, marginRight: 10, backgroundColor: '#F9F9F9', borderBottomEndRadius: 20, marginTop: 10,marginBottom:20 }}>
                        <SafeAreaView style={{marginTop:20}}>
                          <FlatList
                            data={this.props.fetchCurrentMonthAccountDetails?.data}
                            nestedScrollEnabled={true}
                            onEndReached={this._handleLoadMore}
                            onEndReachedThreshold={0.01}
                            renderItem={({item}) => (

                                <View style={{ borderBottomWidth: 1, margin: 10 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text>{item.name} Class 12th</Text>
                                    <Text style={{ marginLeft: 130 }}>Rs 10,000</Text>
                                </View>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text>4:00 PM to 5:00 PM S M T W T F S</Text>
                                    <Text style={{ marginLeft: 44 }}>This Month</Text>
                                </View>
                            </View>
                            )}
                            />
                        </SafeAreaView>
                        </View> : 
                        
                        null
                    
                        }

                        <View style={{ marginLeft: 10, marginRight: 10, backgroundColor: '#5B82FF', borderRadius: 20, marginTop: 20, height: '42%' }}>
                            <Text style={{ margin: 10, color: 'white', fontSize: 15 }}>Actual Earnings</Text>
                            <View style={{ marginBottom: 10, borderBottomColor: 'white' }}>

                                <Text style={{ margin: 10, color: 'white', fontSize: 20 }}>Rs {this.props.fetchPreviousMonthAccountDetails && this.props.fetchPreviousMonthAccountDetails?.totalActualEarning}</Text>
                                <Text style={{ color: 'white', fontSize: 12, marginLeft: 10 }}>{this.getPreviousMonthData()}</Text>

                            </View>
                            <View style={{ flexDirection: 'row' }}>
                                <View style={{ flexDirection: 'row', marginLeft: 10 }}>
                                    <Image

                                        source={images.browser}
                                        resizeMode='contain'
                                        style={{
                                            width: 30, height: 30,
                                            borderRadius: 10,
                                        }}

                                    ></Image>
                                    <Text style={{ color: 'white', marginLeft: 10, alignSelf: 'center', fontSize: 15 }}>Online</Text>
                                </View>
                            
                            </View>
                            <View style={{ flexDirection: 'row', marginTop: 5, borderBottomWidth: 1, borderBottomColor: 'white' }}>
                                <Text style={{ marginLeft: 10, color: 'white', fontSize: 15, marginBottom: 10 }}>{this.props.fetchPreviousMonthAccountDetails && this.props.fetchPreviousMonthAccountDetails.onlineStudentCount}</Text>
                            </View>
                            <TouchableOpacity
                            onPress={()=>{
if(this.state.showPreviousMonthDetails)
{
    //this.showPreviousdetails()
    this.hidePreviousdetails()
}
else{
    //this.hidePreviousdetails()
    this.showPreviousdetails()
}
                               

                                }}>
                                <Text style={{ alignSelf: 'center', color: 'white', fontSize: 15, marginTop: 10, marginBottom:10 }}>{this.getShowDetailsText()}</Text>
                            </TouchableOpacity>
                          
                        </View>

  {this.state.showPreviousMonthDetails && this.props.fetchPreviousMonthAccountDetails?.data && this.props.fetchPreviousMonthAccountDetails?.data  && !isEmpty(this.props.fetchPreviousMonthAccountDetails?.data)? 
                        
                        <View style={{ marginLeft: 10, marginRight: 10, backgroundColor: '#F9F9F9', borderBottomEndRadius: 20, marginTop: 10, }}>
                        <SafeAreaView style={{marginTop:20}}>
                          <FlatList
                            data={this.props.fetchPreviousMonthAccountDetails?.data}
                            nestedScrollEnabled={true}
                            onEndReached={this._handleLoadMore}
                            onEndReachedThreshold={0.01}
                            renderItem={({item}) => (

                                <View style={{ borderBottomWidth: 1, margin: 10 }}>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text>{item.name} Class 12th</Text>
                                    <Text style={{ marginLeft: 130 }}>Rs 10,000</Text>
                                </View>
                                <View style={{ flexDirection: 'row' }}>
                                    <Text>4:00 PM to 5:00 PM S M T W T F S</Text>
                                    <Text style={{ marginLeft: 44 }}>This Month</Text>
                                </View>
                            </View>
                            )}
                            />
                        </SafeAreaView>
                        </View> : 
                        
                        null
                    
                        }

                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ backgroundColor: '#5B82FF', margin: 10, height: '80%', width: '45%', borderRadius: 10, flexDirection: 'row' }}>
                                <Image
                                    resizeMode='contain'
                                    source={require('../../images/dwnld.png')}
                                    style={{
                                        width: 20, height: 20, marginTop: 10, marginLeft: 10,
                                        borderRadius: 10,
                                    }}
                                ></Image>
                                <TouchableOpacity
                                style={{justifyContent:'center'}}
                                onPress={()=>{this.downloadMonthlyStatement()}}
                                >
                                    <Text style={{ color: 'white', alignSelf: 'center', fontSize: 14, marginLeft: 10 }}>Monthly Statement</Text>
                                    </TouchableOpacity>
                            </View>
                            <View style={{ backgroundColor: '#5B82FF', margin: 10, height: '80%', width: '45%', borderRadius: 10, flexDirection: 'row' }}>
                                <Image
                                    resizeMode='contain'
                                    source={require('../../images/dwnld.png')}
                                    style={{
                                        width: 20, height: 20, marginTop: 10, marginLeft: 10,
                                        borderRadius: 10,
                                    }}
                                ></Image>
                                 <TouchableOpacity
                                style={{justifyContent:'center'}}
                                onPress={()=>{this.downloadYearlyStatement()}}
                                >
                                <Text style={{ color: 'white', alignSelf: 'center', fontSize: 14, marginLeft: 10 }}>Actual Statement</Text></TouchableOpacity>
                            </View>
                        </View>

                    </View>
                    </ScrollView>
                    </View>


        )
    }

}
const mapStateToProps = state => ({
    prof: state.prof,
    fetchAccountDetailsData: state.dash.fetchAccountData,
    fetchCurrentMonthAccountDetails : state.dash.fetchTeacherMonthlyAccountData,
    fetchPreviousMonthAccountDetails : state.dash.fetchTeacherPreviousMonthlyAccountData,
  });
  
  const mapDispatchToProps = {
    fetchAccountData,
    fetchTeacherMonthlyAccountData,
    fetchTeacherPreviousMonthlyAccountData,
  };

export default connect(mapStateToProps, mapDispatchToProps) (MyAccount);

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        marginBottom: 40,
        marginTop: 10
    },
    labelContainer: {


        justifyContent: 'center', alignContent: 'center',
        backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
        width: '98%', borderRadius: 10,

    },
    topHead: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingLeft: 10,
        marginBottom: 5,
        marginTop: 5
    },
    topHead2: {

        flexDirection: 'row',
        flexWrap: 'wrap',
        // justifyContent: 'space-between',
        paddingRight: 10,
        paddingLeft: 10,

    },
    ButtonContainer: {
        // flex: .8,
        borderWidth: 1,
        borderColor: `${COLORS.MAINCOLOR.BLUE}`,
        padding: 5,
        paddingLeft: 15,
        paddingRight: 15,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
    },
    ViewDetailContainer: {
        // flex: .8,
        borderWidth: 1,
        borderColor: `${COLORS.MAINCOLOR.BLUE}`,
        padding: 5,
        paddingLeft: 10,
        paddingRight: 10,
        backgroundColor: '#fff',

        marginBottom: 10
    },
    Buttontext: {
        color: `${COLORS.MAINCOLOR.BLUE}`,
        fontSize: 12
    },
    grossText: {

        flexDirection: 'row',

        width: widthPercentageToDP('50%'),

    },
    MyAccount2: {
        flex: 1,
        flexDirection: 'column'
    },
    MyAccountItems: {
        flex: 1,
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignContent: 'center',
        justifyContent: 'space-around',
        paddingLeft: 15,
        paddingTop: 10
    }
})
