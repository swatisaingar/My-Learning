import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity, Dimensions,
  FlatList, Alert, Image, ActivityIndicator,
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP, heightPercentageToDP } from '../../constants/styles'
import * as EnquiryAPI from '../../Services/enquiryAPIs';
import { connect } from 'react-redux';
import moment from 'moment'
import Loader from '../../Common/Loader';
import _ from "lodash";
import { appbluebtnColor, appblueColor, appgrayColor, loginheaderColor, apppinkColor, appheadertextColor, appcountColor, } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import Modal from "react-native-modal";
import { Checkbox } from 'react-native-paper';
import NavigationService from '../../Services/NavigationService';
import { getClassesData, teacherClassesData, fetchActiveCoursesData, fetchSubsRecord } from '../../actions';
import HTML from 'react-native-render-html';
import { isNumber, isEmpty, now } from 'lodash';
import AsyncStorage from '@react-native-async-storage/async-storage';
import QRCode from 'react-native-qrcode-svg';
import Share from 'react-native-share';
import RNFS from 'react-native-fs';
import { baseURL } from '../../util/AppConstants';


var params;
class MyClassesScreen extends Component {

  constructor(props) {
    super(props);
    this.state = {
      image: '',
      name: '',
      standard: '',
      teachername: '',
      teacherlastname: '',
      enquiries: [],
      filterArr: [{ id: -1, text: 'Top Rated' }, { id: 1, text: 'Top Rated', selected: 0 },
      { id: 2, text: 'Best Match', selected: 0 }, { id: 3, text: 'Price Low to High', selected: 0 }, { id: 4, text: 'Price High to Low', selected: 0 },],
      showLoader: true,
      showPopup: false,
      canceltext: '',
      _id: '',
      _selectedids: [],
      start: 0, total: 0,
      start2: 0, total2: 0,
      filterpopup: false,
      searchList: [{
        'class': "CHemistry Class 12th",
        'teacher': 'By Sooraj Rai',
      }],
      activeCourseList: [],
      teacherListIamgeData: [],
      finalWishData: [],
      imageData: {},
      imageLoading: true,
      profileImage: {},
      showQr1: false,
    }
    params = this.props.navigation.state.params;
  }

  finalWishData = [];

  async componentDidMount() {
    let profileData = await AsyncStorage.getItem('user_id');
    let AuthToken = await AsyncStorage.getItem('id_token');

    this.props.fetchSubsRecord();

    this.props.getClassesData(profileData);

    //this.props.teacherClassesData(profileData)
    this.props.fetchActiveCoursesData({ status: true })
    // console.log('this.props?.courseListData[1]?.courseClass?.course?.imageId',this.props?.courseListData.data[1]?.courseClass?.course?.imageId)
    if (this.props.courseListData != null && this.props.courseListData.length > 0) {
      this.props.imageWithoutLoopLoad(this.props?.courseListData[1]?.courseClass?.course?.imageId)
    }
    this.props.fetchActiveCoursesData({ status: true })


    this?.props?.subscriptionData?.data?.map((item) => {
      let id = item.course_id.imageId;
      fetch(`${baseURL}file-blobs/getImage/${id}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${AuthToken}`,
        }
      }).then(data => {
        return data.json()
      }).then(resposne => {
        // console.log('image response',resposne)
        let imageData = this.state.imageData || {};
        imageData[resposne.data.id] = resposne.data;
        this.setState(imageData);
        this.setState({ imageLoading: false });
      }).
        catch((error) => {
          console.log("#error", error);
        })
    })


    this.props?.courseListData?.data?.map((item) => {
      let id = item?.courseClass?.course?.imageId;
      fetch(`${baseURL}file-blobs/getImage/${id}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${AuthToken}`,
        }
      }).then(data => {
        return data.json()
      }).then(resposne => {
        // console.log('image response',resposne)
        let imageData = this.state.imageData || {};
        imageData[resposne.data.id] = resposne.data;
        this.setState(imageData);
        this.setState({ imageLoading: false });
      }).
        catch((error) => {
          console.log("#error", error);
        })
    })

    let id = this.props.prof?.profData?.data?.imageId;
    fetch(`${baseURL}file-blobs/getImage/${id}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let profileImage = this.state.profileImage || {};
      profileImage[resposne.data.id] = resposne.data;
      this.setState(profileImage);
    }).
      catch((error) => {
        console.log("#error", error);
      })
  }

  async componentDidUpdate(prevProps) {

    let AuthToken = await AsyncStorage.getItem('id_token');
    if (this.props.courseData != null) {
      if (prevProps.courseData != this.props.courseData) {
        if (this.props.courseData && this.props.courseData.data != null) {
          this.setState({
            image: this.props.courseData && this.props.courseData.data.map((item) => item.course && item.course.image && item.course.image.content),
            name: this.props.courseData && this.props.courseData.data.map((item) => item.course && item.course.name),
            standard: this.props.courseData && this.props.courseData.data.map((item) => item.course && item.course.standard && item.course.standard.class),
            teachername: this.props.courseData && this.props.courseData.data.map((item) => item && item.teacher && item.teacher.firstName),
            teacherlastname: this.props.courseData && this.props.courseData.data.map((item) => item && item.teacher && item.teacher.lastName),
            teacherExp: this.props.courseData && this.props.courseData.data.map((item) => item && item.teacher && item.teacher.lastName),
            showLoader: false,
          })
        }
      }
    }


    if (prevProps.teacherActiveCourseData != this.props.teacherActiveCourseData) {
      if (this.props.teacherActiveCourseData != null && this.props.teacherActiveCourseData.data) {

        this.props.teacherActiveCourseData?.data?.map((item) => {
          // this.props.imageLoad(item?.courseClass?.course?.imageId)
          let id = item?.image?.id;
          fetch(`https://api.idutor.tk/api/file-blobs/getImage/${id}`, {
            method: 'GET',
            headers: {
              Authorization: `Bearer ${AuthToken}`,
            }
          }).then(data => {
            return data.json()
          }).then(resposne => {
            let imageData = this.state.teacherListIamgeData || {};
            imageData[resposne.data.id] = resposne.data;
            this.setState(imageData);
            this.setState({ teacherListIamgeData: imageData, })
          }).
            catch((error) => {
              console.log("#error", error);
            })
        })

        this.setState({ activeCourseList: this.props?.teacherActiveCourseData?.data, showLoader: false, })
      }
    }


  }


  componentWillUnmount() {
    this.finalWishData = [];
  }
  setChecked1(status) {
    this.setState({
      checked1: status
    })
  }
  setChecked2(status) {
    this.setState({
      checked2: status
    })
  }
  setChecked3(status) {
    this.setState({
      checked3: status
    })
  }
  setChecked4(status) {
    this.setState({
      checked4: status
    })
  }

  studyView = () => {
    this.setState({ study: true })
  }


  navigateToClassesForCourseScreen(item) {
    this.props.navigation.navigate('ClassDetailScreen', { courseData: item })
  }

  setClassStudentSizeColor(item) {
    if (item.studentEnrolled >= item.minBatchSize) {
      return '#36CE00'

    }
    else {
      return apppinkColor
    }
  }
  getClassStartTimeFormatted(startTime) {

    console.log("startTime :", startTime)
    const sTime = moment(startTime, "hh:mm A");
    console.log("startTime By moment :", sTime)
    return sTime.format("hh:mm A")
  }

  getCourseStatusText(status) {

    switch (status) {
      case 1:
        return 'Open'

      default:
        return ''
    }
  }

  getCourseDuration(duration) {
    if (duration < 60) {
      return duration + " min"
    }
    else if (duration >= 60) {
      return (duration / 60) + " hr"
    }
  }

  showQRCodeScanner() {
    if (!this.state.showQr1) {
      this.setState({ showQr1: true })
    }
  }

  saveQRCode() {
    this.svg.toDataURL(this.callback)
  }

  callback(dataURL) {
    let shareImageBase64 = {
      title: 'React Native',
      url: `data:image/png;base64,${dataURL}`,
      subject: 'Share Link',
    }

    Share.open(shareImageBase64).catch(error => console.log(error))
  }

  downloadQRCode = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        {
          title: 'Cool Photo App Camera Permission',
          message:
            'Cool Photo App needs access to your camera ' +
            'so you can take awesome pictures.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      )
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.svg.toDataURL(data => {
          RNFS.writeFile(
            RNFS.CachesDirectoryPath + '/some-name.png',
            data,
            'base64',
          )
            .then(success => {
              return CameraRoll.save(
                RNFS.CachesDirectoryPath + '/some-name.png',
                'photo',
              )
            })
            .then(() => {
              ToastAndroid.show('Saved to gallery !!', ToastAndroid.SHORT)
            })
        })
      } else {
        console.log('Camera permission denied')
      }
    } catch (err) {
      console.warn(err)
    }
  }

  async getUserProfileImage() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    let id = this.props.prof.profData &&
      this.props.prof.profData.data &&
      this.props.prof.profData.data.imageId
    //let id = item.course.imageId;
    console.log("imageId ========", id)
    fetch(`https://api.idutor.tk/api/file-blobs/getImage/${id}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let imageData = this.state.teacherListIamgeData || {};
      imageData[id] = resposne.data;
      this.setState(imageData);
      console.log('image datadata', imageData)
      this.setState({ teacherListIamgeData: imageData, })
    }).
      catch((error) => {
        console.log("#error", error);
      })

    console.log("ImageData=============", this.state.teacherListIamgeData)


  }

  render() {
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>

        <Modal

          isVisible={this.state.showImage}
          animationType="fade"
          transparent={true}
          backdropColor={'rgba(0,0,0,0.35)'}
          backdropOpacity={1}
          onBackdropPress={() => this.setState({ filterpopup: false })}
          onRequestClose={() => {
            this.setState({ filterpopup: false });
          }}
        >
          <View
            style={{
              flex: 1,

              justifyContent: "flex-end",
              alignItems: "center",
              height: 310,
            }}
          >
            <View
              style={{
                backgroundColor: "white",
                height: 310,
                width: widthPercentageToDP('100%'),
                alignContent: "center",
                justifyContent: "center", borderTopLeftRadius: 20, borderTopRightRadius: 20
              }}
            >
              <View>
                <Text style={{ fontSize: 20, marginTop: 20, marginLeft: 20 }}>Filter your Search</Text>
                <View style={{ flexDirection: 'row', paddingLeft: 10, paddingRight: 10, alignItems: 'center', marginTop: 10 }}>
                  <Checkbox
                    uncheckedColor={'gray'}
                    color={loginheaderColor}

                    status={this.state.checked1 ? 'checked' : 'unchecked'}
                    onPress={() => this.setChecked1(!this.state.checked1)}
                  />
                  <Text style={{ color: 'black' }}>Don't show In-progress Courses</Text>

                </View>


                <View style={{ flexDirection: 'row', paddingLeft: 10, paddingRight: 10, alignItems: 'center', marginTop: 10 }}>
                  <Checkbox
                    uncheckedColor={'gray'}
                    color={loginheaderColor}

                    status={this.state.checked2 ? 'checked' : 'unchecked'}
                    onPress={() => this.setChecked2(!this.state.checked2)}
                  />
                  <Text style={{ color: 'black' }}>My Friends / Idutor Recommended </Text>

                </View>


                <View style={{ flexDirection: 'row', paddingLeft: 10, paddingRight: 10, alignItems: 'center', marginTop: 10 }}>
                  <Checkbox
                    uncheckedColor={'gray'}
                    color={loginheaderColor}

                    status={this.state.checked3 ? 'checked' : 'unchecked'}
                    onPress={() => this.setChecked3(!this.state.checked3)}
                  />
                  <Text style={{ color: 'black' }}>Online Payment Only</Text>

                </View>

                <View style={{ flexDirection: 'row', paddingLeft: 10, paddingRight: 10, alignItems: 'center', marginTop: 10 }}>
                  <Checkbox
                    uncheckedColor={'gray'}
                    color={loginheaderColor}

                    status={this.state.checked4 ? 'checked' : 'unchecked'}
                    onPress={() => this.setChecked4(!this.state.checked4)}
                  />
                  <Text style={{ color: 'black' }}>Assured Registration</Text>

                </View>
                <View style={{ flexDirection: 'row', justifyContent: 'flex-end', marginRight: 20, marginTop: 10 }}>
                  <TouchableOpacity

                    onPress={() => {
                      this.setState({ filterpopup: false, checked1: false, checked2: false, checked3: false, checked4: false })
                    }}
                  >
                    <Text style={{ color: "black", textAlign: "center", marginRight: 10 }}>
                      CLEAR
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity

                    onPress={() => {
                      this.setState({ filterpopup: false })
                    }}
                  >
                    <Text style={{ color: appblueColor, textAlign: "center", marginLeft: 10 }}>
                      APPLY
                    </Text>
                  </TouchableOpacity>

                </View>
              </View>
            </View>
          </View>
        </Modal>

        <Modal
          isVisible={this.state.showQr1}
          animationType='fade'
          transparent={true}
          backdropColor={'rgba(0,0,0,0.35)'}
          backdropOpacity={1}
          onBackdropPress={() => this.setState({ showQr1: false })}
          onRequestClose={() => {
            this.setState({ showQr1: false })
          }}>
          <View
            style={{
              marginBottom: 10,
              height: heightPercentageToDP('60%'),
              width: widthPercentageToDP('90%'),
              backgroundColor: 'white',
              marginTop: 80,
            }}>
            <View
              style={{
                backgroundColor: 'white',
                width: 130,
                height: 130,
                borderRadius: 70,
                alignSelf: 'center',
                position: 'absolute',
                top: -70,
                justifyContent: 'center',
                borderWidth: 1,
              }}>

              {this.props.prof.profData && this.state.teacherListIamgeData[0]?.content ? (
                <Image
                  style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: 70,
                    alignSelf: 'center',
                  }}
                  source={{
                    uri: `data:image/jpeg;base64,${this.props.prof.profData &&
                      this.props.prof.profData.data && this.props.prof.profData.data.image &&
                      this.state.teacherListIamgeData[0]?.content}`,
                  }}
                />
              ) : (
                  <Image
                    style={{ width: 125, height: 125, alignSelf: 'center' }}
                    source={images.male}
                  />
                )}
            </View>
            <TouchableOpacity
              style={{ position: 'relative', left: 310, marginTop: 10 }}
              onPress={() => this.setState({ showQr1: false })}>
              <Image resizeMode='contain' source={images.drawerclose} />
            </TouchableOpacity>
            <View style={{ marginTop: 40 }}>
              <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>

                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.firstName}
                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.lastName}
              </Text>
              <Text
                style={{
                  textAlign: 'center',
                  color: '#888888',
                  fontStyle: 'italic',
                }}>

                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.experienceInYear}
                yr,
                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.qualifications &&
                  this.props.prof.profData.data.qualifications.map(
                    item => item.qualification,
                  )}
              </Text>
              <View style={{ alignSelf: 'center', margin: 10 }}>
                <QRCode
                  value={`{id: ${this.props.prof.profData && this.props.prof.profData.data &&
                    this.props.prof.profData.data.id},name: ${this.props.prof
                      .profData && this.props.prof.profData.data && this.props.prof.profData.data.firstName}}`}
                  size={200}
                  getRef={c => (this.svg = c)}
                />
              </View>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  marginBottom: 5,
                  alignSelf: 'center',
                  marginTop: 10,
                  backgroundColor: '#1976D2',
                  borderRadius: 35,
                  width: widthPercentageToDP('32%'),
                  textAlign: 'center',
                  height: 50,
                }}
                onPress={() => this.saveQRCode()}>
                <Image
                  resizeMode='contain'
                  source={images.share_list}
                  style={{ alignSelf: 'center', marginLeft: 20 }}
                />
                <Text
                  style={{
                    fontSize: 20,
                    marginLeft: 10,
                    color: 'white',
                    alignSelf: 'center',
                  }}>
                  Share
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  marginTop: 10,
                }}
                onPress={() => this.downloadQRCode()}>
                <Image
                  resizeMode='contain'
                  source={images.download}
                  style={{ alignSelf: 'center' }}
                />
                <Text style={{ marginLeft: 10 }}> Save to Photos </Text>
              </TouchableOpacity>
            </View>
          </View>
          {this.state.canceltext == false ? (
            <View
              style={{
                elevation: 10,
                backgroundColor: 'white',
                marginBottom: 10,
                borderRadius: 10,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  paddingTop: 10,
                  paddingBottom: 10,
                }}>
                <Image
                  style={{
                    width: 20,
                    height: 20,
                    marginLeft: 20,
                    alignSelf: 'center',
                  }}
                  source={images.info}
                />
                <View style={{ width: '80%', alignContent: "flex-start" }}>
                  <Text
                    style={{
                      fontWeight: 'bold',
                      color: appheadertextColor,
                      fontSize: 12,
                    }}>
                    Did you know ?
                  </Text>
                  <Text
                    numberOfLines={4}
                    style={{ fontSize: 10, color: appheadertextColor }}>
                    You can invite your students directly to your profile on
                    idutor by sharing your QR code with them.idutor does not
                    charge any convenience fee for students enrolled to your
                    courses using your QR code.
                  </Text>
                </View>
              </View>
            </View>
          ) : null}
        </Modal>

        {this.props.selctType.typeselectedData.logintype == "Student" ? <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();

              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

            </TouchableOpacity>

          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15, marginLeft: 30 }} source={images.logo} resizeMode={'contain'} />

          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>
            <TouchableOpacity
              onPress={() => {
                this.setState({
                  filterpopup: true
                })
              }}
            >
              <Icon1 style={{ marginLeft: 15, marginTop: 10 }} name="bell-o" size={20} color="black" /></TouchableOpacity>
            <TouchableOpacity onPress={() => NavigationService.navigate('ProfileScreen')}>
             {(this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content) ? <Image
                resizeMode='contain'
                source={{ uri: `data:image/jpeg;base64,${this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content}` }}
                style={{ width: 20, height: 20, marginLeft: 5, marginRight: 10, marginTop: 10, borderWidth: 1 }}
              />:<View style={{
                width: 25,
                height: 25,
                marginLeft: 5,
                marginRight: 20,
                marginTop: 15,
                borderWidth: 1
              }}><ActivityIndicator size='small'/></View>}
            </TouchableOpacity>
          </View>
        </View> : <View><View style={{ flexDirection: 'row', backgroundColor: 'white', height: 100, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                NavigationService.openDrawerr();
              }}
            >
              <Image style={{ width: 20, height: 20, marginLeft: 10 }} source={images.menu} />
            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 10 }} source={images.logo} resizeMode={'contain'} />

          <TouchableOpacity
            onPress={() => {
              this.setState({ filterpopup: true })
            }}
          >
            <Icon1 style={{ marginTop: 15, alignContent: 'flex-end', marginRight: 10 }} name="bell-o" size={20} color={'black'} />
          </TouchableOpacity>
        </View>

            <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
              <View style={[Styles.searchinput,]}>

                <View style={Styles.searchbackground} />
                <View style={{ flexDirection: 'row', }}>
                  <Icon1 style={{ marginLeft: 10, alignSelf: 'center' }} name="search" size={15} color="gray" />

                  <Text style={{
                    color: 'gray', flex: 1, height: 50, textAlignVertical: 'center',
                    alignSelf: 'center',
                    zIndex: 1,
                    paddingLeft: 10,
                  }}>Search</Text>
                  <TouchableOpacity
                    style={{ alignContent: 'center', justifyContent: 'center', }}
                    onPress={() => {
                      //this.setState({ showQr1: true })
                      this.showQRCodeScanner()
                      console.log("QR code scanner clicked", "true")
                    }

                    }>
                    <Image
                      source={images.qrcode}
                      style={{ width: 18, height: 18, marginRight: 35, alignSelf: 'center' }}
                    />
                  </TouchableOpacity>

                </View>
              </View>
            </View>
          </View>
        }
        {/* {console.log('this.props.subscriptionDatathis.props.subscriptionData',this.props.subscriptionData.data)} */}
        {this.props.selctType.typeselectedData.logintype === "Student" ?
          <ScrollView
            showsVerticalScrollIndicator={false}
            nestedScrollEnabled={true}
            style={styles.container}>
            {(this.props.subscriptionData && this.props.subscriptionData.totalCount !== 0) ?
              <FlatList
                data={(this.props.subscriptionData && this.props.subscriptionData.data)}
                nestedScrollEnabled={true}
                renderItem={({ item }) =>
                (
                  <View>
                   
                    <TouchableOpacity
                      onPress={() => {
                        NavigationService.navigate('ClassDetailScreen', { id: item.course_id.id })
                      }}
                    >
                      <View style={{

                        paddingRight: 5,
                        paddingLeft: 5,
                        marginTop: 10,
                        justifyContent: 'center', alignItems: 'center',
                      }}>
                        {(item.courseStatus == 2
                          || item.courseStatus == 1 && <View style={styles.labelContainer}>

                            <View style={{ flexDirection: 'row' }}>

                              {!this.state.imageLoading ? <Image

                                source={{ isStatic: true, uri: `data:image/jpeg;base64,${this.state.imageData[item?.courseClass?.course?.imageId] && this.state.imageData[item?.courseClass?.course?.imageId].content}` }}
                                style={{
                                  width: widthPercentageToDP('22%'),
                                  borderRadius: 10,

                                }}
                              ></Image> :
                                <View style={{
                                  width: widthPercentageToDP('22%'),
                                  borderRadius: 10,
                                }}>
                                  <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                                </View>}


                              <View style={{ width: '80%' }}>
                                <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                                  <Text style={{ fontSize: 12, marginLeft: 10 }}>{item && item.course_id && item.course_id.name} Class-{item && item.course_id && item.course_id.standard && item.course_id.standard.class}</Text>

                                </View>
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                                  <View>
                                    <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item && item.teacherDetails && item.teacherDetails.firstName} {' '}{item && item.teacherDetails && item.teacherDetails.lastName}{' '}{item && item.teacherDetails && item.teacherDetails.experienceInYear}yr</Text>
                                    <Text style={{ marginLeft: 10, fontSize: 12 }}>{item && item.teacherDetails && item.teacherDetails.qualification && item.teacherDetails.qualification[0] && item.teacherDetails.qualification[0].qualification}</Text>
                                  </View>

                                </View>
                                <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                                <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 5 }}>TIMING (START FROM {item && item.course_id && item.course_id.createdDate && moment(item && item.course_id && item.course_id.createdDate).format('DD-MM-YYYY')})</Text>
                                <View style={{ flexDirection: 'row', marginRight: 20, justifyContent: 'space-between' }}>
                                  <Text style={{ fontSize: 10, marginLeft: 10, color: loginheaderColor }}>{moment(item.course_id.startDate).format('hh:mm A')} to {moment(item.course_id.endDate).format('hh:mm A')}</Text>
                                  <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: item.course_id.courseDays.map((item) => item.status === true) ? loginheaderColor : 'black' }}>{item.course_id.courseDays.map((item) => item.day.substring(0, 1))}</Text>
                                </View>

                                <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 5, marginBottom: 10 }}>
                                  <View>
                                    <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                    <Text style={{ color: loginheaderColor, fontSize: 10 }}>{item.course_id.courseStatus ? 'OPEN' : 'REGISTER'}</Text>
                                  </View>
                                  {/* <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>Number of Claases</Text>
                                {console.log('courseClasscourseClass',item)}
                                <Text style={{ color: loginheaderColor, fontSize: 10 }}>{item?.length}</Text>
                              </View> */}
                                </View>


                              </View>
                            </View>
                          </View>)}
                      </View>
                    </TouchableOpacity>
                  </View>)

                }

              />
              :

              <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', margin: 20 }}>
                <Text>No Claases found for this course</Text>
              </View>}

          </ScrollView >

          :

          <ScrollView><View style={{ marginBottom: 10 }}>
            <Text style={{ margin: 10, fontSize: 15 }}>My Courses</Text>
            {this.state.showLoader ? (
              <View >
                <ActivityIndicator />
              </View>
            ) : null}
            {this.props.teacherActiveCourseData && this.props.teacherActiveCourseData.totalCount !== 0 ? <FlatList
              data={this.props.teacherActiveCourseData && this.props.teacherActiveCourseData.data}
              nestedScrollEnabled={true}
              onEndReachedThreshold={0.01}
              renderItem={({ item }) =>
              (<View>
                <TouchableOpacity
                  onPress={() => {
                    this.navigateToClassesForCourseScreen(item)
                  }}
                >
                  <View style={{

                    paddingRight: 5,
                    paddingLeft: 5,
                    marginTop: 10,
                    justifyContent: 'center', alignItems: 'center'
                  }}>
                    <View style={styles.labelContainer}>

                      <View style={{ flexDirection: 'row', flex: 1, }}>

                        {
                          isEmpty(this.state.teacherListIamgeData[item.image?.id]?.content)
                            ?
                            <View style={{ flex: 1, justifyContent: 'center' }}>

                              <Image style={Styles.calimage}
                                source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                              />
                            </View>
                            :

                            <Image

                              source={{ uri: `data:image/jpeg;base64,${this.state.teacherListIamgeData[item.image?.id]?.content}`, }}
                              style={{
                                width: widthPercentageToDP('22%'),
                                borderRadius: 10,
                                marginHorizontal: 10,
                                marginVertical: 10,
                              }}
                            ></Image>

                        }


                        <View style={{ width: '85%', flex: 3 }}>
                          <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                            <Text style={{ fontSize: 12, marginLeft: 10 }}>{item.name} Class {item.standard.class}</Text>
                            <View style={{ flexDirection: 'row', marginRight: 20 }}>
                              <Image

                                source={images.star}
                                style={{
                                  width: 15,
                                  height: 15, marginRight: 1, marginLeft: 1
                                }}
                              ></Image>
                              <Image

                                source={images.star}
                                style={{
                                  width: 15,
                                  height: 15, marginRight: 1, marginLeft: 1
                                }}
                              ></Image>
                              <Image

                                source={images.star}
                                style={{
                                  width: 15,
                                  height: 15, marginRight: 1, marginLeft: 1
                                }}
                              ></Image>
                              <Image

                                source={images.star}
                                style={{
                                  width: 15, marginRight: 1, marginLeft: 1,
                                  height: 15,
                                }}
                              ></Image>

                              <Image

                                source={images.star}
                                style={{
                                  width: 15,
                                  height: 15, marginRight: 1, marginLeft: 1
                                }}
                              ></Image>
                            </View>

                          </View>
                          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                            <View>
                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                              <Image
                                resizeMode='contain'
                                source={images.confirmation}
                                style={{
                                  width: 16,
                                  height: 16, alignSelf: 'center',
                                  marginHorizontal: 10,
                                }}
                              ></Image>
                              <Image
                                resizeMode='contain'
                                source={images.share_list}
                                style={{
                                  width: 16,
                                  height: 16, alignSelf: 'center',
                                  marginRight: 10,
                                }}
                              ></Image>
                            </View>

                          </View>
                          <View style={{ width: '92%', marginHorizontal: 10, marginRight: 20, height: 1, backgroundColor: '#D3D3D3', alignSelf: 'center', marginTop: 5 }}></View>

                          <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING </Text>
                          <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>

                            <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{item?.courseClasse && item?.courseClasses[0] && this.getClassStartTimeFormatted(item?.courseClasses[0]?.startTime)} to {item?.courseClasses[0] && this.getClassStartTimeFormatted(item?.courseClasses[0]?.endTime)} ({this.getCourseDuration(item?.courseDuration)})</Text>
                            <View style={{ flexDirection: 'row', marginRight: 10 }}>
                              {item.courseDays && item.courseDays.length > 0 && item.courseDays.map(i => {
                                return <Text style={{ fontSize: 13, marginLeft: 5, fontWeight: i.status ? 'bold' : 'normal', fontSize: 10, color: i.status ? loginheaderColor : 'black' }}>{i.day.slice(0, 1)}</Text>
                              })}

                            </View>
                          </View>

                          <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 5 }}>
                            <View>
                              <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                              <Text style={{ color: loginheaderColor }}>{this.getCourseStatusText(item.courseStatus)}</Text>
                            </View>
                            <View style={{ right: 20 }}>
                              <Text style={{ fontSize: 10 }}>Students Enrolled (Min {item.minBatchSize})</Text>
                              <Text style={{ color: this.setClassStudentSizeColor(item), fontSize: 10 }}>{item.studentEnrolled}/{item.minBatchSize}</Text>
                            </View>
                          </View>
                        </View>


                      </View>
                    </View>
                  </View>

                </TouchableOpacity>
              </View>
              )

              }

            /> :

              <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', margin: 20 }}>
                <Text>No Claases found for this course</Text>
              </View>

            }
          </View>
          </ScrollView>
        }




        <View style={{
          flex: 1,
          flexDirection: 'row',
          flexWrap: 'wrap',
          alignContent: 'center',
          justifyContent: 'space-around',
          // paddingLeft: 15,
          // padding: 5,
          position: 'absolute',
          bottom: 0,
          alignSelf: 'center'
        }}>

        </View>
      </View >
    )
  }

}

const mapStateToProps = state => ({
  prof: state.prof,
  selctType: state.selctType,
  courseListData: state.dash.courseListData,
  teacherClassData: state.home.teacherClassData,
  teacherActiveCourseData: state.dash.fetchActiveCourseData,
  imagewithoutloopData: state.dash.imagewithoutloopData,
  subscriptionData: state.dash.subscriptionData,
  // imageData: state.dash.imageData
});

const mapDispatchToProps = {
  getClassesData, teacherClassesData, fetchActiveCoursesData,
  fetchSubsRecord
};

export default connect(mapStateToProps, mapDispatchToProps)(MyClassesScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
