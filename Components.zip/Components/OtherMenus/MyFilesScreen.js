import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList, Alert, Image, PermissionsAndroid, ToastAndroid, ActivityIndicator
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import { connect } from 'react-redux';
import Loader from '../../Common/Loader';
import { appblueColor, appgrayColor, loginheaderColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import NavigationService from '../../Services/NavigationService';
import Accordion from 'react-native-collapsible/Accordion';
import { getFilesData, getFilesStudentAssignmentData, uploadAssignment, imageForTeacher, imageLoad, IsImageEmpty, getClassesData } from '../../actions';
import ImagePicker from 'react-native-image-crop-picker';
import BottomSheet from 'reanimated-bottom-sheet';
import Animated from 'react-native-reanimated';
import RNFetchBlob from 'rn-fetch-blob';
import RNFS from 'react-native-fs';
import CameraRoll from "@react-native-community/cameraroll";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { isEmpty, _ } from 'lodash';
import { baseURL } from '../../util/AppConstants';

const SECTIONS = [
  {
    title: 'First',
    count: 1,
    data: [

      {
        'id': 1,
      },

    ],
  },
  {
    title: 'Second',
    count: 2,
    data: [

      {
        'id': 1,
      },
      {
        'id': 1,
      }
    ],
  }


];
class MyFilesScreen extends Component {

  constructor(props) {
    super(props);
    this.state = {
      topicsCovered: '',
      coursetitle: '',
      firstName: '',
      lastName: '',
      assignmentName: '',
      assignmentCount: '',
      image: '',
      studentassgnmt: '',
      submitvalue: '',
      imagevalue: '',
      imageContentType: '',
      courseClassId: '',
      loading: false,
      showLoader: false,
      activeSections: [],
      finalWishData: [],
      imageData: {},
      profileImage: {},
      imageLoading: true,
      dropdownView: false,
      selectedValue: 0
    }
  }


  async componentDidMount() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    let profileData = await AsyncStorage.getItem('user_id');

    this.props.getClassesData(profileData);

    let id = this.props.prof?.profData?.data?.imageId;
    fetch(`${baseURL}file-blobs/getImage/${id}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let profileImage = this.state.profileImage || {};
      profileImage[resposne.data.id] = resposne.data;
      this.setState(profileImage);
    }).
      catch((error) => {
        console.log("#error", error);
      })


      this.props?.courseListData?.data?.map((item) => {
        let id = item.courseClass.course.imageId;
        fetch(`${baseURL}file-blobs/getImage/${id}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${AuthToken}`,
          }
        }).then(data => {
          return data.json()
        }).then(resposne => {
          
          let imageData = this.state.imageData || {};
          imageData[resposne.data.id] = resposne.data;
          this.setState(imageData);
          this.setState({ imageLoading: false });
          
        }).
          catch((error) => {
            console.log("#error", error);
          })
      })

    // this.props.getFilesStudentAssignmentData("067be86f-db01-4935-807d-f32306cabeab")
  }

  componentDidUpdate(prevProps) {
    if (prevProps.courseListData != this.props.courseListData) {

      for (let i = 0; i < this.props.courseListData.data.length; i++) {
        this.setState({
          topicsCovered: this.props.courseListData.data[i].courseClass.topicsCovered,
          coursetitle: this.props.courseListData.data[i].courseClass.title,
          firstName: this.props.courseListData && this.props.courseListData.data[i] && this.props.courseListData.data[i].teacher && this.props.courseListData.data[i].teacher.firstName,
          lastName: this.props.courseListData && this.props.courseListData.data[i] && this.props.courseListData.data[i].teacher && this.props.courseListData.data[i].teacher.lastName,
        })

      }
    }

    // console.log('this.props.students', this.props.students)
    if (prevProps.students != this.props.students) {

      for (let k = 0; k < this.props.students.length; k++) {
        this.setState({
          studentassgnmt: this.props.students[k].courseClassId.title + " " + this.props.students[k].title,
          submitvalue: this.props.students[k].submitStatus,
        });

        if (this.props.students[k].image) {
          this.setState({
            imageData: this.props.students[k].image,
            courseClassId: this.props.students[k].courseClassId.id
          })
        }
      }
    }

  }

  bs = React.createRef();
  fall = new Animated.Value(1)

  takePhotoFromCamera = () => {
    ImagePicker.openCamera({
      width: 300,
      height: 400,
      cropping: true,
      includeBase64: true,
    }).then(image => {
      this.setState({
        img: `${image.data}`,
        width: `${image.width}`,
        height: `${image.height}`,
        path: `${image.path}`,
        size: `${image.size}`,
        mime: `${image.mime}`,
        modificationDate: `${image.modificationDate}`,
      })
      this.bs.current.snapTo(1)
      this.uploadMethod(image)
    }).catch(e => {
      console.log('exception value', e);
    });
  }

  choosePhotoFromLibrary = () => {
    ImagePicker.openPicker({
      width: 300,
      height: 400,
      cropping: true,
      includeBase64: true,
    }).then(image => {

      this.setState({
        imagevalue: `${image.data}`,
        width: `${image.width}`,
        height: `${image.height}`,
        path: `${image.path}`,
        size: `${image.size}`,
        mime: `${image.mime}`,
        modificationDate: `${image.modificationDate}`,
      })
      this.bs.current.snapTo(1);
      this.uploadMethod(image)
    }).catch(e => {
      console.log('exception value', e);
    });


  }

  storedForFiles = (indexStored) => {
    this.setState({ selectedValue: indexStored })
  }

  checkForClass = (indexValue) => {
    this.props?.courseListData?.data?.map((item,index) => {
      if (index === indexValue) {
        this.setState({ dropdownView: true });
        console.log('item.courseClass.iditem.courseClass.id',item.courseClass.id)
        this.props.getFilesStudentAssignmentData(item.courseClass.id);
        console.log('duvfsljhhhhhhhhh',this.props.students)
      }    
    })
    
  }

  uploadMethod = async (values) => {

    for (let i = 0; i < this.props.students.length; i++) {

      let preImage = this.props.students[i]
      preImage.image.content = values.data;
      preImage.image.width = values.width;
      preImage.image.height = values.height;
      preImage.image.name = values.path;
      preImage.image.contentSize = values.size;
      preImage.image.contentContentType = values.mime,
        preImage.image.createTime = values.modificationDate

      preImage.courseClassId.id = this.props.students[i].courseClassId.id

      const { uploadAssignment } = this.props;
      await uploadAssignment(preImage);

    }
  }

  renderInner = () => (
    <View style={{ backgroundColor: appgrayColor, borderTopStartRadius: 15, borderTopEndRadius: 15, height: '100%' }}>
      <View style={{ alignItems: 'center', marginTop: 20 }}>
        <Text style={{ fontSize: 25, fontWeight: '900' }}>Upload Photo</Text>
        <Text style={{ fontSize: 16, marginTop: 10 }}>Choose Your Profile Picture</Text>
      </View>
      <TouchableOpacity style={{ backgroundColor: 'white', marginTop: 30, width: '80%', alignSelf: 'center', borderWidth: 1, borderRadius: 10, height: '12%' }}
        onPress={this.takePhotoFromCamera}>
        <Text style={{ fontSize: 18, alignSelf: 'center', padding: 5 }}>Take Photo</Text>
      </TouchableOpacity>
      <TouchableOpacity style={{ backgroundColor: 'white', marginTop: 30, width: '80%', alignSelf: 'center', borderWidth: 1, borderRadius: 10, height: '12%' }}
        onPress={this.choosePhotoFromLibrary}>
        <Text style={{ fontSize: 18, alignSelf: 'center', padding: 5 }}>Choose From Your Library</Text>
      </TouchableOpacity>
      <TouchableOpacity style={{ backgroundColor: 'white', marginTop: 30, width: '80%', alignSelf: 'center', borderWidth: 1, borderRadius: 10, height: '12%' }} onPress={() => this.bs.current.snapTo(1)}>
        <Text style={{ fontSize: 18, alignSelf: 'center', padding: 5 }}>Cancel</Text>
      </TouchableOpacity>
    </View>
  );


  _renderHeader = section => {
    return (
      <FlatList
        data={(this.props.courseListData && this.props.courseListData.data)}
        nestedScrollEnabled={true}
        renderItem={({ item }) =>
        (
          <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, marginTop: 10, marginLeft: 10, paddingBottom: 10 }}>

            {<View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <View style={{ flexDirection: 'row', marginRight: 5, marginTop: 5, marginLeft: 10 }}>
                {!this.state.imageLoading ? <Image
                  resizeMode='contain'
                  source={{ isStatic: true, uri: `data:image/jpeg;base64,${this.state.imageData[item.courseClass.course.imageId] && this.state.imageData[item.courseClass.course.imageId].content}` }}
                  style={{
                    width: widthPercentageToDP('22%'),
                    borderRadius: 10,

                  }}
                ></Image> :
                  <View style={{
                    width: widthPercentageToDP('22%'),
                    borderRadius: 10,
                  }}>
                    <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                  </View>}
                <View style={{ marginLeft: 10 }}>
                  <Text style={{ fontWeight: 'bold', fontSize: 13, }}>{item && item.courseClass && item.courseClass.topicsCovered} {item && item.courseClass && item.courseClass.title}</Text>
                  <Text style={{ fontSize: 12, fontStyle: 'italic' }}>By {item && item.teacher && item.teacher.firstName} {item && item.teacher && item.teacher.lastName}</Text>
                  <Text style={{ fontSize: 12, }}>Assignment</Text>
                </View>
              </View>
              <View style={{ alignSelf: 'center', position: 'absolute', right: 20 }}>

                <Icon1 name="angle-down" size={20} color="black" />

                <Text style={{ fontSize: 30, color: loginheaderColor }}>{this.state.assignmentCount}</Text>

              </View>
            </View >}

          </View>
        )}
      />

    );
  };

  actualDownload = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        {
          title: 'Cool Photo App Camera Permission',
          message:
            'Cool Photo App needs access to your camera ' +
            'so you can take awesome pictures.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        console.log('You can download', this.state.imageData[item.courseClass.course.imageId].content);

        RNFS.writeFile(RNFS.CachesDirectoryPath + "/some-name.png", this.state.imageData.content, 'base64')
          .then((success) => {

            return CameraRoll.save(RNFS.CachesDirectoryPath + "/some-name.png", 'photo')
          })
          .then(() => {
            ToastAndroid.show('Saved to gallery !!', ToastAndroid.SHORT)
          })

      } else {
        console.log('Camera permission denied');
      }
    } catch (err) {
      console.warn(err);
    }


  }



  async downloadFile() {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        {
          title: 'Storage Permission',
          message: 'App needs access to memory to download the file ',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.actualDownload();

      } else {
        Alert.alert(
          'Permission Denied!',
          'You need to give storage permission to download the file',
        );
      }
    } catch (err) {
      console.log(err);
    }
  }


  _renderContent = () => {

    return (

      <FlatList
        data={this.props.students}
        nestedScrollEnabled={true}

        onEndReached={this._handleLoadMore}
        onEndReachedThreshold={0.01}
        renderItem={({ item }) =>
          <View style={{ flexDirection: 'row', justifyContent: 'space-around', backgroundColor: appgrayColor, marginRight: 10, marginLeft: 10 }}>
            <Text style={{ alignSelf: 'center', fontSize: 12 }}> {this.state.studentassgnmt} </Text>
            <View style={{ flexDirection: 'row' }}>

              <TouchableOpacity style={{ width: 30, height: 30, borderRadius: 15, backgroundColor: appblueColor, alignSelf: 'center', justifyContent: 'center' }}
                onPress={() => { this.downloadFile() }}>
                <Image

                  source={images.dwnld}
                  style={{
                    width: 12,
                    height: 15, alignSelf: 'center'
                  }}

                ></Image>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => { this.bs.current.snapTo(0) }}>
                {this.state.submitvalue == false ? <Text style={Styles.uploadButton}>Upload</Text> : null}
              </TouchableOpacity>
            </View>
          </View>

        }></FlatList>
    );
  };

  _updateSections = activeSections => {
    this.setState({ activeSections });
  };


  render() {
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>
        <BottomSheet
          ref={this.bs}
          snapPoints={[330, 0]}
          renderContent={this.renderInner}
          initialSnap={1}
          callbackNode={this.fall}
          enabledGestureInteraction={true}
        />
        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 50, justifyContent: 'space-between', elevation: 10, marginTop: 1 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                NavigationService.openDrawerr();
              }}
            >
              <Image style={{ width: 20, height: 20, marginLeft: 10 }} source={images.menu} />
            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 10, marginLeft: 100 }} source={images.logo} resizeMode={'contain'} />

          <TouchableOpacity
            onPress={() => {
              this.setState({ filterpopup: true })
            }}
          >
            <Icon1 style={{ marginTop: 15, alignContent: 'flex-end', marginLeft: 80 }} name="bell-o" size={25} color={'black'} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => NavigationService.navigate('ProfileScreen')}>
            {(this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content) ?<Image
              resizeMode='contain'
              source={{ uri: `data:image/jpeg;base64,${this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content}` }}
              style={{ width: 25, height: 25, marginLeft: 5, marginRight: 20, marginTop: 15, borderWidth: 1 }}
            />:<View style={{
              width: 25,
              height: 25,
              marginLeft: 5,
              marginRight: 20,
              marginTop: 15,
              borderWidth: 1
            }}><ActivityIndicator size='small'/></View>}
          </TouchableOpacity>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          nestedScrollEnabled={true}
          style={styles.container}>
          <Loader show={this.state.showLoader} />
          {/* {console.log('this.props.courseListData', this.props.courseListData)} */}

          {/* {
            !isEmpty(this.props.courseListData) ?
              <Accordion
                sections={(this.props.courseListData && this.props.courseListData.data)}
                activeSections={this.state.activeSections}
                renderHeader={this._renderHeader}
                renderContent={this._renderContent}
                onChange={this._updateSections}
                underlayColor={'white'}
              />
              : <Text style={{ alignSelf: 'center' }}>No Assignment submitted</Text>} */}

          <FlatList
            data={(this.props.courseListData && this.props.courseListData.data)}
            nestedScrollEnabled={true}
            renderItem={({ item, index }) =>
            (
              <View>
                <TouchableOpacity
                  onPress={() => {
                    // NavigationService.navigate('ClassDetailScreen', { id: item })
                    this.storedForFiles(index)
                  }}
                >
                  <View style={{

                    paddingRight: 5,
                    paddingLeft: 5,
                    marginTop: 10,
                    justifyContent: 'center', alignItems: 'center',
                  }}>
                    <View style={styles.labelContainer}>

                      <View style={{ flexDirection: 'row' }}>

                        {!this.state.imageLoading ? <Image

                          source={{ isStatic: true, uri: `data:image/jpeg;base64,${this.state.imageData[item?.courseClass?.course?.imageId] && this.state.imageData[item?.courseClass?.course?.imageId].content}` }}
                          style={{
                            width: widthPercentageToDP('22%'),
                            borderRadius: 10,

                          }}
                        ></Image> :
                          <View style={{
                            width: widthPercentageToDP('22%'),
                            borderRadius: 10,
                          }}>
                            <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                          </View>}


                        <View style={{ width: '80%' }}>
                          <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                            <Text style={{ fontSize: 12, marginLeft: 10 }}>{item?.courseClass?.course && item?.courseClass?.course?.name} Class {item?.courseClass?.course && item?.courseClass?.course?.standard && item?.courseClass?.course?.standard?.class}</Text>


                          </View>
                          <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                            <View>
                              <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item.teacher && item.teacher.firstName} {item.teacher && item.teacher.lastName}, {item.teacher && item.teacher.experienceInYear}yr</Text>
                            </View>

                          </View>
                          <TouchableOpacity onPress={() => { this.checkForClass(index) }} style={{ alignSelf: 'center', position: 'absolute', right: 20 }}>

                            <Icon1 name="angle-down" size={20} color="black" />

                            <Text style={{ fontSize: 30, color: loginheaderColor }}>{this.state.assignmentCount}</Text>

                          </TouchableOpacity>

                          {this.state.dropdownView && index === this.state.selectedValue && <FlatList
                            data={this.props.students}
                            nestedScrollEnabled={true}

                            onEndReached={this._handleLoadMore}
                            onEndReachedThreshold={0.01}
                            renderItem={({ item }) =>
                              <View style={{ flexDirection: 'row', justifyContent: 'space-around', backgroundColor: appgrayColor, marginRight: 10, marginLeft: 10 }}>
                                <Text style={{ alignSelf: 'center', fontSize: 12 }}> {this.state.studentassgnmt} </Text>
                                <View style={{ flexDirection: 'row' }}>

                                  <TouchableOpacity style={{ width: 30, height: 30, borderRadius: 15, backgroundColor: appblueColor, alignSelf: 'center', justifyContent: 'center' }}
                                    onPress={() => { this.downloadFile() }}>
                                    <Image

                                      source={images.dwnld}
                                      style={{
                                        width: 12,
                                        height: 15, alignSelf: 'center'
                                      }}

                                    ></Image>
                                  </TouchableOpacity>
                                  <TouchableOpacity onPress={() => { this.bs.current.snapTo(0) }}>
                                    {this.state.submitvalue == false ? <Text style={Styles.uploadButton}>Upload</Text> : null}
                                  </TouchableOpacity>
                                </View>
                              </View>

                            }></FlatList>}
                        </View>
                      </View>
                    </View>
                  </View>
                </TouchableOpacity>
              </View>)

            }

          />


        </ScrollView >


      </View >
    )
  }

}

const mapStateToProps = state => ({
  courseListData: state.dash.courseListData,
  files: state.dash.fetchfilesData,
  students: state.dash.fetchfilesStudentData,
  assign: state.dash.fetchassignmentData,
  teacherImageData: state.dash.teacherImageData,
  prof: state.prof,
});
const mapDispatchToProps = {
  getFilesData, getFilesStudentAssignmentData, uploadAssignment, imageForTeacher, imageLoad, IsImageEmpty, getClassesData
}
export default connect(mapStateToProps, mapDispatchToProps)(MyFilesScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',

    width: '98%',

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
