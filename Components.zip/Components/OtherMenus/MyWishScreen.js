import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList, Image,ActivityIndicator
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import { connect } from 'react-redux';
import Loader from '../../Common/Loader';
import _ from "lodash";
import { loginheaderColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import { addWishListData, removeWishlistedData, addWishlistedData, imageLoad, IsImageEmpty } from '../../actions';
import moment from 'moment';
import AsyncStorage from '@react-native-async-storage/async-storage';
import NavigationService from '../../Services/NavigationService';
import { baseURL } from '../../util/AppConstants';

class MyWishScreen extends Component {

  constructor(props) {
    super(props);
    this.state = {
      img: '',
      name: '',
      class: '',
      teachername: '',
      teacherqualification: '',
      coursedays: '',
      courseduration: '',
      feedetails: '',
      startdate: '',
      startTime: '',
      endTime: '',
      showLoader: false,
      canceltext: '',
      addWishList: false,
      imageData: {},
      profileImage:{},
      imageLoading: true,
    }
  }

  finalWishData = [];
  async componentDidMount() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    const { addWishListData } = this.props;
    await addWishListData();

    let id = this.props.prof?.profData?.data?.imageId;
      fetch(`${baseURL}file-blobs/getImage/${id}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${AuthToken}`,
        }
      }).then(data => {
        return data.json()
      }).then(resposne => {
        let profileImage = this.state.profileImage || {};
        profileImage[resposne.data.id] = resposne.data;
        this.setState(profileImage);
      }).
        catch((error) => {
          console.log("#error", error);
        })
   
  
    this?.props?.wish?.wishlistData?.data?.map((item) => {
      let id = item.courseId.imageId;
      fetch(`${baseURL}file-blobs/getImage/${id}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${AuthToken}`,
        }
      }).then(data => {
        return data.json()
      }).then(resposne => {
        let imageData = this.state.imageData || {};
        imageData[resposne.data.id] = resposne.data;
        this.setState(imageData);
        this.setState({ imageLoading: false });
      }).
        catch((error) => {
          console.log("#error", error);
        })
    })
  }

  componentDidUpdate(prevProps) {
    if (this.props.wish != null && prevProps.wish != this.props.wish) {
      if (this?.props?.wish?.wishlistData?.data != ' ') {

        for (let i = 0; i < this?.props?.wish?.wishlistData?.data?.length; i++) {
          this.setState({
            img: this?.props?.wish?.wishlistData?.data[0]?.courseId?.image?.content,
            name: this?.props?.wish?.wishlistData?.data[0]?.courseId?.name,
            class: this?.props?.wish?.wishlistData?.data[0]?.courseId?.standard?.class,
            courseduration: this?.props?.wish?.wishlistData?.data[0]?.courseId?.courseDuration,
            feedetails: this?.props?.wish?.wishlistData?.data[0]?.courseId?.fee,
          })

          var courseDayArray = [];
          this?.props?.wish?.wishlistData?.data[0]?.courseId?.courseDays?.map(item => {
            courseDayArray.push(item.day.substring(0, 1));
          })
          this.setState({ coursedays: courseDayArray })

          let retriveDate = this?.props?.wish?.wishlistData?.data[0]?.courseId?.startDate;
          let standardDate = new Date(retriveDate)
          let finalDate = standardDate.toLocaleDateString()
          this.setState({ startdate: finalDate })

          let storedTime = standardDate.toLocaleTimeString();
          this.setState({ startTime: storedTime })

          let retriveendDate = this?.props?.wish?.wishlistData?.data[0]?.courseId?.endDate;
          let standardendDate = new Date(retriveendDate)
          let storedendTime = standardendDate.toLocaleTimeString();
          this.setState({ endTime: storedendTime })


          let storedValue = [];
          storedValue = this?.props?.wish?.wishlistData?.data[i]?.courseId?.courseUsers;


          for (let j = 0; j < storedValue?.length; j++) {
            this.setState({
              teachername: this?.props?.wish?.wishlistData?.data[i]?.courseId?.courseUsers[j]?.teacher_id?.firstName + this?.props?.wish?.wishlistData?.data[i]?.courseId?.courseUsers[j]?.teacher_id?.lastName
                + " , " + this?.props?.wish?.wishlistData?.data[i]?.courseId?.courseUsers[j]?.teacher_id?.experienceInYear,

            })

            var teacherqualArray = [];
            this?.props?.wish?.wishlistData?.data[0]?.courseId?.courseUsers[j]?.teacher_id?.qualification?.map(item => {
              teacherqualArray.push(item?.qualification)
            })
            this.setState({ teacherqualification: teacherqualArray })
          }
        }
      }
    }

    if (prevProps.removeWishListData != this.props.removeWishListData) {
      if (this.props.removeWishListData.data === "Course removed from WishList") {
        this.props.addWishListData();
      }
    }
  }

  wishlist = async (courseid) => {
    let profileData = await AsyncStorage.getItem('user_id');
    this.props.addWishlistedData(true, profileData, courseid);
  }

  remove = (courseid) => {

    this.props.removeWishlistedData(courseid);

    if (this.props.removeWishListData != null) {
      this.setState({ addWishList: false })
    }

  }

  render() {

    var storedValue = 0;
    for (let i = 0; i < this.props.ratingData && this.props.ratingData.data && this.props.ratingData.data.length; i++) {
      storedValue = storedValue + this.props.ratingData.data[i].rating;
    }
    var Avgrating = storedValue / this.props.ratingData && this.props.ratingData.totalCount

    let stars = [];
    let path = '';
    let integer_part = Math.trunc(Avgrating);
    let decimat_part = Avgrating - integer_part;
    let total_star_count = 0;
    for (let i = 1; i <= Avgrating; i++) {
      path = require('../../images/star.png');
      stars.push((<Image style={{
        width: 15,
        height: 15, marginRight: 1, marginLeft: 1
      }} source={path} />));
      total_star_count++;
    }
    if (decimat_part != 0) {
      path = require('../../images/star-half.png');
      stars.push((<Image style={{
        width: 20,
        height: 20, marginRight: 1, marginLeft: 1, position: 'relative', top: -2
      }} source={path} />));
      total_star_count++;
    }
    if (total_star_count != 5) {
      path = require('../../images/unfilled-star.png');
      for (let i = total_star_count; i < 5; i++) {
        stars.push((<Image style={{
          width: 15,
          height: 15, marginRight: 1, marginLeft: 1
        }} source={path} />));
      }
    }

    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>

        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();

              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />

          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

            <Icon1 style={{ marginLeft: 15, marginTop: 15 }} name="bell-o" size={20} color="black" />
            <TouchableOpacity onPress={()=>NavigationService.navigate('ProfileScreen')}>
            {(this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content) ?<Image
              resizeMode='contain'
              source={{uri:`data:image/jpeg;base64,${this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content}`}}
              style={{ width: 25, height: 25, marginLeft: 5, marginRight: 20, marginTop: 15,borderWidth:1 }}
            />:<View style={{
              width: 25,
              height: 25,
              marginLeft: 5,
              marginRight: 20,
              marginTop: 15,
              borderWidth: 1
            }}><ActivityIndicator size='small'/></View>}
            </TouchableOpacity>
          </View>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          nestedScrollEnabled={true}
          style={styles.container}>
          <Loader show={this.state.showLoader} />
          {this?.props?.wish?.wishlistData?.totalCount !== 0 ? <FlatList
            data={this?.props?.wish?.wishlistData && this?.props?.wish?.wishlistData.data}
            nestedScrollEnabled={true}
            onEndReachedThreshold={0.01}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => <View>

              <View style={{

                paddingRight: 5,
                paddingLeft: 5,
                marginTop: 10,
                justifyContent: 'center', alignItems: 'center'
              }}>
                {<View style={styles.labelContainer}>

                  <View style={{ flexDirection: 'row' }}>

                    {!this.state.imageLoading ? <Image

                      source={{ isStatic: true, uri: `data:image/jpeg;base64,${this.state.imageData[item.courseId.imageId] && this.state.imageData[item.courseId.imageId].content}` }}
                      style={{
                        width: widthPercentageToDP('22%'),
                        borderRadius: 10,

                      }}
                    ></Image> :
                      <View style={{
                        width: widthPercentageToDP('22%'),
                        borderRadius: 10,
                      }}>
                        <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                      </View>}


                    <View style={{ width: '80%' }}>
                      <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                        <Text style={{ fontSize: 12, marginLeft: 10 }}>{item?.courseId?.name} Class-{item?.courseId?.standard?.class}</Text>
                        <View style={{ flexDirection: 'row', marginRight: 20 }}>
                          {stars}
                        </View>
                      </View>
                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                        <View>
                          <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12, color: '#888888' }}>By {item?.courseId?.courseUsers?.map((item) => item?.teacher_id?.firstName)} {item?.courseId?.courseUsers?.map((item) => item?.teacher_id?.lastName)}{', '} {item?.courseId?.courseUsers?.map((item) => item?.teacher_id?.experienceInYear)}yr</Text>
                          <Text style={{ marginLeft: 10, fontSize: 12 }}>{item?.courseId?.courseUsers?.map((item) => item?.teacher_id?.qualification?.map((item) => item?.qualification))}</Text>
                        </View>
                        <View style={{ flexDirection: 'row' }}>
                          {item.status === true ? <TouchableOpacity onPress={() => this.remove(item.courseId.id)}>
                            <Image
                              resizeMode='contain'
                              source={images.likeselect}
                              style={{
                                width: 20,
                                height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(30)
                              }}
                            ></Image>
                          </TouchableOpacity> :

                            <TouchableOpacity onPress={() => this.wishlist(item.courseId.id)}>
                              <Image
                                resizeMode='contain'
                                source={images.shortlist_blck}
                                style={{
                                  width: 20,
                                  height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(30)
                                }}
                              ></Image>
                            </TouchableOpacity>}
                          {/* {item.status === true && <TouchableOpacity onPress={() => this.remove(item.courseId.id)}>
                            <Image
                              resizeMode='contain'
                              source={images.likeselect}
                              style={{
                                width: 20,
                                height: 20, alignSelf: 'center', marginLeft: widthPercentageToDP(30)
                              }}
                            ></Image>
                          </TouchableOpacity>} */}

                          <Image
                            resizeMode='contain'
                            source={images.confirmation}
                            style={{
                              width: 20,
                              height: 20, marginLeft: 2
                            }}
                          ></Image>
                        </View>
                      </View>
                      <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                      <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10, color: '#888888' }}>TIMING (START FROM {moment(item?.courseId?.createdDate).format('DD-MM-YYYY')})</Text>
                      <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                        <Text style={{ fontSize: 10, marginLeft: 10, }}>{moment(item?.courseId?.startDate).format('hh:mm A')} to {moment(item?.courseId?.endDate).format('hh:mm A')}</Text>
                        <View style={{ flexDirection: 'row', marginRight: 10 }}>
                          <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10 }}>{item?.courseId?.courseDays?.map(item => item?.day.substring(0, 1))}</Text>
                        </View>
                      </View>

                      <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 5 }}>
                        <View>
                          <Text style={{ fontSize: 10, color: '#888888' }}>Number of Claases</Text>
                          <Text style={{ fontSize: 10 }}>{item?.courseId?.courseClass?.length}</Text>
                        </View>
                        <View style={{ right: 20 }}>
                          <Text style={{ fontSize: 10, color: '#888888' }}>{item?.courseSubscriptionModes?.map((item) => item?.subscriptionModeId?.name)}</Text>
                          <Text style={{ fontSize: 10 }}>₹{' '}{item?.courseId?.fee}</Text>

                        </View>

                      </View>
                      <TouchableOpacity onPress={async () => {

                        this.props.navigation.navigate('SearchDetailActivity', { courseId: item.courseId.id });

                      }} style={Styles.wishregistercoursebutton}>
                        <Text style={{ color: 'white', justifyContent: 'center', alignContent: 'center', alignSelf: 'center' }}>Register</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>}
              </View>

            </View>
            }
          /> : <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', margin: 20 }}>
              <Text>Course is not Wishlisted yet</Text>
            </View>}

        </ScrollView >

        <View style={{
          flex: 1,
          flexDirection: 'row',
          flexWrap: 'wrap',
          alignContent: 'center',
          justifyContent: 'space-around',
          position: 'absolute',
          bottom: 0,
          alignSelf: 'center'
        }}>

        </View>
      </View >
    )
  }

}

const mapStateToProps = state => ({
  wish: state.wish,
  ratingData: state.dash.ratingData,
  addtoWishListData: state.dash.addtoWishListData,
  removeWishListData: state.dash.removeWishListData,
  prof: state.prof,
});

const mapDispatchToProps = {
  addWishListData, addWishlistedData, removeWishlistedData,
  // imageLoad, IsImageEmpty
};

export default connect(mapStateToProps, mapDispatchToProps)(MyWishScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
