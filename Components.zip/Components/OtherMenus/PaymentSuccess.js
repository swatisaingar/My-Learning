import React, { Component } from 'react';
import {
    Platform,
    StyleSheet,
    Text,
    View, TouchableOpacity, Image, FlatList, StatusBar, ActivityIndicator, ImageBackground, Dimensions, ScrollView, Modal, TouchableWithoutFeedback, WebView
} from 'react-native';
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import images from '../../util/img';
import { loginheaderColor, appheadertextColor } from '../../util/AppConstants';
import NavigationService from '../../Services/NavigationService';
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { connect } from 'react-redux';
import moment from 'moment';


class PaymentSuccess extends React.Component {
    constructor(props) {

        super(props);
        this.state = {
            searchList: [{
                'class': "CHemistry Class 12th",
                'teacher': 'By Sooraj Rai',
            },
            {
                'class': "CHemistry Class 10th",
                'teacher': 'By Sooraj Rai',
            }],
            canceltext: false
        }

    }

    componentDidMount() {
        var arr = [];
        StatusBar.setHidden(false);
        console.log('getPaymentData', this.props.getPaymentData)
    }
    static navigationOptions = ({ navigation }) => {
        return {
            headerShown: false,
            tabBarLabel: 'Active',

        }
    };
    render() {

        return (

            <View style={{ backgroundColor: 'white', flex: 1 }}>
                <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
                    <View style={{ marginTop: 15 }} >
                        <TouchableOpacity
                            onPress={() => {
                                this.props.navigation.goBack();
                            }}
                        >
                            <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />
                        </TouchableOpacity>
                    </View>
                    <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />

                    <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>
                        <Icon1 style={{ marginLeft: 15 }} name="bell-o" size={20} color="black" />
                    </View>
                </View>
                <View style={{ backgroundColor: '#3BB54A', height: 160, flexDirection: 'row' }}>
                    <Image style={{ color: 'white', alignSelf: 'center', fontSize: 20, marginLeft: 30 }} source={images.success} resizeMode={'contain'} />
                    <Text style={{ color: 'white', alignSelf: 'center', fontSize: 20, marginLeft: 10 }}>Payment Successful</Text>
                </View>
                <View style={{ flexDirection: 'column', margin: 10 }}>
                    <Text style={{ color: '#888888' }}>
                        Transaction ID
                    </Text>
                    <Text>
                        {this?.props?.getPaymentData?.data?.orderId}
                    </Text>
                </View>
                <View style={{ flexDirection: 'column', marginLeft: 10 }}>
                    <Text style={{ color: '#888888' }}>
                        Amount
                    </Text>
                        <Text style={{ color: '#FAA21C' }}>
                        ₹{' '}{(this?.props?.getPaymentData?.data?.amount / 100)}
                        </Text>

                </View>
                <View style={{ flexDirection: 'column', margin: 10 }}>
                    <Text style={{ color: '#888888' }}>
                        Date & Time
                    </Text>
                    <Text>
                        {moment(this?.props?.getPaymentData?.data?.txnTime).format('DD-MM-YYYY')}{' '}
                        {moment(this?.props?.getPaymentData?.data?.txnTime).format('hh:mm')}
                    </Text>
                </View>
                <View style={{ flexDirection: 'column', marginLeft: 10 }}>
                    <Text style={{ color: '#888888' }}>
                        Payment ID
                    </Text>
                    <Text>
                        {this?.props?.getPaymentData?.data?.key}
                    </Text>
                </View>
                <TouchableOpacity style={{ position: 'absolute', bottom: 10, alignSelf: 'center' }} onPress={() => NavigationService.navigate('Home')}>
                    <Text style={{ alignSelf: 'center', color: '#165ADC' }}>Back to Home</Text>
                </TouchableOpacity>
            </View>

        );
    }
}

const mapStateToProps = state => ({
    getPaymentData: state.dash.getPaymentData,
});

export default connect(mapStateToProps)(PaymentSuccess);