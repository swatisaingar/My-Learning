import React, { Component, useState } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput, Image, ActivityIndicator, FlatList,
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import { connect } from 'react-redux';
import Loader from '../../Common/Loader';
import _, { values } from "lodash";
import { heightPercentageToDP } from 'react-native-responsive-screen';
import { appblueColor, appheadertextColor, appgrayColor, white, updateTeacherProfileURL } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import { Dropdown } from 'react-native-material-dropdown';
import SectionedMultiSelect from 'react-native-sectioned-multi-select';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { profile, updateprofile, profileWithoutImg, imageWithoutLoopLoad, imageWithoutLoopLoadForBankDoc, imageUpload, fetchBankImageData } from '../../actions';
import csc from 'country-state-city';
var params;
import BottomSheet from 'reanimated-bottom-sheet';
import Animated from 'react-native-reanimated';
import ImagePicker from 'react-native-image-crop-picker';
import NavigationService from '../../Services/NavigationService';
import { isNumber, isEmpty, now } from 'lodash';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../../util/AppConstants';


class ProfileScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showLoader: false,
      fname: '',
      lname: '',
      email: '',
      mob: '',
      mob1: '',
      male: true,
      female: false,
      saving: true,
      current: false,
      img: '',
      cArr: [],
      sArr: [],
      selectedCountry: '',
      selectedState: '',
      address1: '',
      city: '',
      pincode: '',
      category: [],
      language: [],
      emailValid: true,
      standard: '',
      selectedItems: [],
      catListValues: [],
      langKnown: [],
      standardKnown: '',
      categorytemp: [],
      standardtemp: '',
      languagetemp: [],
      standardId: '',
      standardClass: '',
      languageId: '',
      languageClass: '',
      catError: null,
      langError: null,
      standardError: null,
      panNumber: '', year: '',
      accountnumber: '', accountholder: '', ifsccode: '',
      selectedmonth: '',
      //qualifications: [], 
      accountype: '', TcategoryId: [], Tcategory: [], qualification: [],
      yearArr: [], validation1: false, validation: false, finalCountry: '', finalState: '',
      teacherQualificationData: [],
      showAddMoreQualification: false,
      tempQualification: '',
      tempUniversity: '',
      tempYearOfPassing: '',
      bankDetails: '',
      aadhar: '',
      account_type: '',
      isFreelancer: true,
      description: '',
      selectedLanguages: [],
      bankImageData: {},

      selectedmonth: '', qualifications: [], accountype: '', TcategoryId: [], Tcategory: [], qualification: [],
      yearArr: [], validation1: false, validation: false, finalCountry: '', finalState: '',
      imageData: {},
      imageLoading: true,
      profileImage: {}
    }
    params = this.props.navigation.state.params;
  }

  bs = React.createRef();
  fall = new Animated.Value(1)

  takePhotoFromCamera = () => {
    ImagePicker.openCamera({
      width: 200,
      height: 200,
      cropping: true,
      includeBase64: true,
      compressImageMaxWidth: 1000,
      compressImageMaxHeight: 1000,
      compressImageQuality: 1,
    }).then(image => {
      let imageStored = this.props.imagewithoutloopData.data;
      imageStored.content = image.data;
      imageStored.width = image.width;
      imageStored.height = image.height;
      imageStored.contentContentType = image.mime;
      imageStored.contentSize = image.size;
      imageStored.createTime = image.modificationDate;
      imageStored.name = image.path;
      this.props.imageUpload(imageStored)
      this.bs.current.snapTo(1)
    }).catch(e => {
      console.log('exception value', e);
    });
  }

  onChangeCntryText = (value) => {
    this.setState({ selectedCountry: value });
    var states = csc.getStatesOfCountry(value[0]);
    var dropdownArr = [];
    for (var k = 0; k < states.length; k++) {
      var obj = {};
      obj.value = states[k].name;
      obj.id = states[k].id;
      dropdownArr.push(obj);
    }

    this.setState({
      stateArr: dropdownArr,
      selectedState: '',
    })
  }

  onSelectedLanguagesChange = (selectedLang) => {
    console.log("lang selected ==========", selectedLang)
    this.setState({ selectedLanguages: selectedLang });
  };

  onChangeLanguage = (langValue) => {
    this.setState({ langKnown: langValue })


    var filteredCategoryObject = this.state.language && this.state.language.filter(data => (langValue.includes(data.id)));
    this.setState({ languagetemp: filteredCategoryObject })
  }

  onstandardItemChange = (standardvalue) => {
    this.setState({ standardKnown: standardvalue })

    var filteredCategoryObject = this.state.standard && this.state.standard.filter(data => (standardvalue.includes(data.id)));
    let selectedStandardObjectID = filteredCategoryObject && filteredCategoryObject[0].id;
    let selectedStandardObjectClass = filteredCategoryObject && filteredCategoryObject[0].value;
    this.setState({ standardId: selectedStandardObjectID, standardClass: selectedStandardObjectClass })

  }

  onSelectedItemsCatChange = (values) => {
    this.setState({ category: values })
    // var allselectArray = [];
    // var unselectedArray = [];
    // allselectArray.push(values)

    // var unselectedvalue = this.state.catListValues.filter(item => (!values.includes(item.id)));
    // unselectedArray.push(unselectedvalue);
    // if (allselectArray != '' || unselectedArray != '') {
    //   this.setState({ category: values })
    // }

    var filteredCategoryObject = this.state.catListValues.filter(categoryData => (values.includes(categoryData.id)));

    this.setState({ categorytemp: filteredCategoryObject })

  };

  onSelectedCatChange = (values) => {
    this.setState({ Tcategory: values })
  };

  onSelectedQualification = (values) => {
    this.setState({ qualification: values })
  };
  onChangelangText = (values) => {
    this.setState({ languageClass: values })
  }

  choosePhotoFromLibrary = () => {
    ImagePicker.openPicker({
      width: 200,
      height: 200,
      cropping: true,
      includeBase64: true,
      compressImageMaxWidth: 1000,
      compressImageMaxHeight: 1000,
      compressImageQuality: 1,
    }).then(image => {
      let imageStored = this.state.profileImage[this.props.prof?.profData?.data?.imageId];
      imageStored.content = image.data;
      imageStored.width = image.width;
      imageStored.height = image.height;
      imageStored.contentContentType = image.mime;
      imageStored.contentSize = image.size;
      imageStored.createTime = image.modificationDate;
      imageStored.name = image.path;
      this.props.imageUpload(imageStored)
      this.bs.current.snapTo(1)
    }).catch(e => {
      console.log('exception value', e);
    });
  }


  renderInner = () => (
    <View style={{ backgroundColor: appgrayColor, borderTopStartRadius: 15, borderTopEndRadius: 15, height: '100%' }}>
      <View style={{ alignItems: 'center', marginTop: 20 }}>
        <Text style={{ fontSize: 25, fontWeight: '900' }}>Upload Photo</Text>
        <Text style={{ fontSize: 16, marginTop: 10 }}>Choose Your Profile Picture</Text>
      </View>

      <TouchableOpacity style={{ backgroundColor: 'white', marginTop: 30, width: '80%', alignSelf: 'center', borderWidth: 1, borderRadius: 10, height: '12%' }}
        onPress={this.takePhotoFromCamera}>
        <Text style={{ fontSize: 18, alignSelf: 'center', padding: 5 }}>Take Photo</Text>
      </TouchableOpacity>

      <TouchableOpacity style={{ backgroundColor: 'white', marginTop: 30, width: '80%', alignSelf: 'center', borderWidth: 1, borderRadius: 10, height: '12%' }}
        onPress={this.choosePhotoFromLibrary}>
        <Text style={{ fontSize: 18, alignSelf: 'center', padding: 5 }}>Choose From Your Library</Text>

      </TouchableOpacity>
      <TouchableOpacity style={{ backgroundColor: 'white', marginTop: 30, width: '80%', alignSelf: 'center', borderWidth: 1, borderRadius: 10, height: '12%' }} onPress={() => this.bs.current.snapTo(1)}>
        <Text style={{ fontSize: 18, alignSelf: 'center', padding: 5 }}>Cancel</Text>
      </TouchableOpacity>
    </View>
  );

  async componentDidUpdate(prevProps) {
    if (this.props.prof != null) {
      if (this.props.prof != prevProps.prof) {
        if (this.props.prof.profimgData.data && this.props.prof.profimgData.data != null || this.props.prof.profData.data && this.props.prof.profData.data != null) {

          if (this.props.selctType.typeselectedData.logintype == 'Teacher') {
            console.log("Qualifications----------", this.props.prof.profData.data.qualifications)
            console.log("Bank Details----------", this.props.prof.profData.data.payment)
            console.log("Language Details----------", this.props.prof.profData.data.language)


            // this.fetchBankDocumentImageData(this.props.prof.profData.data.payment.imageId)

            this.setState({
              teacherQualificationData: this.props.prof.profData.data.qualifications,
              isFreelancer: this.props.prof.profData.data.isFreelancer,
              bankDetails: this.props.prof.profData.data.payment,
              aadhar: this.props.prof.profData.data.payment.adhaarNumber,
              account_type: this.props.prof.profData.data.payment.account_type == 1 ? 'Savings' : 'Current',
              languageArray: this.props.prof.profData.data.language,
              selectedLanguages: this.props.prof.profData.data.language,
            })
          }


          if (this.props.prof.profimgData.data.gender == 'FEMALE') {
            this.setState({
              fname: this.props.prof.profimgData.data.firstName,
              lname: this.props.prof.profimgData.data.lastName,
              mob: this.props.prof.profimgData.data.contactNumber,
              email: this.props.prof.profimgData.data.email,
              // img: this.props.prof.profData.data.image.content,
              female: true,
              male: false,
              selectedCountry: this.props.prof.profimgData.data.address.country,
              selectedState: this.props.prof.profimgData.data.address.state,
              address1: this.props.prof.profimgData.data.address.street1,
              city: this.props.prof.profimgData.data.address.city,
              pincode: this.props.prof.profimgData.data.address.pin,
              categorytemp: this.props.prof.profimgData.data.preferredCategory,
              languagetemp: this.props.prof.profimgData.data.language,
              standardId: this.props.prof.profimgData.data.standard && this.props.prof.profimgData.data.standard.id,
              standardClass: this.props.prof.profimgData.data.standard && this.props.prof.profimgData.data.standard.class,
              languageId: this.props.prof.profimgData.data.language && this.props.prof.profimgData.data.language.map((item) => item.id),
              languageClass: this.props.prof.profimgData.data.language && this.props.prof.profimgData.data.language.map((item) => item.name),
              panNumber: this.props.prof.profimgData.data && this.props.prof.profimgData.data.payment && this.props.prof.profimgData.data.payment.panNumber,
              ifsccode: this.props.prof.profimgData.data && this.props.prof.profimgData.data.payment && this.props.prof.profimgData.data.payment.ifscCode,
              accountholder: this.props.prof.profimgData.data && this.props.prof.profimgData.data.payment && this.props.prof.profimgData.data.payment.holderName,
              accountnumber: this.props.prof.profimgData.data && this.props.prof.profimgData.data.payment && this.props.prof.profimgData.data.payment.accountNumber,
              current: true,
              saving: false,
              year: this.props.prof.profimgData.data.experienceInYear,
              selectedmonth: this.props.prof.profimgData.data.experienceInMonths,
              qualificationTemp: this.props.prof.profimgData.data.qualifications,
              mob1: this.props.prof.profimgData.data.parentNumber
            })
            let stateTemparray = []
            stateTemparray.push(this.props.prof.profimgData.data.address.state)
            this.setState({ selectedState: stateTemparray })
            let countryTemparray = []
            countryTemparray.push(this.props.prof.profimgData.data.address.country)
            this.setState({ selectedCountry: countryTemparray })
            var states = csc.getStatesOfCountry(this.props.prof.profimgData.data.address.country);
            var dropdownArr = [];
            for (var k = 0; k < states.length; k++) {
              var obj = {};
              obj.value = states[k].name;
              obj.id = states[k].id;
              dropdownArr.push(obj);
            }
            this.setState({ stateArr: dropdownArr })
            let tempArray = [];
            this.props.prof.profimgData.data && this.props.prof.profimgData.data.preferredCategory && this.props.prof.profimgData.data.preferredCategory.map(item => {
              tempArray.push(item.id)
            })
            this.setState({ category: tempArray })

            let temp = [];
            for (let i = 0; i < (this.props.prof.profimgData.data && this.props.prof.profimgData.data.qualifications && this.props.prof.profimgData.data.qualifications.length); i++) {
              var data = this.props.prof.profimgData.data.qualifications[i];
              var namevalue = { id: data.id, value: data.qualification };
              temp.push(namevalue);
            }
            this.setState({
              qualifications: temp
            })

            let tempPref = [];
            for (let i = 0; i < (this.props.prof.profimgData.data && this.props.prof.profimgData.data.preferredCategory && this.props.prof.profimgData.data.preferredCategory.length); i++) {
              var data = this.props.prof.profimgData.data.preferredCategory[i];
              var namevalue = { id: data.id, value: data.name };
              tempPref.push(namevalue);
            }
            this.setState({
              TcategoryId: tempPref
            })


            let selectedStandardId = this.props.prof.profimgData.data && this.props.prof.profimgData.data.standard && this.props.prof.profimgData.data.standard.id;
            let selectedStandardArray = [];
            selectedStandardArray.push(selectedStandardId)
            this.setState({ standardKnown: selectedStandardArray })

            let selectedLanguageId = this.props.prof.profimgData.data && this.props.prof.profimgData.data.language && this.props.prof.profimgData.data.language.map((item) => item.id);
            this.setState({ langKnown: selectedLanguageId });

          }
          else {
            this.setState({
              fname: this.props.prof.profimgData.data.firstName,
              lname: this.props.prof.profimgData.data.lastName,
              mob: this.props.prof.profimgData.data.contactNumber,
              email: this.props.prof.profimgData.data.email,
              // img: this.props.prof.profData.data.image.content,
              male: true, female: false,
              saving: true, current: false,
              address1: this.props.prof.profimgData.data.address.street1,
              city: this.props.prof.profimgData.data.address.city,
              pincode: this.props.prof.profimgData.data.address.pin,
              selectedCountry: this.props.prof.profimgData.data.address.country,
              selectedState: this.props.prof.profimgData.data.address.state,
              categorytemp: this.props.prof.profimgData.data.preferredCategory,
              languagetemp: this.props.prof.profimgData.data.language,
              standardId: this.props.prof.profimgData.data.standard && this.props.prof.profimgData.data.standard.id,
              standardClass: this.props.prof.profimgData.data.standard && this.props.prof.profimgData.data.standard.class,
              languageId: this.props.prof.profimgData.data.language && this.props.prof.profimgData.data.language.map((item) => item.id),
              languageClass: this.props.prof.profimgData.data.language && this.props.prof.profimgData.data.language.map((item) => item.name),
              panNumber: this.props.prof.profimgData.data && this.props.prof.profimgData.data.payment && this.props.prof.profimgData.data.payment.panNumber,
              ifsccode: this.props.prof.profimgData.data && this.props.prof.profimgData.data.payment && this.props.prof.profimgData.data.payment.ifscCode,
              accountholder: this.props.prof.profimgData.data && this.props.prof.profimgData.data.payment && this.props.prof.profimgData.data.payment.holderName,
              accountnumber: this.props.prof.profimgData.data && this.props.prof.profimgData.data.payment && this.props.prof.profimgData.data.payment.accountNumber,
              year: this.props.prof.profimgData.data.experienceInYear,
              selectedmonth: this.props.prof.profimgData.data.experienceInMonths,
              mob1: this.props.prof.profimgData.data.parentNumber,
              qualificationTemp: this.props.prof.profimgData.data && this.props.prof.profimgData.data.qualifications,
            })
            let stateTemparray = []
            stateTemparray.push(this.props.prof.profimgData.data.address.state)
            this.setState({ selectedState: stateTemparray })
            let countryTemparray = []
            countryTemparray.push(this.props.prof.profimgData.data.address.country)
            this.setState({ selectedCountry: countryTemparray })
            var states = csc.getStatesOfCountry(this.props.prof.profimgData.data.address.country);
            var dropdownArr = [];
            for (var k = 0; k < states.length; k++) {
              var obj = {};
              obj.value = states[k].name;
              obj.id = states[k].id;
              dropdownArr.push(obj);
            }
            this.setState({ stateArr: dropdownArr })

            let tempArray = [];
            this.props.prof.profimgData.data.preferredCategory && this.props.prof.profimgData.data.preferredCategory.map(item => {
              tempArray.push(item.id)
            })
            this.setState({ category: tempArray });

            let temp = [];
            for (let i = 0; i < (this.props.prof.profimgData.data && this.props.prof.profimgData.data.qualifications && this.props.prof.profimgData.data.qualifications.length); i++) {
              var data = this.props.prof.profimgData.data.qualifications[i];
              var namevalue = { id: data.id, value: data.qualification };
              temp.push(namevalue);
            }
            this.setState({
              qualifications: temp
            })

            let tempPref = [];
            for (let i = 0; i < (this.props.prof.profimgData.data && this.props.prof.profimgData.data.preferredCategory && this.props.prof.profimgData.data.preferredCategory.length); i++) {
              var data = this.props.prof.profimgData.data.preferredCategory[i];
              var namevalue = { id: data.id, value: data.name };
              tempPref.push(namevalue);
            }
            this.setState({
              TcategoryId: tempPref
            })

            let selectedStandardId = this.props.prof.profimgData.data && this.props.prof.profimgData.data.standard && this.props.prof.profimgData.data.standard.id;
            let selectedStandardArray = [];
            selectedStandardArray.push(selectedStandardId)

            this.setState({ standardKnown: selectedStandardArray })

            let selectedLanguageId = this.props.prof.profimgData.data && this.props.prof.profimgData.data.language && this.props.prof.profimgData.data.language.map((item) => item.id);
            this.setState({ langKnown: selectedLanguageId });

          }
        }

      }
    }
    if (prevProps.imagewithoutloopData != this.props.imagewithoutloopData) {
      this.setState({
        img: this.props.imagewithoutloopData.data.content
      })
    }


    if (prevProps.imageForBankDocData != this.props.imageForBankDocData) {
      console.log("fetch bank image doc data ==============", this.props.imageForBankDocData)
      this.setState({ bankImageData: this.props.imageForBankDocData.data })
    }

  }

  onChangeStateText = (value) => {
    this.setState({
      selectedState: value,
    })
  }


  handlefname = (text) => {
    this.setState({ fname: text })
  }
  handlelname = (text) => {
    this.setState({ lname: text })
  }
  handleemail = (text) => {
    this.setState({ email: text })
  }
  handlemob = (text) => {
    this.setState({ mob: text })
  }

  handlemob1 = (text) => {
    this.setState({ mob1: text })
  }


  // method to add qualification to be added in existing qualification
  addMoreQualification(showAddMore) {

    if ((this.state.tempQualification != '') && (this.state.tempUniversity != '') && ((this.state.tempYearOfPassing != ''))) {
      var tempArray = this.props.prof.profData && this.props.prof.profData.data && this.props.prof.profData.data.qualifications
      console.log("Before update qualification-----------", this.props.prof.profData.data.qualifications)
      console.log("tempArray======", tempArray)



      // createdBy: "1f90a1dc-d461-417e-a3b5-6b1e05cbac0d"
      // createdDate: "2021-02-12T12:14:17.000Z"
      // experience: null
      // id: 1
      // lastModifiedBy: "1f90a1dc-d461-417e-a3b5-6b1e05cbac0d"
      // lastModifiedDate: "2021-02-22T10:29:04.000Z"
      // qualification: "asdasd"
      // status: true
      // university: "ASDvDFS"
      // yearOfPassing: "2019"
      var data = {
        qualification: this.state.tempQualification,
        university: this.state.tempUniversity,
        yearOfPassing: this.state.tempYearOfPassing,
        status: true,
        // experience:null,
        // createdBy:'',
        // createdDate:'',
        // lastModifiedBy:'',
        // lastModifiedDate:'',
      }
      tempArray.push(data)
      console.log("TempArry", tempArray)
      this.setState({ teacherQualificationData: this.tempArray, tempQualification: '', tempUniversity: '', tempYearOfPassing: '', })
    }

    this.setState({ showAddMoreQualification: showAddMore, })

  }



  updateQualification(text, event, index) {

    var tempArray = []
    //var tempArray = !isEmpty(this.props.prof.profData.data.qualifications) ? this.props.prof.profData.data.qualifications : this.state.teacherQualificationData  ;
    this.tempArray = this.props.prof.profData.data.qualifications
    console.log("Before update qualification-----------", this.props.prof.profData.data.qualifications)
    console.log("tempArray======", this.tempArray)
    //     if(!isEmpty(tempArray))
    //    {this.tempArray.map(item => {                  
    //       var findItem = tempArray.find(x => x.id =='');
    //       console.log("findItem------" , findItem)
    //       if (!findItem)
    //       {
    //         var data = {
    //           id:'',
    //           qualification:text,
    //         }
    //         //uniqueTags.push(item);
    //         this.tempArray.push(data)
    //       }
    //       else{

    //           let index =  this.tempArray.findIndex(item => item.id == '');
    //           item.qualification = text
    //           this.tempArray[index] = {... item, };
    //           this.setState({ tempArray });
    //           // reset existing class item status with new status

    //       }

    //   });

    // }
    // else{
    //   var data = {
    //     id:'',
    //     qualification:text,
    //   }
    //   //uniqueTags.push(item);
    //   this.tempArray.push(data)
    // }

    let apiData = this.props.prof && this.props.prof.profData && this.props.prof.profData.data;
    var qualificationList = apiData.qualifications
    var item = qualificationList[index]
    switch (event) {
      case 'qualification':
        item.qualification = text;
        break;

      case 'university':
        item.university = text;
        break;

      case 'year':
        item.yearOfPassing = text;
        break;
    }

    qualificationList[index] = { ...item };
    this.setState({ qualificationList });
    this.setState({ teacherQualificationData: qualificationList })
    console.log("Update Qualification========", qualificationList)

    console.log("TempArry", this.tempArray)
    this.setState({ teacherQualificationData: this.tempArray })
  }



  updateUniversity(text) {
    var data = {
      qualification: text,
    }
    var temp = this.state.teacherQualificationData;
    temp.push(data)

    this.setState({ teacherQualificationData: temp })
  }
  updateYearOfPassing(text) {
    var data = {
      qualification: text,
    }
    var temp = this.state.teacherQualificationData;
    temp.push(data)

    this.setState({ teacherQualificationData: temp })
  }

  onChangecategoryText = (text, index, data) => {
    let Tcategory = data[index].value
    this.setState({
      Tcategory: Tcategory
    })

    var catArr = [];
    for (var k = 0; k < this.props.prof.profimgData.data && this.props.prof.profimgData.data.preferredCategory.length; k++) {
      var obj = {};
      obj.value = this.props.prof.profimgData.data && this.props.prof.profimgData.data.preferredCategory[k].name;
      obj.id = this.props.prof.profimgData.data && this.props.prof.profimgData.data.preferredCategory[k].id;
      catArr.push(obj);
    }

    this.setState({
      TcategoryId: catArr,
    })
  }

  handleaccountnumber = (text) => {
    this.setState({ accountnumber: text })
  }

  handleaccountholder = (text) => {
    this.setState({ accountholder: text })
  }

  handleifsc = (text) => {
    this.setState({ ifsccode: text })
  }

  handlepan = (text) => {
    this.setState({ panNumber: text })
  }

  handleEmail = (text) => {
    this.setState({ email: text })
    let mailformat = /^[a-zA-Z0-9.]+@[a-zA-Z0-9]+\.[A-Za-z]+$/;
    if (mailformat.test(text)) {
      this.setState({ emailValid: false })
    } else {
      this.setState({ emailValid: true })

    }
  }

  onChangeexpText = (data) => {
    this.setState({
      year: data
    })
  }

  onChangeexpText1 = (text) => {
    this.setState({
      selectedmonth: text
    })
  }

  handleadd1 = (text) => {
    if (text.length <= 3) {
      this.setState({ validation1: true });
      this.setState({ address1: text });
    }
    if (text.length === 10) {
      this.setState({ validation1: false });
      this.setState({ address1: text });
    }
    if (text.length > 100) {
      this.setState({ address1: text });
      alert("Address should not less than 100");
    }

    this.setState({ address1: text })
  }
  handleadd2 = (text) => {
    if (text.length <= 3) {
      this.setState({ validation: true });
      this.setState({ city: text });
    }
    if (text.length === 3) {
      this.setState({ validation: false });
      this.setState({ city: text });
    }
    if (text.length > 100) {
      this.setState({ city: text });
      alert("City should not less than 100");
    }

    if (!isNaN(parseInt(text[0]))) {
      this.setState({ city: text });
      alert("City should not start with Number");
    }

    var hasNumber = /\d/;
    if (hasNumber.test(text)) {
      alert('City does not contain number')
    }
    this.setState({ city: text })
  }
  handleadd3 = (text) => {
    this.setState({ pincode: text })
  }

  handleDescription = (text) => {
    this.setState({ description: text })
  }
  async componentDidMount() {
    var cc = csc.getAllCountries();
    var dropdownArr = [];
    for (var k = 0; k < cc.length; k++) {
      var obj = {};
      obj.value = cc[k].name;
      obj.id = cc[k].id;
      dropdownArr.push(obj);
    }
    this.setState({
      cArr: dropdownArr
    })
    var downArr = [];
    for (var k = 0; k < 5; k++) {
      var obj = {};
      obj.value = k;
      obj.id = k;
      downArr.push(obj);
    }
    this.setState({
      yearArr: downArr
    })

    const { profile } = this.props;
    let profileData = await AsyncStorage.getItem('user_id');
    await profile(profileData);

    this.props.profileWithoutImg(profileData)
    this.fetchBankDocumentImageData(this.props.prof?.profData?.data?.payment?.imageId)
    this.props.imageWithoutLoopLoad(this.props.prof?.profData?.data?.imageId);
    let AuthToken = await AsyncStorage.getItem('id_token');
    let id = this.props.prof?.profData?.data?.imageId;
    fetch(`${baseURL}/file-blobs/getImage/${id}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {
      let imageData = this.state.imageData || {};
      imageData[resposne.data.id] = resposne.data;
      this.setState(imageData);
      this.setState({ imageLoading: false });
    }).
      catch((error) => {
        console.log("#error", error);
      })


    let profileid = this.props.prof.profData.data.imageId;
    fetch(`${baseURL}file-blobs/getImage/${profileid}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      }
    }).then(data => {
      return data.json()
    }).then(resposne => {

      let profileImage = this.state.profileImage || {};
      profileImage[resposne.data.id] = resposne.data;
      this.setState(profileImage);
      this.setState({imageLoading:false})
    }).
      catch((error) => {
        console.log("#error", error);
      })



  }

  async getlanguages() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    var lanData = []
    fetch(`${baseURL}languages`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AuthToken}`,
      },
    })
      .then(response =>
        response.json())
      .then(responseJson => {
        var len = responseJson && responseJson.data.length
        if (len > 0) {
          for (let i = 0; i < len; i++) {
            var data = responseJson.data[i]
            var languagelist = { id: data.id, value: data.name }
            lanData.push(languagelist)
          }
        }
        this.setState({
          language: lanData,
          languageArray: responseJson.data,
        })
      })
      .catch(e => {
        console.log('Exception value', e)
      })
  }
  async componentWillMount() {
    this.getData();
    this.getlanguages();
    this.getStandard();
  }


  fetchBankDocumentImageData(imageId) {
    console.log("BankImage data id ======", imageId)
    this.props.fetchBankImageData(imageId)
  }

  async getData() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    var temp = [];
    fetch(`${baseURL}categories`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${AuthToken}`
      }
    }).then(response => response.json())
      .then(responseJson => {
        let cateListData = responseJson.data.length;
        if (cateListData > 0) {
          for (let i = 0; i < cateListData; i++) {
            var data = responseJson.data[i];
            var namevalue = { id: data.id, value: data.name };
            temp.push(namevalue);
          }
        }
        this.setState({
          catListValues: temp
        });
      })
      .catch(e => {
        console.log('Exception value', e);
      })
  }


  async getStandard() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    var standardData = [];
    fetch(`${baseURL}classes`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${AuthToken}`
      }
    }).then(response => response.json())
      .then(responseJson => {

        var len = responseJson.data.length;
        if (len > 0) {
          for (let i = 0; i < len; i++) {
            var data = responseJson.data[i];

            var standardDatavalue = { id: data.id, value: data.class };
            standardData.push(standardDatavalue);
          }
        }
        this.setState({
          standard: standardData
        })
      })
      .catch(e => {
        console.log('Exception value', e);
      })
  }


  updatedprofileValue = async (values) => {


    let apiData = this.props.prof && this.props.prof.profData && this.props.prof.profData.data;
    if (this.props.selctType.typeselectedData.logintype == "Student") {

      apiData.firstName = values.fname;
      apiData.parentNumber = values.mob1;
      apiData.lastName = values.lname;
      apiData.email = values.email;
      if (values.female == true) {
        apiData.gender = 'FEMALE';
      }
      else {
        apiData.gender = 'MALE';
      }

      apiData.address.state = values.selectedState;
      apiData.address.street1 = values.address1;
      apiData.address.city = values.city;
      apiData.address.pin = values.pincode;
      apiData.address.country = values.selectedCountry;
      // apiData.image = [];
      apiData.contactNumber = values.mob;
      apiData.preferredCategory = values.categorytemp,
        apiData.qualifications = values.qualifications
      if (apiData.standard != null) {
        apiData.standard.id = values.standardId,
          apiData.standard.class = values.standardClass
      } else {
        apiData.standard = {
          id: values.standardId,
          class: values.standardClass
        }
      }

      if (apiData.language != null) {
        apiData.language = values.languagetemp

      } else {
        apiData.language = values.languagetemp

      }
      apiData.authorities = ["ROLE_STUDENT"]

      apiData.experienceInMonths = values.selectedmonth;
      apiData.experienceInYear = values.year;


      if ((apiData.preferredCategory && apiData.preferredCategory.length > 0) &&
        (apiData.language && apiData.language.id !== '') &&
        (apiData.standard && apiData.standard.id !== '')) {
        this.setState({ catError: null })
        const { updateprofile } = this.props;
        await updateprofile(apiData);
      } else {
        if (apiData.preferredCategory && apiData.preferredCategory.length === 0) {
          this.setState({ catError: 'Please select atleast one to continue' })
        }
        if (apiData.language && apiData.language.id === '') {
          this.setState({ langError: 'Please select this continue' })
        }
        if (apiData.standard && apiData.standard.id === '') {
          this.setState({ standardError: 'Please select this to continue' })
        }
        //  Alert.alert('Please select atleast one from all preferences !')
      }
    }

    else {
      //updateTeacherProfileURL(values)
      apiData.firstName = values.fname;
      apiData.parentNumber = values.mob1;
      apiData.lastName = values.lname;
      apiData.email = values.email;
      if (values.female == true) {
        apiData.gender = 'FEMALE';
      }
      else {
        apiData.gender = 'MALE';
      }

      // if (values.current == true) {
      //   apiData.payment.account_type = 2;
      // }
      // else {
      //   apiData.payment.account_type = 1;
      // }
      apiData.address.state = values.selectedState;
      apiData.address.street1 = values.address1;
      apiData.address.city = values.city;
      apiData.address.pin = values.pincode;
      apiData.address.country = values.selectedCountry;
      // apiData.image.content = this?.props?.imagewithoutloopData?.data?.content;
      // apiData.image.width = values.width;
      // apiData.image.height = values.height;
      // apiData.image.name = values.path;
      // apiData.image.contentSize = values.size;
      // apiData.image.contentContentType = values.mime,
      //   apiData.image.createTime = values.modificationDate,
      apiData.image = [],
        apiData.contactNumber = values.mob;
      apiData.preferredCategory = values.categorytemp,
        apiData.qualifications = values.teacherQualificationData
      // apiData.description = values.description
      //apiData.standard='';
      // if (apiData.standard != null) {
      //   apiData.standard.id = values.standardId,
      //     apiData.standard.class = values.standardClass
      // } else {
      //   apiData.standard = {
      //     id: values.standardId,
      //     class: values.standardClass
      //   }
      // }

      if (apiData.language != null) {
        apiData.language = values.languagetemp

      } else {
        apiData.language = values.languagetemp

      }
      // if (apiData.language != null) {
      //   apiData.language = values.languagetemp

      // } else {
      //   apiData.language = values.selectedLanguages

      // }
      if (this.props.selctType.typeselectedData.logintype == "Student") {
        apiData.authorities = ["ROLE_STUDENT"]
      }
      else {
        apiData.authorities = ["ROLE_TEACHER"]
      }


      apiData.experienceInMonths = values.selectedmonth;
      apiData.experienceInYear = values.year;
      apiData.preferredCategory = [];
      // if ((apiData.preferredCategory && apiData.preferredCategory.length > 0) &&
      //   (apiData.language && apiData.language.id !== '') &&
      //   (apiData.standard && apiData.standard.id !== '')) {
      //   this.setState({ catError: null })
      //   const { updateprofile } = this.props;
      //   await updateprofile(apiData);
      // } 

      // else {
      //   if (apiData.preferredCategory && apiData.preferredCategory.length === 0) {
      //     this.setState({ catError: 'Please select atleast one to continue' })
      //   }
      //   if (apiData.language && apiData.language.id === '') {
      //     this.setState({ langError: 'Please select this continue' })
      //   }
      //   if (apiData.standard && apiData.standard.id === '') {
      //     this.setState({ standardError: 'Please select this to continue' })
      //   }
      //   //  Alert.alert('Please select atleast one from all preferences !')
      // }

      //this.addMoreQualification(false);

      if ((this.state.tempQualification != '') && (this.state.tempUniversity != '') && ((this.state.tempYearOfPassing != ''))) {
        var tempArray = this.props.prof.profData && this.props.prof.profData.data && this.props.prof.profData.data.qualifications
        console.log("Before update qualification-----------", this.props.prof.profData.data.qualifications)
        console.log("tempArray======", tempArray)

        var data = {
          qualification: this.state.tempQualification,
          university: this.state.tempUniversity,
          yearOfPassing: this.state.tempYearOfPassing,
          status: true,
          // experience:null,
          // createdBy:'',
          // createdDate:'',
          // lastModifiedBy:'',
          // lastModifiedDate:'',
        }
        tempArray.push(data)
        console.log("TempArry", tempArray)
        this.setState({ teacherQualificationData: this.tempArray, tempQualification: '', tempUniversity: '', tempYearOfPassing: '', })
        apiData.qualification = tempArray;
      }

      else {
        apiData.qualification = values.teacherQualificationData;
        console.log("qualifications========", apiData.qualification)
      }

      // apiData.payment={
      //   accountNumber: values.accountNumber,
      //   account_type: values.account_type,
      //   bankName: values.bankName,
      //   holderName:values.holderName,
      //   id:values.id,
      //   ifscCode: values.ifscCode,
      //   panNumber: values.panNumber,
      //   status:''
      // }

      apiData.payment = values.bankDetails;
      if (values.bankDetails.imageId == null) {
        apiData.payment.image = {}
      }

      else {

        apiData.payment.image = {
          id: values.bankDetails.imageId
        }
      }
      console.log("ApiData------------------", apiData)

      this.setState({ catError: null })
      const { updateprofile } = this.props;
      await updateprofile(apiData);
    }


  }

  deleteQualificationInList(index) {
    let apiData = this.props.prof && this.props.prof.profData && this.props.prof.profData.data;
    var qualificationList = apiData.qualifications
    var item = qualificationList[index]
    item.status = false
    qualificationList[index] = { ...item };
    this.setState({ qualificationList });
    this.setState({ teacherQualificationData: qualificationList })
    console.log("Delete Qualification========", qualificationList)
  }


  setGenderBgColor() {
    if (!this.state.male && !this.state.female) {
      if (this.props.prof && this.props.prof.profData.data && this.props.prof.profData.data) {
        if (this.props.prof.profData.data.gender == "MALE") {
          this.setState({
            male: true,
            female: false,
          })
          return "MALE"
        }

        else if (this.props.prof.profData.data.gender == "FEMALE") {
          this.setState({
            male: false,
            female: true,
          })
          return "FEMALE"
        }


        else {
          this.setState({
            male: true,
            female: false,
          })
          return "MALE"
        }

      }
    }

    else if (this.state.male) {
      return "MALE"
    }
    else if (this.state.female) {
      return "FEMALE"
    }

    else {



      this.setState({
        male: true,
        female: false,
      })
      return "MALE"

    }
  }


  render() {
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>
        <BottomSheet
          ref={this.bs}
          snapPoints={[330, 0]}
          renderContent={this.renderInner}
          initialSnap={1}
          callbackNode={this.fall}
          enabledGestureInteraction={true}
        />

        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();

              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15, marginLeft: '15%' }} source={images.logo} resizeMode={'contain'} />

          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

            <TouchableOpacity>
              <Icon1 style={{ marginLeft: 1, marginTop: 8 }} name="bell-o" size={24} color="black" /></TouchableOpacity>
           { (this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content) ?
           <Image
              resizeMode='contain'
              source={{ uri: `data:image/jpeg;base64,${this.state.profileImage[this.props.prof?.profData?.data?.imageId] && this.state.profileImage[this.props.prof?.profData?.data?.imageId].content}` }}
              style={{ width: 25, height: 25, marginLeft: 5, marginRight: 5, marginTop: 8, borderWidth: 1 }}
            />:<View style={{ width: 25, height: 25, marginLeft: 5, marginRight: 5, marginTop: 8, borderWidth: 1 }}><ActivityIndicator size='small'/></View>}
          </View>
        </View>
        <View style={{ height: '90%', marginBottom: 60, }}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            nestedScrollEnabled={true}
            style={[styles.container, { marginBottom: 60, paddingBottom: 60, flexGrow: 1, height: '80%', }]}>
            <Loader show={this.state.showLoader} />

            { }<View style={{ height: heightPercentageToDP('63%'), backgroundColor: appheadertextColor }}>
              <TouchableOpacity onPress={() => this.bs.current.snapTo(0)} style={{ backgroundColor: 'white', borderRadius: 100 / 2, alignSelf: 'center', marginTop: 10, }}>
                {this.state.img != null ? <View><Image style={{ width: 100, height: 100, borderRadius: 100 / 2, }} source={{
                  uri: `data:image/jpeg;base64,${this.state.img}`,
                }} /></View> 
                
                // <View style={{
                //   width: 100, height: 100, borderRadius: 100 / 2,
                // }}>
                //     <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                //   </View>
                  :null}
                {this.state.female == true && this.state.img === null ?  <View>
                  <Image style={{ width: 100, height: 100, alignSelf: 'center' }} source={images.female} />
                </View> : null}
                {this.state.male == true && this.state.img === null? <View>
                  <Image style={{ width: 100, height: 100, alignSelf: 'center' }} source={images.male} />
                </View> : null}
                <View style={{ backgroundColor: 'white', width: 30, height: 30, borderRadius: 15, position: 'absolute', right: 0, bottom: 10, justifyContent: 'center', borderColor: 'black', borderWidth: 1 }}>
                  <Image style={{ width: 20, height: 20, alignSelf: 'center' }} source={images.cam} resizeMode={'contain'} />
                </View>
              </TouchableOpacity>

              <View style={{ flexDirection: 'row', justifyContent: 'center' }}>

                <View style={[Styles.profilescreeninput1, { marginTop: 20 }]}>

          <View style={Styles.loginbackground} />
                  <TextInput
                    ref='fname'
                    style={Styles.textInput}
                    value={this.state.fname}
                    disableFullscreenUI={true}
                    onChangeText={this.handlefname}
                    placeholder="First Name"
                    placeholderTextColor={'gray'}
                    underlineColorAndroid="transparent"
                    returnKeyType="next"

                  />
</View>

<View style={[Styles.profilescreeninput1, { marginTop: 20 }]}>
<View style={Styles.loginbackground} />
                  <TextInput
                    ref='lname'
                    style={Styles.textInput}
                    value={this.state.lname}
                    disableFullscreenUI={true}
                    onChangeText={this.handlelname}
                    placeholder="Last Name"
                    placeholderTextColor={'gray'}
                    underlineColorAndroid="transparent"
                    returnKeyType="next"

                  />
                  
                  
                  </View>
             
              </View>

              <View style={[Styles.loginscreeninput1, { marginTop: 20 }]}>

               
                <View style={Styles.loginbackground} />

                <TextInput
                  ref='mob'
                  style={Styles.textInput}
                  value={this.state.mob}
                  disableFullscreenUI={true}
                  onChangeText={this.handlemob}
                  placeholder="Mobile Number"
                  placeholderTextColor={'gray'}
                  underlineColorAndroid="transparent"
                  returnKeyType="done"
                />
              </View>

              {this.props.selctType.typeselectedData.logintype == "Student" && <View style={[Styles.loginscreeninput1, { marginTop: 20 }]}
              >
                <View style={Styles.loginbackground} />

                <TextInput
                  ref='mob'
                  style={Styles.textInput}
                  value={this.state.mob1}
                  disableFullscreenUI={true}
                  onChangeText={this.handlemob1}
                  placeholder="Parent Contact Number"
                  placeholderTextColor={'gray'}
                  underlineColorAndroid="transparent"
                  returnKeyType="done"
                />
              </View>}

              <View style={[Styles.loginscreeninput1, { marginTop: 20 }]}
              >
                <View style={Styles.loginbackground} />

                <TextInput
                  ref='mob'
                  style={Styles.textInput}
                  value={this.state.email}
                  disableFullscreenUI={true}
                  onChangeText={this.handleEmail}
                  placeholder="Email Address"
                  placeholderTextColor={'gray'}
                  underlineColorAndroid="transparent"
                  returnKeyType="done"
                />

              </View>
              {/* {(this.state.email !== '' && this.state.emailValid) && <Text style={{marginLeft: 25, color : 'red'}}>Please enter a valid email address</Text>} */}


              <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                <TouchableOpacity
                  // style={[this.state.male ? Styles.selectedprofilescreeninput1 : Styles.profilescreeninput1, { marginTop: 20 }]}
                  style={[this.setGenderBgColor() == "MALE" ? Styles.selectedprofilescreeninput1 : Styles.profilescreeninput1, { marginTop: 20 }]}
                  onPress={() => {
                    this.setState({
                      male: true,
                      female: false
                    })
                  }}
                >
                  <View>

                    <Text style={{ alignSelf: 'center' }}>Male</Text>
                  </View>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[this.setGenderBgColor() == "FEMALE" ? Styles.selectedprofilescreeninput1 : Styles.profilescreeninput1, { marginTop: 20 }]}

                  onPress={() => {
                    this.setState({
                      male: false,
                      female: true
                    })
                  }}
                >
                  <View
                  >

                    <Text style={{ alignSelf: 'center' }}>Female</Text>

                  </View>
                </TouchableOpacity>
              </View>

              {this.props.selctType.typeselectedData.logintype == "Student" ? null :

                <Text style={{ flex: 1, color: '#fcfcfc', marginTop: 30, marginRight: 10, marginLeft: 10, }}>Account Holder Name, under Bank Account details need to be same as the logged in User 'First Name Last Name'.</Text>
              }
            </View>

            <Text style={{ fontWeight: 'bold', marginTop: 10, marginLeft: 10 }}>Address</Text>

            <View style={[Styles.addprofilescreeninput1, { marginTop: 20, marginBottom: 10, width: widthPercentageToDP('95%') }]}
            >
              <View style={Styles.loginbackground} />

              <TextInput
                ref='add'
                style={Styles.textInput}
                value={this.state.address1}
                disableFullscreenUI={true}
                onChangeText={this.handleadd1}
                placeholder="Complete Residential Address line1"
                placeholderTextColor={'gray'}
                underlineColorAndroid="transparent"
                returnKeyType="done"
              />
            </View>
            {this.state.validation1 && <View>
              <Text style={{ marginLeft: 25 }}>Address must be greater than 8</Text>
            </View>}

            <View style={[Styles.addprofilescreeninput1, { marginTop: 20, marginBottom: 10, width: widthPercentageToDP('95%') }]}
            >
              <View style={[Styles.loginbackground, {}]} />

              <TextInput
                ref='add'
                style={[Styles.textInput]}
                value={this.state.city}
                disableFullscreenUI={true}
                onChangeText={this.handleadd2}
                placeholder="City"
                placeholderTextColor={'gray'}
                underlineColorAndroid="transparent"
                returnKeyType="done"
              />
            </View>
            {this.state.validation && <View>
              <Text style={{ marginLeft: 25 }}>Address must be greater than 8</Text>
            </View>}

            <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>
              <SectionedMultiSelect
                IconRenderer={Icon}
                items={this.state.cArr}
                uniqueKey="id"
                selectToggleIconComponent={<Icon1 style={{ marginRight: 20 }} name="angle-down" size={20} color="black" />
                }
                itemFontFamily={"Avenir / normal - 200"}
                searchPlaceholderText="Search Country"
                showDropDowns={true}
                hideSearch={false}
                readOnlyHeadings={false}
                onSelectedItemsChange={this.onChangeCntryText}
                single={true}
                hideConfirm={true}
                displayKey='value'
                styles={{ selectToggleText: { color: appheadertextColor, fontSize: 13, textAlignVertical: 'center' }, button: { backgroundColor: 'red', fontSize: 15 }, container: { marginTop: 200, marginBottom: 200 }, selectToggle: { backgroundColor: 'white', alignContent: 'center', paddingLeft: 10, borderRadius: 30, height: 50 } }}
                modalWithTouchable={true}
                selectedItems={this.state.selectedCountry}
                alwaysShowSelectText={true}
              />
            </View>

            <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>
              <SectionedMultiSelect
                IconRenderer={Icon}
                items={this.state.stateArr}
                uniqueKey="id"
                selectToggleIconComponent={<Icon1 style={{ marginRight: 20 }} name="angle-down" size={20} color="black" />
                }
                itemFontFamily={"Avenir / normal - 200"}
                searchPlaceholderText="Search State"
                showDropDowns={true}
                hideSearch={false}
                readOnlyHeadings={false}
                onSelectedItemsChange={this.onChangeStateText}
                single={true}
                hideConfirm={true}
                displayKey='value'
                styles={{ selectToggleText: { color: appheadertextColor, fontSize: 13, textAlignVertical: 'center' }, button: { backgroundColor: 'red', fontSize: 15 }, container: { marginTop: 200, marginBottom: 200 }, selectToggle: { backgroundColor: 'white', alignContent: 'center', paddingLeft: 10, borderRadius: 30, height: 50 } }}
                modalWithTouchable={true}
                selectedItems={this.state.selectedState}
                alwaysShowSelectText={true}
              />
            </View>


            <View style={[Styles.addprofilescreeninput1, { marginTop: 20, marginBottom: 10, width: widthPercentageToDP('95%') }]}
            >
              <TextInput
                ref='add'
                style={Styles.textInput}
                value={this.state.pincode}
                disableFullscreenUI={true}
                onChangeText={this.handleadd3}
                placeholder="Zip Code"
                placeholderTextColor={'gray'}
                underlineColorAndroid="transparent"
                returnKeyType="done"
              />
            </View>

            {this.props.selctType.typeselectedData.logintype == "Student" ? <View>
              <Text style={{ fontWeight: 'bold', marginTop: 10, marginLeft: 10 }}>Preferences</Text>

              <View style={{ marginLeft: widthPercentageToDP(5), fontSize: widthPercentageToDP(15), marginTop: widthPercentageToDP(5), marginBottom: widthPercentageToDP(0) }}>
                <Text>Select Language</Text></View>

              <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>
                <SectionedMultiSelect
                  IconRenderer={Icon}
                  items={this.state.language}
                  uniqueKey="id"
                  selectToggleIconComponent={<Icon1 style={{ marginRight: 20 }} name="angle-down" size={20} color="black" />
                  }
                  itemFontFamily={"Avenir / normal - 200"}
                  searchPlaceholderText="Search Language"
                  showDropDowns={true}
                  hideSearch={false}
                  readOnlyHeadings={false}
                  onSelectedItemsChange={this.onChangeLanguage}
                  single={true}
                  hideConfirm={true}
                  displayKey='value'
                  styles={{ selectToggleText: { color: appheadertextColor, fontSize: 13, textAlignVertical: 'center' }, button: { backgroundColor: 'red', fontSize: 15 }, container: { marginTop: 200, marginBottom: 200 }, selectToggle: { backgroundColor: 'white', alignContent: 'center', paddingLeft: 10, borderRadius: 30, height: 50 } }}
                  modalWithTouchable={true}
                  selectedItems={this.state.langKnown}
                  alwaysShowSelectText={true}

                />

              </View>

              <View style={{ marginLeft: widthPercentageToDP(5), fontSize: widthPercentageToDP(15), marginTop: widthPercentageToDP(5), marginBottom: widthPercentageToDP(0) }}>
                <Text>Select Standard</Text></View>
              <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>
                <SectionedMultiSelect
                  IconRenderer={Icon}
                  items={this.state.standard}
                  uniqueKey="id"
                  selectToggleIconComponent={<Icon1 style={{ marginRight: 20 }} name="angle-down" size={20} color="black" />
                  }
                  itemFontFamily={"Avenir / normal - 200"}
                  searchPlaceholderText="Search Standard"
                  showDropDowns={true}
                  hideSearch={false}
                  readOnlyHeadings={false}
                  onSelectedItemsChange={this.onstandardItemChange}
                  single={true}
                  hideConfirm={true}
                  displayKey='value'
                  styles={{ selectToggleText: { color: appheadertextColor, fontSize: 13, textAlignVertical: 'center' }, button: { backgroundColor: 'red', fontSize: 15 }, container: { marginTop: 200, marginBottom: 200 }, selectToggle: { backgroundColor: 'white', alignContent: 'center', paddingLeft: 10, borderRadius: 30, height: 50 } }}
                  modalWithTouchable={true}
                  selectedItems={this.state.standardKnown}
                  alwaysShowSelectText={true}
                />
              </View>

              <View style={{ marginLeft: widthPercentageToDP(5), fontSize: widthPercentageToDP(15), marginTop: widthPercentageToDP(5), marginBottom: widthPercentageToDP(0) }}>
                <Text>Preferred Category</Text></View>
              <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>

                <SectionedMultiSelect
                  IconRenderer={Icon}
                  items={this.state.catListValues}
                  uniqueKey="id"
                  selectToggleIconComponent={<Icon1 style={{ marginRight: 20 }} name="angle-down" size={20} color="black" />
                  }
                  itemFontFamily={"Avenir / normal - 200"}
                  searchPlaceholderText="Search Category"
                  showDropDowns={true}
                  hideSearch={false}
                  readOnlyHeadings={false}
                  onSelectedItemsChange={this.onSelectedItemsCatChange}
                  single={false}
                  hideConfirm={true}
                  displayKey='value'
                  styles={{ selectToggleText: { color: appheadertextColor, fontSize: 13, textAlignVertical: 'center' }, button: { backgroundColor: 'red', fontSize: 15 }, container: { marginTop: 200, marginBottom: 200 }, selectToggle: { backgroundColor: 'white', alignContent: 'center', paddingLeft: 10, borderRadius: 30, height: 50 } }}
                  modalWithTouchable={true}
                  selectedItems={this.state.category}
                  alwaysShowSelectText={false}
                />
              </View>
            </View>
              : <View>
                <Text style={{ fontWeight: 'bold', marginTop: 10, marginLeft: 10 }}>Experience</Text>
                <View style={{ flexDirection: 'row', justifyContent: 'space-evenly' }}>
                  <Dropdown
                    placeholder="Years"
                    placeholderTextColor='gray'
                    rippleCentered={true}
                    renderAccessory={() => (
                      <Image resizeMode="contain" source={images.dropdown} style={{ marginTop: 5, justifyContent: 'center', }} />
                    )}
                    inputContainerStyle={{ borderBottomColor: 'transparent', justifyContent: 'center' }}
                    dropdownPosition={0}
                    dropdownOffset={{ top: 5, left: 0, }}
                    onChangeText={() => this.onChangeexpText}
                    containerStyle={{ elevation: 10, width: widthPercentageToDP('45%'), paddingLeft: 20, justifyContent: 'center', alignContent: 'center', alignSelf: 'center', backgroundColor: 'white', borderRadius: 20, paddingRight: 20, height: 50, marginTop: 20, paddingTop: 10, marginBottom: 5 }}
                    fontSize={15}
                    ref={this.dropdown}
                    value={this.state.year}
                    data={this.state.yearArr}
                  />
                  <Dropdown
                    placeholder="Months"
                    placeholderTextColor='gray'
                    rippleCentered={true}
                    renderAccessory={() => (
                      <Image resizeMode="contain" source={images.dropdown} style={{ marginTop: 5, justifyContent: 'center', }} />
                    )}
                    inputContainerStyle={{ borderBottomColor: 'transparent', justifyContent: 'center' }}
                    dropdownPosition={0}
                    dropdownOffset={{ top: 5, left: 0, }}
                    onChangeText={() => this.onChangeexpText1}
                    containerStyle={{ elevation: 10, width: widthPercentageToDP('45%'), paddingLeft: 20, justifyContent: 'center', alignContent: 'center', alignSelf: 'center', backgroundColor: 'white', borderRadius: 20, paddingRight: 20, height: 50, marginTop: 20, paddingTop: 10, marginBottom: 5 }}
                    fontSize={15}
                    ref={this.dropdown}
                    value={this.state.selectedmonth}
                    data={this.state.yearArr}
                  />
                </View>

                <View style={{ flexDirection: 'row' }}>
                  <Text style={{ fontWeight: 'bold', marginTop: 10, marginLeft: 10 }}>Qualification</Text>
                  <Text style={{ marginTop: 10, marginLeft: 220, color: '#165ADC' }}
                    onPress={() => {

                      //this.setState({showAddMoreQualification:true,})
                      this.addMoreQualification(true)

                    }}>Add More</Text>
                </View>
                {console.log("teacher Qualifications============", this.props.prof.profData && this.props.prof.profData.data && this.props.prof.profData.data.qualifications)}
                {this.props.prof && this.props.prof.profData && this.props.prof.profData.data && !isEmpty(this.props.prof.profData.data.qualifications) ? (

                  <FlatList
                    data={this.props.prof.profData && this.props.prof.profData.data && this.props.prof.profData.data.qualifications}
                    nestedScrollEnabled={true}
                    onEndReached={this._handleLoadMore}
                    onEndReachedThreshold={0.01}
                    renderItem={({ item, index }) => {
                      return (
                        <View style={{ justifyContent: 'center', marginLeft: 10, marginRight: 10 }}>
                          {item.status ? (
                            <View style={{ width: widthPercentageToDP('95%'), marginRight: 10, elevation: 10, marginTop: 10 }}>
                              <View style={{
                                flexDirection: "row",
                                justifyContent: "flex-end"
                              }}>
                                <TouchableOpacity
                                  onPress={() => { this.deleteQualificationInList(index) }}>
                                  <Text style={{ color: 'red', fontSize: 12, alignSelf: 'flex-end', marginHorizontal: 20 }}>Delete</Text>
                                </TouchableOpacity>
                              </View>

                              <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>
                                <TextInput
                                  style={Styles.textInput}
                                  value={item.qualification}
                                  disableFullscreenUI={true}
                                  // onChangeText={this.updateQualification()}
                                  onChangeText={(text) => {
                                    this.updateQualification(text, 'qualification', index)
                                    //this.setState({qualification:text})
                                  }}
                                  placeholder="Enter qualification"
                                  placeholderTextColor={'gray'}
                                  underlineColorAndroid="transparent"
                                  returnKeyType="done"
                                />
                                {/* <Text style={Styles.textInput}>{item.qualification}</Text> */}
                              </View>

                              <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>
                                <TextInput
                                  style={Styles.textInput}
                                  value={item.university}
                                  disableFullscreenUI={true}
                                  // onChangeText={this.updateQualification()}
                                  onChangeText={(text) => {
                                    this.updateQualification(text, 'university', index)
                                    //this.setState({university:text})
                                  }}
                                  placeholder="Enter university"
                                  placeholderTextColor={'gray'}
                                  underlineColorAndroid="transparent"
                                  returnKeyType="done"
                                />
                                {/* <Text style={[Styles.infobuttonText,{ padding:10}]}>{item.university}</Text> */}
                              </View>

                              <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>
                                <TextInput
                                  style={Styles.textInput}
                                  value={item.yearOfPassing}
                                  disableFullscreenUI={true}
                                  // onChangeText={this.updateQualification()}
                                  onChangeText={(text) => {
                                    this.updateQualification(text, 'yearOfPassing', index)
                                    //this.setState({yearOfPassing:text})
                                  }}
                                  placeholder="Enter year of passing"
                                  placeholderTextColor={'gray'}
                                  underlineColorAndroid="transparent"
                                  returnKeyType="done"
                                />
                                {/* <Text style={Styles.textInput}>{item.university}</Text> */}
                              </View>

                            </View>
                          ) : null}

                        </View>
                      )
                    }
                    }
                  />) : null}


                {this.state.showAddMoreQualification ?

                  (
                    <View style={{ width: widthPercentageToDP('95%'), marginLeft: 10, marginRight: 10, elevation: 10, marginTop: 10 }}>


                      <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>
                        <TextInput
                          style={Styles.textInput}
                          value={this.state.tempQualification}
                          disableFullscreenUI={true}
                          // onChangeText={this.updateQualification()}
                          onChangeText={(text) => {
                            //this.updateQualification(text)
                            this.setState({ tempQualification: text })
                          }}
                          placeholder="Enter qualification"
                          placeholderTextColor={'gray'}
                          underlineColorAndroid="transparent"
                          returnKeyType="done"
                        />
                      </View>

                      <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>
                        <TextInput
                          style={Styles.textInput}
                          value={this.state.tempUniversity}
                          disableFullscreenUI={true}
                          // onChangeText={this.updateQualification()}
                          onChangeText={(text) => {
                            //this.updateQualification(text)
                            this.setState({ tempUniversity: text })
                          }}
                          placeholder="Enter university"
                          placeholderTextColor={'gray'}
                          underlineColorAndroid="transparent"
                          returnKeyType="done"
                        />
                      </View>

                      <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>
                        <TextInput
                          style={Styles.textInput}
                          value={this.state.tempYearOfPassing}
                          disableFullscreenUI={true}
                          // onChangeText={this.updateQualification()}
                          onChangeText={(text) => {
                            //this.updateQualification(text)
                            this.setState({ tempYearOfPassing: text })
                          }}
                          placeholder="Enter year of passing"
                          placeholderTextColor={'gray'}
                          underlineColorAndroid="transparent"
                          returnKeyType="done"
                        />
                      </View>

                    </View>
                  )
                  : null}

                {/* <Text style={{ fontWeight: 'bold', marginLeft: 10 , marginTop:20}}>Description</Text>
              <View style={[Styles.addprofilescreeninput1, { marginTop: 10, marginBottom: 10, height:'2%' }]}>
                <TextInput
                  style={{marginHorizontal:10,alignSelf:'flex-start'}}
                  value={this.state.description}
                  disableFullscreenUI={true}
                  onChangeText={(text) => {
                    //this.updateQualification(text)
                    this.handleDescription(text)
                   }}
                  placeholder="About"
                  placeholderTextColor={'gray'}
                  underlineColorAndroid="transparent"
                  returnKeyType="done"
                  multiline={true}
                  numberOfLines={4}
                />
              </View> */}

                <Text style={{ fontWeight: 'bold', marginTop: 10, marginLeft: 10 }}>Language Spoken</Text>


                <View style={[Styles.multilabel, { marginLeft: 10, backgroundColor: 'white', marginTop: 10, justifyContent: 'center', borderRadius: 20, elevation: 10, marginRight: 10, marginBottom: 10 }]}>
                  {console.log("lang array in UI ", this.state.languageArray, this.state.selectedLanguages)}
                  <SectionedMultiSelect
                    IconRenderer={Icon}
                    items={this.state.languageArray}
                    uniqueKey="id"
                    selectToggleIconComponent={<Icon1 style={{ marginRight: 20 }} name="angle-down" size={20} color="black" />
                    }
                    itemFontFamily={"Avenir / normal - 200"}
                    searchPlaceholderText="Search Language"
                    showDropDowns={true}
                    hideSearch={false}
                    readOnlyHeadings={false}
                    onSelectedItemsChange={this.onChangeLanguage}
                    single={false}
                    hideConfirm={true}
                    displayKey='name'
                    styles={{ selectToggleText: { color: appheadertextColor, fontSize: 13, textAlignVertical: 'center' }, button: { backgroundColor: 'red', fontSize: 15 }, container: { marginTop: 200, marginBottom: 200 }, selectToggle: { backgroundColor: 'white', alignContent: 'center', paddingLeft: 10, borderRadius: 30, height: 50 } }}
                    modalWithTouchable={true}
                    selectedItems={this.state.langKnown}
                    alwaysShowSelectText={true}

                  />
                </View>


{ this.props.selctType.typeselectedData.logintype == "Student" ? <View style={{ justifyContent: 'center', }}>

<Dropdown
  placeholder="Language"
  placeholderTextColor='gray'
  renderAccessory={() => (
    <Image resizeMode="contain" source={images.dropdown} style={{ marginTop: 5, justifyContent: 'center', }} />
  )}
  rippleCentered={true}
  inputContainerStyle={{ borderBottomColor: 'transparent', justifyContent: 'center' }}
  dropdownPosition={0}
  dropdownOffset={{ top: 5, left: 0, }}
  onChangeText={this.onChangelangText}
  containerStyle={{ elevation: 10, width: widthPercentageToDP('95%'), paddingLeft: 20, justifyContent: 'center', alignContent: 'center', alignSelf: 'center', backgroundColor: 'white', borderRadius: 20, paddingRight: 20, height: 50, marginTop: 20, paddingTop: 10, marginBottom: 5 }}
  fontSize={15}
  ref={this.dropdown}
  value={this.state.languageClass}
/>
</View>  : null  }
                


                {/* to show bank details if isFreelancer='true' */}
                {
                  this.state.isFreelancer ? (
                    <View>
                      <View style={{ flexDirection: 'row' }}>
                        <Text style={{ fontWeight: 'bold', marginTop: 10, marginLeft: 10 }}>Bank Details</Text>
                        <TouchableOpacity onPress={() => {

                          NavigationService.navigate('BankDetailsScreen', { profileData: this.props.prof.profData.data });
                        }
                        }
                        >
                          <Text style={{ marginTop: 10, marginLeft: 230, color: '#165ADC' }}>Change</Text>
                        </TouchableOpacity>
                      </View>

                      <View style={{ flexDirection: 'row', margin: 10 }}>
                        <Text style={{ color: '#888888' }}>Account Holder Name</Text>
                        <Text style={{ marginLeft: 75 }}>{this.state.accountholder}</Text>
                      </View>

                      <View style={{ flexDirection: 'row', margin: 10 }}>
                        <Text style={{ color: '#888888' }}>Account Type</Text>
                        <Text style={{ marginLeft: 125 }}>{this.state.account_type}</Text>
                        {

                    /* {this.props.prof.profData && this.props.prof.profData.data && this.props.prof.profData.data.payment && this.props.prof.profData.data.payment.account_type == 1 && this.state.current ? <Text style={{ marginLeft: 130 }}>Savings</Text> : null}
                    {this.props.prof.profData && this.props.prof.profData.data && this.props.prof.profData.data.payment && this.props.prof.profData.data.payment.account_type == 2 && this.state.saving ? <Text style={{ marginLeft: 130 }}>Current</Text> : null} */}
                      </View>

                      <View style={{ flexDirection: 'row', margin: 10 }}>
                        <Text style={{ color: '#888888' }}>Account Number</Text>
                        <Text style={{ marginLeft: 107 }}>{this.state.accountnumber}</Text>
                      </View>

                      <View style={{ flexDirection: 'row', margin: 10 }}>
                        <Text style={{ color: '#888888' }}>IFSC Code</Text>
                        <Text style={{ marginLeft: 147 }}>{this.state.ifsccode}</Text>
                      </View>

                      <View style={{ flexDirection: 'row', margin: 10 }}>
                        <Text style={{ color: '#888888' }}>PAN Number</Text>
                        <Text style={{ marginLeft: 130 }}>{this.state.panNumber}</Text>
                      </View>
                      <View style={{ flexDirection: 'row', margin: 10 }}>
                        <Text style={{ color: '#888888' }}>Aadhar(UIN)</Text>
                        <Text style={{ marginLeft: 130 }}>{this.state.aadhar}</Text>
                      </View>

                      <View style={{ flexDirection: 'row', margin: 10, }}>
                        <Text style={{ color: '#888888' }}>ID Proof*</Text>
                      </View>
                      <View style={{ flexDirection: 'row', margin: 10, height: '50%', marginBottom: 80, }}>
                        <View style={{ marginRight: 40, marginStart: 40, marginVertical: 20, height: '30%', width: '80%', backgroundColor: '#00393939', alignContent: 'center', justifyContent: 'center' }}>

                          {
                            (isEmpty(this.state.bankImageData)) ?
                              <Image
                                resizeMode="contain"
                                source={images.id_doc_palceholder}
                                style={{ marginTop: 5, justifyContent: 'center', alignSelf: 'center' }} />
                              :
                              <View>
                                {console.log("image get data 2========", this.state.bankImageData.content)}
                                <Image style={{ width: '100%', height: '100%', }}
                                  source={{ uri: `data:image/jpeg;base64,${this.state.bankImageData?.content}`, }} />
                              </View>
                          }


                        </View>
                      </View>
                    </View>) : null
                }



              </View>
            }
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.navigate('ChangePasswordScreen');
              }}
            >
              <Text style={{ fontWeight: 'bold', marginTop: 10, marginLeft: 10, alignSelf: 'center' }}>Change Password</Text>
            </TouchableOpacity>
          </ScrollView >
        </View>



        <TouchableOpacity onPress={() => this.updatedprofileValue(this.state)} style={{ position: 'absolute', bottom: 10, alignSelf: 'center', left: 20, right: 20 }}>
          <Text style={{ marginBottom: 5, color: 'white', marginTop: 10, backgroundColor: appblueColor, borderRadius: 20, paddingBottom: 10, paddingTop: 10, textAlign: 'center', width: '100%' }}>Save</Text>
        </TouchableOpacity>


      </View >
    )
  }

}

const mapStateToProps = state => ({

  user: state.auth,
  prof: state.prof != null ? state.prof : {},
  selctType: state.selctType,
  profimgData: state.prof,
  imagewithoutloopData: state.dash.imagewithoutloopData,
  imageForBankDocData: state.prof.fetchBankImageDataData,
});


const mapDispatchToProps = {
  profile,
  updateprofile,
  profileWithoutImg, imageWithoutLoopLoad,
  imageUpload,
  imageWithoutLoopLoadForBankDoc,
  fetchBankImageData,
};
export default connect(mapStateToProps, mapDispatchToProps)(ProfileScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 60

  },
  labelContainer: {
    justifyContent: 'center', alignContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
