import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity, 
   Alert, TextInput, Dimensions, Image
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import * as EnquiryAPI from '../../Services/enquiryAPIs';
import { connect } from 'react-redux';
import Loader from '../../Common/Loader';
import _ from "lodash";
import { appbluebtnColor, appblueColor, appgrayColor, apppinkColor, loginheaderColor, appheadertextColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import Modal from "react-native-modal";
import { Checkbox } from 'react-native-paper';
import { Rating, AirbnbRating } from 'react-native-elements';
import moment from 'moment';
import { fetchReview } from '../../actions';
import AsyncStorage from '@react-native-async-storage/async-storage';
import HTML from 'react-native-render-html';

var params;
class ReqRecordingScreen extends Component {

  constructor(props) {
    super(props);
    this.state = {
      enquiries: [],
      filterArr: [{ id: -1, text: 'Top Rated' }, { id: 1, text: 'Top Rated', selected: 0 },
      { id: 2, text: 'Best Match', selected: 0 }, { id: 3, text: 'Price Low to High', selected: 0 }, { id: 4, text: 'Price High to Low', selected: 0 },],
      showLoader: false,
      showPopup: false,
      canceltext: '',
      _id: '',
      _selectedids: [],
      start: 0, total: 0,
      start2: 0, total2: 0,
      filterpopup: false,
     
      study:false,
      showImage:false,
      ratingg:0
    }
    params = this.props.navigation.state.params
  }

  handlereview = (text) => {
    this.setState({ review: text })
  }

  ratingCompleted = (rating) => {
    this.setState({ ratingg: rating })
  }

  submitReview = async(value) => {
    let profileData = await AsyncStorage.getItem('user_id');
    this.props.fetchReview(this.state.ratingg, value, params.id.courseClass.id, profileData);

  }

  studyView = () =>{
    console.log('view clicked');
    this.setState({study:true})
  }
  render() {
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>

        <Modal

          isVisible={this.state.showImage}
          animationType="fade"
          transparent={true}
          backdropColor={'rgba(0,0,0,0.35)'}
          backdropOpacity={1}
          onBackdropPress={() => this.setState({ showImage: false })}
          onRequestClose={() => {
            this.setState({ showImage: false });
          }}
        >
          <View
            style={{
              flex: 1,

              justifyContent: "flex-end",
              alignItems: "center",
              height: 310,
            }}
          >
           <Text>Hii</Text>
          </View>
        </Modal>

        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();

              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

              {/* <Image style={{ width: 20, height: 20,marginLeft:10 }} source={images.menu} /> */}
            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />

          {/* <Text style={{color:'white',marginTop:15}}>Search</Text> */}
          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

            <TouchableOpacity
              onPress={() => {
                this.setState({
                  filterpopup: true
                })
              }}
            >
              <Icon1 style={{ marginLeft: 15 }} name="bell-o" size={20} color="black" /></TouchableOpacity>
          </View>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          nestedScrollEnabled={true}
          style={styles.container}>
          <Loader show={this.state.showLoader} />
          <View style={{ justifyContent: 'center', marginRight: 10, marginLeft: 10 }}>

           {params && params.id && params.id.classStatus === 1 && <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10, paddingBottom: 10 }}>

              <View style={{ flexDirection: 'row', marginLeft: 10, marginRight: 10 }}>

                <Image style={Styles.calimage}
                  source={{ uri:  `data:image/jpeg;base64,${this?.props?.imagewithoutloopData?.data?.content}`}}
                />

                <View style={{ marginLeft: 10, marginTop: 5 }}>
                  <Text style={{ fontWeight: 'bold', fontSize: 13, }}>{params && params.id && params.id.courseClass && params.id.courseClass.course && params.id.courseClass.course.name} class-{params && params.id && params.id.courseClass && params.id.courseClass.course && params.id.courseClass.course.standard && params.id.courseClass.course.standard.class}</Text>
                  <Text style={{ fontSize: 12, fontStyle: 'italic' }}>By {params && params.id && params.id.teacher && params.id.teacher.firstName} {params && params.id && params.id.teacher && params.id.teacher.lastName}</Text>
                </View>

                <View style={{ position: 'absolute', right: 0, alignSelf: 'center' }}>
                  <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(params && params.id && params.id.courseClass.course && params.id.courseClass.course.createdDate).format('DD-MM-YYYY')}</Text>
                  <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{params && params.id && params.id.courseClass && params.id.courseClass.endTime}</Text>
                  {/* <Text style={{marginBottom:5, color:'white',alignSelf:'flex-end',marginTop:10,backgroundColor:loginheaderColor,borderRadius:20,paddingLeft:10,paddingRight:10,paddingBottom:5,paddingTop:5}}>Join Class</Text> */}
                 <Text style={{ fontSize: 12, color: 'green', fontWeight: 'bold' }}>Attended</Text>
                </View>
              </View >

            </View>}

            {params && params.id && params.id.classStatus === 4 && <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 10, paddingBottom: 10 }}>

              <View style={{ flexDirection: 'row', marginLeft: 10, marginRight: 10 }}>

              <Image style={Styles.calimage}
                  source={{ uri:  `data:image/jpeg;base64,${this?.props?.imagewithoutloopData?.data?.content}`}}
                />
                
                <View style={{ marginLeft: 10, marginTop: 5 }}>
                  <Text style={{ fontWeight: 'bold', fontSize: 13, }}>{params && params.id && params.id.courseClass && params.id.courseClass.course && params.id.courseClass.course.name} class-{params && params.id && params.id.courseClass && params.id.courseClass.course && params.id.courseClass.course.standard && params.id.courseClass.course.standard.class} class 10th</Text>
                  <Text style={{ fontSize: 12, fontStyle: 'italic' }}>By {params && params.id && params.id.teacher && params.id.teacher.firstName} {params && params.id && params.id.teacher && params.id.teacher.lastName}</Text>
                </View>

                <View style={{ position: 'absolute', right: 0, alignSelf: 'center' }}>
                  <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(params && params.id && params.id.courseClass.course && params.id.courseClass.course.createdDate).format('DD-MM-YYYY')}</Text>
                  <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{params && params.id && params.id.courseClass && params.id.courseClass.endTime}</Text>
                  <Text style={{ fontSize: 12, color: '#FF5656', fontWeight: 'bold' }}>Missed</Text>
                </View>
              </View >

            </View>}
          </View >
              {console.log('params.idparams.id',params.id.courseClass.studyMaterial.content)}
          <Text style={{ marginLeft: 10, marginTop: 10, fontWeight: 'bold', fontSize: 12 }}>Study Material</Text>

          <View style={{ flexDirection: 'row', justifyContent: 'space-around', backgroundColor: 'white', marginRight: 10, marginLeft: 10 }}>
            <Text style={{ fontSize: 12, marginTop: 15 }}> {params && params.id && params.id.courseClass && params.id.courseClass.studyMaterial && params.id.courseClass.studyMaterial.name} </Text>
            <Text style={Styles.uploadButton} onPress={()=>this.setState({showImage:true})}>View</Text>
          </View>

          {this.state.showImage && <View style={{ justifyContent: 'center',backgroundColor:'red' }}>
            <Image
              source={{uri:'https://reactnative.dev/img/tiny_logo.png'}}
              style={{width:100,height:100}}
            />
            {/* <HTML html={params.id.courseClass.studyMaterial && params.id.courseClass.studyMaterial.content} imagesMaxWidth={Dimensions.get('window').width} /> */}
          </View>}

          {this.props.getCartData && this.props.getCartData.data.cartCourses[0].CartCourseAddons === [] &&<Text style={{ marginLeft: 10, marginTop: 10, fontWeight: 'bold', fontSize: 12 }}>Recordings</Text>}
           {this.props.getCartData && this.props.getCartData.data.cartCourses[0].CartCourseAddons === [] && <View style={{ elevation: 5, backgroundColor: 'white', marginLeft: 10, marginRight: 10, marginBottom: 10, borderRadius: 20, marginTop: 10 }}>
            <View style={{ flexDirection: 'row', paddingTop: 5, paddingBottom: 5 }}>
              <Image style={{ width: 25, height: 25, marginLeft: 20, alignSelf: 'center' }} source={images.infoorng} />
              <View style={{ width: '70%', alignSelf: 'center' }}>
                <Text style={{ fontWeight: 'bold', color: appheadertextColor, fontSize: 10, marginLeft: 10 }}>You can only make 2 requests per month</Text>
              </View>
              <TouchableOpacity
                style={{ alignSelf: 'center', }}
                onPress={() => {

                }}
              >
                <Text style={{ fontWeight: 'bold', color: appbluebtnColor, fontSize: 10 }}>Request</Text>
              </TouchableOpacity>
            </View>
          </View>}
         
          {this.props.reviewData && this.props.reviewData.data === "Review Submitted" ? <Text style={{ marginLeft: 10, marginTop: 10, fontWeight: 'bold', fontSize: 12 }}>Review has been submitted Successfully.</Text> : <View>
            <Text style={{ marginLeft: 10, marginTop: 10, fontWeight: 'bold', fontSize: 12 }}>Your Review & Rating</Text>
            <View style={{ flexDirection: 'column', justifyContent: 'space-between', margin: 5, marginLeft: 10 }}>
              <AirbnbRating
                count={5}
                defaultRating={3}
                showRating={false}
                reviews={["OK", "Good", "Hmm...", "Very Good", "Amazing"]}
                starContainerStyle={{ justifyContent: 'flex-start', width: '100%', marginTop: 10 }}
                onFinishRating={this.ratingCompleted}

                size={25}
              />
            </View>
            <View style={[Styles.loginscreeninput1, { marginTop: 20 }]}
            >
              <View style={Styles.reviewbackground} />

              <TextInput
                ref='fname'
                style={Styles.textInput}
                //  onChangeText = {this.handlePassword}
                value={this.state.review}
                disableFullscreenUI={true}
                onChangeText={this.handlereview}
                placeholder="Review"
                placeholderTextColor={'gray'}
                underlineColorAndroid="transparent"
                returnKeyType="done"
              />
            </View>

            <TouchableOpacity
              style={[
                Styles.withoutselectoptionbutton,
                { marginTop: 20, backgroundColor: appblueColor},
              ]}
              onPress={() => {
                this.submitReview(this.state.review)
              }}
            >
              <Text style={{ color: 'white', textAlign: "center"}}>
                Submit
                      </Text>

            </TouchableOpacity>
          </View>}
        </ScrollView >


      </View >
    )
  }

}

const mapStateToProps = state => ({
  getCartData: state.dash.getCartData,
  reviewData: state.dash.reviewData,
  courseData: state.dash.courseData,
  imagewithoutloopData:state.dash.imagewithoutloopData
});

const mapDispatchToProps = {
  fetchReview
};
export default connect(mapStateToProps, mapDispatchToProps)(ReqRecordingScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
