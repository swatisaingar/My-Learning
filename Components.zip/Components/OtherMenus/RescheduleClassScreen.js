import React, { Component } from 'react'
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity, TouchableWithoutFeedback,
    FlatList, Alert, ToastAndroid, Image, TextInput,
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP , heightPercentageToDP } from '../../constants/styles'
import * as EnquiryAPI from '../../Services/enquiryAPIs';
import { connect } from 'react-redux';
import NavigationService from '../../Services/NavigationService';
import _, { isEmpty } from "lodash";
import { appbluebtnColor, appblueColor, appgrayColor, apppinkColor, loginheaderColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import DateTimePicker from '@react-native-community/datetimepicker';
import {rescheduleClass,} from '../../actions'
import moment from 'moment'
import Modal from "react-native-modal";
import QRCode from 'react-native-qrcode-svg'
import Share from 'react-native-share'
import RNFS from 'react-native-fs'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../../util/AppConstants';

class RescheduleClassScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            filterpopup: false,
            selectedDate : '',
            mode:'date',
            classDataState: this.props.navigation.state.params  && this.props.navigation.state.params.classData,
            fromWhere: this.props.navigation.state.params.fromWhere,
            showDateTimePicker: false,
            date:new Date(),
            mode:'date',
            rescheduleDate: new Date(),
            rescheduleStartTime:'',
            rescheduleEndTime:'',
            startTimeSelection:true,
            endTimeSelection:true,
            profileImage:{},
            showQr1:false,
            imageData: {},
            imageLoading: true,
            teacherListIamgeData:[],
   
        }

        console.log("ClassData-----", this.props.navigation.state.params.classData)
        console.log("FromWhere -----", this.props.navigation.state.params.fromWhere)
        console.log("course data -----", this.props.navigation.state.params.courseData)
        
       
    }


    rescheduleClassApiCall()
    {
        var date = new Date(this.state.rescheduleDate)
        var sTime = moment(this.state.rescheduleStartTime, "HH:mm");
        var eTime = moment(this.state.rescheduleEndTime, "HH:mm");
        console.log("date---------", date)
        var rescheduleDate = moment.utc(date).local().format();
        console.log("rescheduleDate---------", rescheduleDate)
        const data = ({...this.props.navigation.state.params.classData, 
            date: rescheduleDate ,//'2021-02-22T00:00:00.000Z',
            startTime: sTime, 
            endTime:eTime,
            classStatus: 3
           })
           
      this.props.rescheduleClass(data)
    }


 async componentDidMount()
{
    let AuthToken = await AsyncStorage.getItem('id_token');
    // this.props.navigation.state.params?.classData?.map((item) => {
        // this.props.imageLoad(item?.courseClass?.course?.imageId)
        console.log("item to fetch image============", item)
        let id = this.props.navigation.state.params.courseData?.imageId;
        console.log("imageId ========", id)
        fetch(`${baseURL}file-blobs/getImage/${id}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${AuthToken}`,
          }
        }).then(data => {
          return data.json()
        }).then(resposne => {
          console.log("image======", resposne.data)
          let imageData = this.state.teacherListIamgeData || {};
          imageData[resposne.data.id] = resposne.data;
          this.setState(imageData);
          console.log('image datadata', imageData)
          this.setState({ teacherListIamgeData: imageData, })
        }).
          catch((error) => {
            console.log("#error", error);
          })
// })
}
    showDatePickerDialog()
    {
     this.setState({mode:'date',showDateTimePicker:true, })
    }


    showTimePickerDialog()
    {
        console.log("Time picker open ", 'true')
        this.setState({mode:'time',showDateTimePicker:true, })
    }


    setValue = (event, selectedDate) => {
        

        if (this.state.mode == 'date') {
            const currentDate = selectedDate || new Date();
            this.setDate(selectedDate);
            

          } 
          
          else {
            const selectedTime = selectedDate || new Date();
            this.setTime(selectedTime);
            
          }

        console.log("selection----------", selectedDate)
        
      };


      setMode(type)
      {
          this.setState({mode:type,})
      }

      setDate(currentDate)
      {
    
       // var currentDate = moment.utc(new Date()).format();

        var currentDate = moment(new Date(currentDate)  , "dd-MM-YYYY")
        var courseEndDate = moment(new Date(this.props.navigation.state.params.classData.course.endDate) , 'dd-MM-YYYY')
    
        console.log("selected date  ========", currentDate)
        console.log("class date ========", courseEndDate)

        var dayDiff = courseEndDate.diff(currentDate , 'days')
        console.log("diff in date=============", dayDiff)
        var dayDiff = 0
if(dayDiff>0)
{
    this.setState({rescheduleDate:currentDate, showDateTimePicker:false,})
}
else{

    alert("You can not select date greater than course end date")
}
       
        console.log("selected date ,-----", new Date(currentDate))
      }
    
      setTime(currentTime)
      {

        var currentDate = moment.utc(new Date()).format();

        var currentDate = moment(new Date(currentDate)  , "dd-MM-YYYY")
        var courseEndDate = moment(new Date(this.props.navigation.state.params.classData?.course?.endDate) , 'dd-MM-YYYY')
    
        console.log("today ========", currentDate)
        console.log("class date ========", courseEndDate)

        var dayDiff = courseEndDate.diff(currentDate , 'days')
        console.log("diff in date=============", dayDiff)

        if(dayDiff==0)
        {

        }

        else if(dayDiff<0)
        {


        }

        else 
        {

            
        }
        this.setState({showDateTimePicker:false,})

          if(this.state.startTimeSelection)
          
          {
            var endTime = moment(currentTime).add(70, 'minutes').format('hh:mm A')
            console.log("end time =======", endTime)
            this.setState({rescheduleStartTime:moment(currentTime).format('hh:mm A')})
            this.setState({rescheduleEndTime:endTime})
          }
          else{
            const sTime = moment(this.state.rescheduleDate, "HH:mm");
            const eTime = moment(currentTime, "HH:mm");

            var minutes = eTime.diff(sTime , 'minutes');
              console.log("time diff", minutes)
              if(minutes>70)
              {
                  alert('You can not select class end time grearter than 70 minutes')
              }
              else{
                this.setState({rescheduleEndTime:moment(currentTime).format('hh:mm A')})
              }
            
          }
        
      }
        getDateDiffernece(date1, date2)
        {
      
      const start = new Date(date1); // selected date
      const end   = new Date(date2); // course end date
      var msDiff = start.getTime() - end.getTime();    //Future date - current date
      var daysTill30June2035 = Math.floor(msDiff / (1000 * 60 * 60 * 24));
    
          console.log("day diff-----", daysTill30June2035)

          if(daysTill30June2035>0)
          {
              alert('You can not reschedule class beyond end date')
              this.setState({rescheduleDate : moment(new Date()).format('DD-MM-YYYY')})

          }
          else{
            // do nothing 
            this.setState({rescheduleDate : moment(new Date()).format('DD-MM-YYYY')})
          }
      
        }


        getValidTimeDurationForClass()
        {
            
           var timeDiff = moment.duration(this.state.rescheduleEndTime , this.state.rescheduleStartTime )
           console.log("timeDifff-----", timeDiff)

           if(timeDiff>70)
           {
               Alert.alert('Time are not in range' , 'Time duration should not be greater than 70 min')
           }
              
        }
      
    componentDidUpdate = prevProps =>
    {
        if(this.props.rescheduleClassDataProps!=null)
        {
            if(prevProps.rescheduleClassDataProps!=this.props.rescheduleClassDataProps )
            {
              console.log('reschedule class : ', this.props.rescheduleClassDataProps)
        
              if(this.props.rescheduleClassDataProps.data)
              {
                console.log('reschedule class  success : ', this.props.rescheduleClassDataProps.data)
                var classStatus = this.props.rescheduleClassDataProps.data.classStatus
                console.log("class stataus -----" , classStatus)
                Alert.alert(
                  classStatus == 3 ? 'Reschedule Class': 'Cancel Class',
                  this.props.rescheduleClassDataProps.data.classStatus == 3 ? 'Class is rescheduled successfully ' : 'Class is cancelled successfully',
                  [
                   
                    { text: 'OK', onPress: () => 
                    {
                      
                      console.log('OK Pressed')
                      NavigationService.navigate(this.state.fromWhere)
                    
                    }
                  }
                  ],
                  { cancelable: false }
                );
              }
        
              else{
                Alert.alert(
                  'Reschedule Class',
                  this.props.rescheduleClassDataProps.message ? this.props.rescheduleClassDataProps.message : 'Error in reschedule class',
                  [
                   
                    { text: 'OK', onPress: () => console.log('OK Pressed') }
                  ],
                  { cancelable: false }
                );
    
                console.log("getting error in reschedule ------", "Error")
              }
            }
        }
        else{
            console.log("previous reducer is null -----", "True")
        }
        
    }
    handleConfirm = (date) => {
        console.warn("A date has been picked: ", date);
        hideDatePicker();
      };

      hideDatePicker()
      {
        this.setState({showDatePicker:false})
      }


  getClassStartTimeFormatted(startTime)
  {

    console.log("startTime :", startTime)
    const sTime = moment(startTime, "hh:mm A");
    console.log("startTime By moment :", sTime)
    return sTime.format("hh:mm A")

  }
  getDateIsValid()
  {

  }


  getCourseName()
  {
   var courseName =  this.props.navigation.state.params.classData && this.props.navigation.state.params.classData.courseName
   if(isEmpty(courseName) && this.props.navigation.state.params.classData!=null)
   {
       courseName = this.props.navigation.state.params.classData && this.props.navigation.state.params.classData.course && this.props.navigation.state.params.classData.course.name
   }
   return courseName
  }

  getClassTitle()
  {
      var classTitle = this.props.navigation.state.params.classData && this.props.navigation.state.params.classData.title
      return classTitle
  }

  getClassEndDate()
  {
    
    var classEndDate = this.props.navigation.state.params.classData && this.props.navigation.state.params.classData.course && moment(this.props.navigation.state.params.classData.course.endDate).format("DD-MM-yyyy")
    return classEndDate
  }

  getClass()
  {
      var standard = this.props.navigation.state.params.classData && this.props.navigation.state.params.classData.standard && this.props.navigation.state.params.classData.standard.class
      console.log("standard -----", standard)
      switch(standard)
      {
          case '1':
              {
                
                return ' Class 1st'
              }
              case '2':
                  {
                      return 'Class 2nd'
                  }

                  case '3':
                      {
                          return 'Class 3rd'
                      }

                     default:
                          {
                              return 'Class '+standard
                          }
          
      }
    }


    showQRCodeScanner()
    {
        if(!this.state.showQr1)
        {
            this.setState({showQr1 : true})
        }
    }

    saveQRCode()
    {
        this.svg.toDataURL(this.callback)
    }

    callback(dataURL) {
        let shareImageBase64 = {
          title: 'React Native',
          url: `data:image/png;base64,${dataURL}`,
          subject: 'Share Link',
        }
    
        Share.open(shareImageBase64).catch(error => console.log(error))
      }

      downloadQRCode = async () => {
        try {
          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
            {
              title: 'Cool Photo App Camera Permission',
              message:
                'Cool Photo App needs access to your camera ' +
                'so you can take awesome pictures.',
              buttonNeutral: 'Ask Me Later',
              buttonNegative: 'Cancel',
              buttonPositive: 'OK',
            },
          )
          if (granted === PermissionsAndroid.RESULTS.GRANTED) {
            this.svg.toDataURL(data => {
              RNFS.writeFile(
                RNFS.CachesDirectoryPath + '/some-name.png',
                data,
                'base64',
              )
                .then(success => {
                  return CameraRoll.save(
                    RNFS.CachesDirectoryPath + '/some-name.png',
                    'photo',
                  )
                })
                .then(() => {
                  ToastAndroid.show('Saved to gallery !!', ToastAndroid.SHORT)
                })
            })
          } else {
            console.log('Camera permission denied')
          }
        } catch (err) {
          console.warn(err)
        }
      }

     async getUserProfileImage()
      {
        let AuthToken = await AsyncStorage.getItem('id_token');
        let id = this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.imageId
        //let id = item.course.imageId;
        console.log("imageId ========", id)
        fetch(`https://api.idutor.tk/api/file-blobs/getImage/${id}`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${AuthToken}`,
         }
        }).then(data => {
          return data.json()
        }).then(resposne => {
          let imageData = this.state.teacherListIamgeData || {};
          imageData[id] = resposne.data;
          this.setState(imageData);
          console.log('image datadata',imageData)
          this.setState({teacherListIamgeData : imageData, })
        }).
          catch((error) => {
            console.log("#error", error);
          })

        console.log("ImageData=============", this.state.teacherListIamgeData)
    
  
      }


    render() {
        return (
            <View style={{ backgroundColor: 'white', flex: 1 }}>

<Modal
          isVisible={this.state.showQr1}
          animationType='fade'
          transparent={true}
          backdropColor={'rgba(0,0,0,0.35)'}
          backdropOpacity={1}
          onBackdropPress={() => this.setState({ showQr1: false })}
          onRequestClose={() => {
            this.setState({ showQr1: false })
          }}>
          <View
            style={{
              marginBottom: 10,
              height: heightPercentageToDP('60%'),
              width: widthPercentageToDP('90%'),
              backgroundColor: 'white',
              marginTop: 80,
            }}>
            <View
              style={{
                backgroundColor: 'white',
                width: 130,
                height: 130,
                borderRadius: 70,
                alignSelf: 'center',
                position: 'absolute',
                top: -70,
                justifyContent: 'center',
                borderWidth: 1,
              }}>

              {this.props.prof.profData  && this.state.teacherListIamgeData[0]?.content? (
                <Image
                  style={{
                    width: '100%',
                    height: '100%',
                    borderRadius: 70,
                    alignSelf: 'center',
                  }}
                  source={{
                    uri: `data:image/jpeg;base64,${this.props.prof.profData &&
                      this.props.prof.profData.data && this.props.prof.profData.data.image &&
                      this.state.teacherListIamgeData[0]?.content}`,
                  }}
                />
              ) : (
                  <Image
                    style={{ width: 125, height: 125, alignSelf: 'center' }}
                    source={images.male}
                  />
                )}
            </View>
            <TouchableOpacity
              style={{ position: 'relative', left: 310, marginTop: 10 }}
              onPress={() => this.setState({ showQr1: false })}>
              <Image resizeMode='contain' source={images.drawerclose} />
            </TouchableOpacity>
            <View style={{ marginTop: 40 }}>
              <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>

                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.firstName}
                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.lastName}
              </Text>
              <Text
                style={{
                  textAlign: 'center',
                  color: '#888888',
                  fontStyle: 'italic',
                }}>

                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.experienceInYear}
                yr,
                {this.props.prof.profData &&
                  this.props.prof.profData.data &&
                  this.props.prof.profData.data.qualifications &&
                  this.props.prof.profData.data.qualifications.map(
                    item => item.qualification,
                  )}
              </Text>
              <View style={{ alignSelf: 'center', margin: 10 }}>
                <QRCode
                  value={`{id: ${this.props.prof.profData && this.props.prof.profData.data &&
                    this.props.prof.profData.data.id},name: ${this.props.prof
                      .profData && this.props.prof.profData.data && this.props.prof.profData.data.firstName}}`}
                  size={200}
                  getRef={c => (this.svg = c)}
                />
              </View>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  marginBottom: 5,
                  alignSelf: 'center',
                  marginTop: 10,
                  backgroundColor: '#1976D2',
                  borderRadius: 35,
                  width: widthPercentageToDP('32%'),
                  textAlign: 'center',
                  height: 50,
                }}
                onPress={() => this.saveQRCode()}>
                <Image
                  resizeMode='contain'
                  source={images.share_list}
                  style={{ alignSelf: 'center', marginLeft: 20 }}
                />
                <Text
                  style={{
                    fontSize: 20,
                    marginLeft: 10,
                    color: 'white',
                    alignSelf: 'center',
                  }}>
                  Share
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  justifyContent: 'center',
                  marginTop: 10,
                }}
                onPress={() => this.downloadQRCode()}>
                <Image
                  resizeMode='contain'
                  source={images.download}
                  style={{ alignSelf: 'center' }}
                />
                <Text style={{ marginLeft: 10 }}> Save to Photos </Text>
              </TouchableOpacity>
            </View>
          </View>
          {this.state.canceltext == false ? (
            <View
              style={{
                elevation: 10,
                backgroundColor: 'white',
                marginBottom: 10,
                borderRadius: 10,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  paddingTop: 10,
                  paddingBottom: 10,
                }}>
                <Image
                  style={{
                    width: 20,
                    height: 20,
                    marginLeft: 20,
                    alignSelf: 'center',
                  }}
                  source={images.info}
                />
                <View style={{ width: '80%', alignContent:"flex-start" }}>
                  <Text
                    style={{
                      fontWeight: 'bold',
                      color: appheadertextColor,
                      fontSize: 12,
                    }}>
                    Did you know ?
                  </Text>
                  <Text
                    numberOfLines={4}
                    style={{ fontSize: 10, color: appheadertextColor }}>
                    You can invite your students directly to your profile on
                    idutor by sharing your QR code with them.idutor does not
                    charge any convenience fee for students enrolled to your
                    courses using your QR code.
                  </Text>
                </View>
              </View>
            </View>
          ) : null}
        </Modal>
                <ScrollView>
                    <View><View style={{ flexDirection: 'row', backgroundColor: 'white', height: 100, justifyContent: 'space-between', elevation: 10 }}>
                        <View style={{ marginTop: 15 }} >
                            <TouchableOpacity
                                onPress={() => {
                                    this.props.navigation.goBack();

                                }}
                            >
                                <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />

                            </TouchableOpacity>
                        </View>
                        <Image style={{ width: 90, height: 25, marginTop: 10 }} source={images.logo} resizeMode={'contain'} />

                        <TouchableOpacity
                            onPress={() => {
                                this.setState({ filterpopup: true })
                            }}
                        >
                            <Icon1 style={{ marginTop: 15, alignContent: 'flex-end', marginRight: 10 }} name="bell-o" size={20} color={'black'} />
                        </TouchableOpacity>
                    </View>

                        <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                            <View style={[Styles.searchinput,]}>

                                <View style={Styles.searchbackground} />
                                <View style={{ flexDirection: 'row', }}>
                                    <Icon1 style={{ marginLeft: 10, alignSelf: 'center' }} name="search" size={15} color="gray" />

                                    <Text style={{
                                        color: 'gray', flex: 1, height: 50, textAlignVertical: 'center',
                                        alignSelf: 'center',
                                        zIndex: 1,
                                        paddingLeft: 10,
                                    }}>Search</Text>
                                   <TouchableOpacity
                                    style={{alignContent:'center', justifyContent:'center' ,}}
                                    onPress={ ()=>{
 //this.setState({ showQr1: true })
 this.showQRCodeScanner()
 console.log("QR code scanner clicked", "true")
                                    }
                                       
                                    }>
                                     <Image
                                        source={images.qrcode}
                                        style={{ width: 18, height: 18, marginRight: 35, alignSelf: 'center' }}
                                    />
                                    </TouchableOpacity>

                                </View>
                            </View>

                        </View>
                    </View>

                    <View style={{ justifyContent: 'center', marginLeft: 10, marginRight: 10 }}>
                        <Text style={{ margin: 10 , fontWeight:'bold' , fontSize:13,fontFamily:'Helvetica' }}>Reschedule Class</Text>
                        <View style={{ width: widthPercentageToDP('95%'), backgroundColor: appgrayColor, marginRight: 10, elevation: 10, marginTop: 5 }}>

                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>

                                {/* <Image style={Styles.calimage }
                                    source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                                /> */}

{
                                  isEmpty(this.state.teacherListIamgeData[this.props.navigation.state.params.courseData?.imageId]?.content)
                                    ?
                                    <Image style={Styles.calimage}
                                      source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                                    // source={{ uri:`data:image/jpeg;base64,${this.state.teacherListIamgeData[item.course.imageId]?.content}`,  }} 
                                    />
                                    :
                                    <Image style={Styles.calimage}
                                      resizeMode='contain'
                                      source={{ uri: `data:image/jpeg;base64,${this.state.teacherListIamgeData[this.props.navigation.state.params.courseData?.imageId]?.content}`, }}
                                    />
                                }
                                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginLeft: 5, marginRight: 5, marginTop: 10, padding: 10 }}>
                                    <View style={{width:'50%', }}>
                                        <Text style={{ fontWeight: 'bold', fontSize: 13, }}> {this.getCourseName()} - {this.getClass()}</Text>
                                        <Text style={{ fontSize: 12, }}>{this.props.navigation.state.params.classData && this.props.navigation.state.params.classData.title}</Text>
                                    </View>

                                    <View style={{width:'30%'}}>
                                        <Text style={{ fontWeight: 'bold', fontSize: 13, alignSelf: 'flex-end' }}>{moment(this.props.navigation.state.params.classData.date).utc().format("DD , MMM")}</Text>
                                        <Text style={{ fontSize: 12, alignSelf: 'flex-end' }}>{this.getClassStartTimeFormatted(this.props.navigation.state.params.classData.startTime)}</Text>
                                    </View>
                                </View>
                            </View >


                        </View>
                        <Text style={{ margin: 10 , fontWeight:'bold' , fontSize:13,fontFamily:'Helvetica' }}>Update Details</Text>

                        <View style={[Styles.addprofilescreeninput1, { marginTop: 20, marginBottom: 10, flexDirection: 'row' }]}
                        >
                            <TextInput
                                ref='add'
                                style={Styles.textInput}
                                value={moment(this.state.rescheduleDate).format("DD-MM-YYYY")}
                                disableFullscreenUI={true}
                                onChangeText={this.getDateIsValid()}
                                placeholder={moment(this.state.rescheduleDate).format("DD-MM-YYYY")}
                                placeholderTextColor={'gray'}
                                underlineColorAndroid="transparent"
                                returnKeyType="done"
                            />
<TouchableOpacity 
style={{
    width: '20%',
    height: '50%', alignSelf: 'center'
}}
onPress={()=>{
                                    console.log("calendar clicked :-", 'true')
                                    this.setState({showDatePicker:true,})
                                    this.showDatePickerDialog()
                                }
                                    
                                    }>
                            <Image

                                source={images.cal_slct}
                                style={{
                                    width: 25,
                                    height: 25, marginRight: 10, alignSelf: 'center'
                                }}
                                
                            ></Image>
                            </TouchableOpacity>
                        </View>

                        <View style={{ flexDirection: 'row' }}>
                            <Text style={{ color: '#888888', marginLeft: 10 }}>Start Time</Text>
                            <Text style={{ color: '#888888', marginLeft: 130 }}>End Time</Text>
                        </View>

                        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                            <View style={[{
                                width: '50%', marginTop: 20, marginBottom: 10, backgroundColor: 'white', height: 50, elevation: 5, borderRadius: 20, flexDirection: 'row'
                            }]}
                            >
                                
                                <TextInput
                                    ref='add'
                                    style={Styles.textInput}
                                    value={this.state.rescheduleStartTime}
                                    disableFullscreenUI={true}
                                    onChangeText={this.getValidTimeDurationForClass()}
                                    placeholder={this.state.rescheduleStartTime}
                                    placeholderTextColor={'gray'}
                                    underlineColorAndroid="transparent"
                                    returnKeyType="done"
                                />

<TouchableOpacity 
style={{
    width: '30%',
    height: '50%', marginRight: 10, alignSelf: 'center'
}}
onPress={()=>{
                                    console.log("calendar clicked :-", 'true')
                                    this.setState({showDatePicker:true,startTimeSelection:true, endTimeSelection:false,mode:'time'})
                                    this.showTimePickerDialog()
                                }
                                    
                                    }>
                                <Image

                                    source={images.id_clock}
                                    style={{
                                        width: 25,
                                        height: 25, marginRight: 10, alignSelf: 'center'
                                    }}
                                ></Image>
                                </TouchableOpacity>
                            </View>

                            <View style={[{
                                width: '50%', marginTop: 20, marginBottom: 10, backgroundColor: 'white', height: 50, elevation: 5, borderRadius: 20, flexDirection: 'row'
                            }]}
                            >
                                 <TextInput
                                    ref='add'
                                    style={Styles.textInput}
                                    value={this.state.rescheduleEndTime}
                                    disableFullscreenUI={true}
                                    onChangeText={this.getValidTimeDurationForClass()}
                                    placeholder={this.state.rescheduleEndTime}
                                    placeholderTextColor={'gray'}
                                    underlineColorAndroid="transparent"
                                    returnKeyType="done"
                                />
<TouchableOpacity 
 style={{
    width: '30%',
    height: '50%', marginRight: 10, alignSelf: 'center', justifyContent:'center',
}}
onPress={()=>{
                                    console.log("calendar clicked :-", 'true')
                                    this.setState({showDatePicker:true,startTimeSelection:false, endTimeSelection:true,mode:'time',})
                                    this.showTimePickerDialog()
                                }
                                    
                                    }>
                               

                                <Image

                                    source={images.id_clock}
                                    style={{
                                        width: 25,
                                        height: 25, marginRight: 10, alignSelf: 'center'
                                    }}
                                ></Image>
                                </TouchableOpacity>
                            </View>

                        </View>

                        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginLeft: 5, marginRight: 5, marginTop: 10, padding: 10 }}>
                                    <View style={{width:'10%',alignSelf:'center' }}>
                                    <Image

source={images.info}
style={{
    width: 25,
    height: 25, marginRight: 10, alignSelf: 'center'
}}
></Image>
                                    </View>

                                    <View style={{width:'90%'}}>
                                        <Text style={{ fontWeight: 'bold', fontSize: 11, alignSelf: 'flex-start' }}>Course end date {this.getClassEndDate()}</Text>
                                        <Text style={{ fontSize: 10, alignSelf: 'flex-start' }}>The classes can be rescheduled within the defined course end date only</Text>
                                    </View>
                                </View>

                    </View>

                </ScrollView>
                <TouchableOpacity 
                
                onPress={() => 
                    {
                        this.rescheduleClassApiCall()
                    
                    }} 
                    
                    style={{ position: 'absolute', bottom: 10, alignSelf: 'center', left: 20, right: 20 }}>
                    <Text style={{ marginBottom: 5, color: 'white', marginTop: 10, backgroundColor: appblueColor, borderRadius: 20, paddingBottom: 10, paddingTop: 10, textAlign: 'center', width: '100%', fontSize: 15 }}>Update</Text>
                </TouchableOpacity>

                {this.state.showDateTimePicker && (
        <DateTimePicker
          testID="dateTimePicker"
          value={this.state.rescheduleDate}
          mode={this.state.mode}
          is24Hour={true}
          display="default"
          onChange={this.setValue}
        />
      )}
      
            </View >
        )
    }




}


const mapStateToProps = state => ({
    prof: state.prof,
    rescheduleClassDataProps : state.dash.rescheduleClassData,
  })

  const mapDispatchToProps = {
   
    rescheduleClass,
  }


const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        marginBottom: 40,
        marginTop: 10
    },
    labelContainer: {


        justifyContent: 'center', alignContent: 'center',
        backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
        width: '98%', borderRadius: 10,

    },
    topHead: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingLeft: 10,
        marginBottom: 5,
        marginTop: 5
    },
    topHead2: {

        flexDirection: 'row',
        flexWrap: 'wrap',
        // justifyContent: 'space-between',
        paddingRight: 10,
        paddingLeft: 10,

    },
    ButtonContainer: {
        // flex: .8,
        borderWidth: 1,
        borderColor: `${COLORS.MAINCOLOR.BLUE}`,
        padding: 5,
        paddingLeft: 15,
        paddingRight: 15,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
    },
    ViewDetailContainer: {
        // flex: .8,
        borderWidth: 1,
        borderColor: `${COLORS.MAINCOLOR.BLUE}`,
        padding: 5,
        paddingLeft: 10,
        paddingRight: 10,
        backgroundColor: '#fff',

        marginBottom: 10
    },
    Buttontext: {
        color: `${COLORS.MAINCOLOR.BLUE}`,
        fontSize: 12
    },
    grossText: {

        flexDirection: 'row',

        width: widthPercentageToDP('50%'),

    },
    MyAccount2: {
        flex: 1,
        flexDirection: 'column'
    },
    MyAccountItems: {
        flex: 1,
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignContent: 'center',
        justifyContent: 'space-around',
        paddingLeft: 15,
        paddingTop: 10
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(RescheduleClassScreen);
