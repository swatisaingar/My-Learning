import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity, TouchableWithoutFeedback,
  FlatList, Alert, TextInput, ToastAndroid, Image, Dimensions
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import Topbar from '../../Common/MenuBar'
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import * as EnquiryAPI from '../../Services/enquiryAPIs';
import { connect } from 'react-redux';
import Moment from 'moment';
import Loader from '../../Common/Loader';
import TextField from '../../Common/TextInput';
import _ from "lodash";
import { heightPercentageToDP } from 'react-native-responsive-screen';
import { appbluebtnColor, appblueColor, appgrayColor, loginheaderColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import Modal from "react-native-modal";
import { Checkbox } from 'react-native-paper';
import NavigationService from '../../Services/NavigationService';
import { aboutUs } from '../../actions';
import HTML from 'react-native-render-html';

class TermsScreen extends Component {

  constructor(props) {
    super(props);
    this.state = {
      title: '',
      desc: '',
      filterArr: [{ id: -1, text: 'Top Rated' }, { id: 1, text: 'Top Rated', selected: 0 },
      { id: 2, text: 'Best Match', selected: 0 }, { id: 3, text: 'Price Low to High', selected: 0 }, { id: 4, text: 'Price High to Low', selected: 0 },],
      showLoader: false,
      showPopup: false,
      canceltext: '',
      _id: '',
      _selectedids: [],
      start: 0, total: 0,
      start2: 0, total2: 0, 

      searchList: [{
        'class': "CHemistry Class 12th",
        'teacher': 'By Sooraj Rai',
      }]
    }
  }
  componentDidUpdate(prevProps) {
    console.log("COMPONENT DID UPDATE CALLED");
    if(this.props.terms!=null)
    {
      if(this.props.terms!=prevProps.terms)
      {

        console.log("COMPONENT DID UPDATE CALLED"+JSON.stringify(this.props.terms));
this.setState({
  title:this.props.terms && this.props.terms.aboutData && this.props.terms.aboutData.data && this.props.terms.aboutData.data.name,
  desc:this.props.terms && this.props.terms.aboutData && this.props.terms.aboutData.data && this.props.terms.aboutData.data.content
})
      }
    }

  }
  async componentDidMount() {

    const { aboutUs } = this.props;
    await aboutUs();
     
  }

  showAlert(text) {
    Alert.alert('Error', text, [
      {
        text: 'OK'
      }
    ]);
  }


  render() {
    return (
      <View style={{ backgroundColor: 'white', flex: 1 }}>


        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();

              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={28} color="black" />
            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />
          <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

            <TouchableOpacity
              onPress={() => {
                this.setState({
                  filterpopup: true
                })
              }}
            >
              <Icon1 style={{ marginLeft: 15,}} name="bell-o" size={20} color="black" /></TouchableOpacity>
              
          </View>
        </View>
        <Text style={{ fontWeight: 'bold', marginLeft: 10, marginTop: 10, }}>{this.state.title}</Text>
        <ScrollView style={{ flex: 1, marginLeft: 10, marginRight: 10 }}>
          <View style={{ justifyContent: 'center', }}>
            <HTML html={this.state.desc} imagesMaxWidth={Dimensions.get('window').width} />
          </View>
        </ScrollView>

      </View >
    )
  }

}

const mapStateToProps = state => ({
  terms: state.aboutus

});
const mapDispatchToProps = {
  aboutUs
};
export default connect(mapStateToProps, mapDispatchToProps)(TermsScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
