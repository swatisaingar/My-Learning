import React, { Component } from 'react'
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity, TouchableWithoutFeedback,
    FlatList, Alert, TextInput, ToastAndroid, Image
} from 'react-native'
import Icon1 from 'react-native-vector-icons/FontAwesome';
import Topbar from '../../Common/MenuBar'
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import * as EnquiryAPI from '../../Services/enquiryAPIs';
import { connect } from 'react-redux';
import Moment from 'moment';
import Loader from '../../Common/Loader';
import TextField from '../../Common/TextInput';
import _ from "lodash";
import { heightPercentageToDP } from 'react-native-responsive-screen';
import { appbluebtnColor, appblueColor, appgrayColor, loginheaderColor,appheadertextColor } from '../../util/AppConstants';
import images from '../../util/img';
import Styles from '../../uistyles/Styles';
import Modal from "react-native-modal";
import { Checkbox } from 'react-native-paper';
import NavigationService from '../../Services/NavigationService';
import { profile, updateprofile, fetchBankDocumentIamgeCall , uploadBankImageData, fetchBankImageData} from '../../actions';
import {isNumber, isEmpty, now} from 'lodash';

var param ;
var bankDocImageData;
class UpdatedBankDetails extends Component {

    constructor(props) {
        super(props);
        this.state = {
            saving: true,
            current: false,
            profileDataToUpdate:'',
            docImage:'',
            docImageId:'',
           
        }
        console.log("ProfileData to update bank details-----", this.props.navigation.state.params && this.props.navigation.state.params.profileData)
        console.log("bank data=====", this.props.navigation.state.params.profileData.payment)

        console.log("bank data direct =====", this.props.navigation.state.params, this.props.navigation.state.params.docImageData)
        this.setState({docImage:this.props.navigation.state.params.docImageData, })
        bankDocImageData = this.props.navigation.state.params.docImageData,
        console.log('bankDocImageData==============',bankDocImageData)
        param = this.props.navigation.state.params && this.props.navigation.state.params.profileData
       
    }

componentDidMount(){
    if(this.props.navigation.state.params.profileData && this.props.navigation.state.params.profileData.data)
    {
        console.log('asjdvfkbv',this.props.navigation.state.params.profileData.data)
    }
    this.setState({
        profileDataToUpdate:this.props.navigation.state.params.profileData
    })

    var imageId = this.props.navigation.state.params && this.props.navigation.state.params.profileData && this.props.navigation.state.params.profileData.payment!=null && this.props.navigation.state.params.profileData.payment.imageId
    console.log("bank image id ========", imageId)
    this.props.fetchBankImageData(imageId)
}

componentDidUpdate(prevProps)
{
     if(prevProps.updateProfileData != this.props.updateProfileData)
     {
        console.log('updated profile========',this.props.updateProfileData)
     }

    //  if(prevProps.imagewithoutloopData != this.props.imagewithoutloopData)
    //  {
    //      console.log("Get bank image data ==========",this.props.imagewithoutloopData) 
    //      this.setState({docImage:this.props.imagewithoutloopData })
    //  }
}

updatedprofileValue()
{
        // const { updateprofile } = this.props;
        // await updateprofile(apiData);

        // if(param.payment.imageId==null)
        // {
        //     param.payment.image={}
        // }

        // else{

        //     param.payment.image ={
        //         id : this.props.updateProfileData.data.payment.imageId
        //     }
        // }

        console.log('apidata tempPayment being called',param.payment)
        var imageToUpload = this.props.navigation.state.params.docImageData
        param.payment.image = imageToUpload

        delete param.image
        console.log('apidata tempPayment after being called',param.payment , param)
        this.props.updateprofile(param)

}
    render() {
        return (
            <View style={{ backgroundColor: 'white', flex: 1 }}>

                <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 60, justifyContent: 'space-between', elevation: 10 }}>
                    <View style={{ marginTop: 15 }} >
                        <TouchableOpacity
                            onPress={() => {
                                this.props.navigation.goBack();

                            }}
                        >
                            <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={30} color="black" />

                        </TouchableOpacity>
                    </View>
                    <Image style={{ width: 90, height: 25, marginTop: 10 }} source={images.logo} resizeMode={'contain'} />

                    <View style={{ alignContent: 'flex-end', marginRight: 10, flexDirection: 'row', alignSelf: 'center' }}>

                        <TouchableOpacity>
                            <Icon1 style={{ marginLeft: 15 }} name="bell-o" size={20} color="black" /></TouchableOpacity>
                    </View>
                </View>

                <Text style={{ margin: 10, fontSize: 15 }}>Change Bank Details</Text>

                <View style={{ flexDirection: 'row', margin: 10 }}>
                    <Text style={{ color: '#888888' }}>Account Holder Name</Text>
                    {console.log("payment in UI  ==========",param , param.payment )}
                    <Text style={{ marginLeft: 75 }}>{param.payment &&  param.payment.holderName}</Text>
                </View>

                <View style={{ flexDirection: 'row', margin: 10 }}>
                    <Text style={{ color: '#888888' }}>Account Type</Text>
                    {param && param.payment  && param.payment.account_type == 1 ? <Text style={{ marginLeft: 130 }}>Savings</Text>:null}
                {param && param.payment &&  param.payment.account_type == 2 ? <Text style={{ marginLeft: 130 }}>Current</Text>:null}
                </View>

                <View style={{ flexDirection: 'row', margin: 10 }}>
                    <Text style={{ color: '#888888' }}>Account Number</Text>
                    <Text style={{ marginLeft: 107 }}>{ param && param.payment.accountNumber}</Text>
                </View>

                <View style={{ flexDirection: 'row', margin: 10 }}>
                    <Text style={{ color: '#888888' }}>IFSC Code</Text>
                    <Text style={{ marginLeft: 147 }}>{param && param.payment.ifscCode}</Text>
                </View>

                <View style={{ flexDirection: 'row', margin: 10 }}>
                    <Text style={{ color: '#888888' }}>PAN Number</Text>
                    <Text style={{ marginLeft: 130 }}>{param && param.payment.panNumber}</Text>
                </View>
                <View style={{ flexDirection: 'row', margin: 10 }}>
                    <Text style={{ color: '#888888' }}>Aadhar Number</Text>
                    <Text style={{ marginLeft: 110 }}>{param && param.payment.adhaarNumber}</Text>
                </View>
                {console.log("image for doc IN UISGSHXGSHXSH==========", this.props.navigation.state.params.docImageData)}

                {
                     (isEmpty(this.props.navigation.state.params.docImageData)) ?  
                     <Image 
                     resizeMode="contain"
                     source={images.id_doc_palceholder} 
                     style={{ marginTop: 5, justifyContent: 'center',alignSelf:'center' }}/>
                      :
                      <View>
                        {console.log("image get data 2 in Update bank details ========",this.state.docImage )}
                        <Image style={{ width: '50%', height: '50%', alignSelf:'center',}} 
                        source={{ uri:`data:image/jpeg;base64,${this.props.navigation.state.params.docImageData?.content}`,  }} />
                      </View> 
                   }

                <TouchableOpacity onPress={() => {
                        this.updatedprofileValue();
                        //pProfile
                }
                } style={{ position: 'absolute', bottom: 10, alignSelf: 'center', left: 20, right: 20 }}>
                    <Text style={{ marginBottom: 5, color: 'white', marginTop: 10, backgroundColor: appblueColor, borderRadius: 20, paddingBottom: 10, paddingTop: 10, textAlign: 'center', width: '100%' }}>Confirm</Text>
                </TouchableOpacity>
            </View >
        )
    }

}

const mapStateToProps = state => ({
    user: state.auth,
    // prof: state.prof,
    updateProfileData : state.prof.profData,
    uploadBankImageDataResp : state.prof.bankImageDataData,
    imagewithoutloopData : state.prof.fetchBankImageDataData
});

const mapDispatchToProps = {
    // profile,
    updateprofile,
    uploadBankImageData,
    fetchBankImageData,

};

export default connect(mapStateToProps, mapDispatchToProps)(UpdatedBankDetails);

