import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View, TouchableOpacity, Image, FlatList, StatusBar, ActivityIndicator, ImageBackground, Dimensions, ScrollView, Modal, TouchableWithoutFeedback, WebView
} from 'react-native';
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP } from '../../constants/styles';
import images from '../../util/img';
import { appbluebtnColor, appblueColor, appgrayColor, loginheaderColor } from '../../util/AppConstants';
import NavigationService from '../../Services/NavigationService';
// import JustifiedText from 'react-native-justified-text';


export default class DormantScreen extends React.Component {
  constructor(props) {

    super(props);
    this.state = {
      data: [],
      text: '',
      modalVisible: false,
      currentImage: '',
      slideEnable: true,
      searchList: [{
        'class': "CHemistry Class 12th",
        'teacher': 'By Sooraj Rai',
      },
      {
        'class': "CHemistry Class 10th",
        'teacher': 'By Sooraj Rai',
      }]
    }

  }
  setModalVisible(visible, img) {
    this.setState({ modalVisible: visible, currentImage: img }); // set current image path to show it in modal
  }
  componentDidMount() {
    var arr = [];
    StatusBar.setHidden(false);


  }
  static navigationOptions = ({ navigation }) => {
    return {
      headerShown: false,
      tabBarLabel: 'Dormant',

    }
  };
  render() {

    return (

      <View>
        <FlatList
          data={this.state.searchList}
          nestedScrollEnabled={true}

          onEndReached={this._handleLoadMore}
          onEndReachedThreshold={0.01}
          renderItem={({ item }) => <View

          >
            <TouchableOpacity
              onPress={() => {
                console.log("LIST ITEM CLICKED");
                NavigationService.navigate('Events');
                //this.props.navigation.navigate('SearchDetailActivity')
                //this.props.navigation.navigate('LoginScreen');
              }}
            >
              <View style={{

                paddingRight: 5,
                paddingLeft: 5,
                marginTop: 10,
                justifyContent: 'center', alignItems: 'center',
              }}>
                <View style={styles.labelContainer}>

                  <View style={{ flexDirection: 'row' }}>

                    <Image

                      source={{ isStatic: true, uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                      style={{
                        width: widthPercentageToDP('22%'),
                        borderRadius: 10,
                      }}
                    ></Image>

                    <View style={{ width: '80%' }}>
                      <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                        <Text style={{ fontSize: 12, marginLeft: 10 }}>Chemistry Class 12th</Text>
                        <View style={{ flexDirection: 'row', marginRight: 20 }}>
                          <Image

                            source={images.star}
                            style={{
                              width: 15,
                              height: 15, marginRight: 1, marginLeft: 1
                            }}
                          ></Image>
                          <Image

                            source={images.star}
                            style={{
                              width: 15,
                              height: 15, marginRight: 1, marginLeft: 1
                            }}
                          ></Image>
                          <Image

                            source={images.star}
                            style={{
                              width: 15,
                              height: 15, marginRight: 1, marginLeft: 1
                            }}
                          ></Image>
                          <Image

                            source={images.star}
                            style={{
                              width: 15, marginRight: 1, marginLeft: 1,
                              height: 15,
                            }}
                          ></Image>

                          <Image

                            source={images.star}
                            style={{
                              width: 15,
                              height: 15, marginRight: 1, marginLeft: 1
                            }}
                          ></Image>
                        </View>

                      </View>
                       <View style={{ flexDirection: 'row'}}>
                       <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By Sooraj Rai, 5yr</Text>
                        <Image
                          resizeMode='contain'
                          source={images.confirmation}
                          style={{
                            width: 16,
                            height: 16, marginLeft:150,alignSelf:'center'
                          }}
                        ></Image>
                       
                      </View>
                      <Text style={{ marginLeft: 10, fontSize: 12 }}>M.A. Science</Text>
                      <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                      <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM 19-11-2020)</Text>
                      <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                        <Text style={{ fontSize: 10, marginLeft: 10, color: loginheaderColor }}>5:00 to 6:00 (1 hr)</Text>
                        <View style={{ flexDirection: 'row', marginRight: 10 }}>
                          <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10 }}>S</Text>
                          <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: loginheaderColor }}>M</Text>
                          <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10 }}>T</Text>
                          <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: loginheaderColor }}>W</Text>
                          <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10 }}>T</Text>
                          <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: loginheaderColor }}>F</Text>
                          <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10 }}>S</Text>
                        </View>
                      </View>

                      <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 5, marginBottom: 10 }}>
                        <View>
                          <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                          <Text style={{ color: loginheaderColor, fontSize: 10 }}>Registered</Text>
                        </View>
                        <View style={{ right: 20 }}>
                          <Text style={{ fontSize: 10 }}>DURATION (END DATE)</Text>
                          <Text style={{ color: loginheaderColor, fontSize: 10, alignSelf: 'flex-end' }}>3 M - (19-02-2021)</Text>
                        </View>
                      </View>


                    </View>
                  </View>
                </View>
              </View>

            </TouchableOpacity>


          </View>
          }
        />

      </View>

    );
  }
  renderRow(item, index) {
    console.log('item inside' + item.text);
    return (



      <View style={{ margin: 5, width: Dimensions.get('window').width / 2 - 10 }}>
        <TouchableWithoutFeedback onPress={() => {
          //this.setModalVisible(true, item.img);
          global.pos = Number(index);
          //global.pos=item.id;

          global.images = this.state.data;

          console.log('current position   ' + global.pos);
          //console.log('total images'+global.images.length);

          this.props.navigation.navigate('SliderScreen');
        }}>
          <View style={{ justifyContent: 'center' }}>
            <Image
              style={{ height: 100, width: '100%' }}
              resizeMode={'cover'}
              source={{ uri: item.img }}>
            </Image>
            <View style={{ position: 'absolute', width: '100%', bottom: 0, left: 0, backgroundColor: 'black', opacity: .6 }}>
              <Text style={{ margin: 4, color: 'white', textAlign: 'center', fontFamily: 'Helvetica', fontSize: 11, fontWeight: 'bold' }} numberOfLines={1}>{item.text}</Text>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </View>


    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})



