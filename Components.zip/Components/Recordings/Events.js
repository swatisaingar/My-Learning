import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,Image,
  FlatList, Alert, Modal, TextInput,ToastAndroid
} from 'react-native'
import Topbar from '../../Common/MenuBar'
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import NavigationService from '../../Services/NavigationService';
import { connect } from 'react-redux';
import Moment from 'moment';
import Loader from '../../Common/Loader';
import _ from "lodash";
 import VideoPlayer from "react-native-video-player";
//import Video from 'react-native-video';
// import Video from 'react-native-af-video-player'
import images from '../../util/img';
import Icon1 from 'react-native-vector-icons/FontAwesome';
import Styles from '../../uistyles/Styles';

class Events extends Component {

  constructor(props) {
    super(props);
    this.state = {
      enquiries: [{"name":"Class topic name by Teacher1"},{"name":"Class topic name by Teacher2"},{"name":"PG3"}],
      showLoader: false,
      showPopup: false,
      canceltext: '',
      _id:'',
      _selectedids:[],
      start: 0,total:0
    }
  }

  componentDidMount() {
   
  }

  showAlert(text) {
    Alert.alert('Error', text, [
      {
        text: 'OK'
      }
    ]);
  }
  _handleLoadMore = () => {
		console.log(
		  "load more" + this.state.start + "TOTAL" + this.state.total
		);
	
		if (this.state.start <= this.state.total) {
		
		console.log("CALL METHOD"); 
	
		}
	  };

  render() {
    return (
        <View style={{flex:1}}>
          <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 50, justifyContent: 'space-between', elevation: 10 ,marginTop:5}}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();
              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={25} color="black" />
            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 10,marginLeft:120 }} source={images.logo} resizeMode={'contain'} />

            <Icon1 style={{ marginTop: 15, alignContent: 'flex-end',marginLeft:80 }} name="bell-o" size={25} color={'black'} />
            <TouchableOpacity onPress={()=>NavigationService.navigate('ProfileScreen')}>
          <Image
              resizeMode='contain'
                source={images.prof}
                style={{ width: 25, height: 25, marginLeft:5,marginRight:20,marginTop:15}}
              />
              </TouchableOpacity>
        </View>
          <View style={{flexDirection:'row',justifyContent:'center',marginTop:30}}>
          <View style={[Styles.searchinput,]}>
 
            <View style={Styles.searchbackground} />
<View style={{flexDirection:'row', }}>
       <Icon1 style={{ marginLeft: 10,alignSelf:'center' }} name="search" size={15} color="gray" />

       <Text style={{color:'gray',   flex: 1,height:50,textAlignVertical:'center',
alignSelf:'center',
    zIndex: 1,
    paddingLeft: 10,}}>Search Teacher/Courses</Text>
         
            
            </View>
            {/* <Icon1 style={{ marginRight: 10,alignSelf:'center' }} name="qrcode" size={20} color="black" /> */}

            </View> 
            </View>   
        <ScrollView style={styles.container}>
          <Loader show={this.state.showLoader} />
         
         

          <FlatList
            data={this.state.enquiries}
            onEndReached={this._handleLoadMore}
            onEndReachedThreshold={0.01}
            renderItem={({ item }) => <View>
              <View style={{justifyContent:'center'}}>
   
                <View  style={{
                  paddingTop: 10,
                  alignItems: 'center'
                }}>
              <View style={styles.statusContainer}>
              
                <View style={styles.topHead}>
                 
                    <Text style={{fontSize:12,fontWeight:'bold'}}>{item.name}</Text>
              <Text style={{fontSize:12,fontStyle:'italic'}}>27-11-2020</Text>
                    {/* <Text style={{fontSize:12}}>{Moment(item.updatedAt).format('MMM DD, YYYY hh:mm a')}</Text> */}

                  

                 {/*  <View
                      style={{
                        justifyContent: 'flex-end',
                        alignItems: 'flex-end',
                        marginRight:10
                      }}
                    >
                      <Text style={{fontWeight:'bold',fontSize:12,}}>Status : {item.status}</Text>
                      </View> */}
                
                </View>
                
              
              </View>
</View>
<TouchableOpacity onPress={() => {
NavigationService.navigate('EventsPlay');
}} >
<Image source={{uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' } } style={{
							height: 200, width: (widthPercentageToDP('95%')),borderRadius:10,elevation:10,
					marginLeft:10,marginRight:10
						}}></Image> 
            </TouchableOpacity>
            <Image style={{ width: 30, height: 30,alignSelf:'center',position:'absolute' }} source={images.play}  />

 {/* <Video source={{uri: "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"}}   // Can be a URL or a local file.
       ref={(ref) => {
         this.player = ref
       }}   
       useNativeControls 
       // Store reference
         // Callback when video cannot be loaded
       style={styles.backgroundVideo} />  */}
   {/* <Video url={"http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"} /> */}
{/* <VideoPlayer
    video={{ uri: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' }}
    videoWidth={widthPercentageToDP('100%')}
    videoHeight={200}
    disableFullscreen
    
    thumbnail={{ uri: 'http://testbmj.tk:4999/api/product-store/getProductImage?name=20-HWAY-MDS-8-002_s.jpeg' }}
/> */}
{/* <Video
          autoPlay
          url={'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'}
          title={"TITLEEE"}
          logo={'http://testbmj.tk:4999/api/product-store/getProductImage?name=20-HWAY-MDS-8-002_s.jpeg'}
          placeholder={'http://testbmj.tk:4999/api/product-store/getProductImage?name=20-HWAY-MDS-8-002_s.jpeg'}
          onMorePress={() => {console.log("MORE PRESSED")}}
         // onFullScreen={status => this.onFullScreen(status)}
         // fullScreenOnly
        /> */}
{/* 
<Player
         
         /> */}
                     </View>
            </View>
            }
          // keyExtractor={item => item.id}
          />

         



          
        </ScrollView >
      
        
        </View>
    )
  }
//   refresh = (data) => {
//     console.log("RCVD" + data);
//     if (this.props.user && this.props.user.user && this.props.user.user.data.token) {
//       this.setState({ showLoader: true })
//       EnquiryAPI.enquiryHistory(this.props.user.user.data.token, 0,10).then(res => {

//        // console.log(JSON.stringify(res));
//         this.setState({ showLoader: false })
//         if (res.data.status == 1 && res.data.enquiries) {
        
// if(res.data.enquiries.length>0)
// {

//           this.setState({ enquiries: res.data.enquiries, start: this.state.start + 10,total:res.data.count });
//           console.log(JSON.stringify(res.data));
// }
// else
// {
//   ToastAndroid.showWithGravity(
//     "There is no enquiry submitted by you",
//     ToastAndroid.SHORT,
//     ToastAndroid.BOTTOM //can be SHORT, LONG
//   );
// }
//         } else if (res.data.status != 1) {
//           console.log(JSON.stringify(res.data))
//           this.showAlert(res.data.message);
//         }
//       });
//     }

//   };
}

const mapStateToProps = state => ({
  user: state.user
});

export default connect(mapStateToProps)(Events);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop:10
  },
  statusContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    width: widthPercentageToDP('95%')
  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft:10,
    marginBottom:5,
    marginTop:5
  },
  topHead2: {
    
    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,
 
  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',
   
    marginBottom:10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize:12
  },
  grossText: {
  
    flexDirection: 'row',
   
    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  },
  backgroundVideo: {
 width:'100%',height:200
  },
})
