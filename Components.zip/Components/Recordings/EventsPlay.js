import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,Image,
  FlatList, Alert, Modal, TextInput,ToastAndroid
} from 'react-native'
import Topbar from '../../Common/MenuBar'
import { COLORS, widthPercentageToDP } from '../../constants/styles'

import { connect } from 'react-redux';
import Moment from 'moment';
import Loader from '../../Common/Loader';
import _ from "lodash";
// import VideoPlayer from "react-native-video-player";
//import Video from 'react-native-video';
// import Video from 'react-native-af-video-player'
import VideoPlayer from 'react-native-video-controls';

class Events extends Component {

  constructor(props) {
    super(props);
    this.state = {
      enquiries: [{"name":"Class topic name by Teacher"},{"name":"PG2"},{"name":"PG3"}],
      showLoader: false,
      showPopup: false,
      canceltext: '',
      _id:'',
      _selectedids:[],
      start: 0,total:0
    }
  }

  componentDidMount() {
   
  }

  showAlert(text) {
    Alert.alert('Error', text, [
      {
        text: 'OK'
      }
    ]);
  }
  _handleLoadMore = () => {
		console.log(
		  "load more" + this.state.start + "TOTAL" + this.state.total
		);
	
		if (this.state.start <= this.state.total) {
		
		console.log("CALL METHOD"); 
	
		}
	  };

  render() {
    return (
     <View style={{flex:1,justifyContent:'center',backgroundColor:'black'}}>
   {/*  <VideoPlayer
    video={{ uri: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' }}
    videoWidth={widthPercentageToDP('100%')}
    videoHeight={200}
    thumbnail={{ uri: 'http://testbmj.tk:4999/api/product-store/getProductImage?name=20-HWAY-MDS-8-002_s.jpeg' }}
/>  */}
     <VideoPlayer
  source={{uri: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4'}}
 // navigator={this.props.navigator}
 //navigator={null}
//  tapAnywhereToPause={true}
disableFullscreen	={false}
disableBack
disableVolume
toggleResizeModeOnFullscreen	
playWhenInactive={true}
playInBackground={true}
title={'yesss'}
/>
        
        </View>
    )
  }
//   refresh = (data) => {
//     console.log("RCVD" + data);
//     if (this.props.user && this.props.user.user && this.props.user.user.data.token) {
//       this.setState({ showLoader: true })
//       EnquiryAPI.enquiryHistory(this.props.user.user.data.token, 0,10).then(res => {

//        // console.log(JSON.stringify(res));
//         this.setState({ showLoader: false })
//         if (res.data.status == 1 && res.data.enquiries) {
        
// if(res.data.enquiries.length>0)
// {

//           this.setState({ enquiries: res.data.enquiries, start: this.state.start + 10,total:res.data.count });
//           console.log(JSON.stringify(res.data));
// }
// else
// {
//   ToastAndroid.showWithGravity(
//     "There is no enquiry submitted by you",
//     ToastAndroid.SHORT,
//     ToastAndroid.BOTTOM //can be SHORT, LONG
//   );
// }
//         } else if (res.data.status != 1) {
//           console.log(JSON.stringify(res.data))
//           this.showAlert(res.data.message);
//         }
//       });
//     }

//   };
}

const mapStateToProps = state => ({
  user: state.user
});

export default connect(mapStateToProps)(Events);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop:10
  },
  statusContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: widthPercentageToDP('95%')
  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft:10,
    marginBottom:5,
    marginTop:5
  },
  topHead2: {
    
    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,
 
  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',
   
    marginBottom:10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize:12
  },
  grossText: {
  
    flexDirection: 'row',
   
    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  },
  backgroundVideo: {
 width:'100%',height:200
  },
})
