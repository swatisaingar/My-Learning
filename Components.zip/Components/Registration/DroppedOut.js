import React, { Component } from 'react';
import {
    Platform,
    StyleSheet,
    Text,
    View, TouchableOpacity, Image, FlatList, StatusBar, ActivityIndicator, ImageBackground, Dimensions, ScrollView, Modal, TouchableWithoutFeedback, WebView
} from 'react-native';
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import { appbluebtnColor, appblueColor, appgrayColor, loginheaderColor, apppinkColor, appheadertextColor } from '../../util/AppConstants';

// import JustifiedText from 'react-native-justified-text';
import images from '../../util/img';
// import JustifiedText from 'react-native-justified-text';
import { connect } from 'react-redux';
import {fetchDropStudentData} from '../../actions'
import {isNumber, isEmpty, now} from 'lodash';
import moment from 'moment'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../../util/AppConstants';

 class DroppedOut extends React.Component {
    constructor(props) {

        super(props);
        this.state = {
            data: [],
            text: '',
            modalVisible: false,
            currentImage: '',
            slideEnable: true,
            searchList: [{
                'class': "CHemistry Class 12th",
                'teacher': 'By Sooraj Rai',
            },],

            studentList:[],
            showLoader:true,
            teacherListIamgeData:[],
        }

    }
    setModalVisible(visible, img) {
        this.setState({ modalVisible: visible, currentImage: img }); // set current image path to show it in modal
    }


    componentDidMount()
    {
        var arr = [];
        StatusBar.setHidden(false);
        this.props.fetchDropStudentData({
            type:'dropout',
           
        
          })
    }

     async componentDidUpdate(prevProps)
    {
        if (
            prevProps.teacherStudentListData != this.props.teacherStudentListData
          ) {
              this.setState({showLoader : false,})
         
            console.log("teacher's student list -----", this.props.teacherStudentListData)
            this.setState({studentList:this.props.teacherStudentListData.data, })

            this.props.studentData?.data?.data?.map((item) => {
                // this.props.imageLoad(item?.courseClass?.course?.imageId)
                console.log("item to fetch image============", item)
                let id = item?.imageId;
                console.log("imageId ========", id)
                fetch(`${baseURL}file-blobs/getImage/${id}`, {
                  method: 'GET',
                  headers: {
                    Authorization: `Bearer ${AuthToken}`,
                 }
                }).then(data => {
                  return data.json()
                }).then(resposne => {
                  console.log("image======", resposne.data)
                  let imageData = this.state.teacherListIamgeData || {};
                  imageData[resposne.data.id] = resposne.data;
                  this.setState(imageData);
                  console.log('image datadata',imageData)
                  this.setState({teacherListIamgeData : imageData, })
                }).
                  catch((error) => {
                    console.log("#error", error);
                  })
        
                console.log("ImageData=============", this.state.teacherListIamgeData)
            
                    console.log("ImageData=============", this.state.teacherListIamgeData)
                
                  })

                  this.setState({activeStudentList: this.props.studentData.data.data ,})
            }
           
        }

    
    static navigationOptions = ({ navigation }) => {
        return {
            headerShown: false,
            tabBarLabel: 'Dropped Out',

        }
    };

    getPaymentStatus(status)
    {
        switch(status)
        {
            case 1:
                return "Paid"

                case 2:
                    return 'Pending'

                    default:
                        return 'Unknown'
        }
    }


        render() {

        return (

            <View style={{marginTop:10,flex:1, justifyContent:'center'}}>

{this.state.showLoader ? (
          <View style={{marginTop:40, alignSelf:'center', }}>
            <ActivityIndicator />
          </View>
        ) : null}
                  {
                    isEmpty(this.props.teacherStudentListData && this.props.teacherStudentListData.data) ?(
                        <View style={{flexDirection:'row',marginVertical:20,flex:1, justifyContent:'center'}}>
                               <Text style = {{alignSelf:'center' , justifyContent:'space-evenly',fontSize:15, fontWeight:'bold' , fontFamily:'Helvetica'}}>No student found</Text>
                            </View>
                         
                    )
                    :
                    (<View>
     <FlatList
     style={{marginBottom:10}}
                    data={this.props.teacherStudentListData && this.props.teacherStudentListData.data}
                    nestedScrollEnabled={true}
                    onEndReached={this._handleLoadMore}
                    onEndReachedThreshold={0.01}
                    renderItem={({ item }) => <View

                    >
                        <TouchableOpacity
                            onPress={() => {

                            }}
                        >
                            <View style={{

                                paddingRight: 5,
                                paddingLeft: 5,
                                marginTop: 10,
                                justifyContent: 'center', alignItems: 'center'
                            }}>
                                <View style={styles.labelContainer}>

                                    <View style={{ flexDirection: 'row' , marginBottom:10,}}>

                                    {
                                  isEmpty(this.state.teacherListIamgeData[item.imageId]?.content) 
                                    ?
                                    <Image style={{ 
                                        width: widthPercentageToDP('22%'),
                                    borderRadius: 10,}}
                                      source={{ uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                                    // source={{ uri:`data:image/jpeg;base64,${this.state.teacherListIamgeData[item.course.imageId]?.content}`,  }} 
                                    />
                                    :
                                    <Image style={{
                                        width: widthPercentageToDP('22%'),
                                        borderRadius: 10,
                                    }}
                                      resizeMode='contain'
                                      source={{ uri: `data:image/jpeg;base64,${this.state.teacherListIamgeData[item.imageId]?.content}`, }}
                                    />
                                }
                                        
                                          <View style={{ width: '75%', }}>
                                            <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                                            <Text style={{ fontSize: 14, marginLeft: 10 , color:'#353839', fontFamily:'Helvetica', fontWeight:'bold',}}>{item.firstName} {item.lastName}</Text>
                                                <Text style={{ color: loginheaderColor,fontSize: 14,fontFamily:'Helvetica', fontWeight:'bold', }}>Rs. {item.course_id.fee}</Text>
                                               
                                            </View>
                                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                                                
                                                <Text style={{ fontSize: 12, marginLeft: 10 , color:'#888888', fontFamily:'Helvetica'}}>{item.course_id.name} Class {item.course_id.standard.class}</Text>
                                                    <Text style={{ color:'#4d4d4d',marginLeft: 10, fontSize: 12 }}>{}</Text>
                                               
                                               
                                            </View>

                                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 5 }}>
                                                <View>
                                                    <Text style={{ fontSize: 9 , color:'#888888', fontWeight:'bold', fontFamily:'Helvetica',}}>START DATE</Text>
                                                    <Text style={{ fontSize: 11, fontFamily:'Helvetica', color:'#4d4d4d' }}>{moment(new Date(item.subscribedOn)).format('DD/MM/YYYY')}</Text>
                                                </View>
                                                <View style={{ right: 20 }}>
                                                    <Text style={{ fontSize: 9 , color:'#888888', fontWeight:'bold', fontFamily:'Helvetica',}}>END DATE</Text>
                                                    <Text style={{ fontSize: 11, fontFamily:'Helvetica', color:'#4d4d4d' }}>{moment(new Date(item.subscribedOn)).format('DD/MM/YYYY')}</Text>
                                                </View>
                                                <View style={{right:20 ,}}>
                                                <Text style={{ color:'#36CE00',marginLeft: 10, fontSize: 11, fontFamily:'Helvetica', }}>{this.getPaymentStatus(item.paymentStatus)}</Text>
                                                </View>
                                            </View>             
                                        </View>
                                    </View>
                                </View>

                  
                            </View>

                        </TouchableOpacity>
                    </View>
                    }
                />
                    </View>
                    )
                }

            </View>

        );
    }

    renderRow(item, index) {
        console.log('item inside' + item.text);
        return (



            <View style={{ margin: 5, width: Dimensions.get('window').width / 2 - 10 }}>
                <TouchableWithoutFeedback onPress={() => {
                    //this.setModalVisible(true, item.img);
                    global.pos = Number(index);
                    //global.pos=item.id;

                    global.images = this.state.data;

                    console.log('current position   ' + global.pos);
                    //console.log('total images'+global.images.length);

                    this.props.navigation.navigate('SliderScreen');
                }}>
                    <View style={{ justifyContent: 'center' }}>
                        <Image
                            style={{ height: 100, width: '100%' }}
                            resizeMode={'cover'}
                            source={{ uri: item.img }}>
                        </Image>
                        <View style={{ position: 'absolute', width: '100%', bottom: 0, left: 0, backgroundColor: 'black', opacity: .6 }}>
                            <Text style={{ margin: 4, color: 'white', textAlign: 'center', fontFamily: 'Helvetica', fontSize: 11, fontWeight: 'bold' }} numberOfLines={1}>{item.text}</Text>
                        </View>
                    </View>
                </TouchableWithoutFeedback>
            </View>


        )
    }
}

const mapStateToProps = state => ({
   
    teacherStudentListData : state.dash.fetchDropStudentData,
  })

  const mapDispatchToProps = {
   
    fetchDropStudentData,
  }

  export default connect(mapStateToProps, mapDispatchToProps)(DroppedOut)
const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        marginBottom: 40,
        marginTop: 10
    },
    labelContainer: {


        justifyContent: 'center', alignContent: 'center',
        backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
        width: '98%', borderRadius: 10,height:90

    },
    topHead: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingLeft: 10,
        marginBottom: 5,
        marginTop: 5
    },
    topHead2: {

        flexDirection: 'row',
        flexWrap: 'wrap',
        // justifyContent: 'space-between',
        paddingRight: 10,
        paddingLeft: 10,

    },
    ButtonContainer: {
        // flex: .8,
        borderWidth: 1,
        borderColor: `${COLORS.MAINCOLOR.BLUE}`,
        padding: 5,
        paddingLeft: 15,
        paddingRight: 15,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
    },
    ViewDetailContainer: {
        // flex: .8,
        borderWidth: 1,
        borderColor: `${COLORS.MAINCOLOR.BLUE}`,
        padding: 5,
        paddingLeft: 10,
        paddingRight: 10,
        backgroundColor: '#fff',

        marginBottom: 10
    },
    Buttontext: {
        color: `${COLORS.MAINCOLOR.BLUE}`,
        fontSize: 12
    },
    grossText: {

        flexDirection: 'row',

        width: widthPercentageToDP('50%'),

    },
    MyAccount2: {
        flex: 1,
        flexDirection: 'column'
    },
    MyAccountItems: {
        flex: 1,
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignContent: 'center',
        justifyContent: 'space-around',
        paddingLeft: 15,
        paddingTop: 10
    }
})

