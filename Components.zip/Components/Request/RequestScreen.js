import React, { Component } from 'react';
import {
    Platform,
    StyleSheet,
    Text,
    View, TouchableOpacity, Image, FlatList, StatusBar, ActivityIndicator, ImageBackground, Dimensions, ScrollView, Modal, TouchableWithoutFeedback, WebView
} from 'react-native';
import Icon1 from 'react-native-vector-icons/FontAwesome';
import { COLORS, heightPercentageToDP, widthPercentageToDP } from '../../constants/styles'
import { appbluebtnColor, appblueColor, appgrayColor, loginheaderColor, apppinkColor, appheadertextColor } from '../../util/AppConstants';
import Styles from '../../uistyles/Styles';

export default class RequestScreen extends React.Component {
    constructor(props) {

        super(props);
        this.state = {
            reject: true,
            accept: false,
            data: [],
            text: '',
            modalVisible: false,
            currentImage: '',
            slideEnable: true,
            searchList: [{
                'class': "CHemistry Class 12th",
                'teacher': 'By Sooraj Rai',
            },]
        }

    }
    setModalVisible(visible, img) {
        this.setState({ modalVisible: visible, currentImage: img }); // set current image path to show it in modal
    }
    componentDidMount() {
        var arr = [];
        StatusBar.setHidden(false);


    }
    static navigationOptions = ({ navigation }) => {
        return {
            headerShown: false,
            tabBarLabel: 'Requests',

        }
    };
    render() {

        return (

            <View>
                <ScrollView>
                    <View style={{

                        paddingRight: 5,
                        paddingLeft: 5,
                        marginTop: 10,
                        justifyContent: 'center', alignItems: 'center'
                    }}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text>Registration Requests for Offline Payments</Text>
                            <Image

                                source={{ isStatic: true, uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                                style={{
                                    width: widthPercentageToDP('10%'),
                                    height: heightPercentageToDP('5%'),
                                    borderRadius: 10,
                                    marginLeft: 25
                                }}
                            ></Image>
                        </View>
                        <View style={{ flexDirection: 'row', backgroundColor: '#F9F9F9', borderRadius: 10, width: '92%', alignSelf: 'center', height: 40, marginTop: 10 }}>
                            <Text style={{ marginLeft: 10, alignSelf: 'center', fontSize: 15 }}>New</Text>
                            <Text style={{ justifyContent: 'flex-end', color: '#5B82FF', marginLeft: 290, alignSelf: 'center', fontSize: 15 }}>25</Text>
                        </View>

                        <View style={[styles.labelContainer], { marginTop: 20 }}>

                            <View style={{ flexDirection: 'row' }}>

                                <Image

                                    source={{ isStatic: true, uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                                    style={{
                                        width: widthPercentageToDP('22%'),
                                        borderRadius: 10,
                                    }}
                                ></Image>

                                <View style={{ width: '75%' }}>
                                    <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                                        <Text style={{ fontSize: 12, marginLeft: 10 }}>Ramesh Sharma</Text>
                                        <Text style={{ color: loginheaderColor, fontSize: 12 }}>Rs. 1000</Text>

                                    </View>

                                    <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                                        <Text style={{ fontSize: 12, marginLeft: 10 }}>Delhi</Text>
                                        <Text style={{fontSize: 12 }}>21/21/2020</Text>

                                    </View>

                                    <Text style={{ fontSize: 12, marginLeft: 10 }}>Chemistry Class 12th</Text>

                                    <Text style={{ fontSize: 12, marginLeft: 10 }}>Timing</Text>
                                    <Text style={{ marginLeft: 10, fontSize: 12 }}>5:00 AM to 6:00 PM (1hr) S M T W T F S</Text>

                                    <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                                        <TouchableOpacity
                                            style={{
                                                backgroundColor: '#165ADC', marginLeft: 10,
                                                marginRight: 10,
                                                alignSelf: 'center',
                                                justifyContent: 'center',
                                                height: 40,
                                                width: '42%',
                                                borderRadius: 20,
                                                elevation: 5,
                                                marginTop: 5,
                                            }}
                                            onPress={() => {
                                                console.log("LIST ITEM CLICKED");
                                                this.setState({
                                                    reject: true,
                                                    accept: false
                                                })
                                            }}
                                        >
                                            <View>
                                                <Text style={{ alignSelf: 'center' }}>Reject</Text>
                                            </View>
                                        </TouchableOpacity>
                                        <TouchableOpacity
                                            style={{
                                                backgroundColor: '#FAA21C', marginLeft: 10,
                                                marginRight: 10,
                                                alignSelf: 'center',
                                                justifyContent: 'center',
                                                height: 40,
                                                width: '42%',
                                                borderRadius: 20,
                                                elevation: 5,
                                                marginTop: 5,
                                            }}
                                            onPress={() => {
                                                console.log("LIST ITEM CLICKED");
                                                this.setState({
                                                    reject: false,
                                                    accept: true
                                                })
                                            }}
                                        >
                                            <View
                                            >

                                                <Text style={{ alignSelf: 'center' }}>Accept</Text>

                                            </View>
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            </View>
                        </View>

                        
                        <View style={[styles.labelContainer], { marginTop: 20 }}>

                            <View style={{ flexDirection: 'row' }}>

                                <Image

                                    source={{ isStatic: true, uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                                    style={{
                                        width: widthPercentageToDP('22%'),
                                        borderRadius: 10,
                                    }}
                                ></Image>

                                <View style={{ width: '75%' }}>
                                    <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                                        <Text style={{ fontSize: 12, marginLeft: 10 }}>Ramesh Sharma</Text>
                                        <Text style={{ color: loginheaderColor, fontSize: 12 }}>Rs. 1000</Text>

                                    </View>

                                    <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                                        <Text style={{ fontSize: 12, marginLeft: 10 }}>Delhi</Text>
                                        <Text style={{fontSize: 12 }}>21/21/2020</Text>

                                    </View>

                                    <Text style={{ fontSize: 12, marginLeft: 10 }}>Chemistry Class 12th</Text>

                                    <Text style={{ fontSize: 12, marginLeft: 10 }}>Timing</Text>
                                    <Text style={{ marginLeft: 10, fontSize: 12 }}>5:00 AM to 6:00 PM (1hr) S M T W T F S</Text>

                                    <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                                        <TouchableOpacity
                                            style={{
                                                backgroundColor: '#165ADC', marginLeft: 10,
                                                marginRight: 10,
                                                alignSelf: 'center',
                                                justifyContent: 'center',
                                                height: 40,
                                                width: '42%',
                                                borderRadius: 20,
                                                elevation: 5,
                                                marginTop: 5,
                                            }}
                                            onPress={() => {
                                                console.log("LIST ITEM CLICKED");
                                                this.setState({
                                                    reject: true,
                                                    accept: false
                                                })
                                            }}
                                        >
                                            <View>
                                                <Text style={{ alignSelf: 'center' }}>Reject</Text>
                                            </View>
                                        </TouchableOpacity>
                                        <TouchableOpacity
                                            style={{
                                                backgroundColor: '#FAA21C', marginLeft: 10,
                                                marginRight: 10,
                                                alignSelf: 'center',
                                                justifyContent: 'center',
                                                height: 40,
                                                width: '42%',
                                                borderRadius: 20,
                                                elevation: 5,
                                                marginTop: 5,
                                            }}
                                            onPress={() => {
                                                console.log("LIST ITEM CLICKED");
                                                this.setState({
                                                    reject: false,
                                                    accept: true
                                                })
                                            }}
                                        >
                                            <View
                                            >

                                                <Text style={{ alignSelf: 'center' }}>Accept</Text>

                                            </View>
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            </View>
                        </View>

                        
                        <View style={[styles.labelContainer], { marginTop: 20,marginBottom:30 }}>

                            <View style={{ flexDirection: 'row' }}>

                                <Image

                                    source={{ isStatic: true, uri: 'https://lh3.googleusercontent.com/fife/ABSRlIptCaXnC8c-p_KPnzBZ30WZRFWDxre9_Dd9SgNCqcpDjsO2LS_NwLUGL1okHJeeVCzgyd1tlsg2BIhicuZ8Pj-xx3yXc3pnIbYYOVfJY2loePC9jkCfSD4gV-C4rnWbFgGlSrZqBMU9iBgQpSMTqaCSzzGH44jGlqdJt7ou0xyDH04vE2CWogNg1ZKZhN8Trf_As2rb7u-CHVq0tYmMBHeYtMrgs-3uaL_kCRc5PEjgS6jxe4x4-zm7LBWHTb-FPR8p0X4RDkCALiVjRZM9Rww5bc5a6T_F1W1nfofeE5xIIvsxfw_fO0yrlKBCEV7firznM4tbfQrWafRZcmH_7PuttYH6PhXbSyNvCa3YmHfWJNw9fwWLoJU1eKUzfQ8oi0xdXueOvdwZ6X-PSudx1MjQxA3ZoQ03FMmiUgP_ml0cXCmpQ9fuZB3LlmUryVHL1JMyXQRc202G1Zj-eddbFaNm9FGUBN0uyIz-2Bkq_L3NLHQW8YTzwpqg5UrhghQZzlGkHpGkH9iWDRwnCApjGGWvpI7K2nzu20QbR8WlWEYpSfCVgGNTWYDcXo_-WZ6ZzNEqVBodDZCv5SC9PHKf_lqs_LrpbeS8neWbaiZhFhxWj_Kxq25oWf7yuFXML20W3RXVOZAaNr24plnVV-6RVmpiGuJUOyf5taPmNLIOBtCUfDMe5SZ47WCpg5rHPrA-CJsKUc5p7gsqOIb_pktsr63asEGLTt-hDQx3r9gjcIapuA=s32-c' }}
                                    style={{
                                        width: widthPercentageToDP('22%'),
                                        borderRadius: 10,
                                    }}
                                ></Image>

                                <View style={{ width: '75%' }}>
                                    <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                                        <Text style={{ fontSize: 12, marginLeft: 10 }}>Ramesh Sharma</Text>
                                        <Text style={{ color: loginheaderColor, fontSize: 12 }}>Rs. 1000</Text>

                                    </View>

                                    <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                                        <Text style={{ fontSize: 12, marginLeft: 10 }}>Delhi</Text>
                                        <Text style={{fontSize: 12 }}>21/21/2020</Text>

                                    </View>

                                    <Text style={{ fontSize: 12, marginLeft: 10 }}>Chemistry Class 12th</Text>

                                    <Text style={{ fontSize: 12, marginLeft: 10 }}>Timing</Text>
                                    <Text style={{ marginLeft: 10, fontSize: 12 }}>5:00 AM to 6:00 PM (1hr) S M T W T F S</Text>

                                    <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                                        <TouchableOpacity
                                            style={{
                                                backgroundColor: '#165ADC', marginLeft: 10,
                                                marginRight: 10,
                                                alignSelf: 'center',
                                                justifyContent: 'center',
                                                height: 40,
                                                width: '42%',
                                                borderRadius: 20,
                                                elevation: 5,
                                                marginTop: 5,
                                            }}
                                            onPress={() => {
                                                console.log("LIST ITEM CLICKED");
                                                this.setState({
                                                    reject: true,
                                                    accept: false
                                                })
                                            }}
                                        >
                                            <View>
                                                <Text style={{ alignSelf: 'center' }}>Reject</Text>
                                            </View>
                                        </TouchableOpacity>
                                        <TouchableOpacity
                                            style={{
                                                backgroundColor: '#FAA21C', marginLeft: 10,
                                                marginRight: 10,
                                                alignSelf: 'center',
                                                justifyContent: 'center',
                                                height: 40,
                                                width: '42%',
                                                borderRadius: 20,
                                                elevation: 5,
                                                marginTop: 5,
                                            }}
                                            onPress={() => {
                                                console.log("LIST ITEM CLICKED");
                                                this.setState({
                                                    reject: false,
                                                    accept: true
                                                })
                                            }}
                                        >
                                            <View
                                            >

                                                <Text style={{ alignSelf: 'center' }}>Accept</Text>

                                            </View>
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            </View>
                        </View>

                    </View>

                    </ScrollView>
            </View>





        );
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        marginBottom: 40,
        marginTop: 10
    },
    labelContainer: {


        justifyContent: 'center', alignContent: 'center',
        backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
        width: '98%', borderRadius: 10,
        height: 90

    },
    topHead: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingLeft: 10,
        marginBottom: 5,
        marginTop: 5
    },
    topHead2: {

        flexDirection: 'row',
        flexWrap: 'wrap',
        // justifyContent: 'space-between',
        paddingRight: 10,
        paddingLeft: 10,

    },
    ButtonContainer: {
        // flex: .8,
        borderWidth: 1,
        borderColor: `${COLORS.MAINCOLOR.BLUE}`,
        padding: 5,
        paddingLeft: 15,
        paddingRight: 15,
        backgroundColor: '#fff',
        justifyContent: 'center',
        alignItems: 'center',
    },
    ViewDetailContainer: {
        // flex: .8,
        borderWidth: 1,
        borderColor: `${COLORS.MAINCOLOR.BLUE}`,
        padding: 5,
        paddingLeft: 10,
        paddingRight: 10,
        backgroundColor: '#fff',

        marginBottom: 10
    },
    Buttontext: {
        color: `${COLORS.MAINCOLOR.BLUE}`,
        fontSize: 12
    },
    grossText: {

        flexDirection: 'row',

        width: widthPercentageToDP('50%'),

    },
    MyAccount2: {
        flex: 1,
        flexDirection: 'column'
    },
    MyAccountItems: {
        flex: 1,
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignContent: 'center',
        justifyContent: 'space-around',
        paddingLeft: 15,
        paddingTop: 10
    }
})

