import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList, Alert, TextInput, TouchableWithoutFeedback, Image, ImageBackground, Dimensions
} from 'react-native';
import Icon1 from 'react-native-vector-icons/FontAwesome';
import RequestScreen from './RequestScreen';
import PaymentScreen from './PaymentScreen';

import { COLORS, widthPercentageToDP } from '../../constants/styles'
import { BASEURLIMAGE, loginheaderColor, appgrayColor, appbluebtnColor, appheadertextColor } from '../../util/AppConstants';
import images from '../../util/img';
import { createStackNavigator } from 'react-navigation-stack';

import { createAppContainer } from 'react-navigation'

import { createMaterialTopTabNavigator } from 'react-navigation-tabs';

class RequestTab extends Component {

  render() {


    const Stylelist = createAppContainer(createStackNavigator({
      TabDrawerScreen1: {
        screen:
          createMaterialTopTabNavigator({
            RequestScreen: { screen: RequestScreen },
            PaymentScreen: { screen: PaymentScreen },
          },
            {

              tabBarPosition: 'top',
              swipeEnabled: true,
              tabBarOptions: {
                scrollEnabled: true,
                activeTintColor: loginheaderColor,
                inactiveTintColor: appheadertextColor,
                indicatorStyle: {
                  opacity: 1,
                  backgroundColor: loginheaderColor

                },
                style:
                {
                  backgroundColor: 'white',
                },

                showIcon: false,
                lazy: true,
                upperCaseLabel: false,
                labelStyle: {
                  fontSize: 14,
                  fontFamily: "Helvetica",


                },

                tabStyle: { height: 50, width: Dimensions.get('window').width / 2 }
              }
            }
          ),
      },
    },

      { headerMode: 'none' }
    ));



    return (

      <View style={{ backgroundColor: 'white', flex: 1 }}>
        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 50, justifyContent: 'space-between', }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                this.props.navigation.goBack();
              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={30} color="black" />

            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 10 }} source={images.logo} resizeMode={'contain'} />

          <Icon1 style={{ marginTop: 15, alignContent: 'flex-end', marginRight: 10 }} name="bell-o" size={20} color={'black'} />

        </View>
        <Stylelist /></View >

    )
  }



}


export default RequestTab;

