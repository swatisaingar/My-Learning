'use strict';

import React, { Component } from 'react';
import { widthPercentageToDP, heightPercentageToDP } from 'react-native-responsive-screen';
import { connect } from 'react-redux';
import { UserLogout, imageWithoutLoopLoad ,profile} from '../actions';
import { Text, View, FlatList, TouchableOpacity, Alert, StyleSheet, Image, ScrollView } from 'react-native';
import { COLORS } from '../constants/styles';
import { BASEURLIMAGE, loginheaderColor, appheadertextColor } from '../util/AppConstants';
import NavigationService from '../Services/NavigationService';
import images from '../util/img';
import AsyncStorage from '@react-native-async-storage/async-storage';
var params;
import { baseURL } from '../util/AppConstants';

class SlideMenu extends Component {
	constructor(props) {
		super(props);
		this.state = {

			showCat: true,
			catdata: [],
			image: false,
			teacherimage: '',
			imageurl: '',
			name: 'User Name',
			newImageData:{},
			profileImage: {},
			imageData: {},
		}
		this.tableData = {
			Home: {
				screen: 'Home',
				title: 'Home',
				hasChild: false,
				icon: images.homeblck
			},
			Calendar: {
				screen: 'CalendarTab',
				title: 'Calendar',
				hasChild: false,
				icon: images.cal_blck
			},
			MyClasses: {
				screen: 'MyClassesScreen',
				title: 'My Classes',
				hasChild: false,
				icon: images.cal_blck
			},
			MySubscription: {
				screen: 'Subscriptions',
				title: 'My Subscription',
				hasChild: false,
				icon: images.touch
			},
			MyFiles: {
				screen: 'MyFilesScreen',
				title: 'My Files',
				hasChild: false,
				icon: images.files
			},
			MyShortlist: {
				screen: 'MyWishScreen',
				title: 'My Shortlist',
				hasChild: false,
				icon: images.shortlist_blck
			},
			FAQ: {
				screen: 'FAQScreen',
				title: 'FAQ',
				hasChild: false,
				icon: images.conversation
			},
			AboutUs: {
				screen: 'TermsScreen',
				title: 'About Us',
				hasChild: false,
				icon: images.aboutus
			},
			Logout: {
				screen: 'Logout',
				title: 'Logout',
				hasChild: false,
				icon: images.logout
			}
		};

		this.teachertableData = {
			Home: {
				screen: 'DashboardScreen',
				title: 'Home',
				hasChild: false,
				icon: images.homeblck
			},
			Calendar: {
				screen: 'CalendarTab',
				title: 'Calendar',
				hasChild: false,
				icon: images.cal_blck
			},
			MyClasses: {
				screen: 'MyClassesScreen',
				title: 'My Classes',
				hasChild: false,
				icon: images.laptop
			},
			MySubscription: {
				screen: 'TeacherSubscription',
				title: 'My Courses',
				hasChild: false,
				icon: images.courses
			},
			MyAccount: {
				screen: 'MyAccount',
				title: 'Account',
				hasChild: false,
				icon: images.lecture
			},
			MyStudent: {
				screen: 'RegistrationTab',
				title: 'My Students',
				hasChild: false,
				icon: images.reading
			},
			FAQ: {
				screen: 'FAQScreen',
				title: 'FAQ',
				hasChild: false,
				icon: images.conversation
			},
			AboutUs: {
				screen: 'TermsScreen',
				title: 'About Us',
				hasChild: false,
				icon: images.aboutus
			},
			Logout: {
				screen: 'Logout',
				title: 'Logout',
				hasChild: false,
				icon: images.logout
			}
		};
		params = this.props.navigation.state.params;
		this.menuListData = [];
		Object.keys(this.tableData).forEach(i => {
			this.menuListData.push(this.tableData[i]);
		});

		this.teachermenuList = [];
		Object.keys(this.teachertableData).forEach(i => {
			this.teachermenuList.push(this.teachertableData[i]);
		});
	}
	async componentDidUpdate(prevProps) {

		if (prevProps.user != this.props.user) {
			if (this.props.user != undefined) {
				if (this.props.user.profData != undefined) {

					if (!!this.props.user.profData && !!this.props.user.profData.data && !!this.props.user.profData.data.firstName) {
						this.setState({
							name: 'Welcome ' + this.props.user.profData.data.firstName
						})
					}
					if (!!this.props.user.profData && !!this.props.user.profData.data && !!this.props.user.profData.data.image && !!this.props.user.profData.data.image.content) {
						if (this.props.user.profData.data.image != undefined) {
							let imageUri = `data:image/jpeg;base64,${this.props.imagewithoutloopData && this.props.imagewithoutloopData.data &&this.props.imagewithoutloopData.data.content}`;
							this.setState({
								imageurl: imageUri,
								image: true,
								name: `Welcome ${this.props.user.profData.data.firstName ? this.props.user.profData.data.firstName : ''} ${this.props.user.profData.data.lastName ? this.props.user.profData.data.lastName : ''}`
							})
						}
						// else {
						// 	this.setState({
						// 		imageurl: '',
						// 		image: false,
						// 		name: ''
						// 	})
						// }
					}
				}
				const { user } = this.props;
				if (!!user.user && !!user.user.data && !!user.user.data.token) {
					let data = await client.get('category/categorylist', {
						headers: {
							Authorization: `Bearer ${user.user.data.token}`
						}
					});
					let dataarray = []
					data.data.data.map((item, i) => {
						let datatoadd = {
							childIds: item.childIds,
							categoryName: item.categoryName != undefined ? item.categoryName : 'Testing',
							_id: item._id,
							imagePath: item.imagePath,
							hasSubChild: item.childIds.length > 0 ? true : false,
							childOpen: false
						}
						dataarray.push(datatoadd)
					})
					this.setState({ catdata: dataarray })
				}
			} else {
				this.setState({
					imageurl: '',
					image: false,
					name: ''
				})
			}
		}
	}

	async componentDidMount() {
		this.props.imageWithoutLoopLoad(this.props.prof?.profData?.data?.imageId)
		const { user } = this.props;

		if (user.profData.data != null) {
		
			let imageUri = `data:image/jpeg;base64,${this.props.imagewithoutloopData && this.props.imagewithoutloopData.data && this.props.imagewithoutloopData.data.content}`;
			
			this.setState({
				imageurl: imageUri,
				image: true,
				name: `Welcome ${(user.profData.data && user.profData.data.firstName) ? user.profData.data.firstName : ''} ${(user.profData.data && user.profData.data.lastName) ? user.profData.data.lastName : ''}`
			})
		}
		else {
			this.setState({
				image: false,
				name: 'Welcome ' + user.loginMessage.data.user.first_name + " " + user.loginMessage.data.user.last_name
			})
		}

	}

	async callLogoutApi() {
		const { UserLogout } = this.props;
		await UserLogout();
		AsyncStorage.clear();
		this.props.navigation.closeDrawer();
		this.props.navigation.navigate('SplashScreen1');
	}

	menuTapped(menuInfo) {
		if (menuInfo.item.screen === 'Logout') {
			NavigationService.closeDrawerr();
			this.logOutUser();
		} else if (menuInfo.item.screen === 'Home') {
			this.props.navigation.closeDrawer()
			NavigationService.navigate('DashboardScreen')
		} else {
			this.props.navigation.navigate(menuInfo.item.screen);
		}
	}

	logOutUser() {
		Alert.alert('Logout', 'Are you sure you want to logout?', [
			{ text: 'Cancel' },
			{
				text: 'Ok',
				onPress: () => {
					this.callLogoutApi();
				}
			}
		]);
	}



	renderRow(rowData) {

		return (
			<TouchableOpacity
				style={{
					height: 50,
					justifyContent: 'center',
				}}
				onPress={() => this.menuTapped(rowData)}
			>
				<View style={{ flexDirection: 'row', }}>
					<View style={{ width: '20%', backgroundColor: 'white', height: 50, justifyContent: 'center' }}>

						<Image source={rowData.item.icon} style={{
							height: 20, width: 20,
							marginRight: 8, alignSelf: 'center', resizeMode: 'contain'
						}}></Image>
					</View>
					<View style={{ width: '80%', justifyContent: 'center', height: 50, backgroundColor: loginheaderColor, }}>
						<View>
							<Text style={{ color: 'white', fontSize: 13, alignSelf: 'flex-start', marginLeft: 20, }}>{rowData.item.title}</Text>

						</View></View>
				</View>
			</TouchableOpacity>
		);

	}

	renderListView() {
		return (
			<View style={{ position: 'absolute', top: heightPercentageToDP('20%'), left: 0 }}>
				<FlatList
					bounces={false}
					removeClippedSubviews={false}
					style={{ marginBottom: 20, }}
					data={this.props.selctType && this.props.selctType.typeselectedData && this.props.selctType.typeselectedData.logintype == "Student" ? this.menuListData : this.teachermenuList}
					renderItem={rowData => this.renderRow(rowData)}
				/>

			</View>
		);
	}

	render() {
		return (
			<ScrollView>
				<View style={{ height: heightPercentageToDP('100%'), flex: 1 }}>
					{this.renderProfileView()}
					<View style={{ backgroundColor: 'white', height: '100%' }}>
						<View style={{ flexDirection: 'row', height: '100%' }}>
							<View style={{ width: '20%', backgroundColor: 'white', }}>
							</View>
							<View style={{ width: '80%', backgroundColor: loginheaderColor, }}>
							</View>
						</View>
					</View>
					{this.renderListView()}

					<Text onPress={() => NavigationService.navigate("ConditionScreen", { screen: 'condition' })} style={{ position: 'absolute', bottom: 40, right: 50, alignSelf: 'center', fontSize: 10, color: 'white' }}>Terms & conditions | <Text onPress={() => NavigationService.navigate('ConditionScreen', { screen: 'privacy' })}>Privacy Policy</Text></Text>

				</View>
			</ScrollView>
		);
	}
	renderProfileView() {
		return (

			<View
				style={{
					height: heightPercentageToDP('20%'),
					backgroundColor: appheadertextColor,
					justifyContent: 'center'

				}}
			>
				<View
					style={{ flexDirection: 'row', }}>
					<TouchableOpacity
						onPress={() => {
							this.props.navigation.navigate('ProfileScreen');
						}}
						style={styles.circle}>
						{this.state.imageurl != '' ? <Image source={{ uri: this.state.imageurl }} style={{
							flex: 1, height: 80, width: 80, borderRadius: 50,
							alignSelf: 'center',
						}}></Image> : (this.props.user.profData && this.props.user.profData.data && this.props.user.profData.data.gender === "MALE") ? <Image style={{ width: 80, height: 80 }} source={images.male} /> : <Image style={{ width: 80, height: 80 }} source={images.female} />}
						{/* {this.state.image && (
							
						)} */}

					</TouchableOpacity>
					{<Text style={{
						color: 'white', fontSize: 15,
						marginTop: 6, alignSelf: 'center', width: '60%', marginLeft: 10
					}}>{this.state.name}</Text>}

					<TouchableOpacity style={{ position: 'relative', left: 10, }} onPress={() => { NavigationService.closeDrawerr() }}>
						<Image style={{ width: 25, height: 25 }} source={images.drawerclose} resizeMode={'contain'} />
					</TouchableOpacity>
				</View>

			</View>


		);
	}
}

const styles = StyleSheet.create({
	circle: {
		height: 85,
		width: 85,
		borderRadius: 50,
		borderWidth: 3,
		borderColor: `${COLORS.MAINCOLOR.BLUE}`,
		alignItems: 'center',
		justifyContent: 'center',
		backgroundColor: '#fff',
		marginLeft: 20
	},
	menuContainer: {
		marginTop: 30
	},
	itemStyle: {
		backgroundColor: `${COLORS.MAINCOLOR.BLUE}`
	}
});

const mapStateToProps = state => ({
	selctType: state.selctType,
	user: state.prof,
	prof: state.prof,
	imagewithoutloopData:state.dash.imagewithoutloopData
});

const mapDispatchToProps = {
	UserLogout, imageWithoutLoopLoad,profile
};

export default connect(mapStateToProps, mapDispatchToProps)(SlideMenu);
