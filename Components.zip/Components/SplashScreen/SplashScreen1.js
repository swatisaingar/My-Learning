import React, { useState, useEffect,Component } from 'react'
import { Text, View, Image, ActivityIndicator } from 'react-native'
import styles from './SplashScreenStyle'
import NavigationService from '../../Services/NavigationService'
import images from '../../util/img';
import SplashScreen from 'react-native-splash-screen'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { connect } from 'react-redux'

import { saveLogin ,checkSelectedType} from '../../actions';

class SplashScreen1 extends Component {
  constructor(props) {
    super(props);
    this.state = {
     loading:false
    }
  }
  async componentDidMount() {
    const loginUser = await AsyncStorage.getItem('loginMessage');
    const UserType = await AsyncStorage.getItem('UserType');
    // console.log('resposne for login calleddd', this.props.selctType ,UserType, loginUser)
   
    // console.log('login usersss',token, userId)
    SplashScreen.hide();
    setTimeout(()=>{
      if(loginUser!=null)
    {
      const token = JSON.parse(loginUser).id_token
      const userId = JSON.parse(loginUser).userId
  
      this.props.saveLogin(token, userId)
      this.props.checkSelectedType(UserType)
     NavigationService.navigateAndReset('Home');
    }
    else
    {
      NavigationService.navigateAndReset('StudentTeacherSelectScreen');

    }
      this.setState({loading: true})}, 1500);
  }
  render() {
    return (
      <View style={styles.container}>
        <Image style={styles.loginimage} resizeMode={'contain'} source={images.updatedlogo}>
        </Image>

      </View>
    )
  }
}

const mapStateToProps = state => ({
  user: state.auth,
  selctType: state.selctType
});

const mapDispatchToProps = {
  saveLogin,checkSelectedType
};

export default connect(mapStateToProps,mapDispatchToProps)(SplashScreen1)
