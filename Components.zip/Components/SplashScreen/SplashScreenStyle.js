import { StyleSheet } from 'react-native'
import {ScaledSheet} from 'react-native-size-matters';
export default ScaledSheet.create({
  logo: {
    height: 150,
    width: 150,
    alignSelf: 'center',
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'white',
    //   paddingTop: ( Platform.OS === 'ios' ) ? 20 : 0,
  },
  imageStyle: {

    width: '100%',
    height: '100%',
  },
  loginimage:
  {
    height: "100%", width: "50%",alignSelf:'center'
    
  },

  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:'rgba(0, 0, 0, .7)',

  },
})
