import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View, TouchableOpacity, Image, FlatList, StatusBar, ActivityIndicator
} from 'react-native';
import { COLORS, widthPercentageToDP } from '../../constants/styles'
import images from '../../util/img';
import { appbluebtnColor, loginheaderColor, apppinkColor, appheadertextColor } from '../../util/AppConstants';
import { fetchSubsRecord, CancelSubsRecord, moveToCart, imageLoad, IsImageEmpty } from '../../actions';
import { connect } from 'react-redux';
import moment from 'moment';
import NavigationService from '../../Services/NavigationService';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { baseURL } from '../../util/AppConstants';

class ActiveSubsScreen extends React.Component {
  constructor(props) {

    super(props);
    this.state = {
      image: '',
      courseName: '',
      teacherFirstName: '',
      teacherQualification: '',
      courseStartDate: '',
      courseDays: '',
      coursedayStatus: '',
      status: '',
      duration: '',
      paymentMode: '',
      subscriptionMode: '',
      subscriptionExpiry: '',
      subscriptionOn: '',
      payment: '',
      startTime: '',
      endTime: '',
      courseId: '',
      id: '',
      isLoading: false,
      imageData: {},
      imageLoading: true,
      year:new Date().getFullYear(),
      month:new Date().getMonth(),
      nextmonth:new Date().getMonth() + 1
    }

  }

  finalData = [];
  async componentDidMount() {
    let AuthToken = await AsyncStorage.getItem('id_token');
    var arr = [];
    StatusBar.setHidden(false);
    this.setState({ isLoading: true })
    this.props.fetchSubsRecord();

    this.props.IsImageEmpty();
    this?.props?.subscriptionData?.data?.map((item) => {
      let id = item.course_id.imageId;
      fetch(`${baseURL}file-blobs/getImage/${id}`, {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${AuthToken}`,
        }
      }).then(data => {
        return data.json()
      }).then(resposne => {
        // console.log('image response',resposne)
        let imageData = this.state.imageData || {};
        imageData[resposne.data.id] = resposne.data;
        this.setState(imageData);
        this.setState({ imageLoading: false });
      }).
        catch((error) => {
          console.log("#error", error);
        })
    })
  }

  cancelValue = (indexvalue) => {
    this.props.subscriptionData.data.map((item,index)=>{
      if(indexvalue === index){
        this.props.CancelSubsRecord(item.course_id.id)
      }
    
    })
  }



  checkcartValue = () => {
    this.props.moveToCart(this.props.subscriptionData && this.props.subscriptionData.data[0].course_id.id, this.props.subscriptionData && this.props.subscriptionData.data[0].amount, 10, { "id": 1, "name": "MONTHLY", "status": true, "remarks": null }, { "id": 1, "name": "ONLINE", "status": true, "remarks": null });

    if (this.props.moveToCartResponse && this.props.moveToCartResponse.data === "Moved to Cart") {
      NavigationService.navigate('PayDetailScreen', { courseId: this.state.courseId })
    }
  }

  static navigationOptions = ({ navigation }) => {
    return {
      headerShown: false,
      tabBarLabel: 'Active',

    }
  };

  // renderUpcomingImage = (imageId) => {
  //   return this.finalData && this.finalData.length > 0 && this.finalData.map(i => {
  //     if (i.course_id.imageId === imageId) {
  //       console.log('image callled', i.imageData);
  //       return (
  //         <Image
  //           source={{ isStatic: true, uri: `data:image/jpeg;base64,${i.imageData}` }}
  //           style={{
  //             width: widthPercentageToDP('22%'),
  //             borderTopLeftRadius: 10,
  //             borderTopRightRadius: 10,
  //           }}
  //           PlaceholderContent={<ActivityIndicator size='large' />} />
  //       )
  //     }

  //   })
  // }


  componentDidUpdate(prevProps) {
    if (this.props.subscriptionData != null) {
      if (this.props.subscriptionData != prevProps.subscriptionData) {
        if (this.props.subscriptionData.data && this.props.subscriptionData.data != null) {
         
        }
      }
    }
    console.log('cancel subscription data',this.props.cancelSubscriptionData)
    if(prevProps.cancelSubscriptionData != this.props.cancelSubscriptionData && this.props.cancelSubscriptionData != null){
      if(this.props.cancelSubscriptionData.data === "no active courses found"){
        this.props.fetchSubsRecord();
      }
    }
  }

  render() {

    var storedValue = 0;
    for (let i = 0; i < this.props.ratingData && this.props.ratingData.data.length; i++) {
      storedValue = storedValue + this.props.ratingData.data[i].rating;
    }
    var Avgrating = storedValue / this.props.ratingData && this.props.ratingData.totalCount

    let stars = [];
    let path = '';
    let integer_part = Math.trunc(Avgrating);
    let decimat_part = Avgrating - integer_part;
    let total_star_count = 0;
    for (let i = 1; i <= Avgrating; i++) {
      path = require('../../images/star.png');
      stars.push((<Image style={{
        width: 15,
        height: 15, marginRight: 1, marginLeft: 1
      }} source={path} />));
      total_star_count++;
    }
    if (decimat_part != 0) {
      path = require('../../images/star-half.png');
      stars.push((<Image style={{
        width: 20,
        height: 20, marginRight: 1, marginLeft: 1, position: 'relative', top: -2
      }} source={path} />));
      total_star_count++;
    }
    if (total_star_count != 5) {
      path = require('../../images/unfilled-star.png');
      for (let i = total_star_count; i < 5; i++) {
        stars.push((<Image style={{
          width: 15,
          height: 15, marginRight: 1, marginLeft: 1
        }} source={path} />));
      }
    }

    return (

      <View>
        { !this.props.subscriptionData ? <View style={{ alignItems: 'center', justifyContent: 'center', flex: 1, margin: 20 }}>
          <ActivityIndicator />
        </View> :
          <>
            {/* {console.log('this.props.subscriptionData', this.props.subscriptionData.data)} */}
            {this.props.subscriptionData.totalCount !== 0 ? <FlatList
              data={this.props.subscriptionData && this.props.subscriptionData.data}
              nestedScrollEnabled={true}

              onEndReached={this._handleLoadMore}
              onEndReachedThreshold={0.01}
              renderItem={({ item,index }) =>

                <View>
                  {console.log('item value for',item)}
                  <View style={{

                    paddingRight: 5,
                    paddingLeft: 5,
                    marginTop: 10,
                    justifyContent: 'center', alignItems: 'center',

                  }}>

                    {(item.courseStatus == 2
                      || item.courseStatus == 1) && <View style={styles.labelContainer}>

                        <View style={{ flexDirection: 'row' }}>

                          {!this.state.imageLoading ? <Image

                            source={{ isStatic: true, uri: `data:image/jpeg;base64,${this.state.imageData[item.course_id.imageId] && this.state.imageData[item.course_id.imageId].content}` }}
                            style={{
                              width: widthPercentageToDP('22%'),
                              borderRadius: 10,

                            }}
                          ></Image> :
                            <View style={{
                              width: widthPercentageToDP('22%'),
                              borderRadius: 10,
                            }}>
                              <ActivityIndicator size='large' style={{ marginTop: 10 }} />
                            </View>}

                          <View style={{ width: '80%' }}>
                            <View style={{ flexDirection: 'row', marginTop: 5, justifyContent: 'space-between', width: '100%' }}>
                              <Text style={{ fontSize: 12, marginLeft: 10 }}>{item && item.course_id && item.course_id.name} Class-{item && item.course_id && item.course_id.standard && item.course_id.standard.class}</Text>
                              <View style={{ flexDirection: 'row', marginRight: 20 }}>
                                {stars}
                              </View>

                            </View>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20 }}>
                              <View>
                                <Text style={{ fontStyle: 'italic', marginLeft: 10, fontSize: 12 }}>By {item && item.teacherDetails && item.teacherDetails.firstName} {' '}{item && item.teacherDetails && item.teacherDetails.lastName}{' '}{item && item.teacherDetails && item.teacherDetails.experienceInYear}yr</Text>
                                <Text style={{ marginLeft: 10, fontSize: 12 }}>{item && item.teacherDetails && item.teacherDetails.qualification && item.teacherDetails.qualification[0] && item.teacherDetails.qualification[0].qualification}</Text>
                              </View>
                              <Image
                                resizeMode='contain'
                                source={images.confirmation}
                                style={{
                                  width: 16,
                                  height: 16, alignSelf: 'center'
                                }}
                              ></Image>
                            </View>
                            <View style={{ width: '90%', height: 1, backgroundColor: loginheaderColor, alignSelf: 'center', marginTop: 5 }}></View>

                            <Text style={{ fontSize: 13, marginLeft: 10, fontSize: 10, marginTop: 10 }}>TIMING (START FROM {item && item.course_id && item.course_id.createdDate && moment(item && item.course_id && item.course_id.createdDate).format('DD-MM-YYYY')})</Text>
                            <View style={{ flexDirection: 'row', marginRight: 10, justifyContent: 'space-between' }}>
                              <Text style={{ fontSize: 13, marginLeft: 10, color: loginheaderColor }}>{moment(item.course_id.startDate).format('hh:mm A')} to {moment(item.course_id.endDate).format('hh:mm A')}</Text>
                              <Text style={{ fontSize: 13, marginLeft: 5, fontSize: 10, color: item.course_id.courseDays.map((item) => item.status === true) ? loginheaderColor : 'black' }}>{item.course_id.courseDays.map((item) => item.day.substring(0, 1))}</Text>
                            </View>

                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 5 }}>
                              <View>
                                <Text style={{ fontSize: 10 }}>COURSE STATUS</Text>
                                <Text style={{ color: loginheaderColor }}>{item.course_id.courseStatus === 1 ? 'OPEN' : 'REGISTER'}</Text>
                              </View>
                              <View style={{ right: 20 }}>
                                <Text style={{ fontSize: 10 }}>DURATION</Text>
                                <Text style={{ color: loginheaderColor }}>{this.state.duration}</Text>
                              </View>
                            </View>


                            <View style={{ flexDirection: 'row', marginLeft: 10, justifyContent: 'space-between', marginTop: 5, marginBottom: 10 }}>
                              <Text style={{ color: apppinkColor, fontSize: 10 }}>{item && item.subscriptionModeId && item.subscriptionModeId.subscriptionModeId && item.subscriptionModeId.subscriptionModeId.name}</Text>
                              <Text style={{ fontSize: 10, marginRight: 20 }}>₹{' '}{item.amount}</Text>


                            </View>
                            <TouchableOpacity style={{ left: 160 }} onPress={() => this.cancelValue(index)}>
                              <Text style={{ fontWeight: 'bold', color: appbluebtnColor, fontSize: 12 }}>Cancel Subscription</Text>
                            </TouchableOpacity>
                          </View>


                        </View>
                        {/* {console.log('hasdv cashkdb vvdvvv',new Date('2021-03-25') ,new Date() , new Date('2021-03-5'))} */}
                        { new Date('2021-03-25') > new Date() && new Date() < new Date('2021-03-5') ?
                          <View style={{ elevation: 5, backgroundColor: 'white', marginLeft: 20, marginRight: 20, marginBottom: 10, borderRadius: 20, marginTop: 10 }}>
                            <View style={{ flexDirection: 'row', paddingTop: 5, paddingBottom: 5 }}>
                              <Image style={{ width: 30, height: 30, marginLeft: 20, alignSelf: 'center' }} source={images.infoorng} />
                              <View style={{ width: '70%' }}>
                                <Text style={{ fontWeight: 'bold', color: appheadertextColor, fontSize: 10, marginLeft: 10 }}>Payment Due Rs. 1000. Click Paid once you done the payment</Text>
                              </View>
                              <Text style={{ fontWeight: 'bold', color: appbluebtnColor, fontSize: 12 }} onPress={() =>
                                // NavigationService.navigate('PayPlanScreen',{courseId:this.state.courseId})
                                this.checkcartValue()}>Pay</Text>
                            </View>
                          </View>
                          : null}

                      </View>}
                  </View>

                </View>
              }
            /> : <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', margin: 20 }}>
                <Text>No detail found for this Course</Text>
              </View>}
          </>}
          {/* {this.props.subscriptionData && this.props.subscriptionData.data.map((item)=>item.courseStatus !== 1 && item.courseStatus !== 2) && <View><Text style={{alignSelf:'center'}}>Courses is not Active. </Text></View>} */}
      </View>



    );
  }
}

const mapStateToProps = state => ({
  subscriptionData: state.dash.subscriptionData,
  cancelSubscriptionData: state.dash.cancelSubscriptionData,
  moveToCartResponse: state.dash.addToCartData,
  ratingData: state.dash.ratingData,
  imageData: state.dash.imageData
});

const mapDispatchToProps = {
  fetchSubsRecord, CancelSubsRecord, moveToCart, imageLoad, IsImageEmpty
};

export default connect(mapStateToProps, mapDispatchToProps)(ActiveSubsScreen)

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 40,
    marginTop: 10
  },
  labelContainer: {


    justifyContent: 'center', alignContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: '98%', borderRadius: 10,

  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 5,
    marginTop: 5
  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 15,
    paddingRight: 15,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: '#fff',

    marginBottom: 10
  },
  Buttontext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 12
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  }
})
