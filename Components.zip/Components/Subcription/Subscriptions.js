import React, { Component } from 'react'
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList, Alert, TextInput, TouchableWithoutFeedback, Image, ImageBackground, Dimensions
} from 'react-native';
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';
import Icon1 from 'react-native-vector-icons/FontAwesome';



import { fetchReplyList, sendOA, fetchVendors } from '../../actions';
import NavigationService from '../../Services/NavigationService'
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import ActiveSubsScreen from './ActiveSubsScreen';
import DormantSubsScreen from './DormantSubsScreen';
import CompletedSubsScreen from './CompletedSubsScreen';

import { COLORS, widthPercentageToDP } from '../../constants/styles'
import { connect } from 'react-redux';
import Moment from 'moment';
import Loader from '../../Common/Loader';
import { heightPercentageToDP } from 'react-native-responsive-screen';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Modal from "react-native-modal";
import ImagePicker from 'react-native-image-crop-picker';
import { ThemeConsumer } from 'styled-components';
import Swiper from 'react-native-swiper';
import { BASEURLIMAGE, loginheaderColor, appgrayColor, appbluebtnColor, appheadertextColor } from '../../util/AppConstants';
import SoundPlayer from 'react-native-sound-player'
import Sound from 'react-native-sound';
import Styles from '../../uistyles/Styles';
import images from '../../util/img';

import { client } from "../../util/serviceConfig";
import { useDispatch, useSelector } from 'react-redux'
import { createStackNavigator } from 'react-navigation-stack';

import { createAppContainer } from 'react-navigation'

import { createMaterialTopTabNavigator } from 'react-navigation-tabs';
class Subscriptions extends Component {

  constructor(props) {
    super(props);
    this.state = {

    }
    params = this.props.navigation.state.params;
  }

  async componentDidMount() {



  }







  render() {


    const Stylelist = createAppContainer(createStackNavigator({
      TabDrawerScreen1: {
        screen:
          createMaterialTopTabNavigator({
            ActiveSubsScreen: { screen: ActiveSubsScreen },
            DormantSubsScreen: { screen: DormantSubsScreen },
            CompletedSubsScreen: { screen: CompletedSubsScreen },











          },


            {

              tabBarPosition: 'top',
              swipeEnabled: true,
              tabBarOptions: {
                scrollEnabled: true,
                activeTintColor: loginheaderColor,
                inactiveTintColor: appheadertextColor,
                indicatorStyle: {
                  opacity: 1,
                  backgroundColor: loginheaderColor

                },
                style:
                {
                  backgroundColor: 'white',
                },

                showIcon: false,
                lazy: true,
                upperCaseLabel: false,
                labelStyle: {
                  fontSize: 14,
                  fontFamily: "Helvetica",


                },

                tabStyle: { height: 50, width: Dimensions.get('window').width / 3 }
              }
            }
          ),
      },
      //  SliderScreen: { screen: SliderScreen},
      // VideoPlayScreen: { screen: VideoPlayScreen},

    },

      { headerMode: 'none' }
    ));



    return (


      /*  <View style={{backgroundColor:'white',flex:1}}>
 <View style={{flexDirection:'row',backgroundColor:'white',height:60,justifyContent:'space-between',elevation:10}}>
 <View  style={{ marginTop:15 }} >
             <TouchableOpacity
               onPress={() => {
                 NavigationService.openDrawerr();
 
               }}
             >
               <Image style={{ width: 20, height: 20,marginLeft:10 }} source={images.menu}  />
             </TouchableOpacity>
           </View>
           <Image style={{ width: 90, height: 25,marginTop:10 }} source={images.logo} resizeMode={'contain'} />
 
           <Icon1 style={{marginTop:15,alignContent:'flex-end',marginRight:10 }} name="bell-o" size={20} color={'black'} />
 
           </View>       
      
     
         </View > */
      <View style={{ backgroundColor: 'white', flex: 1 }}>
        <View style={{ flexDirection: 'row', backgroundColor: 'white', height: 50, justifyContent: 'space-between', }}>
          <View style={{ marginTop: 15 }} >
            <TouchableOpacity
              onPress={() => {
                //	NavigationService.openDrawerr();
                this.props.navigation.goBack();
              }}
            >
              <Icon1 style={{ marginLeft: 10 }} name="angle-left" size={25} color="black" />

              {/* <Image style={{ width: 20, height: 20,marginLeft:10 }} source={images.menu}  /> */}
            </TouchableOpacity>
          </View>
          <Image style={{ width: 90, height: 25, marginTop: 15 }} source={images.logo} resizeMode={'contain'} />

          <Icon1 style={{ marginTop: 15, alignContent: 'flex-end', marginRight: 10 }} name="bell-o" size={20} color={'black'} />

        </View>
        <Stylelist /></View >

    )
  }



}

const mapStateToProps = state => ({
  user: state.auth,
  reply: state.reply,
  sendoa: state.sendoa,
  vendors: state.vendors
});
const mapDispatchToProps = {
  fetchReplyList, sendOA, fetchVendors
};

export default connect(mapStateToProps, mapDispatchToProps)(Subscriptions);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    marginBottom: 50,
    marginTop: 10,

  },
  statusContainer: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    backgroundColor: `${COLORS.BLACK.LIGHTISGREY}`,
    width: widthPercentageToDP('95%')
  },
  topHead: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 10,
    marginBottom: 10,
    marginTop: 5


  },
  topHead2: {

    flexDirection: 'row',
    flexWrap: 'wrap',
    // justifyContent: 'space-between',
    paddingRight: 10,
    paddingLeft: 10,

  },
  ButtonContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `white`,
    padding: 10,
    marginTop: 10,

    backgroundColor: 'red',

  },
  ViewDetailContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `red`,
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    backgroundColor: 'red',
    marginTop: 10,
    marginBottom: 10,

  },
  showmoreContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.BLUE}`,
    padding: 5,

    backgroundColor: 'white',


  },
  addcartContainer: {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.DARKBLUE}`,
    padding: 5,
    marginTop: 5,

    backgroundColor: `${COLORS.MAINCOLOR.DARKBLUE}`,


  },
  backContainer:
  {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.DARKBLUE}`,
    padding: 10,
    marginTop: 10,

    backgroundColor: `${COLORS.MAINCOLOR.DARKBLUE}`,


  },
  showmoreclickedContainer:
  {
    // flex: .8,
    borderWidth: 1,
    borderColor: `${COLORS.MAINCOLOR.DARKBLUE}`,
    padding: 5,


    backgroundColor: `${COLORS.MAINCOLOR.DARKBLUE}`,


  },
  Buttontext: {
    color: 'white',
    fontSize: 12,
    alignSelf: 'center'
  },
  showmoreclickedtext: {
    color: 'white',
    fontSize: 10,
    alignSelf: 'center'
  },
  BottomButtontext: {
    color: `white`,
    fontSize: 12,
    alignSelf: 'center'
  },
  showmoretext: {
    color: `${COLORS.MAINCOLOR.BLUE}`,
    fontSize: 10,
    alignSelf: 'center'
  },
  addcarttext: {
    color: 'white',
    fontSize: 10,
    alignSelf: 'center'
  },
  grossText: {

    flexDirection: 'row',

    width: widthPercentageToDP('50%'),

  },
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, .7)',

  },
  MyAccount2: {
    flex: 1,
    flexDirection: 'column'
  },
  MyAccountItems: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignContent: 'center',
    justifyContent: 'space-around',
    paddingLeft: 15,
    paddingTop: 10
  },
  text: {
    fontSize: 10,
    fontWeight: "bold",
    color: `${COLORS.MAINCOLOR.DARKBLUE}`,
  },
  selectoptionbutton: {
    margin: 10,
    height: 40,
    alignSelf: 'center',
    padding: 10,
    width: 200,
    backgroundColor: '#237D99',
    borderRadius: 10


  },
})
